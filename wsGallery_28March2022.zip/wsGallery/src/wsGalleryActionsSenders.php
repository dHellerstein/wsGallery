<?php
session_start() ;
ob_start();

$nowtime=time();
$rootdir=$_SERVER['DOCUMENT_ROOT'] ;
//$curDir=getcwd();
$wsMainDir=$_SESSION['wsGallery_mainDir'];
// functions to send files to client (wsGallery)

require_once($wsMainDir.'/libs/php/wsurvey.getJson.php');

require_once($wsMainDir.'/src/wsGalleryLibUtils.php');

$nowtime=time();
$rootdir=$_SERVER['DOCUMENT_ROOT'] ;
//$curDir=getcwd();
//$wsMainDir=$_SESSION['wsGallery_mainDir'];



  $thmHeaders=['snapshot'=>'snap_','tSmall'=>'thm40_','tMedium'=>'thm66_','tBig'=>'thm90_',
               'snap'=>'snap_','thm40'=>'thm40_','thm66'=>'thm66_','thm90'=>'thm90_',  ];        // custom and full are NOT cached
  $todo=extractRequestVar('todo','');


//:::::::::::::
// return a file, no modifications. Can find files outside of www path
if ($todo=='sendFile' ){
   ob_end_clean();
  $afile=extractRequestVar('file','');
  $atree=extractRequestVar('tree',$_SESSION['wsGallery_currentTree'] );
  $allInfo=returnSelector('~'.$afile,$atree);
  $useFile=$allInfo['realFileName'];
  if (!is_file($useFile)) {
      header($_SERVER["SERVER_PROTOCOL"] . " 404 Not Found"  );
      exit;
  }

  $mimeType=extractRequestVar('mime','');
  if ($mimeType=='') {
     $aext=pathinfo($useFile,PATHINFO_EXTENSION);
     $mimeType=extToMimetype($aext);
  }
  $jlen=@filesize($useFile);
   header('Content-Type: '.$mimeType);
   header( 'Content-Length: ' . $jlen );
   header("x-wsGallery: For  $afile  in tree $atree");
   readfile($useFile);                      // won't happen if noCache  (getResizedImage from cache)
   exit;
}


if ($todo=='getResizedImage' ){
   ob_end_clean();

  $ahow=extractRequestVar('how','specs');    // jan 2022: possible values are snapshot, custom, full (but might change in the future
  $afile=extractRequestVar('file','');
  $atree=extractRequestVar('tree','' );
  $stdWwwDir=extractRequestVar('stdWwwDir','0' );
  $isNotImg=extractRequestVar('isNotImg','0');

  $onTheFly=$_SESSION['wsGallery_onTheFlySnapshots'];

  $noCache=$_SESSION['wsGallery_noCache'] ;

  $allInfo=returnSelector('~'.$afile,$atree);

  $rootDir=$allInfo['rootDir'];
  $cacheDir=$allInfo['cacheDir'];
  $useFile=$allInfo['realFileName'];
  $fileName=$allInfo['relSelFile'];
  $fileNameName=$allInfo['relSelFileName'];
  $fileNameExt=$allInfo['relSelFileExt'];

  if ($ahow=='full')  { // just send the original file
        imageSender($useFile,'Original file. ');
        exit;
  }

//    https://stackoverflow.com/questions/4494704/return-the-contents-of-an-image-in-php-file

// does this thumbnail, or snapshot, exist in a cache; and the cache is enabled
  if ($cacheDir!='' && $noCache!=1)  {                         // cache dir exists for the   directory  hat the file is in
      if (array_key_exists($ahow,$thmHeaders)) {     // this resize might have a  resize that is cached
         $zz1=$thmHeaders[$ahow].$fileNameName.'_'.$fileNameExt.'.jpg';
         $afileC=$cacheDir.'/'.$zz1 ; // $thmHeaders incorporates trailing _, note use of _origExt (all cached files are .jpg)
         if (is_file($afileC)) {                          // cached thumbnail (or snapshot) exists -- use it
              $sizeStuff=@getimagesize($afileC );
              if (array_key_exists('mime',$sizeStuff)) {              // if problems, do not use cache
                 $width=$sizeStuff[0]; $height=$sizeStuff[1];
                 $mime=strtolower($sizeStuff['mime']);
                 header('Content-Type: image/jpeg');      // even if original was not
                 header( 'Content-Length: ' . filesize( $afileC ) );
                 header("x-wsGallery: $ahow cacheSize w=$width,h=$height");
                 readfile($afileC);                      // won't happen if noCache  (getResizedImage from cache)
                 exit;
              }         // getimagesize worked
           }            // file exists
        }                  // in thmheaderws
    }                    // this extension is possibly  cached


// no cached version  of this exists.

// put non-image stuff since it is feasible that cached versions of non-image files exist (created manually)

    if ($isNotImg!='' && $isNotImg!='0')  { // send image as is, or can't resize (since it is nto an image file supported by php)
        notImgSender($useFile,'Non-image file ')  ;     // not a cached file
        exit;
    }

// if here, an image file -- if no on the fly, just send original
    if ($onTheFly==0)    {        // if no on the fly, return full image  -- do not attempt to cache
         $_SESSION['wsGallery_errors'][]='getResizedImage: onthefly not enabled, sending full file. ';
         imageSender($useFile,'On-the-fly not enabled, sending full file. ');
         exit; // no cache resolution
   }

// create a resized image, and possiblye save to cache.

// preset sizes?

    if ($ahow=='snapshot' || $ahow=='snap' ) {
      $newWidth=640;
      $newHeight=480;
      $prefix='snap_';

  } else if ($ahow=='tSmall' || $ahow=='thm40' ) {  // these  thm_xx next are rarely used (use dirCache created), but might be in the future
      $newWidth=40;
      $newHeight=40;
      $prefix='thm40_';
  } else if ($ahow=='tMedium' || $ahow=='thm66' ) {
      $newWidth=66;
      $newHeight=66;
      $prefix='thm66_';

  } else if ($ahow=='tBig' || $ahow=='thm90' ) {
      $newWidth=90;
      $newHeight=90;
      $prefix='thm90_';

  } else if ($ahow=='tBigger' || $ahow=='thm120' ) {
      $newWidth=120;
      $newHeight=120;
      $prefix='thm120_';

  } else {         // custom size, so use specs  -- and keep in native format
     $noCache=1;         // redundant if   $_SESSION['wsGallery_noCache']=-1
     $newWidth=extractRequestVar('width',640);  // snapshot
     $newHeight=extractRequestVar('height',480);

  }

  $quality=extractRequestVar('quality',55);       // useful for jpg



// If caching not possible or disallowed, send an onthefly creation. If no onthefly, send origioal
  if ($cacheDir=='' || $noCache==1 )  { // no cache dir, or a non-cached size (custom size)
    if ($onTheFly==0)    {        // if no on the fly, return full image
        imageSender($useFile,'On-the-fly not enabled, sending full file. ');
    } else {   // onthe fly allowed, so do the resizing and send it (but do not cache!)
        imageResizer($useFile,$newWidth,$newHeight,$quality,null,0) ;  // this writes header and image content to output, and exits  -- Nothing saved to cache. Resize into original type (jpg, gif, etc)
    }
    exit; // no cache resolution
  }

//  caching permitted -- so resize and send image, ANd save to cache
  $relSelFile=$allInfo['relSelFile'];
  $zzName=$allInfo['relSelFileName'];
  $zzExt=$allInfo['relSelFileExt'];
  $saveToFile=$cacheDir.'/'.$prefix.$zzName.'_'.$zzExt.'.jpg';
  $fileLen=imageResizerFile($useFile,$newWidth,$newHeight,$quality,$saveToFile,1) ;  // if here caching allowed. this writes header and image content to output, saves a jpg file to cache
  if ($fileLen===false) {
        header($_SERVER["SERVER_PROTOCOL"] . " 404 Not Found"  );
        header("x-wsGallery: Error in imageSender: unable to save (and send) file $saveToFile" );
         exit;
  }            // else in cache for future use.
  header("x-wsGallery: Creating (and saving) snapshot image" );
  imageSender($saveToFile,'Creating (and caching) snapshot image of '.$saveToFile.' , '.$relSelFile)  ; // and send the newly created file in the cache
  exit;


}

// ::::
// return a text file (plain or html) (used in an <iframe
if ($todo=='sendText') {

     $afile=extractRequestVar('file','');
     $amime=extractRequestVar('mime','text/plain');
     $treeName=extractRequestVar('tree',$_SESSION['wsGallery_currentTree']);
     $pathStuff=returnSelector('~'.$afile,$treeName);

    $useFile=$pathStuff['realFileName'] ;
    if ($useFile===false || $useFile=='') {
          header($_SERVER["SERVER_PROTOCOL"] . " 404 Not Found"  );
          header("x-wsGallery: Error in sendText: unable to find $afile" );
          exit;
    }

     $arf=file_get_contents($useFile);       // a text file to send
     $arf='<pre>'.htmlspecialchars($arf).'</pre>';
        ob_end_clean();
        echo $arf ;
        exit;
}

