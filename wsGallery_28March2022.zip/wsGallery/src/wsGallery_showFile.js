//===============================
// show an image or other kind of file (in a viewer box, or externally)
// for wsGallery

// 11 JAN 2020 FIX THIS  :  add next prior (slideshow) buttons to the rotating and tableau layouts (by themselves)
//  (also note on current image)
//===============================
//
// display chosen file (often an image)
// image is typically something that <img ...> is used to show
// but  if not an image (if an otherExts) it can be shown via <object> and <embed>, or <video>, or <iframe>
// what is used depends on the values of imageExts and otherExts (specified in wsGalleryActionsSenders.php

function showThisFile(athis,getSnapArg,iShrinkArg )    {

  var ethis=wsurvey.argJquery(athis) ;

  var adims,dd=' ',aDesc='', doSay=' ',theImg,hrefUse,doSayt='',custW=1024,custH=768;

  var ef,atree, getFullSnapCustom, iShrinkToFit;

 var screenLayout=  $(document).data('screenLayout' );  // default is dual viewer
 var screenLayout_dual= $(document).data('screenLayout_dual');   // default dual viewer is larger file list

// shortinfo used in external viewer (when clicked on fileList page (not on viewer)
// these "in viewer" showexternals use a short message (uri encoded)
// gotinfo is displayed in the viewer (if info button enabled)

  var shortInfo='',showExternalButton='',gotInfo='',href='';  // set in showThisImage_GetInfo

  href=ethis.attr('file');
  var imageName=href.replace(/^.*[\\\/]/, '')    ;   //https://stackoverflow.com/questions/6365858/use-jquery-to-get-the-file-inputs-selected-filename-without-the-path
  let justName= href.replace(/^.*[\\\/]/, '')    ;     // get the stuff after / (i.e.; jpeg in image/jpeg

  atree=ethis.wsurvey_attr('treeName,tree',''); // feb 2022: got to have tree name specified!
  if (atree=='') {                   // using currentTree is deprecated  (feb 2022)
      alert('showThisFile error: treename not specified ');
      return 0;
  }
  var whichLayout=0;
  var whichBox=ethis.wsurvey_attr('showin,showBox,whichBox',-1); // -1 means "not spcified) -- usually this is NOT avaialbe (will read from input element on screen


   if (arguments.length>1) {     // snapshot/full/custom specified in call?
       getFullSnapCustom=getSnapArg;
   } else {                 // use input box as derfault, but check for attribute. If not input box, use 1
      let aGetSnap=1;
      let eGetSnapshot=$('#getSnapshotImage');      // display snapshot or original image, or custom size?
      if (eGetSnapshot.length>0) aGetSnap= eGetSnapshot.val();
      getFullSnapCustom=ethis.wsurvey_attr('getSnap',aGetSnap);
   }

   if (arguments.length>2) {     // shrink to fit specified in call?
       iShrinkToFit=iShrinkArg;
   } else {                 // use input box as derfault, but check for attribute. If not input box, use 1
      let aShrink=1;
      let eshrinkToFit=$('#shrinkToFit');
      if (eshrinkToFit.length>0) {
         let qshrinkDisable=eshrinkToFit.prop('disabled');
         if (!qshrinkDisable) aShrink= eshrinkToFit.val(); // default if no attribute (if input button is available)
      }
      iShrinkToFit=ethis.wsurvey_attr('doShrink',aShrink);
   }

  var fileStats= $(document).data('currentFiles_stats');  // database with file statistics

  var efdesc=$('#fileDescriptions');

  var  aFileStats='&empty;';
  if  (typeof(fileStats[justName])!='undefined') {
        aDesc=fileStats[justName]['desc'];
      let adate='<span title="creation date of the file (may not be same as when image was created)">'+fileStats[justName]['date']+'</span>';
      let filesize=fileStats[justName]['size'] ;
       let fs1=filesize/1000; let fs2=fs1.toFixed(0); let fs3=wsurvey.addComma(fs2);
       let fileSizeSay='<span title="file size (in kbytes)">'+fs3+'k</span>';
       var wxh='';
       if  (fileStats[justName]['width']!='')   {
          wxh='<span title="width x height (in pixels)">'+fileStats[justName]['width']+' x ' +  fileStats[justName]['height']+'</span>' ;
       }

       aFileStats =aDesc+'<br><em><tt>'+adate+' '+wxh+ ' : ' +fileSizeSay+'</em>';
  }

  efdesc.html('<tt>'+justName+'</tt>:  '+aFileStats).show();

   var isNotImg=ethis.wsurvey_attr('isNotImg','');
   var stdWwwDir=ethis.wsurvey_attr('stdWwwDir',0) ;    // 1 means can use direct url to full images
   var eLayout=$('#iToggleScreenLayout');
   var aLayout=eLayout.attr('which');  //0 large filelist, 1=expanded viwer 2, 2=largest viewer2 small filelist, 3=rotating

// cleanup some vars  ---- which of the layouts to use

   if (screenLayout==0)   { // not set in attributre of caller
         let in2=$('#iWhichViewer'); // where to view
         whichBox=in2.val();                    // 0=combo,1=viwer1,2=viewer2,3=external
         whichLayout=screenLayout ;
   } else if (screenLayout==1) {
         whichBox=123;       // signal to rotate viewers
         whichLayout=1 ;
  } else if  (screenLayout==2) {
        whichLayout=2 ;
        whichBox='tableau';       // signal to tableau viewers
  } else if  (screenLayout==3) {
         whichLayout=3 ;
         whichBox='single';       // signal to single viewer
  }

//   alert('whichLayout='+whichLayout+', screenlayout_dual '+screenLayout_dual+' ;whichbox '+whichBox);

   var qgetInfo=$('#getImgInfo').val();        // info requeseted?

   let forceFull= (whichLayout==3) ? 1 : 0;
   showThisImage_GetInfo(href,qgetInfo,whichBox,href,atree,isNotImg,stdWwwDir,aDesc,whichLayout,forceFull );    // modifies gotInfo ... internal function mostly used variables defined in this caller: sets showExterna, m defined with var

   if (getFullSnapCustom==3) { // custom size
       custH= $(document).data('customImageHeight');     // set when customSise was selected
       custW= $(document).data('customImageWidth');      //
   }

   if (whichLayout==0 && whichBox==3) {    // in new window?
     var sButtons=$('.buttonSnapshot');    // fix up the which-image-file buttons to highlight most recnet choice
     sButtons.removeClass('thisImgInSnapshot');
     ethis.addClass('thisImgInSnapshot');   // most recently selected image
     showThisImage_external(isNotImg,imageName,stdWwwDir,shortInfo,getFullSnapCustom,href,atree,custW,custH ) ;
     showThisImage_markLastShown(ethis)     ;
     return 1;
   }

   if (whichLayout==0 && whichBox==0) {                 // combo view: view fit in viewer 1, full in viewer 2

      theImg1= showThisImage_Img(isNotImg,stdWwwDir,imageName,'snapBox1',gotInfo,getFullSnapCustom,2,href,atree,custW,custH,showExternalButton,whichBox) ;
     theImg= showThisImage_Img(isNotImg,stdWwwDir,imageName,'snapBox2',gotInfo,getFullSnapCustom,1,href,atree,custW,custH,showExternalButton,whichBox) ;
      var sButtons=$('.buttonSnapshot');    // fix up the which-image-file buttons to highlight most recnet choice
      sButtons.removeClass('thisImgInSnapshot');
      ethis.addClass('thisImgInSnapshot');   // most recently selected image
      wsurvey.flContents.headerView('snapBox1',2) ;
      showThisImage_markLastShown(ethis)     ;
      return 1;
   }

   if (whichLayout==1 ) {    // rotatage betwee viewers 1,2,3
     let rbox=eLayout.attr('whichBox');
     var abox='snapBox'+rbox;
     theImg= showThisImage_Img(isNotImg,stdWwwDir,imageName,abox,gotInfo,getFullSnapCustom,iShrinkToFit,href,atree,custW,custH,showExternalButton,whichBox) ;
     var sButtons=$('.buttonSnapshot');    // fix up the which-image-file buttons to highlight most recnet choice
     sButtons.removeClass('thisImgInSnapshot');
     ethis.addClass('thisImgInSnapshot');   // most recently selected image
     showThisImage_markLastShown(ethis)     ;
     rbox++;
     if (rbox>3) rbox=1;
     eLayout.attr('whichBox',rbox);
     return 1;
   }

   if (whichLayout==2) {    // tableau
     whichBox='tableau'
     var abox='tableau';
     theImg= showThisImage_Img(isNotImg,stdWwwDir,imageName,abox,gotInfo,getFullSnapCustom,iShrinkToFit,href,atree,custW,custH,showExternalButton,whichBox) ;
     var sButtons=$('.buttonSnapshot');    // fix up the which-image-file buttons to highlight most recnet choice
     sButtons.removeClass('thisImgInSnapshot');
     ethis.addClass('thisImgInSnapshot');   // most recently selected image
     showThisImage_markLastShown(ethis)     ;
     return 1;
   }

   if (whichLayout==3) {    // singleImage
     var sButtons=$('.buttonSnapshot');    // fix up the which-image-file buttons to highlight most recnet choice
     sButtons.removeClass('thisImgInSnapshot');
     ethis.addClass('thisImgInSnapshot');   // most recently selected image
     whichBox='singleImage'
     abox='singleImage';
     theImg= showThisImage_Img(isNotImg,stdWwwDir,imageName,abox,gotInfo,getFullSnapCustom,iShrinkToFit,href,atree,custW,custH,showExternalButton,whichBox) ;
    return 1 ;
   }

// screenLayout=0 (one of the dusals) ... one (or combo) snapshot box, with selected fit
     var abox='snapBox'+whichBox;
     theImg= showThisImage_Img(isNotImg,stdWwwDir,imageName,abox,gotInfo,getFullSnapCustom,iShrinkToFit,href,atree,custW,custH,showExternalButton,whichBox) ;

     var sButtons=$('.buttonSnapshot');    // fix up the which-image-file buttons to highlight most recnet choice
     sButtons.removeClass('thisImgInSnapshot');
     ethis.addClass('thisImgInSnapshot');   // most recently selected image
      showThisImage_markLastShown(ethis)     ;

     return 1;


  //===========  helper function (with access to caller's variables)
  function showThisImage_GetInfo(afile,qShowGotInfo,whichBox,href,atree,isNotImg,stdWwwDir,aDesc,whichLayout,forceFull ) {

     let dd=$(document).data('currentFiles_stats');
     let aDesc2='',aDesc2ex='',aDesc2i='' ;
     var fileName=afile.replace(/^.*[\\\/]/, '')    ;
     if (typeof(dd[fileName])=='undefined') {         // should not happen
        return 0 ;
     }
     let hh=dd[fileName];

     var asize=hh['size']/1000;
     var hImgOrig=hh['height'], wImgOrig=hh['width'];
     var afile=fileName ;
     var infoDesc= asize.toFixed(1)+'k, '+hh['date']+' :  '+ hh['mimetype']+'  '+wImgOrig+' x '+hImgOrig;
     if (whichBox=='tableau') {
        infoDesc+='  ('+imageName+')  ';
     }
     var gotInfo2=encodeURI(infoDesc);
     var how=getFullSnapCustom+','+wImgOrig+','+hImgOrig     ; // qgetnap 1: full, 2: snap, 3:custon uses custw and custh
     if (aDesc!='') {
       aDesc2=wsurvey.removeAllTags(aDesc);
       aDesc2i='<span title="truncated description"  style="display:inline-block;font-style:oblique;overflow:hidden;text-overflow:ellipsis;height:1em;width:21em;">'+aDesc2+'</span>' ;
       aDesc2ex=' <span title="description"  style="display:inline-block;font-style:oblique;overflow:auto;height:2.1em;width:41em;">'+aDesc2+'</span>' ;
     }
// caller uses shortInfo, showExternalButton, and ainfo

      shortInfo=afile+': '+infoDesc+' '+aDesc2ex ;

     let showExternalButton='<input forBox="'+whichBox+'"  type="button" isNotImg="'+isNotImg+'" stdWwwDir="'+stdWwwDir+'" value="&neArr;" imageName="'+imageName+'" ';
     showExternalButton+='  gotInfo="'+gotInfo2+'" how="'+how+'" tree="'+atree+'"  file="'+afile+'" ';
     if (forceFull==1) {
       showExternalButton+='  title="Show full-sized version of this in external window!" onClick="showImageExternal_snapBox(this,'+forceFull+')">';
     } else {
       showExternalButton+='  title="Show this in external window!" onClick="showImageExternal_snapBox(this,'+forceFull+')">';
     }

      gotInfo=' &nbsp;';
      if (qShowGotInfo==1 || forceFull==1)  {
        gotInfo+='<span name="iimageInfoSnap" class="imageInfoSnap" > ';
      } else {
        gotInfo+='<span name="iimageInfoSnap" class="imageInfoSnap" style="display:none" >';
      }

      if (whichBox=='tableau') {  // kind of a hack to add these buttons
         let expandMe='<input style="color:cyan" type="button" value="&#129001;" file="'+href+'"  treename="'+atree+'"  ';
         expandMe+= '  title="Add this  ('+imageName+'), as a full image, to the tableau"  ';
         expandMe+=' isnotimg="'+isNotImg+'" stdwwwdir="'+stdWwwDir+'" ' ;
         expandMe+='   snap="full" how="asis" onClick="showThisFile(this,1,1)"> ';    // 1=fullimage, 1=asis
         gotInfo+=expandMe ;
         let removeMe='<input style="color:red" type="button" value="&#9003;" title="Remove this image ('+imageName+') from the tableau" onClick="removeFromTableau(this)"> ';
         gotInfo+=removeMe ;
      }

      gotInfo+=showExternalButton;

      gotInfo+= infoDesc+' '+aDesc2i ;
      gotInfo+='</span>';

     return 1;  // vars are returned as variables in closure of caller
  }    // internal function for showThisFile

  // ========= update last shown file span (wchich might not be visible===
  function showThisImage_markLastShown(abutton) {
    var bname=abutton.attr('file');  //  display the name in the "last element displayed"
    var goo=bname.split('/');
    var bname2=goo[goo.length-1];
    var atreez=abutton.attr('treename');
    $('#divDoSlideShow_lastShown').html(bname2);
    $('#divDoSlideShow_lastShown').attr('title','Displaying file: '+bname+' in tree `'+atreez+'`');
    return 1;
  }             // internal function for showThisFile

}



//=================
// show image in external window
// used for the ne button in the fileList (NOT the ne button in the viewer box-- see showThisImage_snapBox

function   showThisImage_external(isNotImg,imageName,stdWwwDir,infoStats,getFullSnapCustom,href,atree,custW,custH ) {
   var theImgF='';
    if (isNotImg=='')  { // IS an image
       if (getFullSnapCustom==1) {  // ful limage
        theImgF= 'Displaying '+imageName+'<br/><tt>'+infoStats+'</tt><br/>';
      } else if (getFullSnapCustom==2) {
        theImgF=' Displaying (snapShot) '+imageName +'<br/><tt>'+infoStats+'</tt><br/>';
      } else {
        theImgF= 'Displaying  customSize ('+custW+'x'+custH+') '+imageName+'<br/><tt>'+infoStats+'</tt><br/>';
      }

      if (getFullSnapCustom==2) {        // snapshot  640x480)
             let ssrc='src/wsGalleryActionsSenders.php?todo=getResizedImage&file='+href+'&how=snapshot&tree='+atree;
             theImgF+='<img src="'+ssrc+'" title="Snapshot (640x480) of '+imageName+'"   > '
             wsurvey.displayInNewWindow(0,{'title':'Image view (wsGallery)','content':theImgF,'header':'Image file (snapShot): '+href,'name':'galleryViewerSnapshot','bars':1});

      } else if (getFullSnapCustom==3)  {           // custom width (as specified for all images)
             let ssrc='src/wsGalleryActionsSenders.php?todo=getResizedImage&file='+href+'&how=custom&width='+custW+'&height='+custH+'&tree='+atree;
             theImgF+='<img src="'+ssrc+'"   title="Cusom size ('+custW+'x'+custH+') of '+imageName+'"    > '
             wsurvey.displayInNewWindow(0,{'title':'Image view (wsGallery)','content':theImgF,'header':'Image file (custom size): '+href,'name':'galleryViewerSnapshot','bars':1});

     } else {       // full
          if (stdWwwDir==1)   {       //   file in standard web tree-- use simple src (not wsgalleryactionsSenders.php
             theImgF+='<img src="'+href+'" title="Image file ... : '+imageName+'"    > '
             wsurvey.displayInNewWindow(0,{'title':'Image view (wsGallery)','content':theImgF,'header':'Image file  : '+href,'name':'galleryViewerSnapshot','bars':1});

          } else {
             let asrc='src/wsGalleryActionsSenders.php?todo=getResizedImage&file='+href+'&how=full&tree='+atree;   // get full image  -- deals with trees not in web dir
             theImgF+='<img src="'+asrc+'" title="Image file .. .. : '+imageName+'"    > '
             wsurvey.displayInNewWindow(0,{'title':'Image view (wsGallery)','content':theImgF,'header':'Image file is: '+href,'name':'galleryViewerSnapshot','bars':1});
          }
      }
      return 1;
  }

// if here , not an img
// use messageListenger and open a new window

   let sw= screen.width,sh=screen.height;
   let wx = window.screenX, wy = window.screenY;
   let wh=$(document).height(),ww=$(document).width();
   let zahref='wsGallery_externalHandler.html';  // contains a flag element that is monitored for mutations
   let mleft=parseInt(wx+(ww/1.2));
   let apos='left='+mleft+',top=100,toolbar=1,menubar=1,directories=0,scrollbars=1,resizable=1';
   var wwExternalViewer=window.open(zahref,'wsGallery_externalViewer','left='+mleft+',top=100,toolbar=1,menubar=1,directories=0,scrollbars=1,resizable=1');
   wwExternalViewer.document.close();

   var hrefUse=href;
   let aii=jQuery.trim(isNotImg); if (aii=='0' ) aii=''
   if (stdWwwDir==0 && aii!='')  {
         hrefUse='src/wsGalleryActionsSenders.php?todo=getResizedImage&file='+href+'&how=full&stdWwwDir=0&isNotImg='+isNotImg+'&tree='+atree;
   }

// write to external window fields. Note that external window listens for messages from this window (to display the image it links to)
// and this send this data when the external window sends a "ready" message back here.
    let newdata={'status':1,
               'linkMessage':imageName,
               'linkHref':hrefUse,
               'info':infoStats };
    $(document).data('externalViewerInfo',newdata);
    $(document).data('externalViewerWindow',wwExternalViewer);

  return 1;
}



//===

function doAutoLoadExternal(athis) {
    var  myOrigin=window.location.protocol+'//'+window.location.hostname;
    if (window.location.port!='') myOrigin+=':'+window.location.port;

   wwExternalViewer=$(document).data('externalViewerWindow');
   if (wwExternalViewer=='') return 1 ; // no external window opend
   let new1=0;
   let newData={'status':'load','newWindow':new1} ;
   wwExternalViewer.postMessage(newData, myOrigin);
  return 1;

}


// ==========
// ne button  in top line of content area of a snapBox
// these buttons are created with necessary info saved as attributes
function showImageExternal_snapBox(athis,forceFull) {
  if (arguments.length<2) forceFull=0;
  var howtypes=['n.a.','full image','snapShot image','customResized image'];
  var imageW='n.a.', imageH='n.a.',ihow=0;
  var ww ;
  var ethis=wsurvey.argJquery(athis);

  aname=ethis.wsurvey_attr('forBox','') ;
  if (aname=='tableau') {
     let eparent=ethis.closest('[name="tableau_span"]');
     let eimg=eparent.find('img');
     let asrc=eimg.attr('src');
     ww=window.open(asrc,'wsGalleryViewer_vu_tableau',"toolbar=1,menubar=0,directories=0,scrollbars=1,resizable=1 " );
    return 1;
  }

// else, not a tableau
  var ww;
  var ebox=wsurvey.flContents.closest(ethis);
  if (ebox===false) {
     alert('Unable to find flContents container ');
     return 0;
  }

 let thisViewer=ebox.attr('id');  // name of snapshotbox -= used in target for extenral veiaewr

  var econtent=wsurvey.flContents.dom(ebox,'c');
  if (econtent===null) {
     alert('Unable to find flContents content area in '+thisViewer);
     return 0;
  }

  var eimgOuter=econtent.find('.snapShotImgOuter');
  if (eimgOuter.length==0) return 0;

  var eimg=eimgOuter.find('[name="imageRequester"]');  // might be <img>, but might be an element next to a <iframe ..>, etc
  if (eimg.length==0)  {
     alert('Unable to find image container in '+thisViewer);
     return 0;
  }
  var ahref=eimg.wsurvey_attr('src','');
  if (ahref=='') return 0;       // giveup

  if (forceFull==1) {   //  a hack to make sure full image is retrieved
     let ihow=ahref.indexOf('&how=');
     if (ihow>-1) {
         let iamp2=ahref.indexOf('&',ihow+1);
         let p1=ahref.substr(0,ihow);
         let p2=ahref.substr(iamp2);
         ahref=p1+'&how=full'+p2;
     }
  }


  var imagename=ethis.wsurvey_attr('imagename','n.a.');
  var filename=ethis.wsurvey_attr('file','n.a');
  var isNotImg=ethis.wsurvey_attr('isNotImg','');
  var stdWwwDir=ethis.wsurvey_attr('stdWwwDir',0);

//  var treeName=ethis.wsurvey_attr('tree',$(document).data('currentTree'));
  var treeName=ethis.wsurvey_attr('tree,treeName','');  // feb 2022: treename must be specified
  if (treeName=='') {                   // using currentTree is deprecated  (feb 2022)
      alert('showImageExternal_snapBox error: treename not specified ');
      return 0;
  }

  if (isNotImg=='') {   // standard image. Might be resized
      var ahow=ethis.wsurvey_attr('how','1,n.a,n.a');
      var vhow=ahow.split(',');
      var ihow=vhow[0];
      if (forceFull>0)ihow=forceFull ;     // force full or snapshot
      var sayhow=howtypes[ihow];
      var imageW=parseInt(vhow[1]);
      var imageH=parseInt(vhow[2]);
      if (ihow==3) {
         let custH= parseInt($(document).data('customImageHeight'));     // set when customSise was selected
         let custW= parseInt($(document).data('customImageWidth'));
         sayhow+=' ('+custW+'x'+custH+') ';
      }
 }
  var gotInfo0=ethis.wsurvey_attr('gotInfo','n.a.');
  var gotInfo=decodeURI(gotInfo0);


// immediate open. in contrast, the "external" option in the "which viewer" (on the file list menu) opens a window with a list of options
    if (stdWwwDir==0 && isNotImg!=='') {
        ahref='src/wsGalleryActionsSenders.php?todo=sendFile&file='+ahref+'&tree='+treeName  ;
    }

    var ww=window.open(ahref,'wsGalleryViewer_vu_'+thisViewer,"toolbar=1,menubar=0,directories=0,scrollbars=1,resizable=1 " );
    if (isNotImg=='') {
      atitle=' |  Viewing: '+imagename+' (using '+sayhow+') '+ gotInfo;
    } else {
      atitle=' | Viewing ' +imagename+ ' ('+isNotImg+') ' + gotInfo ;

    }
    window.setTimeout(function() {
      ww.document.title=atitle;
    },1100);  // might not work  -- cross origin error (even though created internally)

    return 1;
 }


//============================  gotinfo
// make an <img> other containter -- accounting for desired resolution, whether to shrink <img to fit in box, etc
// In particular will be used  write <img to a box, where it will be called and displayed. But maybe a snapshot rather than full image?
// If file (imgFile) not suitable for <img>, this calls  showThisImageImg_other

function showThisImage_Img(isNotImg,stdWwwDir,imgFile,whichBox,gotInfo,getFullSnapCustom,iShrinkToFit,href,atree, custW,custH,showExternalButton,whichBoxSelect) {

   var adims,imgHW='',doSay='',atitle,eventsSnap ;
  var spw2,sph2 ;
// if isNotImg, then can't use <img ...>
// But could use se <a .. and . <video or object/embed, or iframe. Depends on extension

   if (isNotImg!='') {
     showThisImage_Img_other(isNotImg,stdWwwDir,imgFile,whichBox,gotInfo,getFullSnapCustom,iShrinkToFit,href,atree, custW,custH,showExternalButton,whichBoxSelect) ;
     return 1;
   }

// ....  if here, an "image" file!
    var sayScroll='';
    if (whichBox!='singleImage') sayScroll= '&#013;Click on image to scroll to position in image. You can then hold the mouse down to scroll in either direction.';

// ishrinkto fit: 1 no shirn, 1=stretch (non propotional, 2=shrink (propoortional
    if (whichBox!='tableau'  && whichBox!='singleImage'  &&iShrinkToFit!=1)  {   // set <img widht and height to fit into the viewer box  -- this does NOT effect what is downloaded
         adims=wsurvey.flContents.current(whichBox)   ;
         if (iShrinkToFit==2) {
           imgHW=' width="'+(adims[0]-30)+'px" height="'+(adims[1]-30)+'px " '  ;   // strtch to fit (leave room for scroll bars
           doSay='Stretched image: '+ href  ;
           atitle=doSay+sayScroll;
         } else {
           doSay='Shrunken image: '+ href+' '  ;
           atitle=doSay+sayScroll;
         }

    } else {                  // no srhink (and not tableau or single image
         doSay='Image: '+href ;
         atitle=doSay+sayScroll;
         if (whichBox=='tableau'  ) {
            adims=wsurvey.flContents.current(whichBox)
            imgHW=' width="'+(adims[0]-30)+'px" height="'+(adims[1]-30)+'px " '  ;   // strtch to fit (leave room for scroll bars
         }
    }     // qShrinkToFit


    if (getFullSnapCustom==1)  {       // retrieve full image
        if (stdWwwDir==1)   {       //   file in standard web tree-- use simple src (not wsGalleryActionsSenders.php
          hrefUse=' which="fullImage"   src="'+href+'" ';  //  display same thing (full or snapshot)
       } else {
           let asrc='src/wsGalleryActionsSenders.php?todo=getResizedImage&file='+href+'&how=full&tree='+atree;   // get full image  -- deals with trees not in web dir
           hrefUse=' which="full"  src="'+asrc+'" ';
        }

     } else if (getFullSnapCustom==2) {               // retrieve snapshot resized image
         let asrc='src/wsGalleryActionsSenders.php?todo=getResizedImage&file='+href+'&how=snapshot&tree='+atree ;   // get snap shot version (from cache, or dynamically)
         hrefUse='which="snapShot"  src="'+asrc+'" ';

     } else {               // retrieve custom resized image
         let asrc='src/wsGalleryActionsSenders.php?todo=getResizedImage&file='+href+'&how=custom&width='+custW+'&height='+custH+'&tree='+atree  ;  // get custom version dynamically
         hrefUse=' which="custom"  src="'+asrc+'" ';
    }   //  getFullSnapCustom==1

    if (whichBox!='tableau' && whichBox!='singleImage') {
      theImg= gotInfo ;  // info above actual image container
      theImg+='<div class="snapShotImgOuter" title="viewer for an image file" >';    // the image container
      theImg+='<img '+hrefUse+'  name="imageRequester"  title="'+atitle+'" ' + imgHW +'   whichImg="'+imgFile+'" draggable="false" > ';  // the img link
      theImg+='</div>';

    } else if (whichBox=='singleImage') {

       theImg='';
      theImg+='<div class="snapShotImgOuter" title="single-image viewer for an image file" >';    // the image container
      theImg+='<img '+hrefUse+'  name="imageRequester"  title="'+atitle+'" ' + imgHW +'   whichImg="'+imgFile+'" draggable="false" > ';  // the img link
      theImg+='</div>';


    } else {      // tableau viewer box
       theImg ='<img '+hrefUse+'  name="imageRequesterTableau"     onClick="tableauInfoShow(this)"   ';
       theImg+= '   style="margin:8px;" whichImg="'+imgFile+'" draggable="false" > ';  // the img link
    }

    eventsSnap=[];
    eventsSnap[0]=['mousedown','.snapShotImgOuter',doScrollSnapShotDown] ;
    eventsSnap[1]=['mouseup','.snapShotImgOuter',doScrollSnapShotUp] ;
    eventsSnap[2]=['mousemove','.snapShotImgOuter',doScrollSnapShotMove] ;

    doSay=showExternalButton+'&nbsp;'+doSay;


// :::::::::::: special case, tableau and singleImage ::::
    if (whichBox=='tableau') {   // add img to tableau area
      adims=wsurvey.flContents.current(whichBox);
      let spw=(adims[0]-30)/2.1    ;     // these may change if the tableau box is resized. Perhaps this should be changed?
      let sph=(adims[1]-30)/2.1  ;
      let etw=$('#tableImage_wFactor');
      etw.attr('data-use',spw);
      let eth=$('#tableImage_hFactor');
      eth.attr('data-use',sph);

      let etab=$('#tableau_all');
      let aspan;
      if (isNotImg=='') {
        aspan =' <span name="tableau_span"  title="For image: '+imgFile+'\nClick to  &#8505; view info,  &#9003; remove image, or &neArr; view externally" class="ctableau_span  gradientCyan2" ';
      } else {
        aspan =' <span name="tableau_span"  title="For '+isNotImg+' file: '+imgFile+'\nClick to  &#8505; view info,  &#9003; remove image, or &neArr; view externally" class="ctableau_span  gradientCyan" ';
      }

      let etwf=$('#tableImage_wFactor'),atwf=jQuery.trim(etwf.val());
      wfactor= (atwf=='' || isNaN(atwf)) ? 1.0 : parseFloat(atwf);
      wfactor=Math.max(Math.min(wfactor,5),0.2);
      spw2=parseInt(wfactor*spw);

      let ethf=$('#tableImage_hFactor'),athf=jQuery.trim(ethf.val());
      hfactor= (athf=='' || isNaN(athf)) ? 1.0 : parseFloat(athf);
      hfactor=Math.max(Math.min(hfactor,5),0.2);
      sph2=parseInt(hfactor*sph);

      aspan+=' style="oof:1;overflow:auto;width:'+spw2+'px;height:'+sph2+'px;">';

      aspan+='<div name="fungus1">'+gotInfo+'</div>';

      aspan+=theImg+'</span>';

      var easpan=$(aspan);  // used in stretch function (settimeout) below
      easpan.appendTo(etab);
      etab.show();
      let etct=$('#tableauImageCt');
      let atct=parseInt(etct.attr('ict'));
      atct++;
      etct.attr('ict',atct);
      etct.html(atct);

      let etctF=$('#tableauFileCt');
      let atctF=parseInt(etctF.attr('ict'));
      atctF++;
      etctF.attr('ict',atctF);
      etctF.html(atctF);

     } else if (whichBox=='singleImage') {
        wsurvey.flContents.show(whichBox);
        $('#singleImageContentM').html(theImg);
        let edir=wsurvey.flContents.dom('gallery','c')  ;
        let elist=edir.find('#listOfFileInCurrentDir');
        let nbuttons=parseInt(elist.attr('nbuttons'));
        let enow=elist.find('.thisImgInSnapshot');
        iat='n.a.';
        if (enow.length>0) {
          let ebutton=enow.closest('span');
          iat=parseInt(ebutton.attr('buttonnumber'));
        }

        let hh3='<span style="font-size:120%">';
        hh3+='<span style="border-bottom:1px dotted blue;font-style:oblique" title="'+href+' in tree '+atree+'">Viewing ... '+iat+' of '+nbuttons+'</span>: <tt>'+imgFile+'</tt>: '+gotInfo+'</span>';
        wsurvey.flContents.header('singleImage',hh3);

    } else {       // NOT Tableau!  -------------------------------------
       wsurvey.flContents.contents(whichBox,theImg,{'onTop':1,'header':doSay,'addEvents':eventsSnap,'show':1});
     }


// spw2 and sph2 are hieght/width of the container (tableau_span) containg the img
// note use of overflow:hidden for stretch and shrink. Maybe lose a bit of image, but better fill of box
// hence added factors are small (1 or 2)
   if (whichBox=='tableau')  {
         window.setTimeout(function(){       // fit container holding img to content area
         if (iShrinkToFit==1) return 1 ; // show it all
         let eImg=easpan.find('img');
         let eImgH=parseInt(eImg.height()),eImgW=parseInt(eImg.width());    // size of image currently (possibly after prior zooms)
  // add 2  to account for scroll bars (but maybe not, given use of overflow:hidden
         if (iShrinkToFit==2) {         // stretch
            let w1=spw2, h1=sph2;
            eImg.attr('width',w1+'px'); eImg.attr('height',h1+'px');
            easpan.css({'overflow':'hidden','padding':'3px','margin':'3px','border':'purple'});
         } else if (iShrinkToFit==3) {           // shrinkg
            let wFract=(spw2)/(eImgW), hFract=(sph2)/(eImgH);
            let useFract=Math.min(wFract,hFract);
            let newW=parseInt(useFract*eImgW),newH=parseInt(useFract*eImgH);
            newW=Math.max(20,newW); newH=Math.max(20,newH); // avoid too tiny
            eImg.attr('width',newW+'px');
            eImg.attr('height',newH+'px');
            easpan.css({'overflow':'hidden','padding':'1px','margin':'1px','border':'1px dotted pink'});
         }                         // if 1, do nothing
         return 1;
      ;},50);    // wait a moment for dom to settle


   } else if (whichBox=='singleImage') {
       showThisImage_Img_singleImageButons(1);

       if (iShrinkToFit!=1) {    // shrink image to fit single image viewer
         let tol=15,doWidth=40,doHeight=40;
         window.setTimeout(function() {
           let eM=$('#singleImageContentM');
           let  inWidth=eM.innerWidth() ,inHeight=eM.innerHeight() ;  // viewig box dimentiosn
           let emI=eM.find('img');
           let inWidthI=emI.innerWidth(), inHeightI=emI.innerHeight();  // image dimentions
//           if (inWidthI+tol>inWidth || inHeightI>inHeight) {  // shrink can be "grow!"
               wShrink=inWidth/inWidthI,hShrink=inHeight/inHeightI;
               if (iShrinkToFit==3) {
                 let ashrink=Math.min(wShrink,hShrink);
                 doWidth=parseInt(ashrink*inWidthI);
                 doHeight=parseInt(ashrink*inHeightI);
               } else {                    // stretch
                  doWidth=parseInt(wShrink*inWidthI);
                  doHeight=parseInt(hShrink*inHeightI);
               }
               doWidth=Math.max(doWidth,40);
               doHeight=Math.max(doHeight,40);
               emI.attr('width',doWidth+'px');
               emI.attr('height',doHeight+'px');
//           }

         },150);
      }


    //  alert('qqqq '+iShrinkToFit);

   } else if (whichBox!='singleImage') {
       window.setTimeout(function(){       // fit container holding img to content area

            if (whichBoxSelect==0 && whichBox=='snapBox1') return 1;  // don't auto resize if combo mode and snapbox -- it already is "sretched" !

//just get rid of scrollbars if fit to size
          if ( (whichBox=='snapBox1' || whichBox=='snapBox2')  && (iShrinkToFit==2 || iShrinkToFit==3) )  {
              ep2=wsurvey.flContents.find(whichBox,'.snapShotImgOuter');
              ep2.css('overflow','hidden');
          } else {
              ep2=wsurvey.flContents.find(whichBox,'.snapShotImgOuter');
              ep2.css('overflow','auto');
          }
          if  ( iShrinkToFit==3) {   // shrink image first
                 eOuter=wsurvey.flContents.find(whichBox,'.snapShotImgOuter');
                 let eImg=eOuter.find('img');
                 let eImgH=parseInt(eImg.height()),eImgW=parseInt(eImg.width());    // size of image currently (possibly after prior zooms)
                 let boxW=parseInt(adims[0]), boxH=parseInt(adims[1]);      // size of container
                 let wFract=(boxW)/(eImgW+10), hFract=(boxH)/(eImgH+10);  // add 20 to account for scroll bars
                 let useFract=Math.min(wFract,hFract);
                 let newW=parseInt(useFract*eImgW)-20,newH=parseInt(useFract*eImgH)-20;
                 newW=Math.max(20,newW); newH=Math.max(20,newH); // avoid too tiny
                 eImg.attr('width',newW+'px');
                 eImg.attr('height',newH+'px');
          }      // shrinkto fit


          let qq=wsG_contentFit(whichBox,'.snapShotImgOuter'  ) ; // used shrunken image from above
          if (qq['status']!='ok') alert(qq['content']);
          $('.zoomViewers').prop('disabled',false)  ;
          $('.zoomViewers').css('opacity',1.0);
         return 1;

      ;},350);    // wait a moment for dom to settle
   }  // else not tableau or singleimage
 return 1;

}

//=========
//hide or show single imagea viewr navigation buttons
function  showThisImage_Img_singleImageButons(a) {
       let iat=0;

       let esingleO=$('#singleImageContentOuter');
       let esingleB=esingleO.find('button');
       esingleB.removeClass('cSingleImageDisable')
       esingleB.prop('disabled',false);

       let edir=wsurvey.flContents.dom('gallery','c')  ;
       let elist=edir.find('#listOfFileInCurrentDir');
       let nbuttons=parseInt(elist.attr('nbuttons'));
       let nbuttons0=nbuttons-1 ;
       let enow=elist.find('.thisImgInSnapshot');
       if (enow.length>0) {
         let ebutton=enow.closest('span');
         iat=parseInt(ebutton.attr('buttonnumber'));
       }

       if (iat<=0) {
            $('#iSingleImagePrior').addClass('cSingleImageDisable');
            $('#iSingleImagePrior').prop('disabled',true);
            $('#iSingleImageFirst').addClass('cSingleImageDisable');
            $('#iSingleImageFirst').prop('disabled',true);
       }
       if (iat>=nbuttons0) {
            $('#iSingleImageNext').addClass('cSingleImageDisable');
            $('#iSingleImageNext').prop('disabled',true);
            $('#iSingleImageLast').addClass('cSingleImageDisable');
            $('#iSingleImageLast').prop('disabled',true);
       }
}

//-=========================
// deal with non image files (files that can not be displayed via an <img ..> tag

function  showThisImage_Img_other(isNotImg,stdWwwDir,imgFile,whichBox,gotInfo,getFullSnapCustom,iShrinkToFit,href,atree, custW,custH,showExternalButton,whichBoxSelect) {

 if (whichBox=='tableau') {
     let goo=showThisImage_Img_other_tableau(isNotImg,stdWwwDir,imgFile,whichBox,gotInfo,href,atree,showExternalButton) ;
     return goo;
  }

   var adims,imgHW='',doSay='',atitle,eventsSnap ;
    var e5 ;


  var otherExtsSpecs=$(document).data('currentFiles_otherExtsSpecs') ; // how to display "other" extentions (non image) -- set in wsGallery_params.php

    theImg= gotInfo ;
    if (iShrinkToFit!=1) {
      adims=wsurvey.flContents.current(whichBox);
       imgHW=' width="'+(adims[0]-30)+'px" height="'+(adims[1]-30)+'px " '  ;   // shrink image a bit more, to deal with scroll bars
       doSay='Shrunken '+isNotImg+' file: '+ href;
    }

    var hrefUse=href;      // use direct link if possible. IF not possible (file is out of site's normal web path, use wsGallery to get it)
    if (stdWwwDir==0)  hrefUse='src/wsGalleryActionsSenders.php?todo=sendFile&file='+href+'&tree='+atree;

    theImg+='<div class="snapShotImgOuter" title="'+doSay+'" >';    // the image container

    if (typeof(otherExtsSpecs[isNotImg]) =='undefined') {
       wsurvey.dumpObj(otherExtsSpecs,1,'showThisImage_Img_other error: extension ('+isNotImg+') does not match specs in otherExtSpecs ');
      wsurvey.dumpObj(otherExtsSpecs,1,'otherextspecs');
       return 1;
    }
    let dispSpecs=otherExtsSpecs[isNotImg];
    let handler=dispSpecs[0];         // v(ideo), i(Frame), e(mbed), l(ink)
    let more1=dispSpecs[1];   // for v: mime/type, for i: url (or nothing), for e: mime/type
    let more2=dispSpecs[2];   // for v: mime/type, for i: url (or nothing), for e: mime/type

// use specs to display.
    if (handler=='v')  {       // video. By default: mov, mp4 . And less usefully mpeg mpg and avi
        theImg+='<span style="display:none"  name="imageRequester" src="'+hrefUse+'"></span> ';      // contains info used by neArr
        theImg+=' <video controls="controls" imgFile="'+imgFile+'" '+imgHW +'  name="'+hrefUse+'"   type="'+more1+'">';
         theImg+='  <source  src="'+hrefUse+'">';
         theImg+="Your browser does not support the "+more1+" video format...   Try the link below (run outside of the browser)"
        theImg+='<a   title="Show in an external window, or in a tab"  href="'+hrefUse+'" target="externalViewer">'+hrefUse+'</a>';
        theImg+='</video>';
        theImg+='<p><a target="otherViewer" href="'+hrefUse+'" title="Try opening this ('+isNotImg+' file) in a new window" whichImg="'+imgFile+'" draggable="false" >&#127910; '+href+'</a>';   // movie projector icon
    }

    if (handler=='i')  {       // image. Not used by default, but could be used with tif, img, etc
        theImg+='<span style="display:none"  name="imageRequester" src="'+hrefUse+'"></span> ';      // contains info used by neArr
        theImg+=' <img  draggable="false" alt="For image: '+imgFile+'" '+imgHW +'  src="'+hrefUse+'"  >';
        let aspin=getSpinnerImg(25);
         theImg+='<div name="nHandlerWaitDiv" class="cHandlerWaitDiv" style="display:none">'+aspin+' Please wait for  <tt>'+imgFile+'</tt> to be retrieved </div>' ;
         theImg+='<div name="nHandlerErrorDiv" class="cHandlerErrorDiv" style="display:none">Your browser does not support the <tt>'+isNotImg+'</tt> image format...  you can try  to open it in an external window ... </div>' ;
        theImg+='<p><a target="otherViewer" href="'+hrefUse+'" title="Try opening this ('+isNotImg+' file) in a new window" whichImg="'+imgFile+'" draggable="false" >&#128247; '+href+'</a>';   // camera con
    }

// Note that for backward compatability, embed is within an object. THis might be changed in later versions
    if (handler=='e')  {       // embed. By default: pdf .
       theImg+='<span style="display:none"  name="imageRequester" src="'+hrefUse+'"></span> ';      // contains info used by neArr
       adims=wsurvey.flContents.current(whichBox);
       let arf='<object data="'+hrefUse+'" type="'+more1+'"  width="'+(adims[0]-30)+'px" height="'+(adims[1]-30)+'px">';
       arf+=' <embed src="'+hrefUse+'" type="'+more1+'"> ';
       arf+=' <p>This browser does not support '+more1+'. Use the link (below) to download.' ;
       arf+='</embed>  ';
       arf+='<a   title="Show in an external window, or in a tab"  href="'+hrefUse+'" target="externalViewer">'+hrefUse+'</a>';
       arf+='</object>';
       theImg+=arf ;
       theImg+='<p><a target="otherViewer" href="'+hrefUse+'" title="Open  this '+isNotImg+' file in a new window" whichImg="'+imgFile+'" draggable="false" >&#128195; '+href+'</a>';  // scrolling page icon

    }
    if (handler=='l')  {       // link. None of the defaults have this (but this is easiest for admins to specify. Ie; for .js file display
       theImg+='<span style="display:none"  name="imageRequester" src="'+hrefUse+'"></span>';      // contains info used by neArr
       let arf='<p>wsGallery can not display this (<tt>'+isNotImg+'</tt>) file internally. ';
       arf+=' You can let your browser choose how to display this (in an external window)...&nbsp;' ;
       arf+='<a title="Show in an external window, or in a tab" href="'+hrefUse+'" target="externalViewer">'+hrefUse+'</a>';
       theImg+=arf ;
    }


    if (handler=='f') {             // iframe
        let adims=wsurvey.flContents.current(whichBox); 
        if (more1=='text' || more1=='html')  {        // special cases..
          let   goop2='';
          if (more2=='text'  )  {
            let goop='src/wsGalleryActionsSenders.php?todo=sendText&tree='+atree+'&file='+href+'" ';
            goop2='<a target="otherViewer" href="'+goop+'" title="Open  this text file in a new window (or tab)" whichImg="'+imgFile+'" draggable="false" >&#128441; '+href+' (as text)</a>'  ; // text page icon
         } else {
            goop2='<p> <a target="otherViewer" href="'+hrefUse+'" title="Open  this html file (with html formatting enabled) in a new window (or tab)" whichImg="'+imgFile+'" draggable="false" >&#128376; '+href+' (html enabled)</a>'; // spider web icon
         }      // more2

         if (more1=='text')  {
            let goop='src/wsGalleryActionsSenders.php?todo=sendText&tree='+atree+'&file='+href+'" ';
            theImg+='<span style="display:none"  name="imageRequester" src="'+goop+'"></span> ';      // contains info used by neArr
            let arf='<iframe name="viewerIframe" src="'+goop+'" width="95%" height="95%"  title="Display as text file">  ';
            arf+=hrefUse+'</iframe>';
            arf+= goop2;
            theImg+=arf ;
         } else {
            adims=wsurvey.flContents.current(whichBox);
            theImg+='<span style="display:none"   name="imageRequester" src="'+hrefUse+'"></span> ';      // contains info used by neArr
            let arf='<iframe name="viewerIframe" src="'+hrefUse+'" title="display as html file" '
            arf+= ' width="'+(adims[0]-30)+'px" height="'+(adims[1]-30)+'px"> ';
            arf+= hrefUse+'</iframe>';  // hrefuse in case of failure?

            arf+= goop2;
            theImg+=arf ;
         }   // more 1

      } else {       // not text or html,use src to external handler
         theImg+='<span style="display:none"  name="imageRequester" src="'+hrefUse+'"></span> ';      // contains info used by neArr
         let  goo0=window.location.protocol ;
         let goo1=window.location.host;
         let fullHref=goo0+'//'+goo1+href ;
         let aspin=getSpinnerImg(25);
         theImg+='<div name="nHandlerWaitDiv"   class="cHandlerWaitDiv" style="display:block">'+aspin+' Please wait for  <tt>'+imgFile+'</tt> to be retrieved &hellip; </div>' ;
         theImg+='<div name="nHandlerErrorDiv" class="cHandlerErrorDiv" style="display:none"> Your browser does not display the <tt>'+isNotImg+'</tt>  within internal frames ...  you can try  to open it in an external window ... </div>' ;
         arf='<iframe name="viewerIframe" title="Accessing '+fullHref+'" src="'+more1+fullHref+'"  ' ;     // call external handler with full url
         arf+= ' width="'+(adims[0]-30)+'px" height="'+(adims[1]-30)+'px"> ';
         theImg+=arf ;
         theImg+='<a href="'+hrefUse+'" target="externalViewer">'+fullHref+'</a>';
         theImg+='</iframe>';
         theImg+='<p><a target="otherViewer" href="'+hrefUse+'" title="Open  this '+isNotImg+' file in a new window" whichImg="'+imgFile+'" draggable="false" > &#128445;  '+href+' zzzs</a>';  // Frame icon
      }   // use src
    }                   // iframe


    theImg+='</div>';

    eventsSnap=[];
    doSay0=isNotImg+' file: '+href  ;
    let doSay2=isNotImg+' file: '+hrefUse  ;
    doSay=showExternalButton+'&nbsp;'+doSay0 ;

    let eww=wsurvey.flContents.dom(whichBox,'m');
    eww.wsFlOnTop();
    eww.wsFlHeader(doSay);

    if (whichBox!='singleImage') {
       eww.wsFlContents(theImg);
    } else {
        let eww2=eww.find('#singleImageContentM');
        eww2.html(theImg);
        showThisImage_Img_singleImageButons(2);
    }

    if (handler=='i' || handler=='f')  {                                           // <img> -- show/hide "please wait message"
        e5=wsurvey.flContents.dom(whichBox,'m');
       let e5a=eww.wsFlFind('[name="nHandlerWaitDiv"]');
       if (e5a.length>0)  e5a.show();
   }


   if (handler=='i') {                             // load an imagehandler

     e5.imagesLoaded()
      .done(function(instance,image1) {
         e5.find('[name="nHandlerErrorDiv"]').hide();
         e5.find('[name="nHandlerWaitDiv"]').hide();
      })
      .fail(function(instance,image1) {
           e5.find('[name="nHandlerErrorDiv"]').show();
           e5.find('[name="nHandlerWaitDiv"]').hide();
      })
      .progress( function( instanceX, image ) {
         let earf=e5.find('[name="nHandlerErrorDiv"]') ;
         e5.find('[name="nHandlerWaitDiv"]').hide();
          var qresult = image.isLoaded   ; // ? 'loaded' : 'broken';
          if (qresult==false) {
              earf.show();
          } else {
             earf.hide();
          }
       });  // progress
    }       // i handler

   if (handler=='f' && more1!='text') {                             // load an frames monitor
    // Get a handle to the iframe element
          let e6=e5.find('[name="viewerIframe"]');
          let iframe=e6[0];
          e5.find('[name="nHandlerErrorDiv"]').hide();
          e5.find('[name="nHandlerWaitDiv"]').show();
          checkIframeLoaded(iframe,e5,1,doSay0)   ; // monotiring looop  -- mght not be worth the trouble
   }

   window.setTimeout(function(){       // fit container holding img to content area

           if (whichBoxSelect==0 && whichBox=='snapBox1') return 1;  // don't auto resize if combo mode and snapbox -- it already is "sretched" !

           if (iShrinkToFit==3) {   // shrink image first

              eOuter=eww.wsFlFind('.snapShotImgOuter');
              let eImg=eOuter.find('img');

             let eImgH=parseInt(eImg.height()),eImgW=parseInt(eImg.width());
              let boxW=parseInt(adims[0]), boxH=parseInt(adims[1]);// size of image currently (possibly after prior zooms)
              let wFract=(boxW)/(eImgW+10), hFract=(boxH)/(eImgH+10);  // add 20 to account for scroll bars
              let useFract=Math.min(wFract,hFract);
              let newW=parseInt(useFract*eImgW)-20,newH=parseInt(useFract*eImgH)-20;
              newW=Math.max(20,newW); newH=Math.max(20,newH); // avoid too tiny
              eImg.attr('width',newW+'px');
              eImg.attr('height',newH+'px');

          }

           let qq=wsG_contentFit(whichBox,'.snapShotImgOuter'  )
           if (qq['status']!='ok') alert(qq['content']);

           let eez=$('.zoomViewers');
           eez.prop('disabled',true)  ;
           eez.css('opacity',0.3);


      ;},250);    // wait a moment for dom to settle


    return 1;
}        // ::::::::::::; end of not-image file procesins


//====================
// tableau version (fewer options)
function showThisImage_Img_other_tableau(isNotImg,stdWwwDir,imgFile,whichBox,gotInfo,href,atree,showExternalButton ) {

  var atitle ;
  var imgHW='';
  var adims=wsurvey.flContents.current(whichBox);
      let spw=(adims[0]-30)/2.1    ;
      let sph=(adims[1]-30)/2.1  ;
  var  spanStyleWH='width:'+spw+'px;height:'+sph+'px;'

  let etwf=$('#tableImage_wFactor'),atwf=jQuery.trim(etwf.val());
  wfactor= (atwf=='' || isNaN(atwf)) ? 1.0 : parseFloat(atwf);
  wfactor=Math.max(Math.min(wfactor,5),0.2);
  let spw2=parseInt(wfactor*spw);

  let ethf=$('#tableImage_hFactor'),athf=jQuery.trim(ethf.val());
  hfactor= (athf=='' || isNaN(athf)) ? 1.0 : parseFloat(athf);
  hfactor=Math.max(Math.min(hfactor,5),0.2);
  let sph2=parseInt(hfactor*sph);

   var removeMe='<input style="color:red" type="button" value="&#9003;" title="Remove this '+isNotImg+' file ('+imgFile+') from the tableau" onClick="removeFromTableau(this)"> ';

  var otherExtsSpecs=$(document).data('currentFiles_otherExtsSpecs') ; // how to display "other" extentions (non image) -- set in wsGallery_params.php

    theImg='' ;

    var hrefUse=href;      // use direct link if possible. IF not possible (file is out of site's normal web path, use wsGallery to get it)
    if (stdWwwDir==0)  hrefUse='src/wsGalleryActionsSenders.php?todo=sendFile&file='+href+'&tree='+atree;

    if (typeof(otherExtsSpecs[isNotImg]) =='undefined') {
       dump2(otherExtsSpecs,1,6,'showThisImage_Img_other error: extension ('+isNotImg+') does not match specs in otherExtSpecs ');
       return 1;
    }
    let dispSpecs=otherExtsSpecs[isNotImg];
    let handler=dispSpecs[0];         // v(ideo), i(Frame), e(mbed), l(ink)
    let more1=dispSpecs[1];   // for v: mime/type, for i: url (or nothing), for e: mime/type
    let more2=dispSpecs[2];   // for v: mime/type, for i: url (or nothing), for e: mime/type

// use specs to display.
    if (handler=='v')  {       // video. By default: mov, mp4 . And less usefully mpeg mpg and avi
    imgHW=' ';
       // imgHW=' width="'+(adims[0]-30)+'px" height="'+(adims[1]-30)+'px " '  ;   // shrink image a bit more, to deal with scroll bars
        theImg+='<span style="display:none"  name="imageRequester" src="'+hrefUse+'"></span> ';      // contains info used by neArr
        theImg+=' <video controls="controls" imgFile="'+imgFile+'" '+imgHW +'  name="'+hrefUse+'"   type="'+more1+'">';
         theImg+='  <source  src="'+hrefUse+'">';
         theImg+="Your browser does not support the "+more1+" video format...   Try the link below (run outside of the browser)"
        theImg+='<a   title="Show in an external window, or in a tab"  href="'+hrefUse+'" target="externalViewer">'+hrefUse+'</a>';
        theImg+='</video>';

        theImg+='<p>'+removeMe+'<a target="otherViewer" href="'+hrefUse+'" title="Try opening this ('+isNotImg+' file) in a new window" whichImg="'+imgFile+'" draggable="false" >&#127910; '+href+'</a>';   // movie projector icon
    }

    if (handler=='i')  {       // image. Not used by default, but could be used with tif, img, etc
        theImg+='<span style="display:none"  name="imageRequester" src="'+hrefUse+'"></span> ';      // contains info used by neArr
        theImg+=' <img  draggable="false" alt="For image: '+imgFile+'" '+imgHW +'  src="'+hrefUse+'"  >';
        let aspin=getSpinnerImg(25);
        theImg+='<p>'+removeMe+'<a target="otherViewer" href="'+hrefUse+'" title="Try opening this ('+isNotImg+' file) in a new window" whichImg="'+imgFile+'" draggable="false" >&#128247; '+href+'</a>';   // camera con
    }

// Note that for backward compatability, embed is within an object. THis might be changed in later versions
    if (handler=='e')  {       // embed. By default: pdf .
       theImg+='<span style="display:none" style="'+spanStyleWH+'"  name="imageRequester" src="'+hrefUse+'"></span> ';      // contains info used by neArr
       let arf='<object data="'+hrefUse+'" type="'+more1+'"   width="'+(spw2-10)+'px" height="'+(sph2-10)+'px">';
       arf+=' <embed src="'+hrefUse+'" type="'+more1+'"> ';
       arf+=' <p>This browser does not support '+more1+'. Use the link (below) to download.' ;
       arf+='</embed>  ';
       arf+='<a   title="Show in an external window, or in a tab"  href="'+hrefUse+'" target="externalViewer">'+hrefUse+'</a>';
       arf+='</object>';
       theImg+=arf ;
       theImg+='<p>'+removeMe+'<a target="otherViewer" href="'+hrefUse+'" title="Open  this '+isNotImg+' file in a new window" whichImg="'+imgFile+'" draggable="false" >&#128195; '+href+'</a>';  // scrolling page icon

    }
    if (handler=='l')  {       // link. None of the defaults have this (but this is easiest for admins to specify. Ie; for .js file display
       theImg+='<span style="display:none"  name="imageRequester" src="'+hrefUse+'"></span>';      // contains info used by neArr
       let arf='<p>wsGallery can not display this (<tt>'+isNotImg+'</tt>) file internally. ';
       arf+=' You can let your browser choose how to display this (in an external window)...&nbsp;<br>' ;
       arf+=removeMe+'<a title="Show in an external window, or in a tab" href="'+hrefUse+'" target="externalViewer">'+hrefUse+'</a>';
       theImg+=arf ;
    }


    if (handler=='f') {             // iframe
        let adims=wsurvey.flContents.current(whichBox); 
        if (more1=='text' || more1=='html')  {        // special cases..
          let   goop2='';
          if (more2=='text'  )  {
            let goop='src/wsGalleryActionsSenders.php?todo=sendText&tree='+atree+'&file='+href+'" ';
            goop2='<p>'+removeMe+'<a target="otherViewer" href="'+goop+'" title="Open  this text file in a new window (or tab)" whichImg="'+imgFile+'" draggable="false" >&#128441; '+href+' (as text)</a>'  ; // text page icon
         } else {
            goop2='<p>'+removeMe+'<a target="otherViewer" href="'+hrefUse+'" title="Open  this html file (with html formatting enabled) in a new window (or tab)" whichImg="'+imgFile+'" draggable="false" >&#128376; '+href+' (html enabled)</a>'; // spider web icon
         }      // more2

         if (more1=='text')  {
            let goop='src/wsGalleryActionsSenders.php?todo=sendText&tree='+atree+'&file='+href+'" ';
            theImg+='<span style="display:none"  name="imageRequester" src="'+goop+'"></span> ';      // contains info used by neArr
            let arf='<iframe name="viewerIframe" src="'+goop+'" width="95%" height="95%"  title="Display as text file">  ';
            arf+=hrefUse+'</iframe>';
            arf+= goop2;
            theImg+=arf ;
         } else {
            adims=wsurvey.flContents.current(whichBox);
            theImg+='<span style="display:none"   name="imageRequester" src="'+hrefUse+'"></span> ';      // contains info used by neArr
            let arf='<iframe name="viewerIframe" src="'+hrefUse+'" title="display as html file" '
            arf+= ' width="'+(adims[0]-30)+'px" height="'+(adims[1]-30)+'px"> ';
            arf+= hrefUse+'</iframe>';  // hrefuse in case of failure?

            arf+= goop2;
            theImg+=arf ;
         }   // more 1

      } else {       // not text or html,use src to external handler
         theImg+='<span style="display:none"  name="imageRequester" src="'+hrefUse+'"></span> ';      // contains info used by neArr
         let  goo0=window.location.protocol ;
         let goo1=window.location.host;
         let fullHref=goo0+'//'+goo1+href ;
         let aspin=getSpinnerImg(25);
         arf='<iframe name="viewerIframe" title="Accessing '+fullHref+'" src="'+more1+fullHref+'"  ' ;     // call external handler with full url
         arf+= ' width="'+(adims[0]-30)+'px" height="'+(adims[1]-30)+'px"> ';
         theImg+=arf ;
         theImg+='<a href="'+hrefUse+'" target="externalViewer">'+fullHref+'</a>';
         theImg+='</iframe>';
         theImg+='<p>'+removeMe+'<a target="otherViewer" href="'+hrefUse+'" title="Open  this '+isNotImg+' file in a new window" whichImg="'+imgFile+'" draggable="false" > &#128445;  '+href+' zzzs</a>';  // Frame icon
      }   // use src
    }                   // iframe


      let etab=$('#tableau_all');
      let aclass='ctableau_span_'+handler;
      let aspan='<span name="tableau_span"  title="for image: '+imgFile+'" class="'+aclass+'   gradientCyan2" ';

      aspan+=' style="oof:2;overflow:auto;width:'+spw2+'px;height:'+sph2+'px;">';

      aspan+=theImg+'</span>';
      etab.append(aspan);
      etab.show();
      let etct=$('#tableauFileCt');
      let atct=parseInt(etct.attr('ict'));
      atct++;
      etct.attr('ict',atct);
      etct.html(atct);



    return 1;
}        // ::::::::::::; end of not-image file procesins


// ===========
// check frame load but in a not dependable way
function checkIframeLoaded(iframe,e5,niters,doSay) {

    try {
       var iframeDoc = iframe.contentDocument || iframe.contentWindow.document;
    } catch (ee) {
        alert('Problem accessing '+doSay+': '+ee.message);
          e5.find('[name="nHandlerErrorDiv"]').hide();
          e5.find('[name="nHandlerWaitDiv"]').hide();

        return 1;
    }
    // Check if loading is complete

       if (  iframeDoc.readyState  == 'complete' ) {
            e5.find('[name="nHandlerWaitDiv"]').hide();
            return 1;
       }   // If we are here, it is not loaded. Set things up so we check   the status again in 100 milliseconds
       if (niters>50)  {       // 5 seconds

          e5.find('[name="nHandlerErrorDiv"]').show();
          e5.find('[name="nHandlerWaitDiv"]').hide();
          return 1;
       }

       window.setTimeout(function (){  checkIframeLoaded(iframe,e5,niters++,doSay)}, 100);
}



//====================
// add this image to tableau, its full image
function addToTableau(athis) {
   let ethis=wsurvey.argJquery(athis);
   let afile=ethis.attr("file");
   let etableau=ethis.closest('#tableau_all');
   let enaps=etable.find('.buttonSnapshot')
}

//=============
//  Shrink the image container
//   so that it fits  floatingContent content area the need for overflow bars
//
//     anid: if of floatingConteint container
//  lookfor:  string used to find an element in the content area -- this element will be shrunk until it fits.
//               This must be a valid jQuery search string.
//                For example:
//                    '#statusBox'
//                    '.latestNews'
//                    '[name="yourChoice"]'
//                If '', then use the first child (of the content area of anid floatingContent continaer).
//     tol:  tolerance. Optional, default value is 1. See wsurvey.flContents.checkOverflow for details
//  This uses wsurvey.flContents.checkOverflow, so is subject to the same "# of attempts" restrictions (20).
//
//   returns ['status':status,'content':a message]
//      status: 'error'. content contains error message
//              'ok' . content describes final size
//              'nochange' means unable to make a change (took too long). Original size retained. Content notes this

function wsG_contentFit(anid,lookfor,tol) {

   var  wasw1pct,wash1pct,goodh1pct,goodw1pct,ithTry,ii,qover;
   var anid1,anid2,anid3,anid4,ebox2,w1,h1,w1pct,h1pct;

 if (arguments.length<3 || isNaN(tol) ) tol=1;
  tol=parseFloat(tol) ;

  if (arguments.length<2) lookfor='';

  anid2=wsurvey.flContents.dom(anid);
  if (anid2===false) return   {'status':'error','content':'can not find jquery object using id: '+anid};
  var anid3=anid2['content'];

  if (anid3===null) return {'status':'error','content':'no content area in a flContent '};

   if (jQuery.trim(lookfor)=='') {
      ebox2=anid3.children();
      if (ebox2.length==0)    return {'status':'error','content':'no elements in the content area of a flContent '};
   } else {
      ebox2=anid3.find(lookfor);
      if (ebox2.length==0)    {
          wsurvey.flContents.container.error('no matching element ('+lookfor+') in the content area of a flContent' );
          return {'status':'error','content':'no matching element ('+lookfor+') in the content area of a flContent   '};
      }
      if (ebox2.length>1) {
         let amess= 'multiple ('+ebox2.length+' matching elements ('+lookfor+') in the content area of a flContent ';
         return {'status':'error','content':amess};
      }
   }

   w1=100; h1=100;   // start at 100% -- will probably fail
   var igood=0;
   for (var ii=0;ii<20;ii++)  {               // max tries
        w1pct=parseInt(w1)+'%';
        h1pct=parseInt(h1)+'%';

        ebox2.css({'height':h1pct,'width':w1pct});
        qover=wsurvey.flContents.checkOverflow(anid,1,1);
        if (qover['status']===false)  {  //take one more step after fitting
            igood++;
            if (igood>1) break;
        }
        w1=w1*0.97 ; h1=h1*0.97;
        ithTry=ii ;
   }
   if (ithTry==20 && igood==0) {  // giveup
      ebox2.css({'height':'','width':''});  // remove these height and width
      return {'status':'nochange','content':'unable to shrink (after '+ithTry+' iterations)'} ;
   }


// reexpand height and width a bit
    goodh1pct=w1pct; ; goodw1pct=w1pct;

    for (var ii=0;ii<20;ii++)  {               // max tries
       w1=w1*1.01  ;
       w1pct=parseInt(w1)+'%';
       ebox2.css({'height':h1pct,'width':w1pct});  // h1pct doesn't change in this loop

       qover=wsurvey.flContents.checkOverflow(anid,1,1);

       if (qover['status']===true) {  // now over. stop growing
           break  ;
       }
       goodw1pct=w1pct;  // this is no overflow, so it good
    }

    for (var ii=0;ii<20;ii++)  {               // max tries
       h1=h1*1.01  ;
       h1pct=parseInt(h1)+'%';

       ebox2.css({'height':h1pct,'width':goodw1pct});    // w1 doesnt change in this l
       qover=wsurvey.flContents.checkOverflow(anid,1,1);
       if (qover['status']===true) {      // now over. stop growing
           break  ;
       }
       goodh1pct=h1pct;   // no overflow so this is still good
       ithTry=ii ;
    }

    ebox2.css({'height':goodh1pct,'width':goodw1pct});

    let acontent='shrunk to '+parseInt(goodw1pct)+'% x '+parseInt(goodh1pct)+'% (after ' +ithTry+' iterations )'
    return {'status':'ok','content':acontent} ;


}


