<?php
session_start() ;
ob_start();

use wSurvey\getJson as getJs  ;

// -----------------------------------
// action handle, ADMIN VERSION, for wsGallery  -- called from .js side use ajax (.get) functions
//
// Admin changeable parameters are in wsGallery_params.php,
//  what trees (directory paths) are set in wsGallery_treeList.php
//  username/password (for admin only are in wsCheckLogonParams.php
//
// -----------------------------------
//
// actions handled here:
// makeDirList      :create a list of directories in a tree. Save to to a tree specific dirList. json' 'cache' file
// updateFileDescs : update file descrptions
// displayFileDescs : display file descriptions (all files in a dir)
// disableATree : disable a tree
// doDisableDir :  disable view of a directory (in a tree). Tweaks the dirList for this dir
// dirCache  :   wsgallery-init a directory cache
// getAdminMenu  :  show menu of trees (to update, etc)
//
//  ------------------------

$nowtime=time();
$rootdir=$_SERVER['DOCUMENT_ROOT'] ;
//$curDir=getcwd();

if (!array_key_exists('wsGallery_mainDir',$_SESSION)) {
        print 'Error: wsGallery_main is missing. $_SESSION has #fields= '. count($_SESSION)  ;
        exit;
}
$wsMainDir=$_SESSION['wsGallery_mainDir'];
if (trim($wsMainDir)=='') {
     print  "Error: wsGallery_main is empty. $_SESSION has #fields= ". count($_SESSION)   ;
     exit;
}

require_once($wsMainDir.'/libs/php/wsurvey.getJson.php');

require_once($wsMainDir.'/src/wsGalleryLibUtils.php');
require_once($wsMainDir.'/src/wsGalleryLibUtilsAdmin.php');
require_once($wsMainDir.'/src/wsGallery_dirList.php');
require_once($wsMainDir.'/src/wsGallery_dirCache.php');
require_once($wsMainDir.'/src/wsGallery_fileList.php');



  $todo=extractRequestVar('todo','');

  //=====
// create a list of directories in a tree. Save to to a tree specific dirList. json' 'cache' file,
// called by js makeTreeDirList  and  makeTreeDirList_Go (timeout/resume)
if ($todo=='makeDirList') {

   $res=['status'=>'error','content'=>'','foo'=>'bake'] ;

  $logonOk=wsCheckLogon_logonStatusG('wsGallery') ;   // must be admin logon
  if ($logonOk[0]!=1) {
     if ($logonOk[0]==2) {
        $infos=['status'=>'okay','logonName'=>'wsGallery','expire'=>1,'content'=>'Logon session expired. Please relogon!  '];
     } else {
        $infos=['status'=>'error','logonName'=>'wsGallery','content'=>'You must be an administrator to make a directory list '];
        getJs\jsonReturn($infos);
        exit;
     }
   }
   $doThisTree=extractRequestVar('treeName','');
   if ($doThisTree=='') getJs\jsonReturnError('makeDirList error: no treename ');  // debug check feb 2022
   $askips=[];
   $askips1=trim(extractRequestVar('doSkips',''));
   if ($askips1!=='') {
     $askips2=explode(',',$askips1);
     foreach ($askips2 as $jj=>$aa) $askips[trim($aa)]=1;
   }

   $isPreview=trim(extractRequestVar('isPreview','0'));
   $keepDisabled=trim(extractRequestvar('keepDisabled',1));
   $keepDescriptions=trim(extractRequestvar('keepDescriptions',1));
   $removeUnusedCache=trim(extractRequestvar('removeUnusedCache',0));
   $mustHaveViewable=extractRequestVar('mustHaveViewable',1);
   $doResume=extractRequestVar('doResume',0);
   $timeAllowed=extractRequestVar('timeAllowed',3) ;                    // seconds allowed before early return (resumeStatus is set for next call)
   $describeFile=trim(extractRequestVar('describeFile',''));

// timeallowed is for first view. "resume" iterations use 3 or 4 seconds
// makeDirList_base is in wsGallery_dirlist.php -- it will save to dirlist. json

    $resa= makeDirList_base($doResume,$doThisTree,$keepDisabled,$keepDescriptions,$removeUnusedCache,
               $mustHaveViewable,$timeAllowed,$askips,$isPreview,$describeFile )  ;
     if ($resa['doResume']==1) {
        $tinfo=['status'=>'ok','doResume'=>1,'treeName'=>$doThisTree,'resumeMessage'=>$resa['content'],
               'keepDisabled'=>$keepDisabled,'mustHaveViewable'=>$mustHaveViewable,'removeUnusedCache'=>$removeUnusedCache];
        getJs\jsonReturn($tinfo);

    }

// not a resume

   $resa['resumeMessage']=count($resa['dirList']).' directories found.';

   if ($resa['status']=='ok') {         // success at find  directories with stuff in them.
      $resCache=makeDirList_makeCacheDirs($resa['dirList'],$doThisTree,$removeUnusedCache,$isPreview); // create cache dirs, possibly remove orphans
      if ($isPreview==1)  {    // a preview
           getJs\jsonReturnContent($resCache);
      }
      $resa['cacheInfo']=$resCache  ;
      if ($removeUnusedCache==1) {
        $resa['resumeMessage']='Cache directories created (orphans removed).';
      } else {
        $resa['resumeMessage']='Cache directories created.';
      }
   }
   getJs\jsonReturn($resa);


}
// :::::::::::::::::::::::
// display list of changeable file descriptions
if ($todo=="displayFileDescs"){
  $atreename=extractRequestVar('treename');
  $adir=extractRequestVar('dir');
  $vstuff=doGetDirFileList(0,1,$atreename,$adir); // get   file desc list just for this dir (in atree)

  $vstats=$vstuff['fileStats'];

  $stuff='';
  $stuff.='<div   name="fileDescChangeTable" adir="'.$adir.'" treename="'.$atreename.'">';
  $stuff.='<table cellpadding="4" rules="rows" ><tr>';
  $stuff.='<th>';
  $stuff.='  <input type="button" value="?" title="Help for: changing file" onclick="doHelpVu(this)" topic="changeFileDesc0" class="helpTopic_otherTopicButtonNarrow"> ';
  $stuff.='File</th>';
  $stuff.='<th>w x h </th><th>date</th>';
  $stuff.='<td> ';

  $stuff.='<input type="button" value="Update file descriptions" title="Update the descriptions of files in this directory" onclick="updateFileDescriptions(this)"  ';
  $stuff.=' adir="'.$adir.'" treename="'.$atreename.'">';
  $stuff.='  <input type="button" value="?Desc" title="Help for: file descriptions" onclick="doHelpVu(this)" topic="changeFileDesc" class="helpTopic_otherTopicButtonNarrow"> ';
  $stuff.='  <input type="button" value="Import" title="Import file descriptions (in a csv)" onclick="doImportDesc(this)"  > ';
  $stuff.='  <input type="button" value="Export" title="Export file descriptions (as a  csv)" onclick="doExportDesc(this)" > ';

  $stuff.='</td></tr>';
  $stuff.='<tr  id="descriptionReport" style="display:none"><td colspan="4"><div  style= "border:2px solid tan;border-radius:3px" id="descriptionReport2">..</div></td></tr>';

//<button isnotimg="" class="buttonSnapshot" file="/photos/sue1/20150718_143755.jpg"
//  treename="someshots" stdwwwdir="1" onclick="showThisFile(this)" dog="fido">20150718_143755.jpg  </button>
//<button isnotimg="txt" class="buttonSnapshot" file="/photos/sue1/readme.txt" treename="someshots"
//   stdwwwdir="1" onclick="showThisFile(this)" dog="fido">readme.txt  </button>

  foreach ($vstats as $afile=>$ainfo) {
      $amime=$ainfo['mimetype'];
      $afull=$ainfo['fullSel'];
     $stuff.='<tr><td> ';
     $isnotimg='';
     $awidth=$ainfo['width']; $aheight= $ainfo['height'];
     if ($awidth=='') {
         $aext= pathinfo($ainfo['fullSel'],PATHINFO_EXTENSION) ;
         $isnotimg= ' isnotimg="'.strtolower($aext).'" ';
     }
     $stuff.='<button  '.$isnotimg.' file="'.$afull.'" name="fileDescChangeTable_viewFile" treename="'.$atreename.'"  showIn="2"  getSnap="2" doShrink="3" ';
     $stuff.=' title="'.$afull.' ('.$amime.')"> ';
     $stuff.= $afile.'</button>';
     $stuff.='</td>';
     $stuff.='<td><div class="fileDesc_dims">'.$awidth.' x ' .$aheight.'</div></td>';
     $bdate=date("M/j/Y",$ainfo['time']);
     $stuff.='<td><div class="fileDesc_date">'.$bdate.'</div></td>';
     $stuff.='<td><textarea title="Enter a description. No active (script, etc) html tags -- but simple (b, em. etc) are allowed" ';
     $adesc=$ainfo['desc'];
     $stuff.='   rows="1.5" cols="60" name="fileDescs" data-changed="0" afile="'.$afile.'" >'.$adesc.' </textarea>' ;
     $stuff.='</td></tr>';
  }
  $stuff.='</table>';
  $stuff.='</div>';
  getJs\jsonReturnContent($stuff);

}

//::::::::::::::
// update file descrptions
if ($todo=='updateFileDescs') {
   $noCache=$_SESSION['wsGallery_noCache'] ;
   if ($noCache==1) {
      $infos=['status'=>'error','content'=>'Sorry. Caching is disabled, so file descriptions can not be created '];
      getJs\jsonReturn($infos);
   }

   $adir=extractRequestVar('dir','');
   $atree=extractRequestVar('treeName','');
   $changes=extractRequestVar('changes');

   $fileList0=get_fileListCache('~'.$adir,$atree,2)  ; // since allowCache=2, just read from cache file.
   $fileList=$fileList0['fileList'];
   $dirDesc=$fileList0['desc'];
   $lookups=$fileList0['relSelLookup'];

  $oks=[];
   foreach ($changes as $ii=>$c1) {
       $cfile=$c1[0];
       if (!array_key_exists($cfile,$lookups)) {
           $oks[]="Could not save descrptions for: <tt>$cfile</tt> ";
           continue;
       }
       $ith=$lookups[$cfile];   // where in fileList?
       $daDesc= $c1[1] ;      // assume that caller already stripped tags (or removed active tags)
       $fileList[$ith]['desc']=$daDesc;
       $oks[]= " <tt>$cfile</tt> "  ;
   }
   $fileList0['fileList']=$fileList;
   $fileList0['modeTime']=time();

    $cacheDir=$fileList0['pathSelectorInfo']['cacheDir'];
    if ($cacheDir=='' || !is_dir($cacheDir) )  {
      $infos=['status'=>'error',
             'content'=>"Unable to save descriptions: missing or bad cacheDir ($cacheDir) for  dir=$adir in tree=$atree  "];
      getJs\jsonReturn($infos );
    }

   $fileCache=$cacheDir.'/_fileList.json' ;      // can also be used below (if need to create or recreate this file)
   $goof=json_encode($fileList0, JSON_UNESCAPED_UNICODE);
   $nsave=file_put_contents($fileCache,$goof);     // filelist.json -- won't happen if nocache  set above
   $sayit='<ul  class="linearMenu"><li class="linearMenuLi3">'.implode('<li class="linearMenuLi3">',$oks).'</ul>';
   $stuff="Descriptions changed: ".$sayit ;
   getJs\jsonReturnContent($stuff);

}


//:::::::::::::
// disable view of a directory (in a tree). Tweaks the dirList for this dir
if ($todo=='doDisableDir') {
  $res=['status'=>'ok','content'=>''] ;
  $thisTree=trim(extractRequestVar('treeName',''));
  $doDisableList= extractRequestVar('disable',[] );    //an associative array
  $mustHaveViewable=extractRequestVar('mustHaveViewable',1);

   $nchanges=count($doDisableList);
   if ($nchanges>0) {          // if no changes, no call. Hence, doDisableList is always non-empty
      $res=dirList_changeStatus($thisTree,$doDisableList,$mustHaveViewable)  ;
   } else {
       $res['content']=" There were no directories selected (so no disable status are changed)";
   }
   getJs\jsonReturn($res);
}


// ::::
// wsgallery-init a directory cache.
if ($todo=='dirCache') {

  $logonOk=wsCheckLogon_logonStatusG('wsGallery') ;   // must be admin logon
  if ($logonOk[0]!=1) {
      $infos=['status'=>'nologon','logonName'=>'wsGallery'];
       getJs\jsonReturn($infos);
       exit;
   }

  $treeName=extractRequestVar('treename','');
  if ($treeName=='') getJs\jsonReturnError('adminAction dirCache error: no treeName was provided');  // feb 2022: no longer allow for "use default treename"

  $adir=extractRequestVar('dir','');    // adir is a subdirectory -- of the rootdir/rootsel of a treeName. Ie: it is NOT fully qualified

// feb 2022 : should only read this on first call FIX THIS

  $isReinit=extractRequestVar('reinit',0);
  $jstep=extractRequestVar('step',1);
  $action=extractRequestVar('action','start');
  $doResume=extractRequestVar('doResume',0);
  $timeAllowed=extractRequestVar('timeAllowed',4);
  $isMulti=extractRequestVar('isMulti',0);      // not used if action !=start or startmulti
   $removeAll=extractRequestVar('removeall','0');     // if here, subdire specific cache dir DOES exist.
   $doOverwrite=extractRequestVar('overwrite',0);  // the remaining steps may or may not overwrite existing files
   $retainDesc=extractRequestVar('retainDesc','1');

    $thisTreeInfo=getTreeInfo($treeName) ;    // deal with defaults
    $treeName2=$thisTreeInfo['treeName'];
    $imagesDir=$thisTreeInfo['useDir'];
    $infos=doDirCachePhp($imagesDir,$adir,$treeName2,$isReinit,$action,$doResume,$timeAllowed ,$isMulti,$removeAll,$doOverwrite,$retainDesc) ;  // this does the work (in wsgallery_dirCache.php

    getJs\jsonReturn($infos);
}


// show menu of trees (to update, etc)
// Note: instead of getDirListEntry calls : directly  read (of dirlist. json)
//
if ($todo=='getAdminMenu') {

   $treeList=$_SESSION['wsGallery_treeList'];
   $treeListStatus=$_SESSION['wsGallery_treeListStatus'];

   $currentTree=trim($_SESSION['wsGallery_currentTree']);

  $infos=['content'=>'','status'=>'ok'];
  $stuff='<div style="margin:3px 3em 3px 3em;font-weight:700">The current default treeName:<tt> '.$currentTree.'</tt> </div>';
  $stuff='<div style="margin:4px 5em 4px 5em;display:none;background-color: #cbf9f9 " id="getDirAdmin_status">status messages</div>';

  $stuff.='<input type="button" value="&#10068;" title="View help on creating a directory listing" help" onClick="doHelpVu(this)" topic="dirCreateList"   class="helpButton" > ';

  $stuff.='<em>Refresh/update/create a <em>tree</em> directory list ...</em> or &hellip; <button>&#128065;&#9998;</button>';
  $stuff.=' <span style="font-size:80%">create descriptions, thumbnails, and snapshots for a directory in a tree </span>';


//   $stuff.='<div id="getAdminMenu_results" style="xdisplay:none;border:2px solid blue;margin:5px 3em 5px 3em;padding:5px"> ... </div>';

  $stuff.='<table title="Directory `tree` management" cellpadding="5" rules="rows" style="max-height:16em;overflow:auto;margin:3px 2em 4px 2em;border:3px groove cyan">';

  foreach ($treeList as $aTreeName=>$tinfo) {
     $aTreeName=trim($aTreeName);
     if (is_numeric($aTreeName) ) continue;
     $stuff.="<tr>";

     $treeDisabled=0;
     if (array_key_exists($aTreeName,$treeListStatus)) {
          if (array_key_exists('disable',$treeListStatus[$aTreeName] )) $treeDisabled=$treeListStatus[$aTreeName]['disable'];
     }

  // &#9745;&#65039; blue check,   &#127485; blue x   black x &#127367;
     if ($treeDisabled==1) {
        $disableMe='<input type="button" isDisabled="1" treename="'.$aTreeName.'" class="makeDirListDiableButton" title="Currently disabled: Click to Enable this directory tree" value="&#127367;" onClick="doDisableTree(this)">';
     } else {
        $disableMe='<input type="button"  isDisabled="0" treename="'.$aTreeName.'" class="makeDirListDiableButton" title="Currently enabled: Click to disable this directory tree" value="&#9745;&#65039;" onClick="doDisableTree(this)">';
     }
     if ($aTreeName==$currentTree)  {
       $stuff.=' <td><div style="white-space:nowrap;font-weight:700;text-decoration:underline;" title="The currently chosen tree">'.$disableMe.$aTreeName.'</div><td> ';
     } else {
       $stuff.=' <td><div style="white-space:nowrap;font-weight:700;text-decoration:underline;"  title=" ">'.$disableMe.$aTreeName.'</div><td> ';
     }

     $treeCacheDir=$tinfo['cacheTree'] ;
     if (!is_dir($treeCacheDir))  {   // this should never happen
         $stuff.='<td><span style="color:red">There is no cache directory for this tree.</span> The administrator must create it (<tt>'.$treeDir.'</tt>)';
         $stuff.='</td></tr>';
         continue;
     }
     $actualDir=rtrim($tinfo['rootDir'],'/').'/'.ltrim($tinfo['rootSel'],'/');

     $dirListJsonFile=$treeCacheDir.'/dirList.json';  // getAdminMenu direct call  -- better control of error messages
     $gotDirListJson=is_file($dirListJsonFile);

     $stuff.='<td>';               // the "create/update/refresh" tree
     if ($gotDirListJson) {            // dirlist. json (in cache dir) for this actual dir exists (in the
         $actualDirMod=filemtime($actualDir) ;
         $tt1=filemtime($dirListJsonFile);
         $updateDate=date("Y-m-d H:i",$tt1);
         if ($actualDirMod>$tt1)  {  // recent changes to actual directory -- new or removed subdir (but won't detect sub/sub dir changes
            $stuff.='<button  onClick="makeTreeDirList(this)" data-isUpdate="1"    data-treeName="'.$aTreeName.'" ';
            $stuff.=' title="There have been recent changes to the directory structure of this tree -- `update is recommended.&#010;Cache file modTime ('.number_format($tt1).') is older than actualDir  modTime ('.number_format($actualDirMod).')">';
            $stuff.='  <b>!update</b></button>';
//  feb 2022, no longer used rootDir="'.$tinfo['rootDir'].'" rootSel="'.$tinfo['rootSel'].'" stdOut="'.$tinfo['stdWwwDir'].'" ';
        } else {                        // no recent changes
            $stuff.=' <button  onClick="makeTreeDirList(this)"  data-isUpdate="1" data-treeName="'.$aTreeName.'" ';
            $stuff.='  title="No changes detected. You can `refresh` (to refresh file counts and other information).&#010;Last updated: '.$tt1.' = '.$updateDate.'">';
            $stuff.='refresh</button>';
// feb 2022, no longer used rootDir="'.$tinfo['rootDir'].'" rootSel="'.$tinfo['rootSel'].'" stdOut="'.$tinfo['stdWwwDir'].'"
         }
     } else {          // NO listing!
         $stuff.=' <button  onClick="makeTreeDirList(this)"    data-treeName="'.$aTreeName.'"  data-isUpdate="0" ';
         $stuff.='     title="No listing! To display the directories & files in this tree, you MUST create a directory list!">';
         $stuff.='<b>&#10069; Create </b></button>';
// feb 2022, no longer used   rootDir="'.$tinfo['rootDir'].'" rootSel="'.$tinfo['rootSel'].'" stdOut="'.$tinfo['stdWwwDir'].'"
     }
     $stuff.='</td>';

     $stuff.='<td>';
      if ($gotDirListJson)   {
            $stuff.='<input type="button"  treeName="'.$aTreeName.'" onClick="getDirCacheAdmin(this)"   ';
            $stuff.=' title="Select a directory, in this tree, to initialize (create thumbnails, etc)" value="&#128065;&#9998;dirs">';
      } else {        // disable the "initialize a directory" menu IF dirlist. json is out of date. Enccourate admin to update dirlist. json!
            $stuff.='<input type="button"  disabled style="opacity:0.3" treeName="'.$aTreeName.'" onClick="getDirCacheAdmin(this)"   ';
            $stuff.=' title="dirList is out of date: When this tree`s  directory list is updated, on can then initialize its directories (create thumbnails, etc)" value="&#128065;&#9998;dirs">';
       }
     $stuff.='</td>';


     $stuff.='<td><div style="font-size:85%;font-style:oblique">'.$tinfo['desc'].'</div></td>';

     $stuff.='<td><div style="font-size:85%">';
     if ($tinfo['stdWwwDir']==1) { // stdout
        $stuff.='<span style="font-family:monospace;" title="This IS the root directory for this domain"> '.$tinfo['rootDir'].' </span>';
     } else {
        if ($tinfo['underStdWwwDir']==1) { // stdout
          $stuff.='<span style="font-family:monospace;" title="This is under the root directory for this domain (recommendation: change treelist.php!)"> &#9887; '.$tinfo['rootDir'].'</span>';
       } else {
            $stuff.='<span style="font-family:monospace;" title="This is OUTSIDE of  the root directory for this domain"> &#9888; '.$tinfo['rootDir'].'</span>';
       }
     }
     $stuff.='</div></td>'  ;
     $stuff.='<td><div style="font-size:80%">'.$tinfo['rootSel'].'</div></td>';


     if ($gotDirListJson)  {
       $jj1=file_get_contents($dirListJsonFile);
       $stuff3=json_decode($jj1,true);
       $baseI=$stuff3[1]['.'];
       $aDisabled= ($baseI['disabled']>0) ? '#disabled='.$baseI['disabled']  : '';
       $partiallyDisabled= ($baseI['partiallyDisabled']>0) ? ' #partiallyDisabled='.$baseI['partiallyDisabled']  : '' ;

       $stuff.='<td><div style="font-size:80%;overflow:auto;height:2.3em">  <tt>'.$baseI['totDirs'].' </tt>dirs ';
       if ($aDisabled!='' || $partiallyDisabled!='' )$stuff.=" ($partiallyDisabled $aDisabled) ";
       $stuff.=' w/<tt>'.$baseI['totFiles'].'</tt> files  (<tt>'.$baseI['totImages'].'</tt> images)</div></td>';
     }
     $stuff.='</tr>';
  }
  $stuff.='</table>';

  $infos['skipSubDirs']=$_SESSION['wsGallery_skipSubdirs']  ;
  $infos['content']=$stuff ;
  $infos['treeUse']=$aTreeName ;
  getJs\jsonReturn($infos);
}     // getAdminMenu



// read the dirlist. json for   a tree -- admin mode menu of trees (to update, etc). Returns html table, list of dirs, basics
// read dirlist. json directly (insteads of use getDirListEntry) -- to catch out of date files
if ($todo=='getDirCacheAdmin') {

  $atree=extractRequestVar('treename','');
  if ($atree=='')    getJs\jsonReturnError('getDirCacheAdmin error: no tree specified');

  $thisTreeInfo=getTreeInfo($atree) ;     // error exit if no such tree

  $useTree=$thisTreeInfo['treeName'];
  $treeCacheDir=$thisTreeInfo['cacheTree'];

  $dirListJsonFile=$treeCacheDir.'/dirList.json';   // getDirCacheAdmin direct call  -- better control of error messages
   if (!is_file($dirListJsonFile)) {        // shluld not happen
       getJs\jsonReturnError("$useTree problem:  $dirListJsonFile cacheFile is unavailable");
   }
  $dirListJsonFileMod=filemtime($dirListJsonFile);
  $dirListJsonFileModView=date("Y-m-d H:i",$dirListJsonFileMod);

  $actualDir=rtrim($thisTreeInfo['rootDir'],'/').'/'.ltrim($thisTreeInfo['rootSel'],'/');
  $actualDirMod=filemtime($actualDir) ;
  $actualDirModView=date("Y-m-d H:i",$actualDirMod);

  if ($actualDirMod>$dirListJsonFileMod)  {  // recent changes to actual directory -- new or removed subdir (but won't detect sub/sub dir changes
    $res=['status'=>'ok','basics'=>'oof1'];
    $asay="The directory structure of  tree (<tt>$actualDir</tt>  changed ($actualDirModView)-- the dirList. json <em>cache file</em> is ";
    $asay.=" <b>out of date</b> ($dirListJsonFileModView). You should <button onClick=\"wsurvey.flContents.onTop('admin',1)\">!update</button> (or refresh) the directory list for this tree.";
    $res['content']=$asay;
    getJs\jsonReturn($res);
  }

  $jj1=file_get_contents($dirListJsonFile);
  $stuff3=json_decode($jj1,true);
  $useDirs=$stuff3[1] ;        // the dirlist is useable. [0] is the non-admin list of driectorues -- not used for this "admin mode"

  $t1=makeDirList_create_dirsTableHeader($useTree,1) ;
  $t2=makeDirList_create_dirsTable($useDirs,0,1);


  $basics=[];
  $basics['totDirs']=$useDirs['.']['totDirs'];
  $basics['treeName']=$useDirs['.']['treeName'];
  $basics['totFiles']=$useDirs['.']['totFiles'];
  $basics['totImages']=$useDirs['.']['totImages'];
  $basics['disabled']=$useDirs['.']['disabled'];
  $basics['partiallyDisabled']=$useDirs['.']['partiallyDisabled'];
  $basics['desc']=$useDirs['.']['desc'];     // tree description

  $res=['status'=>'ok','content'=>$t1.$t2,'basics'=>$basics];

  getJs\jsonReturn($res);


}     //  getDirCacheAdmin


if ($todo=='updateDirDescs') {
   $treename=extractRequestVar('treename','');
   $dlist=extractRequestVar('list','');
   $lookups=[];
   foreach ($dlist as $ith=>$xx) {
       $adir=$xx[0]; $atitle=strip_tags($xx[1]);
       $lookups[$adir]=$atitle;
   }

   $useDirs=getDirListEntry('*',$treename,1);     // transformed for updateDIrDesc quicker lookup
   if (array_key_exists('.error',$useDirs))  {
       getJs\jsonReturnContent($useDirs['error']); // most likely a "no dirlist. json"
   }

   $ndid=[];
   foreach ($useDirs as  $bdirname=>$bdir) {
       if (!array_key_exists('dirname',$bdir)) continue ;
       $bdirname=$bdir['dirname'];
       if (array_key_exists($bdirname,$lookups)) {
//           $useDirs[$bdirname]['readme']=$lookups[$bdirname];
           $useDirs[$bdirname]['dirDesc']=$lookups[$bdirname];
           $ndid[]=$bdirname;
       }
   }

   setDirListEntry('**',$treename,$useDirs,0,1);     // ** to reacrate html menu -- untransform the dirlist! And okay to work with noViewable dirs

   $sfoo="<b>Descriptions</b> in $treename updated: ".implode(', ',$ndid) ;
   $sfoo.=' &boxV; <input type="button" title="Click to reload wsGallery" value="reload" onClick="location.reload(true)" > to update this tree\'s <em>directory list</em> ';

   getJs\jsonReturnContent($sfoo );
}

if ($todo='disableATree') {
   $atreename=extractRequestVar('treename','');
   $isTreeDisabled=extractRequestVar('current','');
   if ($isTreeDisabled==0) {                       // curently enabled
      $nowDisabled=1;
      $sayEnable=" disabled ";
   } else {
      $nowDisabled=0;
      $sayEnable  = ' enable ';
  }

   $dataDir=$_SESSION['wsGallery_dataDir'] ;
   $treeListJsonStatus=$dataDir.'/treeListStatus.json';

   if (!is_file($treeListJsonStatus))   getJs\jsonReturnError("Unable to find  treeListStatus (trying to change $atreename): $treeListJsonStatus " );

   $arf3=@file_get_contents($treeListJsonStatus );
   $statusStuff=json_decode($arf3, true);
   if (!array_key_exists($atreename,$statusStuff)) {  // should not happen
        $statusStuff[$atreename]=['disable'=>$nowDisabled];
    } else {
        $statusStuff[$atreename]['disable']=$nowDisabled;
   }
   $goof5=json_encode($statusStuff, JSON_UNESCAPED_UNICODE);
   $nsave=file_put_contents($treeListJsonStatus,$goof5);     // filelist.json -- won't happen if nocache  set above

   $dog=getTreeList(1) ; // a shortcut to update $_SESSION vars

   getJs\jsonReturnContent("<tt>$atreename</tt> is <b>$sayEnable</b>: (bytes written: $nsave)");

}

// ::::


print "<br>Unknown action: $todo ";
 exit;



