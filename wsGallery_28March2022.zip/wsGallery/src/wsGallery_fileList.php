<?php

use wSurvey\getJson as getJs  ;

//=======================
// functions used by wsGalleryActions.php
// Main functions:
//    doGetDirFileList  -- return files in a given diretory
 // ===================================================================

// =========================
// get a list of directories, and information about them
// ===================================================================

//=============================
// =========================
// get list of  desired files in a directory -- return as fileName buttons, or as thumbnails
// ======================

// Adir will be a "relative selector" - provided by client (along with treename). Hence, adir is relative to the rootdir and
// rootselector specified for the treename
// ihow can be 0=text buttons, or 1,2,3,4 =thmxxx (xxx=40 66 90 120)
// showfilename: What kind of file name to show in the button. Not used if dircachemode=1 (hardcoded by ihow)
// treename: what tree to look in
// adir: directory (in treename).
// dirCacheMode : used by called by dirCachePhp.
//           If 1 then make all the _button_xxx.json files (not just the one for "ihow").
//           If specified, ihow is ignored
// timeAllowed: seconds allowed before early return (resumeStatus is set for next call) -- only used if dircachemode=1
//
// note if "thumbnails": each <button>  that contains an <img> (that links to the thumbnail)
//      for filenames, each <button> just has the filename
//
// thumbnails are retrieved using  <img src="data/treeName/relSelDir/..." -- where ... depends on ahow (thm40, etc)
//  example: "data/myPhotos/june2020/thm40_bigHouse.jpg"
// iow: no need for treename, since these ponit to the data (cache) directory, which is always directly accesilb
//  (no need to resolve to an out-of-web-path file)

// dirCache call:  $stuff=doGetDirFileList(0,0,$treeName,$adir,  1,timeallowed)  ;

// resumeStatus is used to resume if time out occurred (and then a recall from js side)
//  resumeStatus is kind of useless if dirCacheMode=0 (since timeout/resume calls are NOT done). but for now it is okay


function doGetDirFileList($ihow,$showFileName,$treeName,$adir,$dirCacheMode=0,$timeAllowed=4) {

  $howSizes=[0,40,66,90,120];
  $howList=['text','thm40','thm66','thm90','thm120'];

  $nowtime=time();

  $resumeStatus=[];      // if dircachemode=0, this is a hack to "just do all the steps"

  if ($dirCacheMode==1) {
    $arf=$_SESSION['wsGallery_cacheDirStateVars'];
    if ($arf['treeName']==$treeName && $arf['dir']==$adir  ) {
        $resumeStatus=$arf['resumeStatus'];   // legit state variables, so use them
    }
  }    // on first call, resumestatus=[]

  if ($dirCacheMode==1 && $ihow!=0) getJs\jsonReturnError(" doGetDirFileList: dirCacheMode=1 but ihow!=0 ($ihow) ");   // should never happen (debug check

  if (!array_key_exists($ihow,$howList)) getJs\jsonReturnError('Bad how in  doGetDirFileList ('.$ihow.')');

// basic checks passed ..

  if (!array_key_exists('check1',$resumeStatus)) {   // check for validity

  $adirEntry=getDirListEntry($adir,$treeName) ;
  if (array_key_exists('.error',$adirEntry)) getJs\jsonReturnError($adirEntry['.error'],$adirEntry['treeList']);  // could be any of several problems

  $fullPath=$adirEntry['path'];
  $nViewables=$adirEntry['nFiles'] ; // viewable files

// if 'on the fly' (no dircache mode) make sure requested path is in requested tree, and still exists
   if ($dirCacheMode==0)  {   // do NOT check if dirCacheMode=1 (admin creation)
       if (!is_dir($fullPath))  {        // somehow this dir went away?
          $aerr= "doGetDirFileList Error:  <tt>$adir</tt> can not be found as  directory in tree ($treeName).";
          $aerr='The admin should create/update/refresh a <input type="button" value="directory list" onclick="doAdmin(1)"> for this tree. ';
          $vstuff=['status'=>'na','content'=>$aerr] ;
          return $vstuff ;
       }
       if ($nViewables==0) {            // skip if no "images"  - where images means "displayable files" (could be pdfs, txt, ...)
          $aerr= "<br>No displayable files in directory: ".$adirEntry['dirname'];
          $vstuff=['status'=>'error','content'=>$aerr];
          return $vstuff ;
      }
      $resumeStatus['check1']=$nowtime ;
    }      // dirCacheMode==0
  }      // resumestatus

  $noCache=$_SESSION['wsGallery_noCache'] ;
  $allowCache= ($dirCacheMode==1)  ? 0 : 1 ;
  $smess="  Initializing buttonLists. ";

// ::::::::
// if here, passed error tests. So   the dir exists where it should be!
// go get a list of files (that are viewable, using extensions) in this dir-- with seleector info for each file

  $ahow=$howList[$ihow];
  $aheight=$howSizes[$ihow];$awidth=$howSizes[$ihow];

   $fileStatVars=['size','time','date','desc','width','height','mimetype' ];
   $fileStatVars2 =['desc','fullSel'];

//create, or read from cache, a list of files in this dir (with info on each file)

  if (!array_key_exists('fileListGot',$resumeStatus)) {  // create, or reada from cache, the filelist-- if allowCache=0, do NOT read from cache. if 2, only read from cache (dirCache mode) -- do not create, do not save
     $fileListGot=get_fileListCache($fullPath,$treeName,$allowCache) ;
     if ($fileListGot['status']=='error') getJs\jsonReturnError($fileListGot['content'],$fileListGot);  // could not even be created
     $fileCacheModTime=$fileListGot['modTime'];
     if ($noCache!=1) {
         $cacheDir=$fileListGot['pathSelectorInfo']['cacheDir'];
      } else {
         $cacheDir='';
     }
     if ($dirCacheMode==1) {
       $resumeStatus['fileListGot']=$fileListGot;
       $resumeStatus['cacheDir']=$cacheDir;
       $resumeStatus['fileCacheModTime']=$fileCacheModTime;
       $checkTime=time();
       if ($checkTime-$nowtime >= $timeAllowed) {
           $arf['resumeStatus']=$resumeStatus;
           $_SESSION['wsGallery_cacheDirStateVars']=$arf;
    //       getJs\jsonReturnError("arf ",$arf);
   // print " xxx  $fileCacheModTime ";
           return ['tuba'=>$fileCacheModTime,'status'=>'ok','content'=>"Completed: <em>discovering files ...</em> (in $adir of $treeName)",'doResume'=>1];  // fileListGot =lsit of files, including basic path info
       }  // timeout
     }  // dircachemode=1

  } else {     // never get here if dircachemode=0, since resumeSTatus is always []
      $fileListGot=$resumeStatus['fileListGot'] ;
      $cacheDir= $resumeStatus['cacheDir']  ;
      $fileCacheModTime= $resumeStatus['fileCacheModTime']  ;
  }      //resumeStatus

// Is there a not out of date cache of buttons ? If so, use it for the buttonList   -- but not if  dircCacheMode=1 (dirCache mode) !
  $gotButtonCache=0;   // 0 signals "create the buttons" (do NOT read from cache)
  $buttonList=[];
  $buttonCacheFile='';

  if (!array_key_exists('buttonList',$resumeStatus)) {
    $gotButtonCache=0;   // 0 signals "create the buttons" (do NOT read from cache)
    $buttonList=[];
    $buttonCacheFile='';
    $resumeStatus['buttonListFromCache']=0;
    if ($cacheDir!='' && $noCache!=1) {        // cache read okay
      $buttonCacheFile=$cacheDir.'/_buttonList_'.$ahow.'.json' ;    // could be text, or thumbnail, buttons
      if ($dirCacheMode==0 && is_file($buttonCacheFile)) {            // cache file exists, and not dirCache mode
        $buttonMod=filemtime($buttonCacheFile);
        if ($buttonMod>=$fileCacheModTime) {               // button file later than filelist. That's good!
           $b0=file_get_contents($buttonCacheFile);  // So read from the cache!
           $buttonList=json_decode($b0,true);
           $smess.=" |a $ahow= ".count($buttonList) ;
           $gotButtonCache=count($buttonList);   // no 0 value means 'buttons were read from cache'
           if ($dirCacheMode==1) $resumeStatus['buttonListFromCache']=$nowtime;
        }
      }   // dircache mode=0 and cacheFile (for these buttons) exists
    }   // cachdir!=''

    if ($dirCacheMode==1) {
      $resumeStatus['smess']=$smess ;
      $resumeStatus['gotButtonCache']=$gotButtonCache;
      $resumeStatus['buttonList']=$buttonList;
      $resumeStatus['buttonCacheFile']=$buttonCacheFile ;
      $checkTime=time();
      if ($checkTime-$nowtime >= $timeAllowed) {
           $arf['resumeStatus']=$resumeStatus;
           $_SESSION['wsGallery_cacheDirStateVars']=$arf;
           return ['status'=>'ok','content'=>"Completed: <em>reading buttonList from cache</em> ($adir of $treeName)",'doResume'=>1];  // fileListGot =lsit of files, including basic path info
       }  // timeout
    }   // $dirCacheMode==1

  }  else { //  buttonList resumstatus
      $smess=$resumeStatus['smess'] ;
      $gotButtonCache=$resumeStatus['gotButtonCache'] ;   // 0 signals "create the buttons" (do NOT read from cache)
      $buttonList=$resumeStatus['buttonList']  ;
      $buttonCacheFile=$resumeStatus['buttonCacheFile'] ;
  }      //  resumeStatus

  $useThese_files2=$fileListGot['fileList'];  // used to create buttons, and to extract fileStats

// recrearte filestats, don't just use cached...
  $dirDesc=$adirEntry['dirDesc'];  // feb 2022 : readme should be changed to dirDesc

  if (!array_key_exists('fileStats',$resumeStatus)) {
     $fileStats=[];$messageTop='';
     $relSelLookupTable=$fileListGot['relSelLookup'];
     foreach ($relSelLookupTable as $aRelSel=>$ith1) {     // selector name to index into useThese_Files2
        $a1=$useThese_files2[$ith1];            // location of arelsell (numeric index) in filelistgot
        $aInfo=$a1['fileInfo'];
        $fileStats[$aRelSel]=[] ;
        foreach ($fileStatVars as $igoo=>$avar1) $fileStats[$aRelSel][$avar1]= $aInfo[$avar1];  // from fileInfo sub array
        foreach ($fileStatVars2 as $igoo=>$avar1) $fileStats[$aRelSel][$avar1]= $a1[$avar1];   // from main array
     }
     if ($dirCacheMode!=1) {
         $messageTop=doGetDirFileList_header($treeName,$adir,$dirDesc) ; // write the control bar header (html). Not needed if "dirCache" call

     } else {   // dircache mode =1
        $resumeStatus['fileStats']=$fileStats;
        $resumeStatus['messageTop']=$messageTop;
        $checkTime=time();
        if ($checkTime-$nowtime >= $timeAllowed) {
           $arf['resumeStatus']=$resumeStatus;
           $_SESSION['wsGallery_cacheDirStateVars']=$arf;
           return ['status'=>'ok','content'=>"Completed: <em> create filestats</em>  ($adir of $treeName)",'doResume'=>1];  // fileListGot =lsit of files, including basic path info
        }  // timeout
     }    // dirCacheMode=1

  } else {     // fileStats resumestats
      $fileStats=$resumeStatus['fileStats'] ;
      $messageTop=$resumeStatus['messageTop'] ;
  }   // resumeStatus

// If not read from cache, make the buttons (and store to cache)
//  Buttons can be text, or one of the several thummbnail sizes

 // $gotButtonCache=0 if no cached buttonlist for this dir. so create a buttonlist. ANd save if caching allow3ed
   if (!array_key_exists('buttonListMade',$resumeStatus)) {
     if ($gotButtonCache==0   ) {
        $buttonList=doGetDirFileList_makeButtons($useThese_files2,$ahow,$aheight,$awidth,$showFileName );
        $dbuttons=json_encode($buttonList, JSON_UNESCAPED_UNICODE);
        if ($noCache!=1 && $buttonCacheFile!='') file_put_contents($buttonCacheFile,$dbuttons);  // buttonCacheFile set above -- won't get here if noCache

        if ($dirCacheMode==1) {
           $resumeStatus['gotButtonCache']= $gotButtonCache=count($buttonList);  // already check for this, so just save it
           $resumeStatus['buttonList']=$buttonList;
           $resumeStatus['buttonListMade']=$nowtime;
           $checkTime=time();
           if ($checkTime-$nowtime >= $timeAllowed) {
             $arf['resumeStatus']=$resumeStatus;
             $_SESSION['wsGallery_cacheDirStateVars']=$arf;
             return ['status'=>'ok','content'=>"Completed: <em>save $ahow buttons to cache</em> ($adir of $treeName)",'doResume'=>1];  // fileListGot =lsit of files, including basic path info
          }  // timeout
        }  // dircachmoe

     }  // got button cache
   }    // buttonlistmade

// if here, might of skipped above
   $resumeStatus['buttonListMade']=$nowtime;

   if ($dirCacheMode!=1)  {    // Not dircachemod? Then done -- return results (possibly pulled from cache)
//      $daSpecs=$_SESSION['wsGallery_specsExts'];       $otherExtsSpecs=$daSpecs['otherExtsSpecs']; // feb 2022 : no lonter need to return to js
      $vstuff=['status'=>'ok',                            // 'otherExtsSpecs'=>$otherExtsSpecs,
            'dir'=>$adir,'treename'=>$treeName, 'cacheMessage'=>$fileListGot['cacheMessage'],
           'content'=>'Using ... '.count($buttonList).' file buttons','messageTop'=>$messageTop,
           'fileStats'=>$fileStats,'buttonList'=>$buttonList,
           'dirDesc'=>$dirDesc ,'gotButtonCache'=>$gotButtonCache];

      return $vstuff ;
   }


// If here, in dirCache mode?
// Then also create the thumbnails button cache files .. but don't bother if nocache (or if no cachedir)

  if ($cacheDir=='' || $noCache==1)  return ['status'=>'ok','doResume'=>0,'content'=>'No cacheDir available, so no buttonList or filelist saved','fileList'=>$fileListGot];  // fileListGot =lsit of files, including basic path info

// if here, caching allowed   -- so do the dircache mode actions (of creating all 4 of the cached button lists
  $showFileNames=[2,0,1,2,2];   // text,small,medium,big,bigger. 0=no, 1=snippet,2=full
   for ($jhow=1; $jhow<4;$jhow++) {
      $awidth2=$howSizes[$jhow]; $aheight2=$howSizes[$jhow];
      $ahow2=$howList[$jhow];

      $showFileName2=$showFileNames[$jhow];
       if (!array_key_exists('buttonCacheFile2_'.$ahow2,$resumeStatus)) {
         $buttonList2=doGetDirFileList_makeButtons($useThese_files2,$ahow2,$aheight2,$awidth2,$showFileName2,$dirCacheMode );
         $smess.=" | $ahow2= ".count($buttonList2) ;
         $dbuttons2=json_encode($buttonList2, JSON_UNESCAPED_UNICODE);
         $buttonCacheFile2=$cacheDir.'/_buttonList_'.$ahow2.'.json' ;
         file_put_contents($buttonCacheFile2,$dbuttons2);  // buttonCacheFile set above -- won't get here if noCache
         $resumeStatus['buttonCacheFile2_'.$ahow2]= $buttonCacheFile2;
         $resumeStatus['smess']= $smess;
        $checkTime=time();
         if ($checkTime-$nowtime >= $timeAllowed) {
            $arf['resumeStatus']=$resumeStatus;
            $_SESSION['wsGallery_cacheDirStateVars']=$arf;
            return ['status'=>'ok','content'=>"Completed: <em>saving $ahow2 buttons to cache</em> ($adir of $treeName)",'doResume'=>1];  // fileListGot =lsit of files, including basic path info
        }  // timeout


       } else {
          $smess=$resumeStatus['smess'];
       }     // resumstatus
   }  /// jhow


// success!
   return ['status'=>'ok','content'=>$smess,'fileList'=>$fileListGot,'doResume'=>0];  // fileListGot =lsit of files, including basic path info

}

//======================
//==============
// create list of buttons (for retrieveing files). Button content may be text, or thumbnail
// dircachemode=1 limits actoins -- no creation of thumbnails (but do create buttonLists)

function doGetDirFileList_makeButtons($useThese_files2,$ahow,$aheight=66,$awidth=66,$showFileName_2=2,$dirCacheMode=0 ) {
    $daSpecs=$_SESSION['wsGallery_specsExts'];
   $imgExts=$daSpecs['imgExts']; $imgExts_lookup=makeLookupTable($imgExts);

   $buttonList=[];

//   $curDir=getCwd();   // used in thumbnail createion (for generic icons)
  $wsMainDir=$_SESSION['wsGallery_mainDir'];

   foreach ($useThese_files2 as $app) {      // :::::::::::::::

     $treeName=$app['treeName']; // provied by returnSelector (perhaps as saved in a cache file)
     $aFullSel=$app['fullSel']; $aselRel=$app['relSel'];
     $aName=$app['relSelFile'];
     $aNameBase=$app['relSelFileName'];
     $aExt=$app['relSelFileExt'];
     $stdWwwDir=$app['stdWwwDir'];

     $aExtLc=strtolower($aExt);
     if (array_key_exists($aExtLc,$imgExts_lookup)) {    // this extension should be noted as an image file   -- by isNotImg=''  or '0'
         $isLink='isNotImg="" ' ;
         $isLinkArg='isNotImg=0';
         $gotNotImg=0;
     } else {
         $isLink='isNotImg="'.$aExtLc.'"' ;    // displayable, but not as an image file  -- note its extension
         $isLinkArg='isNotImg='.$aExtLc ;
        $gotNotImg=1;
     }

     if ($ahow=='text') {         // filenames used in <input button
       $daButton='';
       $daButton.='<button  '.$isLink.' class="buttonSnapshot"  ';
       $daButton.='  file="'.$aFullSel.'" treename="'.$treeName.'" stdWwwDir="'.$stdWwwDir.'"    name="listOfFileInCurrentDir_button" >'; // dog=fido
       $daButton.= $aName;           // could add info here in a <span>?
       $daButton.='  </button>';
       $buttonList[]=[$daButton,$aName] ;

     } else {          // thumbnails :  using a direct link to cached file (create if need be)

       $alink0=createThumbNailLink($app,$ahow,$wsMainDir,$imgExts_lookup,$dirCacheMode);
       $alink=$alink0[0]; $amethod1=$alink0[1];
       $imgUse='<img status="'.$amethod1.'"  alt="thumbnail of '.$aselRel.'" src="'.$alink.'" height="'.$aheight.'" width="'.$awidth.'">';

       $daButton='';
       $daButton.='<button  '.$isLink.' stdWwwDir="'.$stdWwwDir.'"  class="buttonSnapshot"   name="listOfFileInCurrentDir_button"    '; // dog=rover
       $daButton.='   name="listOfFileInCurrentDir_button"   file="'.$aFullSel.'" treeName="'.$treeName.'" title="display '.$aselRel.'">';

       $divWidth=intVal($awidth)+10; // how much space to use to display file name

       if ($showFileName_2==2) {                      // also display file info above the button (small or smaller amount)
           $daButton.='<div style="font-size:75%;height:1em;width:'.$divWidth.'px;overflow:hidden">'.$aName.'</div>';       // not as compressed
       } else if ($showFileName_2==1) {        // compressed version of filename
           $daButton.='<div style="font-size:60%;height:1em;width:'.$divWidth.'px;overflow:hidden">'.$aNameBase.'</div>';
       } // else, don't show filename

       $daButton.=$imgUse;
       $daButton.='</button>';
       $buttonList[]=[$daButton,$aName] ;

     }         // getDirFileList

  }      // :::::::: dsethesefiles2 :::::::::::::::

  return $buttonList;
}

//======================    fileListGot

// create a link for use in an img, that connects to a cached file. Could be a generic icon
// ahow: thm40,thm66,thm90
// if caching allowed, save a newly created thumbnail to cache dir.
function createThumbNailLink($app,$ahow,$wsMainDir,$imgExts_lookup=[],$dirCacheMode=0) {
   if (count($imgExts_lookup)==0) {
      $daSpecs=$_SESSION['wsGallery_specsExts'];
      $imgExts=$daSpecs['imgExts']; $imgExts_lookup=makeLookupTable($imgExts);
   }

   $qBuildMode=false;   // If no cacheDIr (For this file). true for warning icons, not generic icons (useful for debuggin)

   $onTheFly=$_SESSION['wsGallery_onTheFlyThumbnails'] ;   // 0 or 1 : 0 to suppress (use generic icons if no cached thumbnail)
   $noCache=$_SESSION['wsGallery_noCache'];

   $cacheDir=$app['cacheDir'];   // '' if no caching of files in this directory. Maybe because of   $_SESSION['wsGallery_noCache']=1  (so kind of redundant)
   $cacheDirSel=$app['cacheDirSel'];

   $prefixesSizes=[ 'thm40'=>40,'thm66'=>66,'thm90'=>90,'thm120'=>120];    // not used if text
   if (!array_key_exists($ahow,$prefixesSizes)) getJs\jsonReturnError("bad size ($ahow) ",$prefixesSizes);

   $aprefix=$ahow.'_';
   $dasize=$prefixesSizes[$ahow];     // size of image to crate for use as thumbnail

   $iconDefault='icons/aFile.jpg';                // if everything else fails
   $iconNoFile='icons/aRedX.jpg';                // if everything else fails
   $iconDir=$wsMainDir.'/icons';

   $origFile=$app['origPath'];    // the file to use when creating a new thumbnail
   if (!is_file($origFile)) {    // should never happn
     return [$iconNoFile,'missing file'] ;               // warning that file does not exist
  }

// original file exists.  ?  if onthefly not enabled, and no caching... send a generic (or warning) icon
   if ($onTheFly!=1 && $dirCacheMode!=1) {   // ignore on the fly restriction if dircache mode
    if ($noCache==1 || $cacheDir=='' ) {      // no cache dir (for this dir that this file is in). Use a generic icon (perhaps size specific)
       if ($qBuildMode) {
           $aicon='icons/aWarning.jpg';         //    return a warning as alert to admin
           return [$aicon,'No cacheDir'];
       } else {
           $aicon = createThumbNailLink_icon($app,$aprefix,$wsMainDir) ;  // find an extension specific generic
           return [$aicon,'No cacheDir '] ;
       }
    }            // no cache dir
  }  // on the fly

// if here, on the fly enabled. But if not disallowed, try to use from cache

// Note: onTheFlyThumbnail  = 0  means create a thumbnail on the fly each time it is requested (if can't look /save in cache)
// Not recommended!

  $origFile=$app['origPath'];    // the file to use when creating a new thumbnail
  $treeName=$app['treeName'];
  $relSel=$app['relSel'];
  $relSelDir=$app['relSelDir'];
  $fileName=$app['relSelFile'];
  $aext=strtolower($app['relSelFileExt']);
  $fileNameNameOrig=$app['relSelFileName'];
  $fileNameName=strtolower($app['relSelFileName']);

// caching allowed, and cache file exists? send a link to it!
  if ($cacheDir!='' && $noCache!=1)  {  //  Note all cached versions have .jpg extension, with fileName_ext (_ext) as original extension
    $lookfor3a=$aprefix.$fileNameNameOrig.'_'.$aext.'.jpg' ;    // move extension to _xxx suffix of original name. since all cached thumnbails are jpg
    $lookfor3=$cacheDir.'/'.$lookfor3a  ;  // physical file exists in cache (all thumbnails must be .jpg ?
    if (is_file($lookfor3)) {          // cache exists for this file's thumbnail (of this size). Use it (via a relative selector to cache location
      $aicon=$cacheDirSel.$lookfor3a ;
      return  [$aicon,'Cached thumbnail'];
    }
  }

// no cache exists for this file. (or caching not alloswed)
// Create a thumbnail and save for future cachhe use (or just send it if noaching). If not image file, use a generic icon as thumbnail

  if (array_key_exists($aext,$imgExts_lookup )===false)  { // not a supported extension (for creating thumbnails). ANd not in cache
        $aicon = createThumbNailLink_icon($app,$aprefix,$wsMainDir) ;       // a generic icon
        return [$aicon,'Thumbnails not available for this mimetype'] ;
  }

  if ($onTheFly==0 && $dirCacheMode!=1 )  { // no cache, but onTheFly not allow3ed. Send generic icon
        $aicon = createThumbNailLink_icon($app,$aprefix,$wsMainDir) ;       // a generic icon
        return [$aicon,'On-the-fly thumbnails disabled '] ;
  }

// else, an ext that can be resized to be a thumbmnail, and on the fly allowed
// Note that if no caching on the fly returns a link to create the icon "on the fly".

  if ($dirCacheMode==0) {    // dirCacheMode is special -- it does NOT create thubnails when it calls here -- it just wants buttonlists
     if ($cacheDir!='' && $noCache!=1) {
       $bytes1=imageResizerFile($origFile,$dasize,$dasize,45,$lookfor3,1) ; // caching okay. so CREATE this thumbnail (and save in cache dir)! (45 is quality). Save as a jpg
       if ($bytes1===false || $bytes1<1)  {   // problem creating ... send a question mark to signal there is an issue (rather than a generic icon)
           $_SESSION['wsGallery_errors'][]='createThumbNailLink: unable to create thumbnail file in '.$lookfor3 ;
           $aicon='icons/aQuestion.jpg';
           return [$aicon,'Problem creating thumbnail'] ;
        }
        $aicon=$cacheDirSel.$lookfor3a ;
        return [$aicon,'Thumbnail created and cached'] ;

     } else {  // no cache. but on the fly enabled (if not, would of been  caught abouve)
        $aicon="wsGalleryActions.php?todo=getResizedImage";
        $aicon.="&file=$relSel&how=$ahow&width=$dasize&height=$dasize&tree=$treeName"   ;
        return [$aicon,'Thumbnail not created -- on the fly link provided'] ;
     }
  }  else {                   // direcache mode just makes <img..> for buttons, doesn't try to create thumbnail files That's for later step in dirCache
      $aicon=$cacheDirSel.$lookfor3a ;
      return [$aicon,'Thumbnail creation not attempted '] ;  // which can be a problem if  thumbnails are not created (the alt message will be shown)
  }

// should never get here
   $aicon='icons/aRedXCircle.jpg';
    return  [$aicon,'impossible!'] ;

}

//================ ahow prefix

// icon given prefix and filename (just use ext of the filename)
function createThumbNailLink_icon($app,$aprefix,$wsMainDir ) {  // find generic icon based on file extension

   $iconDefault='icons/aFile.jpg';                // if everything else fails

   $iconDir=$wsMainDir.'/icons';

   $aext=$app['relSelFileExt'];

   $aicon=$aprefix.$aext.'Icon.jpg';
   $tryFile=$iconDir.'/'.$aicon ;
   if (!is_file($tryFile))  {   // no size specific...
          $aicon=$aext.'Icon.jpg';  // non size specific
          $tryFile=$iconDir.'/'.$aicon;
          if (!is_file($tryFile)) $aicon='';
      }
      if ($aicon=='') {
         $aicon=$aprefix.'aFile.jpg';
         $tryFile=$iconDir.'/'.$aicon;
         if (!is_file($tryFile))  return $iconDefault  ;
      }

// if here, found icon to iuse!
      $iconSel='icons/'.$aicon;
      return $iconSel ;
}

//=============
// create html header for list of directories
function doGetDirFileList_header($treeName,$adir,$dirDesc) {
 $stuff='<div onselectstart ="return false" >';

 // toggle view of text in buttons
   $stuff.='<button  id="showTextInOptions" type="button" status="1" do="mainOptsText" onClick="toggleTextInFileViewerOptions(this)" ';
   $stuff.=' title="Click to toggle display of the text in this list of options">';         // status=1 means "currently displayed"
   $stuff.='<span xclass="redLineThrough" ';
   $stuff.='  <span style="color:black">&#127299; <span class="mainOptsText"> </span>';
   $stuff.='</span>' ;
   $stuff.='</button>';

// redisplay most recently clicked on file
   $stuff.='<input   value="&#10226;" id="redisplayImage" type="button" onClick="redisplayRecentImage(this)" ';
   $stuff.=' title="Click to redisplay most recently selected image, using current control options">';

// stretch shrink or asIs .. note: since start in combo mode, it starts disabled!
   $stuff.=' <span which="1" class="viewDirOptions   viewDirOptions_nocheck">';   // start in combo mode, so disabled
   $stuff.='<input  style="display:none"  onClick="toggleShrinkToFit(this)" id="shrinkToFit" type="checkbox" value="1" disabled ';
   $stuff.='  title="Fit image to viewer: toggle between asIs, stretch, shrink." >';
   $stuff.='<label id="shrinkToFitLabel" for="shrinkToFit"  ';
   $stuff.='         title="Select this to shrink the image so it will fit in a viewer.';
   $stuff.='  &#010; &#11036; `asis` :image is displayed as received from server (it will be scrollable) ';
   $stuff.='  &#010; &#9641; `stretch` :stretch image -- fills viewer, but aspect ratio is NOT retained';
   $stuff.='  &#010; &#128476; `shrink` :shrink image -- retains spect ratio, but may not fill the viewer';
   $stuff.='&#010; Note: in combo and external viewing modes, this is disabled."';
   $stuff.='>';
   $stuff.=' &#11036; <span title="Image displayed as received from server. &#010;It will be scollable" class="mainOptsText"';
   $stuff.='>asIs</span>  </label>';
   $stuff.='<span  id="iopenerShrink" > ';
   $stuff.='   <span    name="whileDropdownNotOpen"  title="mouseover to see dropdown, click to freeze it in place"   >&#9207;</span> ';
   $stuff.='   <span    name="whileDropdownOpen"  style="display:none"  title="click to close dropdown "   >&#9206;</span> ';
   $stuff.='</span> ';

   $stuff.=' </span>  ';

// info toggle
   $stuff.=' <span  which="4" class="viewDirOptions ">';
     $stuff.=' <input  onClick="toggleViewInfo(this)" style="display:none"  id="getImgInfo" type="checkbox" title=" toggle view of file info" value="1">';
     $stuff.='<label for="getImgInfo"  id="getImgInfoL"  title="  toggle view of image info">&#8505; <span class="mainOptsText">Info</span></label>';
   $stuff.=' </span>  ';

// where to display retrieved file (combon, viewer 1 or 2, extenral)
   $stuff.=' <span which="2" class="viewDirOptions  viewDirOptions_viewer">';
   $stuff.=' <input style="display:none" onClick="toggleWhichViewerGet(this)"  id="iWhichViewer" type="checkbox"  value="0" >';
   $stuff.='<label id="LWhichViewer"  for="iWhichViewer"   class="mainOptsTextSmall" ';
    $stuff.=  ' title="Toggle which viewer to use. You can toggle between several modes: ';
   $stuff.='    &#010; &#74787; combo --  display in   viewers 1 and 2   ';
   $stuff.='    &#010; &#128437; viewer &#9312;  --  display in viewer 1';      // &#9461;
   $stuff.='    &#010; &#128437; viewer &#50;&#65039;&#8419; --  display in viewer 2';  // 9462
   $stuff.='    &#010; &#128468; external --  display in external viewer (new window)" ';
   $stuff.='>';
   $stuff.=' &#74787; <span title="Combo mode: file displayed in viewer 1 and in viewer 2.&#010;Clicking on viewer 1 auto-scrolls viewer 2 to same location " ';
   $stuff.='            id="iWhichViewerB">combo</span></label>';
   $stuff.=' </span>  ';
   $stuff.=' <span id="iautoLoadExternal"  style="display:none" class="cautoLoadExternal"> ';    // displayed if external viewer
   $stuff.='<input type="button" value="Auto load external" title="click here to tell the external viewer to load its file" onClick="doAutoLoadExternal(this)" >';
   $stuff.='</span>';
   $stuff.='<span  id="iopenerWhichViewer" > ';
   $stuff.='   <span    name="whileDropdownNotOpen"  title="mouseover to see dropdown, click to freeze it in place"   >&#9207;</span> ';
   $stuff.='   <span    name="whileDropdownOpen"  style="display:none"  title="click to close dropdown "   >&#9206;</span> ';
   $stuff.='</span> ';

// size of image to get from server. 1=full,2=snapshot,3=custom (if custom, Width and Height are asked for)
   $stuff.=' <span  which="7" class="viewDirOptions  viewDisrOptions_viewer">';
     $stuff.=' <input style="display:none"  id="getSnapshotImage" type="checkbox"  value="1" ';
     $stuff.='       onClick="toggleSnapshotGet(this)" title="Toggle between retrieving full image, snapshot (640x480), and custom size" >';
     $stuff.='<label for="getSnapshotImage" class="mainOptsTextSmall" ';
     $stuff.=' title="Toggle between retrieving &#11034;full image,  &#12276; snapshot (640x480), and &#12275; custom size (WxH)">';
     $stuff.='&#11034;F<span class="mainOptsText">ullImage</span></label>';
   $stuff.='<span  id="iopenerGetSnapshot" > ';
   $stuff.='   <span    name="whileDropdownNotOpen"  title="mouseover to see dropdown, click to freeze it in place"   >&#9207;</span> ';
   $stuff.='   <span    name="whileDropdownOpen"  style="display:none"  title="click to close dropdown "   >&#9206;</span> ';
   $stuff.='</span> ';
   $stuff.=' </span>  ';

// display thumbnails     &#128402; &#128073;
   $stuff.=' <span which="5" class="viewDirOptions">';
   $stuff.=' <input id="listWiththumbnails" type="checkbox" style="display:none"  title="View thumbnails instead of filenames" value="1" ';
   $stuff.=' onClick="$(\'#divListWiththumbnails\').toggle() " >';
   $stuff.='<label for="listWiththumbnails"  title="View thumbnails instead of filenames ">&#128443; <span class="mainOptsText mainOptsTextSmall">Thumbnails</span></label>';
   $stuff.='</span>';

// slideshow
   $stuff.=' <span which="6" class="viewDirOptions ">';
   $stuff.=' <input id="doSlideShow" type="checkbox" title="View a slideshow" value="1" ';
   $stuff.=' onClick="$(\'#divDoSlideShow\').toggle() " >';
   $stuff.='<label for="doSlideShow"  title="View a slideshow (several versions). &#010;Unclick to stop a slideshow">&#127902;&#65039;  <span class="mainOptsText mainOptsTextSmall">Slideshow</span></label>';
   $stuff.='</span>';

// layout of file retrieveal buttons (continuouse (wrapped) list, longer list (with info), table (more info)
   $stuff.=' <span which="61"    >';
   $stuff.=' <button  id="ichooseFileListType"  value="1" how="1"   onClick="chooseFileListType(this)"  ';
   $stuff.='          title="Toggle method of displaying the file list" >';
   $stuff.='  &#128466;&#65039; <span class="mainOptsText mainOptsTextSmall" style="width:5em">buttons</span> ';
   $stuff.='</button>';
   $stuff.='</span>';

// get next / prior file
   $stuff.=' <button title="view &larr; prior, or &rarr; next, image file"  style="font-size:75%;background-color:#dfdfef;margin:3px 3px 3px 1em" ';
   $stuff.='     id="iNextPriorImageButtons"  > ';
   $stuff.='  <input type="button" value="&#129092;" do="-1" title="Prior image file (non-image files are skipped)" onClick="doSlideShowNext(this)" >';
   $stuff.='<span class="mainOptsText">prior&vellip;next</span>';
   $stuff.='  <input type="button" value="&#129094;"  do="1" title="Next image file (non-image files are skipped)" onClick="doSlideShowNext(this)" >';
   $stuff.='</span>';

   $stuff.='</div>';

// custom w x h  menu
  $stuff.='<div  id="customSize_WxH" style="display:none" class="viewDirOptionsMoreLime">  &hellip; Select width and height for custom size  &hellip; ';
   $stuff.=' Width  <input type="text" onChange="toggleSnapshotGet_wh(this)" which="Width" defVal="1024" id="customSize_width" size="5" value="1024"  ';
   $stuff.='         size="5" value="1024" title="Enter a width (in pixel). If blank, use 1024">';
   $stuff.='  <span title="click to calculate a 4/3 (w/h) aspect ratio (using current width)" onClick="toggleSnapshotGet_wh(this)" which="calc" s';
   $stuff.='       style="border-bottom:2px inset blue;font-weight:700"> x </span> ';
   $stuff.='  Height  <input type="text"  onChange="toggleSnapshotGet_wh(this)" defVal="768" which="Height"  id="customSize_height" ';
   $stuff.='           size="5" value="768"  title="Enter a height (in pixel). If blank, use 768">';
   $stuff.=' <button  onClick="toggleSnapshotGet_wh(this)" which="save">&#127383; Use these! </button>';
   $stuff.='</div>'   ;


// thumbnails   menu
   $stuff.='<div  id="divListWiththumbnails" class="viewDirOptionsMore">  &hellip; Display list of images with &hellip; ';
   $stuff.=' <input type="button" value="none"  dir="'.$adir.'"   treename="'.$treeName.'" title="Redisplay list using filenames" how="0" onClick="getDirFileListJs(this)">';
   $stuff.=' <input type="button" value="Small" dir="'.$adir.'"  treename="'.$treeName.'" title="Redisplay list using small (40x40) thumbnails" how="1" onClick="getDirFileListJs(this)">';
   $stuff.=' <input type="button" value="Medium " dir="'.$adir.'"  treename="'.$treeName.'" title="Redisplay list using medium (65x65) thumbnails" how="2" onClick="getDirFileListJs(this)">';
   $stuff.=' <input type="button" value="Large " dir="'.$adir.'"  treename="'.$treeName.'" title="Redisplay list using  large thumbnails (90x90)" how="3" onClick="getDirFileListJs(this)">';
   $stuff.=' thumbnails ';
   $stuff.='<span id="thumbNailRetrieveNote" style="font-size:80%;font-style:oblique;padding:5px 5px 5px 1em;overflow:hidden;display:none"><span>';
   $stuff.='</div>'   ;

// slide   submenu
   $stuff.='<div  id="divDoSlideShow" class="viewDirOptionsMore"> ';
   $stuff.='<span title="last displayed image" id="divDoSlideShow_lastShown" class="cdivDoSlideShow_lastShown" > &hellip; </span> ';
   $stuff.=' <input type="button" name="viewDirOptions_slideshow" value="Random" dir="'.$adir.'" title="Randomly show images (never stops)" onClick="doSlideShow(this,1)">';
   $stuff.=' <input type="button" name="viewDirOptions_slideshow"  value="Order" dir="'.$adir.'" title="Show each image in order (stop at end)" onClick="doSlideShow(this,2)">';
   $stuff.=' Delay: <input type="text" value="2" size="4" id="doSlideShowDelay"  title="Delay (seconds) between slides" > ';
   $stuff.=' &boxV; <input type="checkbox" id="doSlideShowImageFilesOnly" checked value="1" dir="'.$adir.'" title="Image files only"  >';
   $stuff.=' <label for="doSlideShowImageFilesOnly" title="If checked, only display images files in the slidedhow">Image files  only</label>';
   $stuff.=' <span id="doSlideShow_fileCt" style="font-family:monospace;font-size:90%">...</span>';
   $stuff.='<span style="float:right">';
   $stuff.=' &boxV; <input type="button" value="&#10068;"   title="Help: slideShow" topic="slideShows" onclick="doHelpVu(this,1)"  class="helpButton" >  ';
   $stuff.=' &boxv; <input type="button" value="&#129092;" do="-1" title="Prior file" onClick="doSlideShowNext(this)" > prior / next';
   $stuff.='  <input type="button" value="&#129094;"  do="1" title="Next file" onClick="doSlideShowNext(this)" >';
   $stuff.='</span >';
   $stuff.='</div>' ;

// descriptions (dir and viewed file) box
   $stuff.='<div id="dirDescriptionsOuter" style="display:none">';
   $stuff.='<table id="dirDescriptionsTable" cellpadding="4" width="95%"><tr>';
   $stuff.='<td valign="top"><input type="button" value="&#8661;" title="Toggle size of this description" onClick="toggleDirDesc(this)"></td>';
   $stuff.='<td>';
   $stuff.='<div  title="Description of this directory (`'.$adir.'` in tree `'.$treeName.'`) " id="dirDescriptions" class="dirDescriptionsC">  ';
   $stuff.=$dirDesc.'</div>';
   $stuff.='<div  title="Description of this file " id="fileDescriptions" class="fileDescriptionsC"> ... </div>  ';

   $stuff.='</td></tr></table>';
   $stuff.='</div>';
   return $stuff;
}



?>


