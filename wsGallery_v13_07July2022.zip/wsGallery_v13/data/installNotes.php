<?php

$rootdir=$_SERVER['DOCUMENT_ROOT'] ;
$nowtime=time();
$curDir=getcwd();
$webRoot=dirname($_SERVER['PHP_SELF']);
$a4a=substr($webRoot,-4);
if ($a4a=='data') $webRoot=substr($webRoot,0,strlen($webRoot)-5);


$wsgDir=dirname($_SERVER['SCRIPT_FILENAME']);
$a4=substr($wsgDir,-4);
if ($a4=='data') $wsgDir=dirname($wsgDir);
$wsGallery_version='....';
if (array_key_exists('ver',$_REQUEST)) {
   $wsGallery_version=$_REQUEST['ver'];
}
$jumpTo='';
if (array_key_exists('jump',$_REQUEST)) {
   $jumpTo=$_REQUEST['jump'];
}


// installation notes

print '<script type="text/javascript"  <script type="text/javascript" src="../libs/publicLib/jquery-3.6.0.min.js"></script> ';

print "<b>Welcome to wsGallery</b> (ver $wsGallery_version)";
$wsgDir=dirname($_SERVER['SCRIPT_FILENAME']);
$a4=substr($wsgDir,-4);
if ($a4=='data') $wsgDir=dirname($wsgDir);

$isfirst=0;
if (isset($installTxt)) {
  $isfirst=1;
  $aa = rtrim(str_replace('\\', '/', $installTxt), '/');
  print '<div style="border:1px dotted blue;padding:6px;margin:4px 2em 5px 3em"> The following administrator notes are shown the first time wsGallery is invoked.  ';
  print 'You can also view them by clicking   <button style="color:blue;border:1px solid blue" class="blueButton">Notes</button> in the &#9881;&#65039; admin settings menu. ';
  print '<br>You can also delete <tt>'.$aa.'</tt> to display this again! ';

} else {
  print '<div style="border:1px dotted blue;padding:6px;margin:4px 2em 5px 3em">Administrator notes  ';
}
print '<menu><li>For installation notes (and the disclaimer): <a href="'.$webRoot.'/readMe.txt" target="details">';
print $wsgDir.'/readMe.txt</a>';
print '<li>For setup details: <a href="'.$webRoot.'/wsGallery_readMe.txt" target="details">';
print $wsgDir.'/wsGallery_readMe.txt</a>';
print '<li><a href="'.$webRoot.'/wsGallery_vuHelp.php" target="details">On line help topics</a> ';
print '<li><input type="button" value="Security note" onClick="$(\'#securityNote\').toggle()"> ';

print '<div id="securityNote" style="margin:3px 3em 3px 3em;background-color:#dffddf;padding:5px;';
if ($isfirst==0) print 'display:none;';
print '"><input type="button" value="x" title="Close this note" onClick="$(\'#securityNote\').hide()"><b>Caution!</b>'  ;
print '<pre>';
print '  wsGallery can be setup to allow access to all the directories of an account.'."\n";
print '  That is: any file on any directory accessible by php.'."\n";
print '  Thus: if you do not control access to the directory and drive wsGallery.php is installed on'."\n";
print '       -- you should NOT install wsGallery on your web server! '."\n";
print '</pre>';
print '</div>';
print '<li title="status of wsGallery (list of galleries and tree, with error notes)" style="margin-top:0.5em"><a  href="#status" style="background-color:#dfdfdf;border:2px groove #afafaf;padding:2px">Status</a> ';

print '</menu>';
print '</div>'   ;


$tt=time();
if (isset($installTxt)) {
  $agoo=$wsgDir.'/data/install.txt';
  $asay='wsGallery first view: '.$tt;
  file_put_contents($agoo,$asay);
}

?>
There are several items -- parameter files and directories -- that should be modified by the administrator.
<div style="background-color:#eeeedd">For security reasons these files can <b>not</b> be modified using tools built into
wsGallery.</div>
That means the administrator must modify them directly -- using server-side text editors, etc.

<table border="1" width="90%">
<tr><th>What</th><th>Where</th><th>Description</th></tr>

<tr><th>Gallery directories</th>
<td>
<?php
print "Directories under <tt>$wsgDir".'/galleries</tt>';
print "<br>Currently: ";
$sGalleries=glob($wsgDir.'/galleries/*', GLOB_ONLYDIR );
$zoob=[];
foreach ($sGalleries as $a1=>$b1) {
    $dname=pathinfo($b1,PATHINFO_FILENAME);
    print '<span style="background-color:#dfdfef;margin:3px 1em 3px 1em">'.$dname.'</span>';
}


?>
</td>
<td>
wsGallery allows one to view files under a <em>gallery</em>. Each gallery contains <em>trees</em>, and
each tree contains <em>directories</em>.
<br>Each <em>gallery</em> requires its own directory  -- which the administrator must create (using tools on the server).
<br> By default, wsGallery is installed with a <tt>main</tt> gallery (that contains a  <tt>_default</tt> tree with
two sample directories).
<br>
<?php
print '  <a href="'.$webRoot.'/wsGallery_readMe.txt" target="details">More details</a> (scroll to section II)  ';
?>
 </td>
</tr>

<tr><th>Logon password</th>
<td>
<?php
$logonFile="$wsgDir/wsurvey.adminLogon_params.php";
print "<tt>$logonFile</tt>  ";
if (!file_exists($logonFile)) {
   print "<br>Logon (password) file (<tt>$logonFile</tt>) does not exist. ";
} else {
    require_once($logonFile);
    if (isset($passwordActual) && trim($passwordActual)!=='') {
        print "<br>Password is set";
    } else {
       print "<br>Password not set (or is set to empty). You must set the <tt>\$passwordActual</tt> parameter in <tt>$logonFile</tt>";

    }
}

?>
</td>
<td>
Contains the administrator password. This is the password used by the admin to logon.
<br> After logging on, the admin can then
use  <input  type="button" value="&#9881;&#65039;" title="View admin tools" >
to initialize <em>trees</em> and <em>directories</em>
</td>
</tr>

<tr>
<th>wsGallery parameters</th>
<td>
<?php
 $paramsPhp=$wsgDir.'/data/wsGallery_params.php';
 $paramsJson=$wsgDir.'/data/params.json';
 $requireLockme='n.a.';

  print "<tt> $paramsPhp</tt>";

  if (!is_file($paramsPhp)) {
       print "<br><b>Error</b>: there is no wsGallery parameters file (<tt>$paramsPhp</tt>)" ;

  } else {

     if (!is_file($paramsJson)) {
         print '<div style="background-color:yellow">data file (<tt>'.$paramsJson.'</tt>) does not exist.</div>';
     } else {
        $paramsPhp_mdate=filemtime($paramsPhp);
        $paramsJson_mdate=filemtime($paramsJson);
        if ($paramsJson_mdate<$paramsPhp_mdate) {
           print '<div style="background-color:yellow">wsGallery parameters: data file (<tt>'.$paramsJson.'</tt>) is older than specification (<tt>'.$paramsPhp.'</tt>) file.</div>';
        }
        $gooX=file_get_contents($paramsJson);
        $gooY=json_decode($gooX,true);
        if (array_key_exists('requireLockme',$gooY))  $requireLockme=$gooY['requireLockme'];
     }    // check json file
     $aa=file_get_contents($paramsPhp);
     $bb=explode("\n",$aa);

     print '<div style="max-width:50em;overflow:auto;height:12em;margin:5px 1em 5px 1em;padding:5px;background-color:#dfdfda;white-space:pre;font-family:monospace;font-size:90%">';
     foreach ($bb as $i1=>$asay) {
        $asay=trim($asay);
        if (substr($asay,0,1)==';') continue;
        print "$asay\n";
    }
     print '</div>';
  }


?>
</td>
<td>
The wsGallery parameters specification file. The defaults are usually adequate.
<br>However, some servers may not support all of the imagetypes wsGallery can work with.
In that case, you may need to edit the  <tt>imgExts</tt> parameter.

<?php
print '<br>Illustrative example of a wsGallery parameters file: <a href="'.$webRoot.'/data/viewNotes.php?view=params" target="details">';
print $wsgDir.'/data/wsGallery_params_original.php</a>';
print '</div>'   ;
?>

</td>
</tr>

<tr>
<th>List of trees<br> in <tt>main</tt> gallery</th>
<td>
<?php
    $treeStuff=getTreeStuff($wsgDir,'main');
    if ($treeStuff['status']=='error') {
       print "<b>Error: <tt>".$treeStuff['content'].'</tt>';
    } else {
       print '<div style="max-width:50em;overflow:auto;height:12em;margin:5px 1em 5px 1em;padding:5px;background-color:#dadadf;white-space:pre;font-family:monospace;font-size:90%">';
        print 'As specified in: <tt>'.$treeStuff['treeFile'].'</tt>';
        print '<p>.showTree: '.$treeStuff['default'].'<br>';
       foreach ($treeStuff['content'] as $atree=>$aspecs) {
            print '<br><span style="font-weight:800;width:15em;border:1px dotted gray;margin:7px">'.$atree.'</span>   '.$aspecs ;
       }   // foreach
     }
     print '</div>'
?>
</td>
<td>
The list of trees in the the <u>main</u> gallery.
<br>You can define one or more <em>trees</em> within a gallery.
<br>Each <em>tree</em> is the root -- directories under it will be visible to
wsGallery. And the user can select which of several trees to explore (and select  directories in a tree).

<?php
print '<br>Illustrative example of a wsGallery treeList file: <a href="'.$webRoot.'/data/viewNotes.php?view=treeList" target="details">';
print $wsgDir.'/data/wsGallery_treeList_original.php</a>';
print '</div>'   ;
?>


</td>
</tr>

<tr>
<th valign="top"><br><span id="autoCreate">Auto creating  trees</span>  (directories in a gallery)</th>

<td  valign="top">
<br><div id="lockMeFile">
<?php
  $lockmeFile="$wsgDir/data/lockme.txt";
   print "  <tt>$wsgDir/data/lockme.txt</tt>";

   if (!file_exists($lockmeFile)) print "<br> <em>does <b>not</b> currently exist</em>";
   if ($requireLockme=='n.a.') {
       print "<br>requireLockme status is unknown; probably due to a missing <tt>$paramsJson</tt>";
   } else if ($requireLockme==0) {
       print "<br>requireLockme is <b>not</b> set. Thus, <tt>$lockmeFile</tt> file is not used. ";
   } else {
       print "<br>requireLockme  <b>is</b> set. Thus, <tt>$lockmeFile</tt> file <b>is</b> used to disable auto initialization of galleries. ";
  }

?>
</div>
</td>
<td>   <br><br>
Each of the wsGaliery <tt>gallery&#39;s</tt> must be initialized. Gallery initialization creates a number of  <em>tree specific</em> subdirectory; and
creates a few <em>cache data</em> files.
<br>
wsGallery can do this automatically, after asking you to logon as an administator.
<br>However, for a bit of extra security you can disable this automatic initializaton.

<ul>

<?php
print "<li> in <tt>$paramsPhp</tt>: set the <tt>requireLockme: 1</tt> (to enable it)";
print "<li> make sure that <tt>$lockmeFile</tt> exists ";
print '</ul>';
print 'When you need to initialize a gallery. ';
print '<ul>';
print "<li> Using server-side tools: remove (or rename)   <tt>$lockmeFile</tt> ";
print "<li> Restart wsGallery ";
print "<li> wsGallery will ask for administrative logon, and then will initialize the <em>current</em> gallery. By default, the gallery is <tt>main</tt>.";
print "<li>If you have several galleries, switch to these galleries  (one at a time). wsGallery will automatically reload,";
print " and (after logging on each time) update the chosen gallery. ";
print "<li> When all your galleries have been initialized: using server-side tools create (or unrename) <tt>$lockmeFile</tt> ";
print "<li> Restart wsGallery ";
print "</ul> ";
?>
Some errors require additional steps. In particular, if a tree directory is accidentally removed, the above may not succeed 
(the required directories and data files may not be automatically created).
<table cellpadding="3"><tr><td valign="top">Solutions:</td>
<td valign="top"><menu>
<li> edit the gallery&#39;s <tt>wsGallery_treeList.php</tt> file, and save it (with a tiny change, such as adding a space somewhere).
<li>Or, remove the the gallery&#39;s  <tt>treelist.json</tt> file.
</menu>
and then reload wsGallery
</td></tr>
</table>

</td>
</tr>

<tr>
<th>
<a name="status">Status</a> </th>

<td>
<?php
//  for each gallery (a directory of /galleries)
 foreach ($sGalleries as $a1=>$b1) {
   $gname=pathinfo($b1,PATHINFO_FILENAME) ;
   print '<hr width="70%" size="3">For gallery <tt>'.$gname.'</tt>: trees (each specified in a subdirectory of <tt>';
   print $b1 .') <br>  ';

    $treeStuff=getTreeStuff($wsgDir,$gname);
    if ($treeStuff['status']=='error') {    // no treeList.php
      print '<div style="margin:3px 2em 3px 2em;background-color:yellow"><b>Error:</b> ';
      print $treeStuff['content'];
      print '</div>';
      continue ;
    }

// treelist.php exists...

   $sfiles0a=glob($wsgDir.'/galleries/'.$gname.'/*', GLOB_ONLYDIR );  // the directories in this gallery 
   $galleryDirs=[];
   foreach ($sfiles0a as $ijj=>$agallery) {
      $cgallery=pathInfo($agallery,PATHINFO_BASENAME);
      $galleryDirs[$cgallery]=$ijj;
   }

   $noCheckems=0;
   $statStuff=[];
   $statFile= $wsgDir.'/galleries/'.$gname.'/treelist.json';   // the trees currently "specified"
   if (file_exists($statFile)) {
        $dd=file_get_contents($statFile);
        $statStuff=json_decode($dd,true);
        $goose=array_keys($statStuff);
        $checkems=[];
        foreach ($goose as $ith=>$ath) {
            if (!is_numeric($ath)) $checkems[$ath]=0;
        }
   }  else {
      print '<div style="margin:3px 2em 3px 2em;background-color:yellow"><b>not</b> accessible: treelist has not been created <span style="font-size:70%">(no '.$statFile.')</span>.</div>';
      $noCheckems=1;
   }
 
// check for mismatch between treelist.php and treelist.json
   $misMatch=[];
   if ($noCheckems==0) {    // DID create checkems
     foreach ($checkems as $atree=>$ioof) {
       if (!array_key_exists($atree,$treeStuff['content'])) $misMatch[]="<u>$atree</u> specified in .json file, but not in .php file ";
     }
     foreach ($treeStuff['content'] as $atree2=>$ioof) {
       if (!array_key_exists($atree2,$checkems)) $misMatch[]="<u>$atree2</u> specified in .php file, but not in .json file ";
     }
     foreach ($treeStuff['content'] as $atree3=>$ioof) {
       if (!array_key_exists($atree3,$galleryDirs)) $misMatch[]="<u>$atree3</u> specified in .php file, but no directory exists  ";
     }

     if (count($misMatch)>0) {
        print '<div style="margin:3px 2em 3px 2em;background-color:#eeddaa">Tree specification mismatches. ';
        print '<menu><li>';
        $aoof=implode('<li>',$misMatch);
        print $aoof;
        print '</ul> ';
       print '</div>';
     }
   }   // checkems

// info on the trees
   $disStuff=[];
   $disableFile= $wsgDir.'/galleries/'.$gname.'/treelistStatus.json';
   if (file_exists($statFile)) {
        $dd=file_get_contents($disableFile);
        $disStuff=json_decode($dd,true);
   }

    foreach ($sfiles0a as $a1=>$b1) {
       $dirJsonFile=$b1.'/dirList.json';
       $gotDirJson =  file_exists($dirJsonFile)   ;
       $sfiles1=glob($b1.'/*', GLOB_ONLYDIR );
       $gname=pathinfo($b1,PATHINFO_FILENAME);
       $isDisable= (array_key_exists($gname,$disStuff)) ? $disStuff[$gname]['disable'] : 0 ;
       if (array_key_exists($gname,$statStuff)) {
          $isStd=$statStuff[$gname]['stdWwwDir'];
          $adesc=$statStuff[$gname]['desc'];
          if ($isStd==1) $gname='<u>'.$gname.'</u>';
          if ($isStd==1) {
              $adesc.= "\n Under this server's stdWwwDir.";
          } else {
              $adesc.= "\n NOT under this server's stdWwwDir.";
          }
          if ($isDisable==1) {
             $adesc.="\n Currently disabled. ";
             $gname='<span title="Desc: '.$adesc.'">'.$gname.' <span style="font-size:80%;font-family:monospace">disabled</span></span>';
             $gname='<span style="margin:2px;border:1px solid red" >'.$gname.'</span>';
          } else {
             $gname='<span title="Desc: '.$adesc.'">'.$gname.'</span>';
          }
          if (!$gotDirJson) $gname.=' <em>unitialized</em> ';
          print ' <div style="display:inline-block;background-color:#afdfef;margin:6px 1em 6px 1em;white-space:nowrap">'.$gname.' (<span title="number of directories in this tree">'.count($sfiles1).'</span> ) </div>';
       } else {   // no entry in treeList
          print ' <span title="This directory is not one of the trees -- its contents will not be accessible to wsGallery" style="background-color:#dfdfef;margin:6px 1em 6px 1em;white-space:nowrap"><span style="color:brown; ">'.$gname.'</span> (<span title="number of directories in this tree">'.count($sfiles1).'</span> ) </span>';
       }
    }  // foreach  $sfiles0a
 }   // foreach ($sGalleries


?>
</td>
<td valign="top">
<b>Key:</b>
<ul>
<?php
?>
<li><span style="background-color:yellow"><b>not</b> accessible </span> : a directory, under
<?php
 print "<tt>$wsgDir/galleries</tt> ";
?>
has no tree information-- it will not be accessible by wsGallery. See the above (auto creating trees) for a remedy.

<li><span style="background-color:#eeddaa">Tree specification mismatches.</span> : 
The specifications in wsGallery_treeList.php do not match wsGallery data.
This is usually due to a modification of a gallery&#39;s wsGallery_treeList.php, and not <em>re creating</em>
its tree information.



<li><span style="margin:5px;border:1px solid red" >treeName</span> : this tree is currently disabled
<li>  <span style="background-color:#dfdfdf;color:brown;">treeName</span> : this directory is not associated with
any of this gallery&#39;s trees
<li>treename <em>uninitialized</em> : this tree has not been initialized (it does not have a <tt>dirList.json</tt> file).
To initialize: use the  <button>&#9881;&#65039; admin tools</button>
<?php
print "<li><u>treename</u> : this tree's directories <u>are</u> under the <em>web root</em>: <tt>$rootdir</tt>";
?>
<li> <tt>(nn)</tt> : number of directories in this tree (each directory contains images and other files).
<li>Hint: mouseOver a treeName to view its description
</ul>
</tr>

</table>
    <hr>
<em>Updated 27 May 2022 </em>
<?php
 if ($jumpTo!='') {
   print '<script type="text/javascript">';
   print "\n";
   print '$(\'html,body\').animate({scrollTop: $("#'.$jumpTo.'").offset().top},\'slow\');';
   print "\n";
   print 'if ("'.$jumpTo.'"=="autoCreate") $("#lockMeFile").css({"padding":"1em","font-weight":700,"border":"2px solid blue"}) ;';
   print "\n";

   print '</script>';
 }

?>

<?php
//==========
// read treelist.php
function  getTreeStuff($wsgDir,$agallery) {

  $res=[];
  $treeFile="$wsgDir/galleries/$agallery/wsGallery_treeList.php";
  $res['treeFile']=$treeFile;
  $res['default']='';
  if (!is_file($treeFile)) {
      $res['status']='error';
      $res['content']="There is no <tt>$treeFile</tt>  ";
  } else {
    $aa=file_get_contents($treeFile);
    $bb=explode("\n",$aa);
    $contents=[];
    foreach ($bb as $i1=>$asay) {
        $asay=trim($asay);
        if ($asay=='') continue;
        if (substr($asay,0,1)==';') continue;
        $goo1=explode(':',$asay,2);
        if (substr($asay,0,1)=='.') {
            $res['default']=$goo1[1];
        } else {
           $atree=trim($goo1[0]);
           $contents[$atree]=$goo1[1];
        }
    }
    $res['status']='ok';
    $res['content']=$contents;
  }
  return $res ;
}
?>

