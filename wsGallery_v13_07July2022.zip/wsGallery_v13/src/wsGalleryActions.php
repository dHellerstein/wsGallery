<?php
session_start() ;
ob_start();

use wSurvey\getJson as getJs  ;

// -----------------------------------
// action handler for wsGallery  -- called from .js side use ajax (.get) functions
//
// Admin changeable parameters are in wsGallery_params.php,
//  what trees (directory paths) are set in wsGallery_treeList.php
//  username/password (for admin only are in wsCheckLogonParams.php
//
//  --------------------------
//todos in wsGallery_actions.php.
//  See wsGalleryActionsAdmin for admin "actions"
//
//
//getDirFileList              retrieve a list of  'displayable' files in a chosen directory.
//                            Calls doGetDirFileList (in wsGallery_fileList.php
//                            Called by getDirFileList in wsGallery.js
//
//retrieveDirList                   retreive html menu of subdirs that contain displayable (i.e.; image) files in chosen tree.
//                             These may be pulled from an existing cache file (created by makeDirLIst)
//                             retrieveDirList is called by loadTreeDirs in wsGallery_dirVUs.js
//
//switchTree                   change value of currentTree (used   the default tree if none provided.
//                             switchTree is called by  switchCurrentTree in wsGallery.js
//
// may 2022 several more !!!

//  ---------------------------------------------


$nowtime=time();
$rootdir=$_SERVER['DOCUMENT_ROOT'] ;
//$curDir=getcwd();
$wsMainDir=$_SESSION['wsGallery_mainDir'];

require_once($wsMainDir.'/libs/php/wsurvey.getJson.php');

require_once($wsMainDir.'/src/wsGalleryLibUtils.php');
require_once($wsMainDir.'/src/wsGallery_fileList.php');


  $todo=extractRequestVar('todo','');

// note: logon stuff done by generic libraries wsCheckLogon.php and wsCheckLogon.js


// ::::
// retrieve 'displayable' files in a chosen directory
if ($todo=='getDirFileList' ) {      // || $todo=='getDirFileListThumbnails') {
    $adir=extractRequestVar('dir','');        // relative dir (relative to treename rootDir/rootSel
    $atree=extractRequestVar('treename','');
    $showFileName=extractRequestVar('showFileName','0');
    $agallery=extractRequestVar('gallery','');

    $ihow=extractRequestVar('how','0');  //    0=text,1= tSmall:40,2= tMedium:65,3= tBig:90;  (perhaps later 4= tBigger:120
 
    $vstuff=doGetDirFileList($ihow,$showFileName,$atree,$adir); // make "ihow" file list just for this dir (in atree) (in wsGallery_fileList.php

    getJs\jsonReturn($vstuff);

    exit;
}

// ::::
// retreive html menu of  dirs that contain displayable (i.e.; image) files in chosen tree.
// And return the dirList associative array (one entry per dir in this tree, and some meta data on the tree)
// These may be pulled from an existing cache file (created by makeDirLIst)

if ($todo=='retrieveDirList') {

    $res=['status'=>'error','content'=>'dogs','treeSwitchMenu'=>'treeList not available'];
    $thisTree=extractRequestvar('treeName','' );    // this is semi deprecated (debug check) feb 2022
    if ($thisTree=='') getJs\jsonReturnError('retrieveDirList: no tree specified');

    $stuff2=getDirListEntry('**',$thisTree,0);     // get everything untransfomed
    if (array_key_exists('error',$stuff2)) {         // a problem
       $res['content']=retrieveDirList_errorNotice($thisTree,$stuff2['error']);
       $res['treeSwitchMenu']=get_treeSwitchMenu() ; // read from cache file
       $res['status']='na';
       getJs\jsonReturn($res);
    }

// if here, got the dirlist. json file!
     $res['status']='ok';
     $res['content']=$stuff2[0];
     $res['dirList']=$stuff2[1];
     $res['treeSwitchMenu']=get_treeSwitchMenu() ; // read from cache file
     $baseI=$stuff2[1]['.'];
     $res['basics']=$baseI; /// treeName, origPath, totFiles, totDirs, totImages, etc
     getJs\jsonReturn($res);


}     //  retrieveDirList


// ::::::::::
// change value of currentTree (used as the default tree if none provided.
if ($todo=='switchTree') {
   $priorCurrentTree=$_SESSION['wsGallery_currentTree'] ;
   $res=['status'=>'ok','content'=>''] ;
   $useTree=extractRequestVar('treeName','') ;

   $thisTreeInfo=getTreeInfo($useTree) ;  // check that useTree exists    -- exits with error if it does not

   $_SESSION['wsGallery_currentTree']=$useTree;
   $res['content']='The current tree is now:'.$useTree.' (prior value='.$priorCurrentTree.')';
   getJs\jsonReturn($res);
}

// ::::::::::::::
// get lsit of galleries
if ($todo=='galleryList') {
  $d1=str_replace('\\','/',$wsMainDir);
  $nowGallery=extractRequestVar('nowGallery','');
  $galleriesDir=$d1.'/galleries';
   $subdirList = glob($galleriesDir . '/*' , GLOB_ONLYDIR);
   $alist=[];
   foreach ($subdirList as $ii=>$adir ) {
     $alist[]=pathinfo($adir,PATHINFO_FILENAME);
   }
   $iwhich=extractRequestVar('which',0);

   if ($iwhich!=0)   getJs\jsonReturnContent($alist);  // just return list of galler ydirs

   $amess='Select a gallery to view : ';
   $amess.='<ul class="thinList">';
   foreach ($alist as $ii=>$adir) {
     if ($adir==$nowGallery){
       $amess.='<li><input type="button" value="&#8629;"  onClick=" wsurvey.flContents.container.close(this)" title="continue using this gallery"><span title="Currently chosen gallery" style="font-weight:800">'.$adir.'</span>';
     } else {
       $amess.='<li><input type="button" value="'.$adir.'" title="switch to this gallery" onClick="switchGallery(this)">';
     }
   }
   $amess.='</ul>'  ;
   getJs\jsonReturnContent($amess);
}

// ::::::::::::::
//==================
// list currently available connections (similar function in wsGalleryAdminActions.php)
if ($todo=="listCollections") {
   $wsMainDir=$_SESSION['wsGallery_mainDir'];
   $jfiles=$wsMainDir.'/data/collections/B_*.json';
   $sCollections=glob($jfiles  );
   $clist=[];
   foreach ($sCollections as $ij=>$cname) {
      $cname1=substr(pathinfo($cname,PATHINFO_FILENAME),2);
      $mdate=filemtime($cname);
      $mdateShow=date('F d Y H:i');
      $goofile=file_get_contents($cname);
      $jsonvar=json_decode($goofile,true);
      $adesc=$jsonvar['desc'];
      $nentries=count($jsonvar['entries']);
      $clist[]=[$cname1,$adesc,$nentries,$mdate,$mdateShow];
   }
  getJs\jsonReturnContent($clist);

}

//==================
// list currently dirs in a collection  (similer to collection_viewDetails in wsgalleryactionsadmin.php)
if ($todo=="collection_listDirs") {
  $acollection=extractRequestVar('collection','');
   $wsMainDir=$_SESSION['wsGallery_mainDir'];
   $jfile=$wsMainDir.'/data/collections/B_'.$acollection.'.json';
   if (!file_exists($jfile)) getJs\jsonReturnError('No such collection: '.$acollection);
   $xx=file_get_contents($jfile);
   $xx2=json_decode($xx,true);
   $bmess='<span style="background-color:#dfdfef;border-bottom:3px groove #eaeaea;border-right:3px groove #ebebeb;">';
   $bmess.='<input type="checkbox" id="showCollectionInNewWindow" value="1" title="Display directory in a new window">';
   $bmess.='<label for="showCollectionInNewWindow"   title="Display directory in a new window">&#128471;</label>';
   $bmess.='</span>';
   $bmess.=' For collection:.. <b>'.$xx2['name'].'</b> <span style="font-style:oblique" title="Description of this collection">'.$xx2['desc'].'</span>';
   $bmess.='<ul  class="selectFileMenu">';

   foreach ($xx2['entries'] as $ia=>$vv) {
     $agallery=$vv[0]; $atree=$vv[1] ; $adir=$vv[2];
     $aentry=$vv[4];
     $aurl='  <input type="button" value="&#128065; '.$aentry.' " ';
     $aurl.=' data-collection="'.$acollection.'" ';
     $aurl.=' data-entry="'.$aentry.'" ';
     $aurl.=' data-gallery="'.$agallery.'" ';
     $aurl.=' data-tree="'.$atree.'" ';
     $aurl.=' data-dir="'.$adir.'" ' ;
     $aurl.=' how="0" ' ;    // 0 1 2 3 (text thm40 thm66 thm90)
     $aurl.=' onClick="showCollectionDirFiles(this)" ' ;
     $aurl.=" title=\"Files in: $agallery / $atree / $adir \" > ";
     $bmess.='<li class="selectFileMenuLi">'.$aurl.'  </tt> <span title="A description of this directory" style="font-style:oblique">'.$vv[3].'</span>';
   }
   $bmess.='</ul>';
   getJs\jsonReturnContent($bmess);
}

//===========
//  read dir and file specs saved for this collection
if ($todo=='getCollectionFiles') {
    $acollection=extractRequestVar('collection','');
    $aentry=extractRequestVar('entry','');

// useful files in $stuff['content']: dir summary treename gallery dirInfo dirDesc  fileList  fileStats buttonList (Text 40 66 and 90)
//   snapList  messageTop     basics
    $stuff= doGetDirFileList_collection($acollection,$aentry) ;  // may 2022 : get all the button lists (text and thumbnails)
    if ($stuff['status']=='error') getJs\jsonReturnError("Error collectFiles $acollection / $aentry ",$stuff);
    getJs\jsonReturn($stuff );

}

//================
// create a favorites .json file; given filelist built on js side
if ($todo=='createFavorites') {
    $aname=extractRequestVar('name','');
    $yourname=extractRequestVar('yourname','');
    $adesc=extractRequestVar('desc','');
    $allList=extractRequestVar('list',[]);
    $fileList=$allList['current'];
    $wsMainDir=$_SESSION['wsGallery_mainDir'];

//    $stuff=['name'=>$aname,'desc'=>$adesc,'list'=>$fileList];

    $dalist=[];
    for ($ii=0;$ii<count($fileList);$ii++) {
       $a1=$fileList[$ii];
       $agallery=$a1['gallery'];
       if (!array_key_exists($agallery,$dalist)) $dalist[$agallery]=[];
       $atree=$a1['tree'];
       if (!array_key_exists($atree,$dalist[$agallery])) $dalist[$agallery][$atree]=[];
       $adir=$a1['dir'];
       if (!array_key_exists($adir,$dalist[$agallery][$atree])) $dalist[$agallery][$atree][$adir]=[];
       $afile=$a1['file'];$bnumber=$a1['bnumber'];$bdesc=$a1['desc'];
       $do1=['file'=>$afile,'bnumber'=>$bnumber,'entry'=>$ii,'desc'=>$bdesc ];
       $dalist[$agallery][$atree][$adir][]=$do1;
    }

// organized entries by dir, to minimize file reads

    $stuff=[];
    $stuff['name']=$aname;
    $stuff['yourname']=$yourname;
    $stuff['desc']=$adesc;
    $stuff['allList']=$allList;
    $sFields=['fileInfo','text','thm40','thm66','thm90','snapshot'];
    foreach ($sFields as $jk=>$afield) $stuff[$afield]=[];

    $warnings=[];

    foreach ($dalist as $agallery=>$d2) {
       foreach ($d2 as $atree=>$d3) {
          foreach ($d3 as $adir=>$d4List) {
            $aroot=$wsMainDir.'/galleries/'.$agallery.'/'.$atree.'/'.$adir.'/';

            $jsonFiles=favorites_jsonFiles($aroot) ;

            $fileList=$jsonFiles['_fileList'];
            $lookup=[];
            if (!array_key_exists('relSelLookup',$fileList)) {
                foreach ($d4List as $jj3=>$d5) {
                   $dentry=$d5['entry'];  $bfile=$d5['file'];
                   $bdesc=$d5['desc'];
                   $stuff['error'][$dentry]='_fileList not useable ';
                   foreach ($sFields as $jk=>$afield) $stuff[$afield][$dentry]=[];

                }
                continue ;  // got to next dir or tree or gallery
            }     // _fileList exists
            $alookup=$fileList['relSelLookup'];

            foreach ($d4List as $jj3=>$d5) {       // entries in this gallery tree dir ...
               $bnumber=$d5['bnumber']; $bfile=$d5['file']; $dentry=$d5['entry'];
               $bdesc=$d5['desc'];
               $stuff['error'][$dentry]=false;   //  default is no fatal error
               foreach ($sFields as $jk=>$afield) $stuff[$afield][$dentry]=[];   // default is "no cached" (snap,text button, thumbnails ..)


               if (!array_key_exists($bfile,$alookup)) {
                   $stuff['error'][$dentry]='Not in _fileList ';
                   continue ;
               }   else {
                  $jlook=$alookup[$bfile];
                  $stuff['fileInfo'][$dentry]=$fileList['fileList'][$jlook];
               }

// No fatal error... see if cached items available

// snapshot?
               if (array_key_exists($bfile,$jsonFiles['_snapshots'])) {
                 $gus=$jsonFiles['_snapshots'][$bfile]  ;
                 $stuff['snapshot'][$dentry]=$gus;
               } else {
                 $warnings[]='No snapshot for entry '.$dentry;
               }


// text button
               if (array_key_exists($bnumber,$jsonFiles['_buttonList_text'])) {
                 $gus=$jsonFiles['_buttonList_text'][$bnumber] ;
                 $stuff['text'][$dentry]=$gus;
                  $textEntry=$gus;
               } else {
                 $warnings[]='No textButton for entry '.$dentry;
               }



// thm40 button
               if (array_key_exists($bnumber,$jsonFiles['_buttonList_thm40'])) {
                 $gus=$jsonFiles['_buttonList_thm40'][$bnumber] ;
                 $stuff['thm40'][$dentry]=$gus;
               } else {
                 $warnings[]='No thm40 for entry '.$dentry;
               }

// thm66 button
               if (array_key_exists($bnumber,$jsonFiles['_buttonList_thm66'])) {
                 $gus=$jsonFiles['_buttonList_thm66'][$bnumber] ;
                 $stuff['thm66'][$dentry]=$gus;
               } else {
                 $warnings[]='No thm66 for entry '.$dentry;
               }

// thm90 button
               if (array_key_exists($bnumber,$jsonFiles['_buttonList_thm90'])) {
                 $gus=$jsonFiles['_buttonList_thm90'][$bnumber] ;
                 $stuff['thm90'][$dentry]=$gus;
               } else {
                 $warnings[]='No thm90 for entry '.$dentry;
               }


            }   // d4list

          } // dir
        }   // tree
    }   // gallery


    $stuff['messageTop']=doGetDirFileList_header(-1,'from favorites',$adesc,$aname,0) ; // write the control bar header (html)... include a 'show collection list' button


    $stuff2=json_encode($stuff, JSON_UNESCAPED_UNICODE);
    getJs\jsonReturnContent(['stuff'=>$stuff2,'warnings'=>$warnings,'name'=>$aname,'desc'=>$adesc] );
    //stuff has fields, each of which arrrays: fileInfo, text, thm40, thm66, thm90, error, filename  (one row per entry in the favorites list)
    // and a name and desc field (strings) -- for the favorite
}

//================
// return menu of public favorites lists
if ($todo=='getPublicFavoritesList') {
    $wsMainDir=$_SESSION['wsGallery_mainDir'];
    $favesDir=$wsMainDir.'/data/favorites/';

   $jfiles=$wsMainDir.'/data/favorites/C_*.json';
   $sCollections=glob($jfiles  );
   if (count($sCollections)==0) {
     getJs\jsonReturnContent('There are no available <em>public</em> favorites-lists');
   }
   $danames=[]; $oof='';
   foreach ($sCollections as $ij=>$a1) {

      $goofile=file_get_contents($a1);
      $gooJson=json_decode($goofile,true);
      if (!array_key_exists('allList',$gooJson)) continue ; // not a valid favorites list

      $fname=$gooJson['name']; $fdesc=$gooJson['desc'];
      $fyourname=(array_key_exists('yourname',$gooJson)) ? trim($gooJson['yourname']) : '' ;

      $fname=strip_tags($fname)     ;     $fname = str_replace(array("\n", "\r"), '', $fname);
      $fdesc=strip_tags($fdesc)     ;    $fdesc = str_replace(array("\n", "\r"), '', $fdesc);
      $fyourname=strip_tags($fyourname)   ;   $fyourname = str_replace(array("\n", "\r"), '', $fyourname);

      $useDesc="Desc: $fdesc \nSubmitted by: $fyourname ";
      $danames[]='<input type="button" data-creator="'.$fyourname.'" value="'.$fname.'"  title="'.$useDesc.'"  onClick="doFavorites_getPublic(this)">' ;
   }
   $oof.='You can choose one of the <tt>'.count($danames).'</tt>  <em>public</em> favorites-lists   ';
   $oof.='<input type="button" value="Sort by creator" onClick="favorites_sortBy(1)" title="Sort favorites list by who created it" > ' ;
   $oof.='<div id="listOfPublicFavorites" class="cListOfPublicFavorites">';
   $oof.='<ul class="linearMenu"><li class="linearMenuLi">'.implode('<li class="linearMenuLi">',$danames).'</ul>';
   $oof.='</div>';
   $oof.='<div id="igetPublicFavoritesList" style="margin:3px 1em 3px 1em;background-color:#dffddf"> ... </div>';

   getJs\jsonReturnContent($oof);

//   foreach ($R

}
//=============
// return a favorites list (from data/favorites)
if ($todo=='getAPublicFavorite'){
  $alist=extractRequestVar('name','');
  $alistName='C_'.$alist.'.json';
  $wsMainDir=$_SESSION['wsGallery_mainDir'];
  $favesDir=$wsMainDir.'/data/favorites/';
  $getFile=$favesDir.$alistName;
  if (!file_exists($getFile)) getJs\jsonReturnContent(['status'=>'error','stuff'=>'Can not find <em>public</em> favorites list: <tt>'.$alist.'</tt>']);
  $stuff=file_get_contents($getFile);
  $stuffJ=json_decode($stuff,true);
  getJs\jsonReturnContent(['status'=>'ok','stuff'=>$stuffJ]);
}

//================
// create a favorites .json file;  ON THE SERVER
// a bit redundant -- could just save it after creating (rather than sending to client and then saving)
// but it does give the client a chance to choose private or public save

if ($todo=='saveFavoritesPublic') {
    $aname=extractRequestVar('name','');
    $adesc=extractRequestVar('desc','');
    $content=extractRequestVar('content',[]);

//    $mdateShow=date('F d Y H:i');

    $wsMainDir=$_SESSION['wsGallery_mainDir'];
    $favesDir=$wsMainDir.'/data/favorites/';
    $useFileJson=$favesDir.'C_'.$aname.'.json';
    $doing='Create favorites-list: '.$aname;
    if (file_exists($useFileJson)) $doing='Overwrite favorites-list: '.$aname;
    $qok=@file_put_contents($useFileJson,$content);      // dirList.json
    if ($qok===false)  {
        $doing.='<br>Unable to save ';
    } else {
        $doing.='<br>'.$qok.' bytes saved ';
    }

    getJs\jsonReturnContent($doing);
}

//=======
// get file notes
if ($todo=='getFileNotes') {
   $agallery=extractRequestVar('gallery','');
   $atree=extractRequestVar('tree','');
   $adir=extractRequestVar('dir','');
   $afile=extractRequestVar('file','');
   $bnumber=extractRequestVar('bnumber','');

   $wsMainDir=$_SESSION['wsGallery_mainDir'];
   $gDir="$wsMainDir/galleries/$agallery/$atree/$adir";
   if (!is_dir($gDir)) {
       getJs\jsonReturnContent(['status'=>'error','stuff'=>"No directory for this file: $gDir "]);
   }
   $gfile="$gDir/$afile.note ";
   if (!file_exists($gfile)) {
       getJs\jsonReturnContent(['status'=>'ok','stuff'=>"No notes ($gfile) for $afile" ]);
   }
   $xx=file_get_contents($gfile);
    getJs\jsonReturnContent(['status'=>'ok','stuff'=>$xx]);

   $xxJson=json_encode($xx,true);
    getJs\jsonReturnContent(['status'=>'ok','stuff'=>$xxJson]);
}

//=======
// add a note to a file
if ($todo=='addFileNote') {
   $agallery=extractRequestVar('gallery','');
   $atree=extractRequestVar('tree','');
   $adir=extractRequestVar('dir','');
   $afile=extractRequestVar('file','');
   $bnumber=extractRequestVar('bnumber','');
   $aname=extractRequestVar('name','');
   $anote=extractRequestVar('note','');
   $akey=extractRequestVar('key','');

   $wsMainDir=$_SESSION['wsGallery_mainDir'];
   $gDir="$wsMainDir/galleries/$agallery/$atree/$adir";
   if (!is_dir($gDir)) {
       getJs\jsonReturnContent(['status'=>'error','stuff'=>"No directory for this file: $gDir "]);
   }

   $maxNoteSize=$_SESSION['wsGallery_maxNoteSize'] ;

   $gfile="$gDir/$afile.note";
   $danotes=[];
   if (file_exists($gfile)) {
      $xx=file_get_contents($gfile);
      $danotes=json_decode($xx,true);
   }
   $atime=time();
   $akeys=explode(',',$akey);
   $bkeys=[];
   foreach ($akeys as $im=>$amm) {
      if (trim($amm)!='') $bkeys[$im]=trim($amm);
   }
   $newNote=['time'=>$atime,'name'=>$aname,'key'=>$bkeys,'note'=>$anote];
   $danotes[]=$newNote;
   $nnotes=count($danotes);
   $notesText=json_encode($danotes,JSON_UNESCAPED_UNICODE);

   if (strLen($notesText)>$maxNoteSize) {
       getJs\jsonReturnContent(['status'=>'error','stuff'=>"Unable to save notes: the size of the notes for this file exceeds the maximum ($maxNoteSize). "]);
   }

   $cc=file_put_contents($gfile,$notesText);
   if ($cc===false) {
       getJs\jsonReturnContent(['status'=>'error','stuff'=>"Unable to save notes to: $gfile "]);
   }

// update flag file
   $flagFile="$gDir/_flag.txt";
   $say1="Notes and keywords added: ".time();
   $cc2=file_put_contents($flagFile,$say1);

   getJs\jsonReturnContent(['status'=>'ok','stuff'=>"There are now $nnotes notes for this file (using <span title=\"maximum bytes allowed: $maxNoteSize)\">$cc bytes</span>)"]);

}

//===========
// switch galleries (the default todo!)

  $d1=str_replace('\\','/',$wsMainDir);
  $nowGallery=extractRequestVar('nowGallery','');
  $galleriesDir=$d1.'/galleries';
  $newGallery=extractRequestVar('newGallery','');
  $newGalleryDir=$galleriesDir.'/'.$newGallery;
  if (!is_dir($newGalleryDir)) {
    getJs\jsonReturnContent("Error: no such gallery=<tt>$newGallery</tt>");
  }
  getJs\jsonReturnContent(['message'=>"Switching galleries: from <tt>$nowGallery</tt> to <b>$newGallery</b>  ... ",'newGallery'=>$newGallery]);


// :::: favorits ...



// ::::

print "<br>Unknown action: $todo ";
 exit;

 //========================
// helper funcdtion for createColletion
// _fileList , _snapshots,  _buttonList_text  _buttonList_thm40  _buttonList_thm66  _buttonList_thm90
function favorites_jsonFiles($aroot) {        // aroot should end with a /
 $doems=['_fileList','_snapshots','_buttonList_text','_buttonList_thm40','_buttonList_thm66','_buttonList_thm90'];
 $stuff=[];
 for ($ij=0;$ij<count($doems);$ij++) {
    $adoem=$doems[$ij];
    $filedo=$aroot.$adoem.'.json';
    if (!file_exists($filedo)) {
       $stuff[$adoem]=[];
    } else {
       $astring=file_get_contents($filedo);
       $ajson=json_decode($astring,true);
       $stuff[$adoem]=$ajson;
    }
  }
  return $stuff;
 }


?>