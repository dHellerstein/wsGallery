<?php
$rootdir=$_SERVER['DOCUMENT_ROOT'] ;
$nowtime=time();
$curDir=getcwd();
$webRoot=dirname($_SERVER['PHP_SELF']);
?>

<html><head><title>Help for wsGallery</title>

<link rel="stylesheet" type="text/css" href="wsGallery.css" />

<style  type="text/css">
.closeHelp1 {
   background-color:#eef2ee;
   border-top: 1px solid gray;
   border-left:1px solid gray;
   border-bottom:3px groove gray;
   border-right:3px groove gray;
   padding:0px 2px 2px 2px;
}

</style>

<script type="text/javascript" src="libs/publicLib/jquery-3.6.0.min.js"></script>
<script type="text/javascript" src="libs/publicLib/md5b.js"></script>

<script type="text/javascript" src="libs/js/wsurvey.utils1.min.js"></script>
<script type="text/javascript" src="libs/js/wsurvey.floatingContent.min.js"></script>


<script type="text/javascript" src="src/wsGallery.js"></script>

<script type="text/javascript">
$(window).on('load',init1) ;

function init1(a) {

   $(document).data('helpMenu_howShow','list');  // list or table
   $(document).data('helpMenu_autoClose',0);  // 0 or 1 (1 = close after selection)
   $(document).data('helpMenu_asTable','');  // 0 or 1 (1 = close after selection)
   $(document).data('helpMenu_asTableAdmin','');  // 0 or 1 (1 = close after selection)
   $(document).data('helpMenu_asList','');  // 0 or 1 (1 = close after selection)
   $(document).data('helpMenu_asListAdmin','');  // 0 or 1 (1 = close after selection)
    $(document).data('logonStatus',10000000000);  // everyone can view this help


   let ehelp=wsurvey.flContents.create('helpTopics',{
         'top':'3em','left':'6px','width':'97%','height':'80%','zIndex':13,
         'escapeOrder':'z',
         'header':'wsGallery Help.','moveIcon':'&#9995;','headerCloser':1,
         'callFunc':':wsGallery.css  , show in a new window &comma; or tab ' });
         
      wsurvey.flContents.contents('helpTopics','<span style="opacity:0.5"> wsGallery help</span>',1);

    let awow=$('#helpDump');  // included stuff
//    let awowContent=awow.html();
//    awow.remove();
    wsurvey.flContents.contents('helpTopics',awow,{'append':1,'show':1,'onTop':1}); // append, but do not show
   doHelpVu(0,2,'Intro')

}

function openAllTopics(a) {
   let eall=$('.helpTopic');

   eall.removeClass('helpTopic');
    eall.css({'border-top':'2px solid blue','margin-top':'1.5em','position':'sticky','overflow':'visible','max-height':'1000em' }),
   eall.show();

   let eall2=$('.helpTopic_otherTopicButton');
   eall2.css({'opacity':'0.2','border':''});
   eall2.prop('disabled',true);

   eall3=$('.helpTopic_subMenuButton');
 
   eall3.css({'opacity':'0.2','border':''});
   eall3.prop('disabled',true);

   eall3.trigger('click');


}

</script>

<div>
  <input type="button" value="&forall;" title="Open all topics." onclick="openAllTopics(this)">

  <input type="button" value="&#127982;" title="List of help topics" onclick="doHelpVuList(this,0)">
<span tyle="font-size:125%;font-weight:800;width:95%;align:middle"> wsGallery Help </span>
</div>
 <hr>



<div id="helpDump">
<?php
 require_once($curDir.'/src/wsGalleryHelp.html');  // help stuff
?>
</div> </div>

<div style="font-style:oblique;background-color:#dedede;width:95%">end of wsGallery help</div>

</body>
</html>
