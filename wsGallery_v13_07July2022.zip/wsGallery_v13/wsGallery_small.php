<?php
session_start() ;
ob_start();

// June 2022
//   wsGallery_small -- a simple viewer of  files and  images in a wsGallery installation -- for small devicse

// User configurable parameters start about 20 lines below here.
$treeSpecs=[];
$rootdir=$_SERVER['DOCUMENT_ROOT'] ;
$nowtime=time();
$curDir=getcwd();
$webRoot=dirname($_SERVER['PHP_SELF']);

require_once($curDir.'/libs/php/wsurvey.getJson.php');
require_once($curDir.'/src/wsGalleryLibUtils.php');

$requestUri=$_SERVER['REQUEST_URI'];

$wsSel=pathinfo($requestUri,PATHINFO_DIRNAME);


?>
<!DOCTYPE HTML>
<html><head><title>wsGallery: small viewer</title>
<meta charset="utf-8">

<link rel="stylesheet" type="text/css" href="wsGallery_get.css" />

<script type="text/javascript" src="libs/publicLib/jquery-3.6.0.min.js"></script>
<script type="text/javascript" src="libs/js/wsurvey.utils1.min.js">  </script>
<script type="text/javascript" src="libs/js/wsurvey.getJson.min.js"></script>
<script type="text/javascript" src="src/wsGallery_get.js">  </script>
<script type="text/javascript" src="src/wsGallery_small.js">  </script>
<script type="text/javascript" src="libs/publicLib/keyShortcut.js"></script>
<script type="text/javascript" src="libs/publicLib/jquery.touchSwipe.min.js"></script>


<script type="text/javascript">
var useGallery='main';   // these can be set in the user changetable parameters section
var useTree=''  ;
var useDir=''
var useFile='';

<?php
  print ' var wsgMainSel="'.$wsSel.'" ;'."\n";
?>

// ---------begin   user changeable parameters    -----------------------
// Note: parameter values specified in the url (the ?xxx=yyy&...) will OVERRIDE parameters specified here.


// what kind of thumbnail to display: values can be none,small (40x40) ,medium (65x65) , or large (90x90)
var showThumbnail='small';

// show the description (at the top of the file viewer). 0=no, 1=yes.
// Or , if > 1 : show, but clip length to this many chacaters (and remove html)
var showDesc=1   ;

// show the    "resize proportionally"  button. 0=no, 1=yes
var showStretch=1;

// text to display at top of window
var  headerLine='<span title="Compact wsGallery viewer" style="font-weight:800">wsGallery viewer</span>' ;



// --------- end of user changeable parameter   -----------------------

// === check for parameters specified in the url. These override user configurable values that are specified above
let arg1=queryString() ;

useGallery= (arg1.hasOwnProperty('gallery')) ? arg1['gallery'] : jQuery.trim(useGallery) ;
useTree= (arg1.hasOwnProperty('tree')) ? arg1['tree'] : jQuery.trim(useTree) ;

useDir= (arg1.hasOwnProperty('dir')) ? arg1['dir'] : jQuery.trim(useDir) ;
useFile= (arg1.hasOwnProperty('file')) ? arg1['file'] : jQuery.trim(useFile) ;

showThumbnail= (arg1.hasOwnProperty('showThumbnail')) ? arg1['showThumbnail'] : jQuery.trim(showThumbnail) ;
showDesc= (arg1.hasOwnProperty('showDesc')) ? arg1['showDesc'] : jQuery.trim(showDesc) ;
showStretch= (arg1.hasOwnProperty('showStretch')) ? arg1['showStretch'] : jQuery.trim(showStretch) ;
headerLine= (arg1.hasOwnProperty('headerLine')) ? jQuery.trim(arg1['headerLine']) : jQuery.trim(headerLine) ;

//  ----- globals: could use $(document), but since this is a smallish stanalond, globals are okay

// ------ user configurable globals ---
var showThumbnails=1 ;    // 0=text,1,2,3 for small,medium,large thumbnails
var showSnapShot=1    ; // 0=full image, 1=snapshot image
var doStretch=2;     ; // 0:as is, 1:stretch , 2:shrink (preserve aspect ratio)
var doSwipe=1;     ; // 0: swipe (prior/next) disable: 1: enabled
var alwaysShowName=1;  ; // 0: do NOT show name (if thunbmail), 1: do show name
// -- end of user configurable globals

// -- these are set by user (via html menus ) ---
var currentTree='',currentDir='',currentGallery='',currentFile='',currentTreeDirs={};
var currentTreeDesc='',currentDirDesc='',currentFileDesc='';
var currentFileList=[],currentFileNumber=-1;

//   --------- end of globals  ----------------

window.onload=init;  // intialize on load .. uses the global variables set above

// --------------------
// intialize several event handlers, etc
//Note that wsGallery_get.css is loaded by .init()

function init() {

   wsurvey.getJson.setErrFunc('jsonErrorShow' );   // error reporting function for getJson. Hopefully is never needed!

   if (headerLine!='')  $('#iheaderLine').html(headerLine);
   doSettingsResize(0) ;  // resize using screen and window specs

 shortcut.add("pageup",viewPriorFile1,{
	'type':'keydown',
	'propagate':true,
	'disable_in_input':true,
	'target':document
  });
   shortcut.add("pagedown",viewNextFile1,{
	'type':'keydown',
	'propagate':true,
	'disable_in_input':true,
	'target':document
   });

// Ready to display !   Start  by displaying a list of galleries
   $('#iheaderLine').html(headerLine);
   getGalleries(false,1);    // --- and start the display!

     $("#simple_viewer").swipe(          //Enable swiping...
         {swipe:doswiper,threshold:5  }                        //Default is 75px, set to 0 for demo so any distance triggers swipe
     );
    $("#simple_viewer").swipe("disable");

}
function doswiper(event, direction, distance, duration, fingerCount,fingerData,currentDirection) {
 if (distance<50 || duration>1000) return 0;
 if (direction=='left'  ) {
     viewNextFile1(event)
     return 0;
 }
 if (direction=='right'  ) {
     viewPriorFile1(event)
     return 0;

 }
 if (direction=='up'  ) {
//   leaveFullScreen(1);
    return 0;
 }
 if (direction=='down'  ) {
//     $("#simple_viewer").swipe("disable");
     return 0;
 }

}

function viewNextFile1(aa) {
   viewNextFile(aa,1);
}
function viewPriorFile1(aa) {
   viewNextFile(aa,-1);
}

// =========== some helper functions

</script>


<style type="text/css">

.viewSimpleTableHeaderC {           /* the header of the viewfile column */
  border:1px dotted blue;
  margin:4px;
  height:1.3em
  overflow:auto;
  display:inline-block;
    xfloat:left ;
}

.viewSimpleTableListC {
  border:1px dotted cyan;
  margin:4px;
  height:21em ;
  align:top;
  overflow:auto;
  vertical-align: top;
  display:inline-block;
}

.usePresetsC,.usePresetsC0 {             /* display the values of the preset variables (at top of screen) */
   margin:3px 1em 3px 1em;
   background-color:#dfdad1;
}

.usePresetsC0 {
   border:1px dotted gray !important ;
}

/* use this to signal that a column is currently hidden */
.usePresetsC_isHidden {
   color:red  !important ;
}

.menuInRow {
   max-height:3em;
   overflow:auto;
}

.chosenTree {
   border:3px dashed green !important ;
   margin:2px;
}

.chosenDir {
   border:3px dashed blue !important ;
   margin:2px;
}

.chosenFile {
   border:3px dashed brown !important ;
   margin:2px;
}

.buttonClicked {
   background-color:lime ;
}

.ccurrentTreeShow {
  display:none;
  font-size:80%;
  background-color:#dfeddf;
}

.ccurrentTreeShowNext {
  display:none;
  font-size:90%;
  background-color: lime;
}

/* Used in the list of files in a directory, and dirs in gallery */
.selectFileListC {
   list-style-type: none;
   margin:3px 2px 6px 1em ;
   padding: 3px 3px 6px 3px;
    background-color:#cedece;
   border-bottom:3px dotted brown ;
}

.selectDirListC   {
   list-style-type: none;
   margin:3px 2px 6px 1em ;
   padding: 3px 3px 6px 3px;
    background-color:#dedede;
   border-bottom:3px dotted gray ;
}

.selectDirListC li  {
  color:#344343;
  font-size: 100%;
  padding:5px;
  display:block;
  vertical-align:top;
  margin:3px 10px 8px 8px;
  border:1px outset #ddddee;
  border-radius:3px;
  max-width:95%;
  overflow:auto;
}


.selectFileListC li  {
  color:#344343;
  font-size: 100%;
  padding:5px;
  display:block;
  vertical-align:top;
  margin:3px 10px 8px 8px;
  border:1px outset #ddddee;
  border-radius:3px;
  max-width:95%;
  overflow:auto;
}
.cshowSingleOpts {
  position: fixed;
  left:1em;
  top:2em;
  padding:3px;
  max-height:1.3em;
  background-color:#dfdfdf;
  opacity:0.8;
}

.cSwipeOn {
   color:green;
   background-color:cyan;
   font-weight:800;
}
</style>


</head>

<body  >

<!-- some headers -->
<div id="simple_header" style="overflow:auto;height:1.8em">

<input type="button" value="&#10068;" style="font-size:100%;margin:0px;padding:0px" title="Tips and hints" onClick="showTips(this)" >

<span id="iheaderLine">
   Simple wsGallery viewer
</span>
<input type="button" value="&#128712;" style="font-size:105%;margin:0px;padding:0px" title="Current status (gallery/tree/dir/file" onClick="showCurrentStatus(this)" >
<input type="button" value="&#9965;"   style="font-size:105%;margin:0px;padding:0px" title="Settings" onClick="doSettings(0)" >
&boxV;
<input type="button" value="&#127794;" title="Select a tree (and then select a directory)" id="choseTreeButton" onClick="selectTree(0)" >
<input type="button" value="&#9636;" title="Select a directory (in the currently selected tree"  id="choseDirButton" onClick="selectDir(0)" >
<input type="button" value="&#128193;" title="Select a file (in the currently selected directory"   id="choseFileButton" onClick="selectFile(0)" >
&boxV;
<input type="button" value="&#8612;" title="View prior file (in the currently selected directory" onClick="viewNextFile(this,-1)" >
<input type="button" value="&#8614;" title="View next file (in the currently selected directory" onClick="viewNextFile(this,1)" >
&boxV;
<input type="button" value="&#129001;" title="View full image " onClick="viewFullImage(1)" >
<input type="button" value="&#128476;" title="View reduced image " onClick="viewReducedImage(1)" >
<input type="button" value="&#128918;" title="Full screen display "  onClick="viewFullScreen(10)" >
<!-- <input type="button" value="&Sscr;" title="Enable/disable swipe "  onClick="doSettingsSwipe(this,2)" > -->

</div>

<!-- outer container ... -->
<div id="simple_viewer_outer"  >
    <!-- the container with gallery/tree/dir/file selection menus, and file viewer -->
  <div id="simple_viewer" style="height:99%;width:95%;overflow:auto;margin:0.2em 1em 0.2em 0.2em;" > </div>
</div>


<!-- for error display -->
<div style="background-color:#ddccdd;display:none" id="simple_notes">
Debugging and technical notes.
<hr>
</div>

<!-- a spacer -->
<div style="height:0.3em;border-bottom:1px dotted black" title="a screen bottom spacer/indicator"></div>

</body>
</html>