<?php

use wSurvey\getJson as getJs  ;

// utilities for wsGallery   -- non-admin

//===========
// Return the treelist (only can be changed by editing .php file)
// and the treeListStatus (can be changed from admin mode)
// and the currentDefaultTree
// print error message if serious issue (or return error message)
// Otherwise, return [defaultTree,treeList,treeListSTatus]
//
// may 2022: these should be fixed
// galleryDir -- NOT USED
// useGallery -- if '', use gallery stored in $_SESSION. OTherwise, the gallery to use.

function getTreeList($useGallery,$doNow0='0' ) {

   $doNow0= trim($doNow0);
   $doNow= ($doNow0=='0' || $doNow0=='') ? 0 : 1 ;

//  $curDir=getcwd();
  $wsMainDir=$_SESSION['wsGallery_mainDir'];

  if ($doNow==0) {       // use default gallery
      $wsMainDir_tree= $_SESSION['wsGallery_mainDir_tree'];
      $dataDir=$_SESSION['wsGallery_dataDir'] ;
  } else {             // use specific gallery (i.e; viewing something from a 'collection'
     $wsMainDir_tree=$_SESSION['wsGallery_mainDir'].'/galleries/'.$useGallery ;
     $dataDir=$wsMainDir_tree ;
  }

  $selToDataRoot=$_SESSION['wsGallery_selToDataRoot'] ;

// basic check. look for wsGallery_treeList.php.
  $treeListPhp=$wsMainDir_tree.'/wsGallery_treeList.php';

  if (!is_file($treeListPhp)) {
     $errMess="<b>Error</b>: missing treeListSpecs file   ($treeListPhp). See wsGallery documentation on how to create one. ";
      return ['error'=>$errMess];
  }
  $treeListPhp_lastMod=@filemtime($treeListPhp);

// is there a treeList.json file? If so, is it too old?

  $treeListJson=$dataDir.'/treelist.json';
  if (!is_file($treeListJson)){
     $errMess= "No json file! (gallery: $useGallery) ".$treeListJson ;
     return ['error'=>$errMess];
  }

// .json verison out of date?
  $treeListJson_lastMod=@filemtime($treeListJson);

  if ($treeListJson_lastMod<$treeListPhp_lastMod) return ['error'=>'json file older then php file'] ;  // too old, need to re-create

  $arf=@file_get_contents($treeListJson );  // exists and not too old... read and return
  if ($arf===false) {
      $errMess="<b>Error</b>: unable to read treeList json file  ($treeListJson). It should be deleted and then recreated. ";
       return ['error'=>$errMess];
  }

// use the .json version!
  $treeListUse=json_decode($arf,true);

  if (!array_key_exists('0',$treeListUse)) {
      $errMess= "<b>Error</b>: problem with  treeList file  ($treeListFile). It may be corrupted (and should be deleted).  ";
      return ['error'=>$errMess];
  }

  $treeListJsonStatus=$dataDir.'/treelistStatus.json';
  if (!is_file($treeListJsonStatus))  {
      $treeListStatus=[];  // non fatal  -- no entry for a tree means "enabled"
  } else {
    $arf2=@file_get_contents($treeListJsonStatus );  // exists and not too old... read a
    $treeListStatus=json_decode($arf2,true);
  }

  $defaultShowTree='';
  if ($doNow==0) {    // default call (i.e.; on wsGallery initialization
     $_SESSION['wsGallery_treeList']=$treeListUse ;    // set the local versions
     $_SESSION['wsGallery_treeListStatus']=$treeListStatus ;
     $defaultShowTree=$treeListUse[0];
     $_SESSION['wsGallery_currentTree']=$defaultShowTree;  // the admin changeable one specified in wsGallery_treeList.php
  }
  return [$defaultShowTree,$treeListUse,$treeListStatus];   // and  return  (note use of array, no 'error' index
}

//===========
//read the .json version of the admin changeable paramers
// print error message if serious issue
//  Return false if no .json file (or is out of date)
function readWsGalleryParams($a) {

  $wsMainDir=$_SESSION['wsGallery_mainDir'];

  $dataDirBase=$_SESSION['wsGallery_dataDirBase'] ;

// basic check. look for wsGallery_params.php.
  $paramsPhp=$wsMainDir.'/wsGallery_params.php';
  if (!is_file($paramsPhp)) {
     $paramsPhp0=$paramsPhp;
     $paramsPhp=$dataDirBase.'/wsGallery_params.php';
     if (!is_file($paramsPhp)) {
        print "<b>Error</b>: a missing parameters file ($paramsPhp0 and $paramsPhp). See wsGallery documentation on how to create one. ";
        exit;
     }
   }
   $paramsPhp_lastMod=@filemtime($paramsPhp);

// is there a params.json file? If so, is it too old?

  $paramsJson=$dataDirBase.'/params.json';
  if (!is_file($paramsJson)) return [false,'no json file.'] ;  // no .json, need to create

  $paramsJson_lastMod=@filemtime($paramsJson);

  if ($paramsJson_lastMod<$paramsPhp_lastMod) return [false,'json file older then php file'] ;  // too old, need to re-create

  $arf=@file_get_contents($paramsJson );  // exists and not too old... read and return
  if ($arf===false) {
      print "<b>Error</b>: unable to read params json file  ($paramsJson). It should be deleted and then recreated. ";
      exit;
  }
  $paramsUse=json_decode($arf,true);
  if (!array_key_exists('noCache',$paramsUse)) {
        print "<b>Error</b>: problem with  params file  ($paramsUse). It may be corrupted (and should be deleted).  ";
        exit;
  }

  return [true,$paramsUse];
}

//=================
// get the list of spinners  from json
function getSpinnerList($a) {

    $spDir=getcwd().'/icons/spinners';
    if (!is_dir($spDir)) {
       print "<b>Error</b>: spinners data directory ($spDir)";
       exit;
    }
    $spDirMtime=@filemtime($spDir);

    $fileJson=$spDir.'/spinners.json';     // put the json in the spinners dirs
    if (!is_file($fileJson)) return [false,'no json file..'] ;

    $jsonMtime=@filemtime($fileJson);
    if ($jsonMtime<$spDirMtime) return [false,'json file is out of date'];

    $zz=@file_get_contents($fileJson);
    $azz=json_decode($zz,'true');

    return [true,$azz];          // no checking for flaws (its jsut a list of relsels)
}

// -----------------------
// a version of wsurvey.adminLogon_status.php  (have it here to avoid including wsurvey.adminLogon.php
function wsCheckLogon_logonStatusG($useL='wsGallery' ) {
  $sessVar='wsurveyadminLogon_status_wsGallery' ;

  if (isset($_SESSION[$sessVar]) && $_SESSION[$sessVar]!=0 ) {  // got recent logon
     $logonExpiry=intVal($_SESSION[$sessVar]);
     if (!is_numeric($logonExpiry)) return [0,0 ] ;  // bad logon, so not logged on
     $nowTime=time();
     $timeLeft= $logonExpiry-$nowTime ;
     if ($timeLeft<=0  ) return [2,0 ];       // expired

     return  [1,$timeLeft ];
  } else {
     return [0,0 ];
  }
}


// -----------------------
//====================
// create a message about need to create a directory listing
function retrieveDirList_errorNotice($useTreeName,$amessage='Problem with cache ') {
  $logonOk=wsCheckLogon_logonStatusG('wsGallery') ;   // must be admin logon

  $xstuff='<div id="switchTreeMenu"  name="nswitchTreeMenu" arf="1" style="display:block" class="cswitchTreeMenu">dirlist shown here ';
  $xstuff.='</div>';
  $aaa=$xstuff.$amessage;


  if ($logonOk[0]!=1) {
       $aaa.='<div   style="padding:4px;margin:3em 3px 3px 3px;border:4px solid brown">Administrative action needed for ';
       $aaa.='    <em>treeName</em> <u>'.$useTreeName.'</u>: a directory listing must be initialized.  ';
       $aaa.='</div>';
       $aaa.='</div>';
   } else {
       $aaa.= '<div   style="padding:4px;margin:3em 3px 3px 3px;border:4px solid brown">Administrative action needed.';
       $aaa.= '<br>Use  <input type="button" value="&#9881;&#65039;"   title="open the admin actions menu" onClick="doAdmin(1)"> ';
       $aaa.= '<u>admin actions</u> to create a directory list for the  <u>'.$useTreeName.'</u> tree';
       $aaa.= '</div>';
   }
   return $aaa;
}


//-------------------------
//===================
// make a glob() useful list for CI lookup
// eg
//   $useThese=makeListCI(['jpg,'jpeg','png'.'gif'])'=
// $useThese will be:  '*.{[jJ][pP][gG],[jJ][pP][eE][gG],[pP][nN][gG],[gG][iI][fF],[bB][mM][pP]}'
// and used as
//    myFiles=glob($apath . '/' . $useThese, GLOB_BRACE);  -- return all files with a desired extension (case insensitive match)

function makeListCI($alist) {
   $astring='*.{';  $aextD=[];
   foreach ($alist as $aext) {
     $aextA=str_split($aext);
     $aextB=[];
     foreach ($aextA as $achar) {
       $aextB[]='['.strtoupper($achar).strtolower($achar).']';
     }
     $aextD[]= implode('',$aextB);
    }
   $astring.=implode(',',$aextD);
   $astring.='}';
    return $astring ;
}

//===========
// create a lookup table from an array. For example, array of exstentions
function makeLookupTable($anarray,$ci=1) {
  $dalookup=[];
    foreach($anarray as $aext) {
     $aextLc= ($ci==1) ? trim(strtolower($aext)): trim($aext); ;
     $dalookup[$aextLc]=0;
  }
  return $dalookup ;
}

//=======================
// image sender -- no procssing
//  source_url: full path

// Send an image file (must be readable by getimagesize (.bmp, .gif, etc
// send as is (origional mimetype).
//https://stackoverflow.com/questions/900207/return-a-php-page-as-an-image
// note 'fileSender' action in wsGalleryActions.php does NOT use this (it is more general, and does not try to add image info)

function imageSender($fullFile,$wsHeader='') {

   ob_end_clean();
   $fname=basename($fullFile);

   if (!file_exists($fullFile)) {
     $fname=basename($fullFile);
     header($_SERVER["SERVER_PROTOCOL"] . " 404 Not Found"  );
     header("x-wsGallery: Error in imageSender: no such file! $fname" );
     exit;
   }
   $sizeStuff=@getimagesize($fullFile );
   if ($sizeStuff===false) {
     header($_SERVER["SERVER_PROTOCOL"] . " 404 Not Found"  );
     header("x-wsGallery: Error in imageSender: no such graphics file $fname" );
     exit;
   }

   $width=$sizeStuff[0]; $height=$sizeStuff[1];
   $filen=filesize($fullFile);
    $mime=strtolower($sizeStuff['mime']);
    header('Content-Type: '.$mime);
    header('Content-Length: '.$filen);
    $wsHeader=trim($wsHeader);
    if ($wsHeader=='') {
       header("x-wsGallery: $fname is $width x $height" );
    } else {
       header("x-wsGallery: $wsHeader. Image size is $width x $height" );
    }
    readfile($fullFile);     // imageSender  
    exit;
}

// -- as above, for text and htmo
function textSender($fullFile,$mimeType='text/plain') {

   ob_end_clean();
   $fname=basename($fullFile);

   if (!file_exists($fullFile)) {
     $fname=basename($fullFile);
     header($_SERVER["SERVER_PROTOCOL"] . " 404 Not Found"  );
     header("x-wsGallery: Error in textSender: no such file $fname" );
     exit;
   }

   $mimetype='text/html';
   $filen=filesize($fullFile);
    header('Content-Type: '.$mimeType);
    header('Content-Length: '.$filen);
    header('x-origFile: '.basename($fullFile));  
    $acontent=file_get_contents($fullFile);        // not from cache!
    $bcontent='<div style="width:98%;height:95%;overflow:auto;white-space:pre;font-family:monospace">';
    $bcontent.=htmlspecialchars($acontent);
    $bcontent.='</div>';

    echo $bcontent ;
    exit;
}

// -- as above, all types (used in external display
function notImgSender($fullFile,$wsgHeader='') {

   ob_end_clean();
   $fname=basename($fullFile);
   if (!file_exists($fullFile)) {
     $fname=basename($fullFile);
     header($_SERVER["SERVER_PROTOCOL"] . " 404 Not Found"  );
     header("x-wsGallery: Error in textSender: no such file $fname" );
     exit;
   }

  if ($wsgHeader=='') $wsgHeader=basename($fullFile);

   $mimeType=mime_content_type($fullFile);

   $filen=filesize($fullFile);
    header('Content-Type: '.$mimeType);
    header('Content-Length: '.$filen);
    header('x-wsGallery: '.$wsgHeader) ;
    $acontent=file_get_contents($fullFile);  // not from cache
    readfile($fullFile);   // notImg sender
    exit;
}

//=======================
// image resizer
//  source_url: full path
//  width and height of returned image -- original image will be scaled to retain ratio
//   quality from 1 to 100, larger numbers better. Note this is used as is for jpeg, converted to 0 to 9 for png (smaller better),
//  and ignored for gif and bmp and xbm
// note: this retains original mime type. In contrast, resizing image that is stored in cache is always stored as jpg

//https://github.com/gayanSandamal/easy-php-image-resizer/blob/master/php-image-resizer.php
function imageResizer($fullFile,$after_width=90,$after_height=90,$quality=75,$comment='') {

   ob_end_clean();
   $quality=min(max(0,$quality),100);

   if (!is_file($fullFile)) {
      echo "Error in imageResizer: no such file= $fullFile" ;
      return false ;
   }

//detect the width and the height of original image
   $aImageInfo=@getimagesize($fullFile );
   if ($aImageInfo===false) {
      echo "Error in imageResizer: not a recognized image file= $fullFile" ;
      return false ;
   }

   $qMemSet=imageResizerMemSet($aImageInfo);
   if ($qMemSet!==false) {
      @trigger_error($qMemSet) ; // will be red by error_get_last
      return false;
   }

   $width=$aImageInfo[0]; $height=$aImageInfo[1];
   $mime=strtolower($aImageInfo['mime']);

   $r = $width / $height;
   if ($after_width / $after_height > $r) {
        $newwidth = $after_height * $r;
        $newheight = $after_height;
   } else {
        $newwidth = $after_width;
        $newheight = $after_width / $r;
   }

    set_error_handler("myErrorHandler");
    if ($mime =='image/jpeg' ) {       // read the image file into gd format
        $img = @imagecreatefromjpeg($fullFile);
    } elseif ($mime=='image/png') {
        $img = @imagecreatefrompng($fullFile);
    } elseif ($mime=='image/gif') {
        $img = @imagecreatefromgif($fullFile);
    } elseif ($mime=='image/bmp' || $mime=='image/x-ms-bmp') {
        $mime='image/bmp' ;
        $img = @imagecreatefrombmp($fullFile);
    } elseif ($mime=='image/xbm' ) {
        $mime='image/xbm' ;
        $img = @imagecreatefromxbm($fullFile);
    } else {
        //show an error message if the file extension is not available
        echo 'image extension is not supported: '.$mime;
        exit;
    }
    if ($img===false) {
        echo "Problem with image file ($fullFile): $mime ";
        exit;
    }
    $imgResized = imagescale($img, $after_width, $after_height );  // rescale
    restore_error_handler();

    header('Content-Type: '.$mime);
    header("x-OrigSize: w=$width,h=$height");
    if ($comment!='')     header("x-comment: $comment");

    if ($mime =='image/jpeg' ) {             // write to output
       imagejpeg($imgResized,null,$quality);
    } elseif ($mime=='image/png') {
       $aquality=100-$quality ;  // 100 is best for jpb
       $aquality=intval((9/100)*$aquality);
       imagepng($imgResized,null,$aquality,PNG_ALL_FILTERS);
     } elseif ($mime=='image/gif') {
        imagegif($imgResized,null);
     } elseif ($mime=='image/bmp') {
         imagebmp($imgResized,null);
     } elseif ($mime=='image/xbm') {
         imagexbm($imgResized,null);

     }   // otherwise, caught above

    imagedestroy($img);      // free memory
    imagedestroy($imgResized);
    return true;
}

//==========
// error im a imagexxx function.
function myErrorHandler($err_severity, $err_msg, $err_file, $err_line,  $err_context) {
     $amess="\n error in imagecreate: at $err_line in $err_file. severity=[$err_severity]: Message=$err_msg";
    $goo=['error'=>true,'message'=>$amess];
    return $goo;
}

 

// ------
// save to file version -- saveToFile should be a fully wualified filename
// this does NOT send the file -- it create a file (saveToFile). call can then send it if need be
function imageResizerFile($fullFile,$after_width=90,$after_height=90,$quality=75,$saveToFile=null ,$asJpg=0,$err2=0 ) {

  $quality=min(max(0,$quality),100);

//detect the width and the height of original image
   $aImageInfo=@getimagesize($fullFile );
   if ($aImageInfo===false) {
      return ['error'=>true,'message'=>"Unable to get image info for: $fullFile"];
   }

   $qMemSet=imageResizerMemSet($aImageInfo);
   if ($qMemSet!==false) {
//      @trigger_error($qMemSet) ; // will be red by error_get_last
      return ['error'=>true,'message'=>"Unable to resize memory for $fullFile: $qMemSet"];
   }


//      error_log("\n about to  $fullFile $bytesNeeded, $bytesAllocated",3,'d:/wwwDanielh/family/wsGallery/php.log');
    $width=$aImageInfo[0]; $height=$aImageInfo[1];
   $mime=strtolower($aImageInfo['mime']);

   $r = $width / $height;
   if ($after_width / $after_height > $r) {
        $newwidth = $after_height * $r;
        $newheight = $after_height;
   } else {
        $newwidth = $after_width;
        $newheight = $after_width / $r;
   }

     set_error_handler('myErrorHandler');
    if ($mime =='image/jpeg' ) {       // read the image file into gd format
   //   if ($fullFile== "D:/photos/before2016/01_august/IMAGE006a.JPG") {
   //       $img =  @imagecreatefromjpeg($fullFile);
    //  } else {
          $img =  @imagecreatefromjpeg($fullFile);
    //  }
    } elseif ($mime=='image/png') {
        $img = @imagecreatefrompng($fullFile);
    } elseif ($mime=='image/gif') {
        $img = @imagecreatefromgif($fullFile);
    } elseif ($mime=='image/bmp' || $mime=='image/x-ms-bmp') {
        $mime='image/bmp' ;
        $img = @imagecreatefrombmp($fullFile);
    } elseif ($mime=='image/xbm'  ) {
        $mime='image/xbm' ;
        $img = @imagecreatefromxbm($fullFile);
    } else {            //show an error message if the file extension is not available
        restore_error_handler();
        return ['error'=>true,'message'=>"Unsupported image type ($mime) for $fullFile"] ;
    }


   if (is_array($img) && array_key_exists('error',$img) ) {   // myErrorHandler got invovled?
        $emess=(array_key_exists('message',$img)) ? $img['message'] : " Error in imagecreate, for $fullFile ";
        restore_error_handler();
        return ['error'=>true,'message'=>$emess];
   }
   if (!$img) {      // some kind of error
        restore_error_handler();
         $emess=" Error in imagecreate: for $fullFile ";
        return ['error'=>true,'message'=>$emess];
    }
    $imgResized = imagescale($img, $after_width, $after_height );  // rescale
    restore_error_handler();

    if ($asJpg==1 || $mime =='image/jpeg' ) {             // write to output. Jpeg if "save as jpeg" is requested
       imagejpeg($imgResized,$saveToFile,$quality);
    } elseif ($mime=='image/png') {
       $aquality=100-$quality ;  // 100 is best for jpb
       $aquality=intval((9/100)*$aquality);
       imagepng($imgResized,$saveToFile,$aquality,PNG_ALL_FILTERS);
     } elseif ($mime=='image/gif') {
        imagegif($imgResized,$saveToFile);
     } elseif ($mime=='image/bmp') {
          imagebmp($imgResized,$saveToFile);
     } elseif ($mime=='image/xbm') {
          imagexbm($imgResized,$saveToFile);
     }   // otherwise, caught above

    imagedestroy($img);      // free memory
    imagedestroy($imgResized);
    $fbytes=filesize($saveToFile);
    return ['error'=>false,'message'=>$fbytes  ];
}

//===============
// check and set memory
function imageResizerMemSet($aImageInfo) {
   $width=$aImageInfo[0]; $height=$aImageInfo[1];
   $achannels= (array_key_exists('channels',$aImageInfo)) ? $aImageInfo['channels'] : 3 ;
   $abits= (array_key_exists('bits',$aImageInfo)) ? $aImageInfo['bits'] : 8 ;
   $t1=$width * $height * $abits * $achannels ;
   $t2=round($t1/8) + Pow(2,16);
   $bytesNeeded=round($t2 * 1.65) ;

//   $bytesNeeded=round( ( ($width * $height * $abits * $achannels) / 8 ) + Pow(2, 16)) * 1.65));

   $bytesAllocated=getBytes(ini_get('memory_limit'))     ;
   if ($bytesAllocated> ($bytesNeeded*1.1)) return false ;     // no memSet required

   $memAvail=$_SESSION['wsGallery_memAvailable'];
   if ($memAvail===false) return "bytesAllocated $bytesAllocated  < bytesneeded $bytesNeeded : avail= n.a."  ; // will be red by error_get_last
   $memAvailM=$memAvail /1000000;
   $memAvailM_use=intval($memAvailM/4);
   $mbytesNeeded=intval($bytesNeeded/1000000);
   if (($memAvailM/4)>$mbytesNeeded) {  // got enough system memory
       $goo=intval(1.2*$mbytesNeeded);
       ini_set('memory_limit',$goo.'M')   ;
   } else {
        return "bytesAllocated $bytesAllocated  < bytesneeded $bytesNeeded : avail=$memAvailM_use vs  $mbytesNeeded " ; // will be red by error_get_last
   }
   return false;    // mem incrase success
}


//=======================
// return  "selectors" and other information on a path (to a directory, or a file)
// returns array with indices See below for list.
//  'error' will be '' if no errors occured. Otherwise, an error message.. Usually some kind of mismatch between the
//  current treeDirectory, or the fullselector (compared to what is specified for the tree)
//
// pp is used (if speciifed) as a shortcut. It MUST be what was returned from a prior call to returnSelector
// for an $pathToCheck in the same path at this call's $pathToCheck!
/// If it is not, it is ignored.
//
// note use of $_SESSION['wsGallery_noCache']. If 1, cacheDir=false (even if it exists in a fine condition)

function returnSelector($pathToCheck,$atree0='',$pp=[],$returnError=0) {

  $isSel=0;$isRelSel=0;

  $rets=['origPath'=>$pathToCheck, 'realFileName'=>'','galleryName'=>'','treeName'=>'','rootDir'=>'',
         'stdWwwDir'=>0,'rootSel'=>'','underStdWwwDir'=>0,'uriSel'=>'',
         'fullSel'=>'','relSel'=>'',
         'relSelDir'=>'','relSelFile'=>'','relSelFileName'=>'','relSelFileExt'=>'',
         'cacheDir'=>'','cacheDirSel'=>'',
         'error'=>'','fromPP'=>0,'desc'=>'' ];


  $pathToCheck=str_replace('\\','/',trim($pathToCheck));   // convert \ to / (simplifies parsing)
  if (substr($pathToCheck,0,1)=='~')  {   // this is a selector
     $isSel=1;
     $pathToCheck=ltrim($pathToCheck,'~');   // get rid of ~
     $ac1=substr($pathToCheck,0,1);
     if ($ac1!=='/') $isRelSel=1;      // if start with /, path is relative to rootDir. If not, relative to rootdir/rootsel (for this tree)
  }

  if (count($pp)>0 && array_key_exists('treeName',$pp) && $pp['treeName']==$atree0) {  // this contains useable info?
       $qGotPP=true;
       $useTreeName=$pp['treeName'];  // use derfault if atree0 = ''
       $galleryName=$pp['galleryName'];
       $rets['treeName']=$useTreeName   ;
       $rets['galleryName']=$pp['galleryName'];    ;
       $treeRootDir=$pp['rootDir'];
       $rets['rootDir']=$treeRootDir;
       $rootSel=$pp['rootSel']  ;     // CAREFULT: treeInfo uses rootSel
       $rets['rootSel']= $rootSel ;
       $rets['fromPP']=1;
       $rets['stdWwwDir']=$pp['stdWwwDir'] ;
       $rets['underStdWwwDir']=$pp['underStdWwwDir'] ;
       $base1=$treeRootDir.$rootSel;

  } else {                    // no prior info (in pp), or pp is flawed
      $qGotPP=false;
      $treeInfo=getTreeInfo($atree0,$returnError) ;  // exits on error
      if ($returnError==1) {
         if (array_key_exists("status",$treeInfo) && $treeInfo['status']=='error') return $treeInfo;
      }
      $useTreeName=$treeInfo['treeName'];  // use derfault if atree0 = ''
      $galleryName=$treeInfo['galleryName'];
      $rets['treeName']=$useTreeName;
      $rets['galleryName']=$galleryName;
      $treeRootDir=$treeInfo['rootDir'];  $rets['rootDir']=$treeRootDir;
      $rets['stdWwwDir']=$treeInfo['stdWwwDir'] ;
      $rets['underStdWwwDir']=$treeInfo['underStdWwwDir'] ;
      $rootSel=$treeInfo['rootSel']  ;  $rets['rootSel']= $rootSel;
  }   // pp exists


// hack to deal with selectors (not files). A bit wasteful since it is uses info that is later re-discoverd
   if ($isSel==1) {       //   /foo/bar/xy.z
       if ($isRelSel==1)  {  // foo/bar.xy.z
          $pathToCheck=$treeRootDir.$rootSel.$pathToCheck;
        } else {
          $pathToCheck=$treeRootDir.$pathToCheck;
        }
     }


// check this in tree's base path
     $base1=strtolower($treeRootDir.$rootSel);
     $base1=str_replace('\\','/',$base1);
     $pcheck1=strtolower(substr($pathToCheck,0,strlen($base1)));
     $pcheck1=str_replace('\\','/',$pcheck1);
     if ($pcheck1!=$base1) {
        $rets['error'].=" path=[$pathToCheck] not under tree=[$useTreeName] ($pcheck1!=$base1)" ;
        return $rets;
     }

  $nblen=strlen($treeRootDir);
  $fullSel=substr($pathToCheck,$nblen);
  if (substr($fullSel,0,2)=='//') $fullSel=substr($fullSel,1);
  if (substr($fullSel,0,1)!='/') $fullSel='/'.$fullSel;
  $rets['fullSel']=$fullSel;

   $arf=$_SERVER['PHP_SELF'];
  $nclen=strlen($rootSel);
  $relSel=substr($fullSel,$nclen);
  $rets['relSel']=$relSel;       // assume it is correct

  $islash=strrpos($relSel,'/' );
  $iperiod=strrpos($relSel,'.',$islash );
  if ($iperiod===false) {   // probalby no filena e, so this path is to a directory
     if ($qGotPP) {
       $relSelDir = $pp['relSelDir'] ;
     } else {
        $relSelDir = rtrim($relSel,'/').'/' ;
     }
      $rets['relSelDir']=$relSelDir;
      $rets['relSelFile']='';
  } else {
     if ($qGotPP) {
       $relSelDir = $pp['relSelDir'] ;
     } else {
       $t1= substr($relSel,0,$islash+1);
       $relSelDir = rtrim($t1,'/').'/';
     }
     $rets['relSelDir'] =$relSelDir;
     $rets['relSelFile']=substr($relSel,$islash+1);

     $tname=trim($rets['relSelFile']);
     if ($tname=='') return $rets ; // no filname or ext

     $iperiod=strrpos($tname,'.');
     if ($iperiod===false) {
        $rets['relSelFileName']=$tname;
        $rets['relSelFileExt']='';
     } else {
        $rets['relSelFileName']=substr($tname,0,$iperiod);
        $rets['relSelFileExt']= substr($tname,$iperiod+1);
     }
  }

  $isStd=$rets['stdWwwDir'];
  if ($isStd==1)  {  // under stdwwwdir
     $uriSel=$rets['uriSel']=$fullSel;
  } else {
     $atree=$rets['treeName'];$agallery=$rets['galleryName'];
     $thisrootSel=dirname($_SERVER['PHP_SELF']);   // ie  /www/gallery/wsGallery.php  would yield /www/gallery
     $thisrootSel=str_replace('\\','/',$thisrootSel);
     $i1=strpos($thisrootSel,'/wsGallery');
     if ($i1!==false) {
       $i2=strpos($thisrootSel,'/',$i1+1);
       $rootUri=rtrim(substr($thisrootSel,0,$i2),'/');
     }
     $adir=$rets['relSelDir'];
     $afile=$rets['relSelFile'];
     $uriSel=$rootUri.'/wsGallery_get.php?todo=sendFile&dir='.$adir.'&tree='.$useTreeName.'&gallery='.$galleryName.'&file='.$afile;
  }
  $rets['uriSel']=$uriSel;
  $noCache=$_SESSION['wsGallery_noCache'] ;

  if ($qGotPP) {       // no need to chec $_SESSION['wsGallery_noCache'] -- it would of been done in the call that made pp
    $rets['cacheDir']=$pp['cacheDir'];
    $rets['cacheDirSel']=$pp['cacheDirSel'];
  } else {

    $cacheTree=$treeInfo['cacheTree'];     // reminder: cacheTree is the root for the tree, cacheDir is for THIS file (in this directory in this tree)
    $cacheSel=$treeInfo['cacheSel'];
    $tdir=rtrim($cacheTree,'/').'/'.rtrim($relSelDir,'/');

  // if a directory's cache directory doesn't exise, or if caching is suppresed: cacheDir return= ''
 // note tat  (cacheTree root MUST exist for a tree, but perhaps no caching of all directories

    if (is_dir($tdir) && $noCache!=1)  {   // JAN 2022 : might want to FIX THIS , to suppress noCache situationally (i.e.; for makeDirList)
         $rets['cacheDir']=$tdir;
         $rets['cacheDirSel']=rtrim($cacheSel,'/').'/'.rtrim($relSelDir,'/').'/';
     }
  }     // cachdir

  $rets['isDir']= (is_dir($pathToCheck)) ? 1 : 0 ;
  $rets['realFileName']=realpath($pathToCheck);    // if no such file, this will be boolean false

  return $rets;

}

//============
// one off (no caching) returnSelector
// treeInfo MUST be correct (is where pathToCheck should be relative to
// this is used when returnSelector fails -- typically due to getting an image in a collection, and the
// image is from a gallery that is NOT the default
// So it is slower, but more dependable, than returnSelector

function returnSelector1($pathToCheck,$treeInfo) {

  $isSel=0;$isRelSel=0;

  $rets=['origPath'=>$pathToCheck, 'realFileName'=>'','galleryName'=>'','treeName'=>'','rootDir'=>'',
         'stdWwwDir'=>0,'rootSel'=>'','underStdWwwDir'=>0,'uriSel'=>'',
         'fullSel'=>'','relSel'=>'',
         'relSelDir'=>'','relSelFile'=>'','relSelFileName'=>'','relSelFileExt'=>'',
         'cacheDir'=>'','cacheDirSel'=>'',
         'error'=>'','fromPP'=>0,'desc'=>'' ];


  $pathToCheck=str_replace('\\','/',trim($pathToCheck));   // convert \ to / (simplifies parsing)
  if (substr($pathToCheck,0,1)=='~')  {   // this is a selector
     $isSel=1;
     $pathToCheck=ltrim($pathToCheck,'~');   // get rid of ~
     $ac1=substr($pathToCheck,0,1);
     if ($ac1!=='/') $isRelSel=1;      // if start with /, path is relative to rootDir. If not, relative to rootdir/rootsel (for this tree)
  }

   $useTreeName=$treeInfo['treeName'];
   $galleryName=$treeInfo['galleryName'];
     $rets['treeName']=$useTreeName;
     $rets['galleryName']=$galleryName;
   $treeRootDir=$treeInfo['rootDir'];  $rets['rootDir']=$treeRootDir;
   $rets['stdWwwDir']=$treeInfo['stdWwwDir'] ;
   $rets['underStdWwwDir']=$treeInfo['underStdWwwDir'] ;
   $rootSel=$treeInfo['rootSel']  ;  $rets['rootSel']= $rootSel;


// hack to deal with selectors (not files). A bit wasteful since it is uses info that is later re-discoverd
   if ($isSel==1) {       //   /foo/bar/xy.z
       if ($isRelSel==1)  {  // foo/bar.xy.z
          $pathToCheck=$treeRootDir.$rootSel.$pathToCheck;
        } else {
          $pathToCheck=$treeRootDir.$pathToCheck;
        }
     }

// check this in tree's base path
     $base1=strtolower($treeRootDir.$rootSel);
     $base1=str_replace('\\','/',$base1);
     $pcheck1=strtolower(substr($pathToCheck,0,strlen($base1)));
     $pcheck1=str_replace('\\','/',$pcheck1);
     if ($pcheck1!=$base1) {
        $rets['error'].=" path=[$pathToCheck] not under tree=[$useTreeName] ($pcheck1!=$base1)" ;
        return $rets;
     }

  $nblen=strlen($treeRootDir);
  $fullSel=substr($pathToCheck,$nblen);
  if (substr($fullSel,0,2)=='//') $fullSel=substr($fullSel,1);
  if (substr($fullSel,0,1)!='/') $fullSel='/'.$fullSel;
  $rets['fullSel']=$fullSel;

   $arf=$_SERVER['PHP_SELF'];
  $nclen=strlen($rootSel);
  $relSel=substr($fullSel,$nclen);
  $rets['relSel']=$relSel;       // assume it is correct

  $islash=strrpos($relSel,'/' );
  $iperiod=strrpos($relSel,'.',$islash );
  if ($iperiod===false) {   // probalby no filena e, so this path is to a directory
      $relSelDir = rtrim($relSel,'/').'/' ;
      $rets['relSelDir']=$relSelDir;
      $rets['relSelFile']='';
  } else {
       $t1= substr($relSel,0,$islash+1);
       $relSelDir = rtrim($t1,'/').'/';
     $rets['relSelDir'] =$relSelDir;
     $rets['relSelFile']=substr($relSel,$islash+1);

     $tname=trim($rets['relSelFile']);
     if ($tname=='') return $rets ; // no filname or ext

     $iperiod=strrpos($tname,'.');
     if ($iperiod===false) {
        $rets['relSelFileName']=$tname;
        $rets['relSelFileExt']='';
     } else {
        $rets['relSelFileName']=substr($tname,0,$iperiod);
        $rets['relSelFileExt']= substr($tname,$iperiod+1);
     }
  }

  $isStd=$rets['stdWwwDir'];
  if ($isStd==1)  {  // under stdwwwdir
     $uriSel=$rets['uriSel']=$fullSel;
  } else {
     $atree=$rets['treeName'];$agallery=$rets['galleryName'];
     $thisrootSel=dirname($_SERVER['PHP_SELF']);   // ie  /www/gallery/wsGallery.php  would yield /www/gallery
     $thisrootSel=str_replace('\\','/',$thisrootSel);
     $i1=strpos($thisrootSel,'/wsGallery');
     if ($i1!==false) {
       $i2=strpos($thisrootSel,'/',$i1+1);
       $rootUri=rtrim(substr($thisrootSel,0,$i2),'/');
     }
     $adir=$rets['relSelDir'];
     $afile=$rets['relSelFile'];
     $uriSel=$rootUri.'/wsGallery_get.php?todo=sendFile&dir='.$adir.'&tree='.$useTreeName.'&gallery='.$galleryName.'&file='.$afile;
  }
  $rets['uriSel']=$uriSel;
  $noCache=$_SESSION['wsGallery_noCache'] ;

  $cacheTree=$treeInfo['cacheTree'];     // reminder: cacheTree is the root for the tree, cacheDir is for THIS file (in this directory in this tree)
  $cacheSel=$treeInfo['cacheSel'];
  $tdir=rtrim($cacheTree,'/').'/'.rtrim($relSelDir,'/');
   if (is_dir($tdir) && $noCache!=1)  {   // JAN 2022 : might want to FIX THIS , to suppress noCache situationally (i.e.; for makeDirList)
         $rets['cacheDir']=$tdir;
         $rets['cacheDirSel']=rtrim($cacheSel,'/').'/'.rtrim($relSelDir,'/').'/';
   }
  $rets['isDir']= (is_dir($pathToCheck)) ? 1 : 0 ;
  $rets['realFileName']=realpath($pathToCheck);    // if no such file, this will be boolean false

  return $rets;

}  //pp
//=================
// check that a treename is legit, and its cache dir exists.
// Return error if not. If exists, return array  of info on this tree
//   treename: string name of tree. Or '' to use default
// note that  $_SESSION['wsGallery_noCache'] does NOT effect this. a tree MUST have a cache directory,  even if its only content is dirlist. json

function getTreeInfo($treename,$returnError=0) {

   $treename=strtolower(trim($treename));   // cleanup
   $treeList= $_SESSION['wsGallery_treeList'] ; // set in wsGallery.php

   if ($treename=='' || $treename=='0') $treename= $_SESSION['wsGallery_currentTree'] ;

   if (!array_key_exists($treename,$treeList)) {
        $res['status']='error';
        $useTreeName=$treeList[0];
        $res['content']="A tree name ($treename) is NOT one of the defined trees (in gallery: ".$treeList[3].")  ";
        $res['content2']=$treeList;
        $_SESSION['wsGallery_errors'][]=$res['content'];
        if ($returnError==1) return  $res ;
        getJs\jsonReturnError($res,$treeList);   // exit with error
    }


    $cacheTree=$treeList[$treename]['cacheTree'];
   if (!is_dir($cacheTree)) {
      $dmess='Warning (getTreeInfo): for tree ('.$treename.') unable to find tree-level cache directory '.$cacheTree;
      $dmess.='<br>Hint: edit this tree\'s wsGallery_treeList.php (add a space), and reload wsGallery';
       if ($returnError==1) return  ['status'=>'error','content'=>$dmess] ;
      getJs\jsonReturnError($dmess);
   }

   $cacheSel='data/'.$treename.'/';

    $vv=$treeList[$treename];
    $vv['treeName']=$treename;
    $vv['galleryName']=$treeList[3];

    $vv['useDir']=$vv['rootDir'].$vv['rootSel'] ;

    return $vv;

}

//================
// read from the html  "tree switch" menu, from a cached file
//  and return as a string,
function  get_treeSwitchMenu($xx=0) {
   $dataDir=$_SESSION['wsGallery_dataDir'] ;            // set in wsgallery.php
   $treeListFile=$dataDir.'/treelistMenu.html';
   $stuff=file_get_contents($treeListFile);
   return $stuff;
}





//=====================
// read a list of files from the cached filelist (_fileList.json) for this dire in this tree
// If .json does not exist, create the file list and save it tothe approprriate cache directory (for use by future clients)
//
// adirFInd -- fullly qualified path. OR perhas a ~relative/path (will be relative to tree's rootdir and rootsel
// atree : tree this directory is under. Error if it is not!
// allowCache: default=1. If 0, do NOT read from cache. Use this to force creation of new _fileList.json file
//                        if 2 (dircache_start), than ONLY read from cache. If not in cache, return some basic stuff
//
// adirFind is used as provided.  So either should be fully qualified directory, or a  xxx/yyy/zzz seletor with a ~ prepended


function get_fileListCache($adirFind,$atree, $allowCache=1 )  {
   $daSpecs=$_SESSION['wsGallery_specsExts'];$allExts=$daSpecs['allExts'];

   $pathSelectorInfo=returnSelector($adirFind,$atree);

   $fullPath= $pathSelectorInfo['realFileName'] ;
   if ($fullPath==false) {
       $aerr= "Directory [$adirFind] not found in tree  ($atree)  " ;
       getJs\jsonReturnError($aerr,$pathSelectorInfo);
  }

   $t2=$pathSelectorInfo['treeName'] ;
   if ($atree!==$t2) {   // should never happen
       $aerr= "Treename associated with this path ($t2) is not requested tree ($atree)" ;
       $vstuff=['status'=>'error','content'=>$aerr];
       $_SESSION['wsGallery_errors'][]= $vstuff['content']    ;
       return $vstuff ;
   }

   $noCache=$_SESSION['wsGallery_noCache'] ;  //--  feb 2022.  let caller worry about nocache. This is returned in vstuff if allowcache=2
   $cacheDirOk=0; $fileCache='';
   $cacheDir=$pathSelectorInfo['cacheDir'];        // tech note: cachedir is the cache for THIS path (it will be under $cacheTree )

   if ($cacheDir!=='' &&  is_dir($cacheDir)) {   // cachedir exists. look for uptodate version of _fileList.json
      $cacheDirOk=1;                    // cache dir exists (so this can be saved if it doesn't exist)
      $fileCache=$cacheDir.'/_fileList.json' ;      // can also be used below (if need to create or recreate this file)
      if (is_file($fileCache)) { // exists... check date
         $pathModTime=filemtime($fullPath);  // last mod of this directory
        $fileCacheModTime=filemtime($fileCache);
        if ($fileCacheModTime>=$pathModTime)   { // this _filelist.json is up to date (assuming no existing file edits)
           $stuff0=file_get_contents($fileCache);   // note: nocache not teeste for, so could return cache info that should NOT be used!
           $vstuff=json_decode($stuff0,true);
           if (array_key_exists('cacheFileInfo',$vstuff)) {  // legit cache file
              if ($allowCache!=0)  {             // allow cache
                 $updateDate=date("Y-m-d H:i",$vstuff['modTime']);
                 $vstuff['cacheMessage']="Using cacheFile ($fileCache): last modified ".$updateDate   ;
                 $vstuff['status']='ok';

                 return $vstuff;
               } else {
                  $cacheMessage='Use of cache file disallowed for this call ';
               }
           }  else { // legit cache file
             $cacheMessage=' Cache file is damaged. ';
           }         // validity check

        }  else {      // cache file up to date
             $cacheMessage=' Cache file is out of date. ';
        }        // time check
     }  else {       // cache file exists
        $cacheMessage=' No existing cache file. ';
     }
  } else {        // cachedir okay
       $cacheMessage="Inaccessible cachedir:  $cacheDir".'.' ;
  }


// no cache file -- make one (or return minimal info if dirCacheStart


// get default dewcription (from a readme.txt file) -- its stored in the dirList. json file for this tree
   $relSelDir=$pathSelectorInfo['relSelDir'];               // pull the dirList entry from this; extrct readme field
   $dirListEntry=getDirListEntry($relSelDir,$atree) ;  // adirfind is a relative seletor ... exit if can't find (note: no need to specify dotransform)

   $adesc=$dirListEntry['dirDesc'];  // feb 2022 : was 'readme'

  if ($allowCache==2)  {           // only read from cache .. but if here there is no cache giveup (status=nocache)
      $cacheDirSel=$pathSelectorInfo['cacheDirSel'];
      $vstuff=['desc'=>'','status'=>'noCache','cacheMessage'=>$cacheMessage,'cacheDir'=>$cacheDir,'cacheDirSel'=>$cacheDirSel];
      return $vstuff;
  }

// create the filelist

  $fullPath2=str_replace('\\','/',$fullPath);
  if (is_string($allExts) && trim($allExts)=='*') {  // This should never happen
    $useThese_files =  glob($fullPath2.'/*');       // look for  these  displayable files -- returns full path to each file
  } else {
    $theseFilesOnlyString=makeListCI($allExts);    // used for ci search  of files in directory (with these extentions)
    $goof=rtrim($fullPath2,'/').'/';
    $gunky=$goof  . $theseFilesOnlyString  ;
    $useThese_files =  glob($gunky, GLOB_BRACE);       // look for  these  displayable files using case insenstive matching -- returns full path to each file
  }

  $useThese_files2=[];   // build a list  with more info ...
  $iuseThese=0;
  $useTheseLookups=[];
  foreach ($useThese_files as $afile) {      // get selector,etc info for this file
      $pp=returnSelector($afile,$atree,$pathSelectorInfo);     // pathSelectorInfo is for dir - include it so save some processing

      if ($pp['error']!=='')   getJs\jsonReturnError($vstuff['content'],"bad return selector (for $afile):   ".$pp['error']);

// get file info (image stuff possibly)
       $pp['fileInfo']=getFileStats($afile);
       $useThese_files2[$iuseThese]=$pp  ;
       $relSelFile=$pp['relSelFile'];
       $useTheseLookups[$relSelFile]=$iuseThese;
       $iuseThese++ ;
   }
   $nowtime=time();
   
//
//  $arf=$_SERVER['PHP_SELF'];
//  $thisrootSel=dirname($_SERVER['PHP_SELF']);   // ie  /www/gallery/wsGallery.php  would yield /www/gallery
//  $thisrootSel=str_replace('\\','/',$thisrootSel);
//  $i1=strpos($thisrootSel,'/wsGallery');
//  if ($i1!==false) {
//    $i2=strpos($thisrootSel,'/',$i1+1);
//    $rootUri=rtrim(substr($thisrootSel,0,$i2),'/');
//  }

   $arf=$_SERVER['PHP_SELF'];
   $pathSelectorInfo['phpSelf']=$arf;
   $vstuff=['status'=>'ok' ,'cacheFileInfo'=>"Unable to save to cache dir",'content'=>'Created','modTime'=>0,
          'fileList'=>$useThese_files2,'pathSelectorInfo'=>$pathSelectorInfo,'desc'=>$adesc,'relSelLookup'=>$useTheseLookups ];


// can it be saved (cacheDir is accessible, and caching not disabled ?)
  if  ($noCache!=1 && $cacheDirOk==1) {
    $vstuff['modTime']= time() ;
    $vstuff['cacheFileInfo']=" Save to cache ($fileCache): ".count($useThese_files2).' entries ';

    $goof=json_encode($vstuff, JSON_UNESCAPED_UNICODE);
    $nsave=file_put_contents($fileCache,$goof);     // filelist.json -- won't happen if nocache (get_fileListCache)
    $vstuff['cacheMessage']=$cacheMessage." Saved to $fileCache " ;
  } else {
      $vstuff['cacheMessage']=$cacheMessage." Cache file not created " ;
  }

  return $vstuff;
}

//=========
// ifnroation on a file -- fully qualified file
function getFileStats($fullFile ) {
     $info1=['fileName'=>$fullFile,'size'=>'','date'=>'','time'=>'','desc'=>'','width'=>'','height'=>'','mimetype'=>''];
     if (!is_file($fullFile)) return $info1 ;

     $fsize=@filesize($fullFile );
     $info1['size']=$fsize;
     $fdate=filemtime($fullFile);
     $info1['time']=$fdate;
     $info1['date']=date ("F d Y H:i ",$fdate);

    $sizeStuff=@getimagesize($fullFile );  // could check for legit extentions to save time...
    if ($sizeStuff!==false) {
          $info1['width']=$sizeStuff[0]  ;
          $info1['height']=$sizeStuff[1];
          $info1['mimetype']=$sizeStuff['mime'];
     }   else {
      $info1['mimetype']=mime_content_type($fullFile);
    }
    return $info1 ;
}

//================
// return dirList  entry for adir (relative) directory  in tree treeName.
// If treename is the current one, save time by using stuff stored in $_SESSION. Otherwise, read the tree's dirlist. json file
//    adir : a dir in a treename.
// or ...
//    '', or '.' : get all dir (tree) info.
//    '*' : return full list of direntries, in an associative array. This is a transofrmation of the simple array --
//                each entry is [dirname]=info
//                treeINfo still in '.'
//    '**' : returns full file, no transformation ([0]=html menu, [1]=array of tree (asscoative array of attributes for each)
// if doValidate=1 : make sure the directory still exists in the tree
// doTransform: used if adir '*' or '**' : 1=transform the array of dirs into an associative array. 0= returns as is
//              Caution: if dirlist worked on, and returned to setDirListEntry -- be sure to specify same doTransform!
//
//   returns either the info requested in adir ("treeInfo", the associative array of all entries, the entire file,  or the adir entry)
//   Or, if some kind of error (such as no dirlist. json file) :
//         {'.error'=>'error message','treeList=>treeList}
//    The error message might contains suggestions and buttons to invoke the admin menu
//    Note use of ".error", not "error" (to avoid conflict with a tree with the name of 'error'

function getDirListEntry($adir,$treeName,  $doTransform=1,$doValidate=0) {

  $dirListCurrent=[] ; // assume no caching

  $adir=str_replace('\\','/',trim($adir));
  if ($adir=='' || $adir=='.') {
      $getTreeInfo=1;
  } else if ($adir=='*') {
      $getTreeInfo=2;
  } else if ($adir=='**') {
      $getTreeInfo=3;
  } else {
    $getTreeInfo=0;
    $adir=trim($adir,'/');  // must be relative selector
  }

   $treeList=$_SESSION['wsGallery_treeList'];
   if (!array_key_exists($treeName,$treeList) )  return ['error'=>"Error: unable to find  tree $treeName in treelist",'treeList'=>$treeList];
   $thisTreeInfo=$treeList[$treeName] ;
   $treeCacheDir=$thisTreeInfo['cacheTree'] ;
   if (!is_dir($treeCacheDir))   {   // even if dirlist. json not yet created, the treeCacheDir WAS created (by initTreeList)
        return ['.error'=>"There is no cache directory ($treeCacheDir) for this tree ($treeName).  The administrator must create it",'treeList'=>$treeList];
  }

  $dirListJsonFile=$treeCacheDir.'/dirList.json';    // getDirListEntry read!
  if (!is_file($dirListJsonFile)) {
       $sfoo="For tree $treeName: unable to find a directory list ($dirListJsonFile). The admin should create/update/refresh a  ";
       $sfoo.=' <input type="button" value="directory list" onclick="doAdmin(1)"> for this tree. ';
 //      getJs\jsonReturnError($sfoo,$treeList);
      return ['.error'=>$sfoo,'treeList'=>$treeList];
   }

  if ($doValidate==1) {
    $actualDir=rtrim($thisTreeInfo['rootDir'],'/').'/'.ltrim($thisTreeInfo['rootSel'],'/');
    if (!is_dir($actualDir))  return ['.error'=>"There is no such directory ($actualDir): for tree: $treeName, dir: $adir",'treeList'=>$treeList];
  }

// ready to get from this trere's dirlist. json (cache) file
  $jj1=file_get_contents($dirListJsonFile);
  $stuff3=json_decode($jj1,true);          // stuff[0] is the html table used to select a dir to view
  
 // getJs\jsonReturnError($stuff3,"crap from  getDirListEntry $adir,$treeName");
  $dirlist=$stuff3[1];

  if ($getTreeInfo==1) return $dirlist['.'];
  if ($getTreeInfo==2) return getDirListEntryTransform($dirlist,$doTransform) ;
  if ($getTreeInfo==3) return $stuff3;   // full file, untransfomed [0]=html menu, [1]=array of trees

  $lookups=$dirlist['.']['dirLookup'];           // a specific dir ...
  if (!array_key_exists($adir,$lookups))  return ['.error'=>"Unable to find ($adir) in dirList lookups",'treeList'=>$treeList ];

  $ith1=$lookups[$adir] ;
  $anentry=$dirlist[$ith1];
  return $anentry;

}

// make associative array of a dirLIst
function getDirListEntryTransform($dirList,$doTransform) {
   if ($doTransform==0) return $dirList ;

   $dirListA=[];
   foreach ($dirList as $ith=>$stuff) {
       if ($ith==='.') {
           $dirListA['.']=$stuff;
           continue;
       }
       if (!array_key_exists("dirname",$stuff)) continue ;   // shouldn't happen
       $adir=$stuff['dirname'];
       $dirListA[$adir]=$stuff;
   }
   return $dirListA ;

}

//==============================
// save a dirListEntry in a tree to its dirlist. json file

function  setDirListEntry($adir,$treeName,$newInfo,$mustHaveViewable=1,$doTransform=0) {

  $adir=str_replace('\\','/',trim($adir));
  if ($adir=='' || $adir=='.') {
      $setTreeInfo=1;
  } else if ($adir=='*') {
      $setTreeInfo=2;
  } else if ($adir=='**') {
      $setTreeInfo=3;
  } else {
    $setTreeInfo=0;
    $adir=trim($adir,'/');  // must be relative selector
  }

  $treeList=$_SESSION['wsGallery_treeList'];
  if (!array_key_exists($treeName,$treeList) )  getJs\jsonReturnError("Error setDirListEntry: unable to find  tree $treeName in treelist",$treeList);
   $thisTreeInfo=$treeList[$treeName] ;
   $treeCacheDir=$thisTreeInfo['cacheTree'] ;
   if (!is_dir($treeCacheDir))  {   // this should never happen
       getJs\jsonReturnError("setDirListEntry: There is no cache directory ($treeCacheDir) for this tree ($treeName).  The administrator must create it",$treeList);
  }

  $dirListJsonFile=$treeCacheDir.'/dirList.json';  // setDirListEntry write!
   if (!is_file($dirListJsonFile))  {   // this could happen if looking at all trees, including those not yet with dirlist. json "created"
     return 'dirList file not yet created -- can not enable or disable!';
  }

  $jj1=file_get_contents($dirListJsonFile);
  $stuff3=json_decode($jj1,true);          // [0]=htmlmenu, and [1]
  $dirlist=$stuff3[1];

  if ($setTreeInfo==1) {  // just change "tree info"
      $dirlist['.']=$newInfo;
      $stuff3[1]=$dirlist;
  } else if ($setTreeInfo==2) {   // chjange "all dirs"
      $stuff3[1]=setDirListEntryUntransform($newInfo,$doTransform);
  } else if ($setTreeInfo==3) {   // create html menu and update  dirsList
      $dirList=setDirListEntryUntransform($newInfo,$doTransform) ;
      $stuff3[1]=$dirList;
      $htmlMenu=makeDirList_create_dirsTableHeader($treeName,0) ;   // non admin mode (for saving for general use)
      $htmlMenu.=makeDirList_create_dirsTable($dirList,$mustHaveViewable,0);
      $stuff3[0]=$htmlMenu;
  } else {                          // just change one of the dir entries
      $lookups=$dirlist['.']['dirLookup'];
      if (!array_key_exists($adir,$lookups))  getJs\jsonReturnError("Unable to find ($adir) in dirList lookups",$dirlist['.'] );
      $ith1=$lookups[$adir] ;
      $dirlist[$ith1]=$newInfo;
      $stuff3[1]=$dirlist;
  }
  $goof=json_encode($stuff3, JSON_UNESCAPED_UNICODE);
  $nsave=file_put_contents($dirListJsonFile,$goof);     // dirList.json -- won't happen if nocache

  return "  entry changed in $dirListJsonFile ";


}
function setDirListEntryUntransform($dirListT,$doTransform) {
    if ($doTransform==0) return $dirListT ;
    $dirList=[];
    $a1=$dirListT['.'];
    $lookup=$a1['dirLookup'];
    $dirList['.']=$a1;
    foreach ($lookup as $adir=>$ith) {
        $dirList[$ith]=$dirListT[$adir]  ;
    }
    return $dirList  ;
}


//=============
// match extension to mimetype. Not necessarily dependable, but good for guessing
//https://gist.github.com/raphael-riel/1253986
function extToMimetype($aext) {
  $types = array(
    'ai'      => 'application/postscript',
    'aif'     => 'audio/x-aiff',
    'aifc'    => 'audio/x-aiff',
    'aiff'    => 'audio/x-aiff',
    'asc'     => 'text/plain',
    'atom'    => 'application/atom+xml',
    'au'      => 'audio/basic',
    'avi'     => 'video/x-msvideo',
    'bcpio'   => 'application/x-bcpio',
    'bin'     => 'application/octet-stream',
    'bmp'     => 'image/bmp',
    'cdf'     => 'application/x-netcdf',
    'cgm'     => 'image/cgm',
    'class'   => 'application/octet-stream',
    'cpio'    => 'application/x-cpio',
    'cpt'     => 'application/mac-compactpro',
    'csh'     => 'application/x-csh',
    'css'     => 'text/css',
    'csv'     => 'text/csv',
    'dcr'     => 'application/x-director',
    'dir'     => 'application/x-director',
    'djv'     => 'image/vnd.djvu',
    'djvu'    => 'image/vnd.djvu',
    'dll'     => 'application/octet-stream',
    'dmg'     => 'application/octet-stream',
    'dms'     => 'application/octet-stream',
    'doc'     => 'application/msword',
    'dtd'     => 'application/xml-dtd',
    'dvi'     => 'application/x-dvi',
    'dxr'     => 'application/x-director',
    'eps'     => 'application/postscript',
    'etx'     => 'text/x-setext',
    'exe'     => 'application/octet-stream',
    'ez'      => 'application/andrew-inset',
    'gif'     => 'image/gif',
    'gram'    => 'application/srgs',
    'grxml'   => 'application/srgs+xml',
    'gtar'    => 'application/x-gtar',
    'hdf'     => 'application/x-hdf',
    'hqx'     => 'application/mac-binhex40',
    'htm'     => 'text/html',
    'html'    => 'text/html',
    'ice'     => 'x-conference/x-cooltalk',
    'ico'     => 'image/x-icon',
    'ics'     => 'text/calendar',
    'ief'     => 'image/ief',
    'ifb'     => 'text/calendar',
    'iges'    => 'model/iges',
    'igs'     => 'model/iges',
    'jpe'     => 'image/jpeg',
    'jpeg'    => 'image/jpeg',
    'jpg'     => 'image/jpeg',
    'js'      => 'application/x-javascript',
    'json'    => 'application/json',
    'kar'     => 'audio/midi',
    'latex'   => 'application/x-latex',
    'lha'     => 'application/octet-stream',
    'lzh'     => 'application/octet-stream',
    'm3u'     => 'audio/x-mpegurl',
    'man'     => 'application/x-troff-man',
    'mathml'  => 'application/mathml+xml',
    'me'      => 'application/x-troff-me',
    'mesh'    => 'model/mesh',
    'mid'     => 'audio/midi',
    'midi'    => 'audio/midi',
    'mif'     => 'application/vnd.mif',
    'mov'     => 'video/quicktime',
    'movie'   => 'video/x-sgi-movie',
    'mp2'     => 'audio/mpeg',
    'mp3'     => 'audio/mpeg',
    'mpe'     => 'video/mpeg',
    'mpeg'    => 'video/mpeg',
    'mpg'     => 'video/mpeg',
    'mpga'    => 'audio/mpeg',
    'ms'      => 'application/x-troff-ms',
    'msh'     => 'model/mesh',
    'mxu'     => 'video/vnd.mpegurl',
    'nc'      => 'application/x-netcdf',
    'oda'     => 'application/oda',
    'ogg'     => 'application/ogg',
    'pbm'     => 'image/x-portable-bitmap',
    'pdb'     => 'chemical/x-pdb',
    'pdf'     => 'application/pdf',
    'pgm'     => 'image/x-portable-graymap',
    'pgn'     => 'application/x-chess-pgn',
    'png'     => 'image/png',
    'pnm'     => 'image/x-portable-anymap',
    'ppm'     => 'image/x-portable-pixmap',
    'ppt'     => 'application/vnd.ms-powerpoint',
    'ps'      => 'application/postscript',
    'qt'      => 'video/quicktime',
    'ra'      => 'audio/x-pn-realaudio',
    'ram'     => 'audio/x-pn-realaudio',
    'ras'     => 'image/x-cmu-raster',
    'rdf'     => 'application/rdf+xml',
    'rgb'     => 'image/x-rgb',
    'rm'      => 'application/vnd.rn-realmedia',
    'roff'    => 'application/x-troff',
    'rss'     => 'application/rss+xml',
    'rtf'     => 'text/rtf',
    'rtx'     => 'text/richtext',
    'sgm'     => 'text/sgml',
    'sgml'    => 'text/sgml',
    'sh'      => 'application/x-sh',
    'shar'    => 'application/x-shar',
    'silo'    => 'model/mesh',
    'sit'     => 'application/x-stuffit',
    'skd'     => 'application/x-koan',
    'skm'     => 'application/x-koan',
    'skp'     => 'application/x-koan',
    'skt'     => 'application/x-koan',
    'smi'     => 'application/smil',
    'smil'    => 'application/smil',
    'snd'     => 'audio/basic',
    'so'      => 'application/octet-stream',
    'spl'     => 'application/x-futuresplash',
    'src'     => 'application/x-wais-source',
    'sv4cpio' => 'application/x-sv4cpio',
    'sv4crc'  => 'application/x-sv4crc',
    'svg'     => 'image/svg+xml',
    'svgz'    => 'image/svg+xml',
    'swf'     => 'application/x-shockwave-flash',
    't'       => 'application/x-troff',
    'tar'     => 'application/x-tar',
    'tcl'     => 'application/x-tcl',
    'tex'     => 'application/x-tex',
    'texi'    => 'application/x-texinfo',
    'texinfo' => 'application/x-texinfo',
    'tif'     => 'image/tiff',
    'tiff'    => 'image/tiff',
    'tr'      => 'application/x-troff',
    'tsv'     => 'text/tab-separated-values',
    'txt'     => 'text/plain',
    'ustar'   => 'application/x-ustar',
    'vcd'     => 'application/x-cdlink',
    'vrml'    => 'model/vrml',
    'vxml'    => 'application/voicexml+xml',
    'wav'     => 'audio/x-wav',
    'wbmp'    => 'image/vnd.wap.wbmp',
    'wbxml'   => 'application/vnd.wap.wbxml',
    'wml'     => 'text/vnd.wap.wml',
    'wmlc'    => 'application/vnd.wap.wmlc',
    'wmls'    => 'text/vnd.wap.wmlscript',
    'wmlsc'   => 'application/vnd.wap.wmlscriptc',
    'wrl'     => 'model/vrml',
    'xbm'     => 'image/x-xbitmap',
    'xht'     => 'application/xhtml+xml',
    'xhtml'   => 'application/xhtml+xml',
    'xls'     => 'application/vnd.ms-excel',
    'xml'     => 'application/xml',
    'xpm'     => 'image/x-xpixmap',
    'xsl'     => 'application/xml',
    'xslt'    => 'application/xslt+xml',
    'xul'     => 'application/vnd.mozilla.xul+xml',
    'xwd'     => 'image/x-xwindowdump',
    'xyz'     => 'chemical/x-xyz',
    'zip'     => 'application/zip'
  );
  $aextC=trim(strtolower($aext)) ;
  if (!array_key_exists($aextC,$types)) return "application/octet-stream";
  return $types[$aextC] ;
}

//===================
// get a <img link to a spinner file (in icons/spinner). Or '' if can't find that dir
// deprecated, done on js size
function getSpinnerImg($ksize=30) {  // semi deprectated
    if (!is_numeric($ksize)) $ksize=30;
    $ksize=intval($ksize);
    $goof=getcwd().'/icons/spinners';
    if (is_dir($goof)) {
       $sfiles0=glob($goof.'/*');
       $sfiles=array_filter($sfiles0,'is_file');      // find subdiretories of this subdir
       $aind=rand(0,count($sfiles)-1);
       $afile=$sfiles[$aind];
       $afilename=pathinfo($afile,PATHINFO_FILENAME);
       $asimg='<img alt="spinner" src="icons/spinners/'.$afilename.'" height="'.$ksize.'px" width="'.$ksize.'px">';
       $tmess=$asimg.'   '.$tmess;
    } else {
      $tmess='';   // give up
    }
    return $tmess ;

}
//=====================
// validate what image files this install of php supports
// returns associateive array with extensions of imagetypes that are supported    
// possible index values: bmp gif jpg jpgeg png wbmp xpm webp
// Lookup using lower case.
// Thus, if this array does not have a key corrspoding to an image type, it is NOT supported

function findPhpImageSupport($a) {

  $imgSupports=[];
  $arf=imagetypes();
  $checkems=[IMG_BMP,IMG_GIF,IMG_JPG,IMG_PNG,IMG_WBMP,IMG_XPM,IMG_WEBP];
  $checkems2=['BMP','GIF','JPG','PNG','WBMP','XPM','WEBP'];
  for ($ii=0;$ii<count($checkems);$ii++) {
      $acheckem=$checkems[$ii];
      $aext=$checkems2[$ii];
      $aextLc=strtolower($aext) ;
      if ($arf & $acheckem) {
          $imgSupports[$aextLc]=1;
          if ($aextLc=='jpg')  $imgSupports['jpeg']=1;
      }
  }

   return $imgSupports;
}


//===-
// extract a request field (GET or POST)
// varname is name of field to get. can be a space delimited list of names (first one found is returned)
// if $errormess='', return $default if no such field
//    if = '1',  display generic error  message and exit
//    else, display $errormess and exit
function extractRequestVar($varname,$default='0',$errorMess='') {
$varname=trim(strtoupper($varname));
$vars =getWords($varname);

foreach ($_REQUEST as $vname=>$oof) {
     $avar=trim(strtoupper($vname)) ;
     for ($ith=0;$ith<count($vars);$ith++) {
        if ($avar==$vars[$ith]) {
           return $oof ;
        }
     }
}
// if here, could not be found

$errorMess=trim($errorMess);
if ($errorMess!=='') {          // an error, quit      -- sep 2014 note: on too large file uploads, you might get this error (buffer overwrite?)
  if ($errorMess=='1') {
     $file = $_SERVER["SCRIPT_NAME"];
      $break = explode('/', $file);
      $pfile = $break[count($break) - 1];
//      ob_get_clean() ;

//      header("Content-Type: text/plain");
      print "\n";
      print '- Error. not able to find request variable (' . $varname . ') in ' . $pfile ;
      if (count($_REQUEST)==0) {
         print '   <br>Note: the $_REQUEST parameter is empty. This is often a sign of an upload that exceeds server limits. '  ;
      }
  } else {
     header("Content-Type: text/plain");
     print $errorMess ;
  }
  exit ;
}

 return $default ;
}

//=============
// trim spaces, convert internal spaces to single space string, break into an array
// if docomma=1, treat commas and tabs and new lines as spaces
function getWords($cval3,$docomma=0) {
    $cval3=trim($cval3);
    if ($docomma==1) {
      $cval4=preg_replace("/[\t\n\r\s,]+/"," ", $cval3) ;             // collapse spaces and other seperators
    } else {
      $cval4=preg_replace("/\s+/"," ", $cval3) ;             // collapse spaces
    }
    $bvars=explode(' ',$cval4) ;
    return $bvars ;

}


// ================
// takes a value from ini_get(), and converts to an integer (i.e.; 8M becomes 8388608)
 function getBytes($val) {
    $val = trim($val);
    preg_match('/([0-9]+)[\s]*([a-zA-Z]+)/', $val, $matches);
    $value = (isset($matches[1])) ? intval($matches[1]) : 0;
    $metric = (isset($matches[2])) ? strtolower($matches[2]) : 'b';
    switch ($metric) {
        case 'tb':
        case 't':
            $value *= 1024;
        case 'gb':
        case 'g':
            $value *= 1024;
        case 'mb':
        case 'm':
            $value *= 1024;
        case 'kb':
        case 'k':
            $value *= 1024;
    }
    return $value;
}

//print_r(getSystemMemoryInfo());
//    [MemTotal] => 8102684000        Total amount of physical RAM
//    [MemFree] => 2894508000         The amount of physical RAM left unused by the system. 
//    [MemAvailable] => 4569396000
//    [SwapTotal] => 4194300000       The total amount of swap available . 
//    [SwapFree] => 4194300000       The total amount of swap free
//

function wmiWBemLocatorQuery( $query ) {
    if ( class_exists( '\\COM' ) ) {
        try {
            $WbemLocator = new \COM( "WbemScripting.SWbemLocator" );
            $WbemServices = $WbemLocator->ConnectServer( '127.0.0.1', 'root\CIMV2' );
            $WbemServices->Security_->ImpersonationLevel = 3;
            // use wbemtest tool to query all classes for namespace root\cimv2
            return $WbemServices->ExecQuery( $query );
        } catch ( \com_exception $e ) {
            echo $e->getMessage();
        }
    } elseif ( ! extension_loaded( 'com_dotnet' ) )
        trigger_error( 'It seems that the COM is not enabled in your php.ini', E_USER_WARNING );
    else {
        $err = error_get_last();
        trigger_error( $err['message'], E_USER_WARNING );
    }

    return false;
}

//  linux and windows versions
function getSystemMemoryInfo( $output_key = '' ) {
    $keys = array( 'MemTotal', 'MemFree', 'MemAvailable', 'SwapTotal', 'SwapFree' );
    $result = array();
    $isWin=0  ;
    if (strtoupper(substr(PHP_OS, 0, 3))  === 'WIN') $isWin=1;

    try {                   // LINUX
       if ($isWin==0) {
         if (!file_exists('/proc/meminfo')) return false;
         $data = explode("\n", file_get_contents("/proc/meminfo"));
         $meminfo = array();
         foreach ($data as $line) {
            list($key, $val) = explode(":", $line);
            $meminfo[$key] = trim($val);
         }
         $amult= (strpos(strtoupper($meminfo['MemFree']),'KB')!==false) ? 1024 : 1 ;        $result['MemFree'] =intval($meminfo['MemFree'])*$amult;
         $amult= (strpos(strtoupper($meminfo['MemAvailable']),'KB')!==false) ? 1024 : 1 ;        $result['MemAvailable'] =intval($meminfo['MemAvailable'])*$amult;
         $amult= (strpos(strtoupper($meminfo['MemTotal']),'KB')!==false) ? 1024 : 1 ;        $result['MemTotal'] =intval($meminfo['MemTotal'])*$amult;
         $amult= (strpos(strtoupper($meminfo['SwapFree']),'KB')!==false) ? 1024 : 1 ;        $result['SwapFree'] =intval($meminfo['SwapFree'])*$amult;
         $amult= (strpos(strtoupper($meminfo['SwapTotal']),'KB')!==false) ? 1024 : 1 ;        $result['SwapTotal'] =intval($meminfo['SwapTotal'])*$amult;

        } else  {    // WINDOWS
            $wmi_found = false;
            if ( $wmi_query = wmiWBemLocatorQuery(
                "SELECT FreePhysicalMemory,FreeVirtualMemory,TotalSwapSpaceSize,TotalVirtualMemorySize,TotalVisibleMemorySize FROM Win32_OperatingSystem" ) ) {
                foreach ( $wmi_query as $r ) {
                    $result['MemFree'] = $r->FreePhysicalMemory * 1024;
                    $result['MemAvailable'] = $r->FreeVirtualMemory * 1024;
                    $result['SwapFree'] = $r->TotalSwapSpaceSize * 1024;
                    $result['SwapTotal'] = $r->TotalVirtualMemorySize * 1024;
                    $result['MemTotal'] = $r->TotalVisibleMemorySize * 1024;
                    $wmi_found = true;
                }
            }
        }
    } catch ( Exception $e ) {
        echo $e->getMessage();
        return false;
    }
    return empty( $output_key ) || ! isset( $result[$output_key] ) ? $result : $result[$output_key];
}


?>
