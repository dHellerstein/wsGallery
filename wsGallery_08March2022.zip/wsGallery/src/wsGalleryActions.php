<?php
session_start() ;
ob_start();

use wSurvey\getJson as getJs  ;

// -----------------------------------
// action handler for wsGallery  -- called from .js side use ajax (.get) functions
//
// Admin changeable parameters are in wsGallery_params.php,
//  what trees (directory paths) are set in wsGallery_treeList.php
//  username/password (for admin only are in wsCheckLogonParams.php
//
//  --------------------------
//todos in wsGallery_actions.php.
//  See wsGalleryActionsAdmin for admin "actions"
//
//
//getDirFileList              retrieve a list of  'displayable' files in a chosen directory.
//                            Calls doGetDirFileList (in wsGallery_fileList.php
//                            Called by getDirFileList in wsGallery.js
//
//retrieveDirList                   retreive html menu of subdirs that contain displayable (i.e.; image) files in chosen tree.
//                             These may be pulled from an existing cache file (created by makeDirLIst)
//                             retrieveDirList is called by loadTreeDirs in wsGallery_dirVUs.js
//
//switchTree                   change value of currentTree (used   the default tree if none provided.
//                             switchTree is called by  switchCurrentTree in wsGallery.js
//

//  ---------------------------------------------


$nowtime=time();
$rootdir=$_SERVER['DOCUMENT_ROOT'] ;
//$curDir=getcwd();
$wsMainDir=$_SESSION['wsGallery_mainDir'];
 
require_once($wsMainDir.'/libs/php/wsurvey.getJson.php');

require_once($wsMainDir.'/src/wsGalleryLibUtils.php');
require_once($wsMainDir.'/src/wsGallery_fileList.php');


  $todo=extractRequestVar('todo','');


// note: logon stuff done by generic libraries wsCheckLogon.php and wsCheckLogon.js

// ::::
// return a resized image. Check cache dir first (for snapshots). Otherwise, make one on the fly


// ::::
// retrieve 'displayable' files in a chosen directory
if ($todo=='getDirFileList' ) {      // || $todo=='getDirFileListThumbnails') {
    $adir=extractRequestVar('dir','');        // relative dir (relative to treename rootDir/rootSel
    $atree=extractRequestVar('treename','');
    $showFileName=extractRequestVar('showFileName','0');
    $ihow=extractRequestVar('how','0');  //    0=text,1= tSmall:40,2= tMedium:65,3= tBig:90;  (perhaps later 4= tBigger:120

    $vstuff=doGetDirFileList($ihow,$showFileName,$atree,$adir); // make "ihow" file list just for this dir (in atree) (in wsGallery_fileList.php
    getJs\jsonReturn($vstuff);

    exit;
}

// ::::
// retreive html menu of  dirs that contain displayable (i.e.; image) files in chosen tree.
// And return the dirList associative array (one entry per dir in this tree, and some meta data on the tree)
// These may be pulled from an existing cache file (created by makeDirLIst)

if ($todo=='retrieveDirList') {

    $res=['status'=>'error','content'=>'dogs','treeSwitchMenu'=>'treeList not available'];
    $thisTree=extractRequestvar('treeName','' );    // this is semi deprecated (debug check) feb 2022
    if ($thisTree=='') getJs\jsonReturnError('retrieveDirList: no tree specified');

    $stuff2=getDirListEntry('**',$thisTree,0);     // get everything untransfomed
    if (array_key_exists('.error',$stuff2)) {         // a problem
       $res['content']=retrieveDirList_errorNotice($thisTree,$stuff2['.error']);
       $res['treeSwitchMenu']=get_treeSwitchMenu() ; // read from cache file
       $res['status']='na';
       getJs\jsonReturn($res);
    }

// if here, got the dirlist. json file!
     $res['status']='ok';
     $res['content']=$stuff2[0];
     $res['dirList']=$stuff2[1];
     $res['treeSwitchMenu']=get_treeSwitchMenu() ; // read from cache file
     $baseI=$stuff2[1]['.'];
     $res['basics']=$baseI; /// treeName, origPath, totFiles, totDirs, totImages, etc
     getJs\jsonReturn($res);


}     //  retrieveDirList


// ::::::::::
// change value of currentTree (used as the default tree if none provided.
if ($todo=='switchTree') {
   $priorCurrentTree=$_SESSION['wsGallery_currentTree'] ;
   $res=['status'=>'ok','content'=>''] ;
   $useTree=extractRequestVar('treeName','') ;

   $thisTreeInfo=getTreeInfo($useTree) ;  // check that useTree exists    -- exits with error if it does not

   $_SESSION['wsGallery_currentTree']=$useTree;
   $res['content']='The current tree is now:'.$useTree.' (prior value='.$priorCurrentTree.')';
   getJs\jsonReturn($res);
}


// ::::

print "<br>Unknown action: $todo ";
 exit;




?>