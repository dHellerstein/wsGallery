//===============================
// direcotry view and retrieve stuff (for current or specifid  tree)
// and disable views of specified diretories
// for wsGallery

//============
// toggle, or force, view of  the 'dirList flContent box -- where the list of the currentTree's directories is displayed
// doshow is optional. 0 (default)= toggle, 1=force show, 2= force hide

function toggleDirVu(doshow) {

   var doshow1='0';
   if (arguments.length<0) doshow='0';
   let atype=typeof(doshow);
   if (atype=='number' || atype=='string'){
      doshow=jQuery.trim(doshow);
   } else {           // a click handler? look for 'show' attribute. if not available, assume toggle
      let e1=wsurvey.argJquery(doshow);
      if (e1.length>0) {
        let aa=e1.wsurvey_attr('show',0)
        doshow=jQuery.trim(aa);
      }
   }
   if (doshow=='2') {     // special case
        wsurvey.flContents.hide(100,'dirList');
        return 1;
   }
   if (doshow=='1') {     // special case
        wsurvey.flContents.hide(100,'dirList',1);
        toggleSwitchTreeMenu(1);
        return 1;
   }

// else toggle
   var isvis =wsurvey.flContents.visible('dirList');
   if (isvis==0  || doshow==1 ) {

        wsurvey.flContents.show(100,'dirList',1);
        toggleSwitchTreeMenu(1);
    } else {
        wsurvey.flContents.hide(200,'dirList');
    }
    return isvis;
}

//===============
// get list of directories for a tree, and display
// Feb 2022: treename is always 0.  Always use the .data('currentTree') value.
//          debug1: not currently used. Could be used for debugging
//          hideTreeList : not currently used. if 1, then hide the tree list menu after displaying stuff in dirList flContents
// Note: to toggle view of the currentTree's directory list (and not reload), use toggleDirVu
//
// loadTreeDirs is called in 3 places in  wsGallery.js
//   in init, in a button loaded in top of the dirLIst - to refresh the current dlirst. NOt that useful anymore  -- except to switch from admin to normal view
//   in init, at the end -- to load the current default tree. Treename=0 : use the "currenTree"
//   in switchCurrentTree buttons in the treeList menu

function loadTreeDirs(treeName,debug1,hideTreeList) {

   if (arguments.length<1) treeName='';       // feb 2022: it should always be '0'
   if (arguments.length<2) debug1='';
   if (arguments.length<3) hideTreeList=0;

   if (treeName=='' || treeName=='0') treeName=$(document).data('currentTree'); // loadTreeDirs -- always use currentTree (invocation=default, or after switchTree call

    var adata={'todo':'retrieveDirList','treeName':treeName,'hideTreeList':hideTreeList }  ;

    wsurvey.getJson.get('wsGalleryActions.php',adata, loadTreeDirsB ,' Retrieving list of files in a directory (using loadTreeDirs)');
    return 1;
}


//=========
// display list of dirs
function loadTreeDirsB(response,origData,otherArgs) {      // don't need  otherArg,tstatus,xhr)

   var hideTreeList=0;
    hh=wsurvey.getJson.check(response,0,'Callback form loadTreesDir');
    if (hh===false) return 0;

    let acontent=hh['content'];
    if (hh['status']=='na') {  // not avaialble
         wsurvey.flContents.contents('dirList',acontent);
         let mm=hh['treeSwitchMenu'];                   // show treelist
         $('#switchTreeMenu').html(mm);
         let ehh=$('[name="headerToggleSwitchTreeButton"]');
         ehh.css({"opacity":''})
         return 1;
    }

// if here okay

     let basics=hh['basics'];
     wsurvey.flContents.contents('dirList',acontent);
     let mm=hh['treeSwitchMenu'];
     $('#switchTreeMenu').html(mm);
      let ehh=$('[name="headerToggleSwitchTreeButton"]');
      ehh.css({"opacity":''})

      if (origData.hasOwnProperty('hideTreeList'))  hideTreeList=origData['hideTreeList']  ;

     let aheader=' :  In the <tt>'+basics.totDirs+' </tt> directories in tree <span class="headerEmphasizer" >'+basics['treeName']+'</span>: # files=<tt>'+basics.totFiles+' (including <tt>'+basics.totImages+'</tt> images) ';
    wsurvey.flContents.header('dirList',aheader);
//     $('#imageDirDetails').show();  // deprecated feb 2022
     if (hideTreeList!=1) {
           toggleSwitchTreeMenu(1);
           let ehh=$('[name="headerToggleSwitchTreeButton"]');
          ehh.css({"opacity":''})

     } else {
         $('#switchTreeMenu').hide();
     }

// add click handlers
    $('#dirListingTable').on('click',dirListClickHandlerClient)
}


//================  ==========================================
// dirlist click handler (several possible actions, depending on what was clicked ) -- client version
function dirListClickHandlerClient(evt) {

   let ethis=wsurvey.argJquery(evt);
   let aname=ethis.attr('name');

   if (aname=='dirListFileViewFiles') {  // simple case: click in desription area -- so that the "lastFocus"
      getDirFileListJs(evt);
      return 1;
   }           // dirlistdescarea

//  if (aname=='dirListFileDescButton') {  // view the list of files and their descriptions button
//       doChangeFileDescs(ethis) ;
//       return 1;
//   }

}