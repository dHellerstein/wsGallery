<?php

use wSurvey\getJson as getJs  ;

//=======================
// functions used by wsGalleryActions.php
// Main functions:
// makeDirList_base -- which callls
//    makeDirList_create == return list of directories (in a tree, defined by a root path)
// ===================================================================

// =========================
// get a list of directories, and information about them
// ===================================================================

//================
// make the directory list (in a tree) =- dirlist. json in the cache directory. Either afresh, or changes to disable
// if makeDirLIst : keepDisabled is 0 or 1
// note that $_SESSION['wsGallery_noCache'] does NOT effect this-- dirlist. json always created in a trees' cache dir (it
// may be the only thing in there
//
// rather than a pure "create a list of directories, perhaps retaining disabbled status"  (no choices on disable status)

 function  makeDirList_base($doResume,$doThisTree,$keepDisabled,$keepDescriptions,$removeUnusedCache,$mustHaveViewable ,$timeAllowed  ) {

   $res=[];

   if ($doResume==1)  {   // a resume .. make sure it's not goofy
      $arf=$_SESSION['wsGallery_cacheDirStateVars'];
      if ($arf['treeName']==$doThisTree   && $arf['action']=='makeDirList') {
        $resumeStatus=$arf['resumeStatus'];
      } else {
         getJs\jsonReturnError("Mismatch in makeDirList_base resume ($treeName,$action)" ,$arf) ;
      }  // if no match, start from scratch (though will skip prior craeted stuff if overwritre=0
      $treeUseInfo=$resumeStatus['treeUseInfo']; // get from resume status
      $priorDirList= $arf['priorDirList'] ;

   }  else {    // first call. if keepdescriptions or keepdisabled -- read the dirlist and save for later use
       $resumeStatus=[];
       $treeUseInfo=getTreeInfo($doThisTree) ; // exit on error
       $resumeStatus['treeUseInfo']=$treeUseInfo ;
       $priorDirList=[];
       if ($keepDescriptions==1 || $keepDisabled==1) {
            $priorDirList0=getDirListEntry('*',$doThisTree,1); // read transformed for easier use belwo
           // getJs\jsonReturnError('makeDirList_base makn priordirlist ',$priorDirList0);
            if (!array_key_exists('error',$priorDirList0) &&!array_key_exists('.error',$priorDirList0)) {  // no error .. pull out releveant attributes
               foreach ($priorDirList0 as $adir=>$vv) {
                  if ($adir==='.') continue ;
                  $priorDirList[$adir]=[];
                  if ($keepDisabled==1)  $priorDirList[$adir]['priorDisable']=$vv['isDisabled'];
                  if ($keepDescriptions==1)  $priorDirList[$adir]['priorDesc']=$vv['dirDesc'];
               }
            }   // not error in getdirlistentry
       }   // keepdesc or keepdisabled
       $arf=['treeName'=>$doThisTree, 'action'=>'makeDirList','resumeStatus'=>$resumeStatus,'priorDirList'=>$priorDirList] ;
       $_SESSION['wsGallery_cacheDirStateVars']=$arf;

   }    // resume=0

//makeDirList_create does the work. First bulid dir list, then files in each dir.
// can return a resume during dir list buile, or during files in each dir

   $stuff2=makeDirList_create($treeUseInfo,$doThisTree,$mustHaveViewable,$priorDirList,$resumeStatus,$timeAllowed);   // [htmlOUtput of dirs , array of dirs]

   if ($stuff2[0]===false )  {         // false means "timeout -- not done yet"
       $arf['resumeStatus']=$resumeStatus;  // called by reference hance changed
       $_SESSION['wsGallery_cacheDirStateVars']=$arf;
       $tmess=$stuff2[1];
       return ['doResume'=>1,'content'=>$tmess] ; // doresume  -- wsGalleryActions will handle the resuto to js
   }

// if here, done. Now do the disabled and descriptions

   $_SESSION['wsGallery_cacheDirStateVars']=[];  // all done with this.

   $cacheTree=$treeUseInfo['cacheTree'];

   $arf=json_encode($stuff2, JSON_UNESCAPED_UNICODE);
   $dirListFile=$cacheTree.'/dirList.json';             // direct write (rather than setDirEntryList
   $qok=@file_put_contents($dirListFile,$arf);
   if ($qok===false) {
       $stuff='<div  style="margin:3em 3px 3px 3px;border:4px solid yellow">Warning: unable to save directory list '.$dirListFile.'</div>';
       $stuff.='Perhaps try again, or use a different treeName';
       $res['status']='error'; $res['content']=$stuff;
   }

// if here, success
// don't make this the current tree (admin has to do that explicitilyi

   $pp2=$stuff2[1];
   $baseI=$pp2['.'];

   $pstats=' <menu class="tightList">';
   $pstats.='<li><tt>'.$baseI['totDirs'].'</tt> <span style="border-bottom:1px dotted blue" title="Does not include directories with NO files, but with non-empty subdirectories">dirs</span>  ';
   $pstats.=' <tt>'.$baseI['totFiles'].'</tt> files / <tt>'.$baseI['totImages'].'</tt> images. ';
   $pstats.=' <li><tt>'.$baseI['disabled'].' </tt> disabled, and '.$baseI['partiallyDisabled'].'</tt> partiallyDisabled   directories. ';
   $pstats.=" <li> Directory list saved to <tt>$dirListFile</tt>";
   $pstats.='</menu>';
   $daOrig='<tt>'.$baseI['origPath'].'</tt>';
   if ($baseI['stdWwwDir']==1) $daOrig='<span style="border-bottom:1px solid blue" title="This path IS under this server\'s webdirectory")>'.$daOrig.'</span> ';
   $stuff='<div  class="makeDirList_report" >For tree:<b>'.$doThisTree.'</b> ('.$daOrig.'). ' ;
   $stuff.=$pstats;
  // print_r($baseI);
   $stuff.='</div>';
     $stuff.='You can <ul class="tightList">';
     $stuff.='<li><input type="button" value="Close this window" title="Close window -- and refresh/update/create another tree!" ';
     $stuff.=   '  onclick="wsurvey.flContents.container.close(this) "> -- and refresh/update/create another tree!';
     $stuff.='<li> <input type="button" treename="'.$doThisTree.'" onclick="getDirCacheAdmin(this)" value="manage the directories in '.$doThisTree.'">';
     $stuff.=' ... change the status or description, or <em>initialize</em> (create thumbnails and snapshots) ';
     $stuff.='</ul>';

   $res['doResume']=0;
   $res['dirList']=$pp2 ;
   $res['status']='ok';
   $res['content']=$stuff;
   $res['basics']=$baseI; /// treeName, origPath, totFiles, totDirs, totImages, etc


   return $res ;

}

//===============
//==================
// create a list of subdirs with displayable files (such as images) under the path directory
// todo=makeDirList  calls this
// note: makeDirList_create is ONLY called from makeDirList_base
// Features:
//      Report info on files with an extension in imgExts
//      Ignore empty directories.
//      Ignore files that are in skips
//      Optionally: ignore directories with no imgExts and no otherExts files
//      Use of case insenstive strings for file matching
//
// arguments
//   treeUseInfo : basinc info on this tree (cachedir, stdWwwDir...
//   treename:  that this path is in
//   mustHaveViewable :  directories that dont have files that match either imgExts or otherExts are ignored
//                       Jan 2022: this is always 1. If we make this changeable, will have to tweak some other functions
//   priorDirList: asssociative array of pre-exising directories and their disable and  descirptions. COuld be [] (keep defaults)
//   resumeStatus : resumeStatus -- this called by refernce array is built over multiple timeout/resume calls. Starts empty!
//   timeALlowed : seconds before stopping (for client to tell you to resume)
//
//  return [done,dirlist[
//    done = false if resume is on (more work needs to be done). in that case, $resumeStatus has state variables
//    dirList : the final results -- an array of info.
//
// Notes; uses global info in   wsGallery_specsExts


function makeDirList_create($treeUseInfo,$treeName,$mustHaveViewable,$priorDirList,&$resumeStatus,$timeAllowed) {

//print "<br>priordirlist ";
//var_dump($priorDirList);
   $nowTime=time();
   $treeDesc=$treeUseInfo['desc'];
   $path=$treeUseInfo['useDir'];

   $skipSubdirs=$_SESSION['wsGallery_skipSubdirs']  ;

//   $skipSubdirs=['snps','trash','tmp','temp','$RECYCLE.BIN'] ;


// find all subdirs under path, using a dynamic (semi recursive) metnod
  if (!array_key_exists("dirCheckDone",$resumeStatus)) {        // dirCheckDone won't exist while dirCheck is being built  with   makeDirList_create_getSubToCheck

    $dirs=makeDirList_create_getSubToCheck($path,$skipSubdirs,$resumeStatus,$nowTime,$timeAllowed);

    if ($dirs===false) {     // false means "need to resume"
       $amess='Building dir list: examining '.$resumeStatus['nextToDo'].' of currently found '.$resumeStatus['nCheckSubs'];
       $amess.=   ' w/ '.$resumeStatus['nAllFiles'].' files detected  ';
       $amess.=' ('.$resumeStatus['nSubs_root'].' subdirs in the rootSel directory of '.$treeName.') ';
       return [false,$amess] ;  // not done with dir builiding
    }   // if past here ... done (no need to resume)

    $nextInDirs=0;
    $resumeStatus['dirCheck']=$dirs ;
    $resumeStatus['nextInDirs']=0;
  } else {       // dircheckdone means "got the dirs, so go to next step)
     $dirs=$resumeStatus['dirCheck'] ;
     $nextInDirs=$resumeStatus['nextInDirs'] ;
  }


// when here, the full tree of "non skip, non empty" dirs are in dirs. Process eadh of them

  $daSpecs=$_SESSION['wsGallery_specsExts'];
  $imgExts=$daSpecs['imgExts'];  $otherExts=$daSpecs['otherExts'];
  $allExts=$daSpecs['allExts'];  $useOnlyString=makeListCI($allExts);
  $otherExts_lookup=makeLookupTable($otherExts);   // lower case lookup (associatlve array with values=0) verions of this array
  $imgExts_lookup=makeLookupTable($imgExts);   // these are just used for summary stat creation
  $readmeString = '[Rr][Ee][Aa][Dd][Mm][Ee][.][Tt][Xx][Tt]'; // case insnstive hack

 // ready to intialize the dirlist!
 if (!array_key_exists('dirList',$resumeStatus) ) {  // dirlist is an expansion of dirCheck (wiith file info, etc)
    $dirList=[];
    $dirList['.']=['treeName'=>$treeName,'mustHaveViewable'=>$mustHaveViewable,
                   'desc'=>$treeDesc,'origPath'=>$path,
                   'totFiles'=>'0','totDirs'=>0,'totImages'=>0];  // totFiles is "viewable" files
    $dirList['.']['disabled']=0;       // # diirectories disabled  (isDisabled=1
    $dirList['.']['partiallyDisabled']=0;  //  # directories partiallydisabled a  (isDisabled=2)
    $dirList['.']['cacheDir']=$treeUseInfo['cacheTree'];
    $stdWwwDir=$treeUseInfo['stdWwwDir'];
    $dirList['.']['stdWwwDir']=$stdWwwDir;
    $dirList['.']['otherExts']=implode(',',$otherExts);  // for info purposes
    $dirList['.']['imgExts']=implode(',',$imgExts);      // for info purposes
    $resumeStatus['dirList']= $dirList ;
 } else {       // doResume got here before
     $dirList=$resumeStatus['dirList'];
 }
// find all "displayable" files (including image files).
 $istart=$nextInDirs;

 for ($ifoo=$istart;$ifoo<count($dirs);$ifoo++) {  // dirs is stable, dirList grows
     $apath=$dirs[$ifoo][0];  $nsubs=$dirs[$ifoo][2]; $subList=$dirs[$ifoo][4];
     $use_files =  glob($apath . '/' . $useOnlyString, GLOB_BRACE);       // look for usable files (images and other)  -- select if match an extension
     $readme_files =  glob($apath . '/' . $readmeString, GLOB_BRACE);       // and the a readme file (ci)

// check if something (displayable files) to record. And record  summary stats on them. NOte: dirLIst is called by ref, so is being augmented
       $nfilesX=makeDirList_create_getSubdirs_fileInfo($mustHaveViewable,$treeName,$apath,$nsubs,$subList,
                       $use_files,$readme_files ,$imgExts_lookup,$otherExts_lookup,$priorDirList,$dirList) ;
// nfilesX= # of displaybels. If 0   displayables, if mustHaveViewable=1, not stored in dirlist. But nfilesx is not used here (for now)

      $nextInDirs++;

      if ($nextInDirs<count($dirs)-1) { // not done, so timeout
        $checkTime=time();
        $diff=$checkTime-$nowTime  ;
        if ( $diff>$timeAllowed)  {  //  timeout, back to js (save state info first)
           $resumeStatus['dirList']=$dirList;   //dirlist is final output, dirs  (dirCheck) is transient
           $resumeStatus['nextInDirs']=$nextInDirs  ;  // after end
            $amess='Finding files: @ '.$nextInDirs.' of  '.count($dirs).' directories. ';
            $amess.=   ' w/ '.$dirList['.']['totFiles'].' found ('.$dirList['.']['totImages'].' are images)';
            return [false,$amess];
         }
      } else {           // done!
           $resumeStatus['nextInDirs']=$nextInDirs  ;  // at end!
           $resumeStatus['dirList']=$dirList  ;  // at end!
      }

  }    //  i e loop over dirs

// got dirlist. No more caching...

   $stuff=makeDirList_create_dirsTableHeader($treeName) ;     // create html table... could take a while
   $stuff.=makeDirList_create_dirsTable($dirList,$mustHaveViewable) ;     // create html table... could take a while

 // add lookup to [.]
 $dirlookup=[] ;
 foreach ($dirList as $ith=>$a1) {
    if ($ith==='.') continue;
    $adirname=$a1['dirname'];
    $dirlookup[$adirname]=$ith;
 }
  $dirList['.']['dirLookup']=$dirlookup ;

  return [$stuff,$dirList ];

}

//===============
// get a list of all the subdirectories under path -- excludin "skips" and "empties".
// Does NOT exclude "no viewables" -- that is determined in a later (create html menu) tsep
//  this is builds dynamically, sort of recursively. dirlist is modifed (called by reference), and so is resumeStatus

function makeDirList_create_getSubToCheck($path,$skips,&$resumeStatus,$nowTime,$timeAllowed) {

  if (!array_key_exists('dirCheck',$resumeStatus)) {  // doesn't exist: get top level subdirs of path
     $path1=rtrim($path,'/').'/*' ;
     $dirs0=glob($path1);
     $dirs=[];
     foreach ($dirs0 as $ij=>$adir) {
        if (!is_dir($adir)) continue;
        $adir_end=makeDirList_create_getSubdirs_noskip($adir,$skips);
        if ($adir_end===false) continue;
        $dirs[]=[$adir,$adir_end,0,0,[]];          // fullpath, subdir name, #subdirs, #files (sum of last two =0, this isn't listed)
     }          // this is the core list of directories  And skips removed.
     $resumeStatus['dirCheck']=$dirs;
     $resumeStatus['nextToDo']=0;
     $resumeStatus['nSubs_root']= count($dirs);  // subdirectories that are not skip and not empt
     $resumeStatus['nCheckSubs']=count($dirs) ;  // does NOT include skipsubs
     $resumeStatus['nSkipSubs']=count($dirs) ;
     $resumeStatus['nAllFiles']=0;
     $nextToDo=0;
   } else {
     $nextToDo=$resumeStatus['nextToDo'];
     $dirs=$resumeStatus['dirCheck'];

  }

// got core list. Now "recurse" through
   for (;;) {       // break when no more subdirs
     if ($nextToDo>=count($dirs)) break;    // done them all!
     $apath=$dirs[$nextToDo][0];
     $adir1=$dirs[$nextToDo][1];

     $afiles=glob($apath . "/*") ;     // this is a checkable subdir, so get all  its files and its subdrectories
     $nitems=count($afiles);  // incluses subdirs
     $oksubs=0    ;
     if ($nitems>0) {
       $bsubs=array_filter($afiles,'is_dir');      // find subdiretories of this subdir
       $nsubsB=count($bsubs);             // if > 0,
       $kfiles=$nitems-$nsubsB ;
       $resumeStatus['nAllFiles']+=$kfiles;
       $dirs[$nextToDo][3]=$kfiles;  // # of files
       $okSubNames=[];
       if ($nsubsB>0){
         $okSubs=0; $skipSubs=0;
         foreach ($bsubs as $ij2=>$bdir) {
           $bdir_end=makeDirList_create_getSubdirs_noskip($bdir,$skips);
           if ($bdir_end===false) {
               $skipSubs++;
              continue;    // a skips, ignore
           }
           $okSubs++ ;         // # of nonskip subdirs
           $okSubNames[]=$bdir_end  ;
           $dirs[]=[$bdir,$bdir_end,0,0,[]];    // a new one (that will examined in future steps of this infiite loop
         }          // foreach
         $dirs[$nextToDo][2]=$okSubs;          // does not include skips subdirectories
         $dirs[$nextToDo][4]=$okSubNames;
         $resumeStatus['nCheckSubs']+=$okSubs;
         $resumeStatus['nSkipSubs']+=$skipSubs;
       }   // nsubsorig

     } // nitems >0

     $nextToDo++;
     if ($nextToDo>=count($dirs)) break;    // done them all!

     $checkTime=time();
     $diff=$checkTime-$nowTime  ;
     if ( $diff>$timeAllowed)  {  //  timeout, back to js (save state info first)
        $resumeStatus['dirCheck']=$dirs;
        $resumeStatus['nextToDo']=$nextToDo  ;  // after end
        return false  ;          // caller will save resumestatus  (called by reference
     }

  }    // infinite loop (for ;;

  $resumeStatus['dirCheck']=$dirs;
  $resumeStatus['dirCheckDone']=1;   // existned of this singals dirCheck is done

  return  $dirs  ;  // the list of subdirs whose files should be examine -- in order to build dirList (some might be dropped if no viewables)
}

//=======================
// add entry $dirList  -- contains summary info on the files in use_files
// will see all files, but only count files with an imgExts or otherExts extension

function  makeDirList_create_getSubdirs_fileInfo($skipNoMatches,$treeName,$apath,$nsubs,$subList,
                     $use_files,$readme_files,$imgExts_lookup,$otherExts_lookup,$priorDirList,&$dirList) {

     $nfiles=count($use_files);  // 'use' able (aka display desired) files in this dir
     if ($nfiles==0) {
        if ($skipNoMatches==1) return false  ;  // if both of these are not true, go to don't bother with this dire
     }

     $dirList['.']['totDirs']++ ;   // augment count of "subdirs with displayable files"  in this tree

     $cacheDirTree= rtrim($dirList['.']['cacheDir'],'/');

     $infoUseFiles=[];        // all files (including non-image iles)
     $nimgs=0;      $nViewables=0;

     foreach ($use_files as $afile) {
        $aext=strtolower(pathInfo($afile,PATHINFO_EXTENSION ));
        $q1=array_key_exists($aext,$imgExts_lookup);
        $q2=array_key_exists($aext,$otherExts_lookup);
        if ($q1 || $q2) {                           // one of the useeable (desired to display) extensions
            $dirList['.']['totFiles']++;        // augment count of dissplayable files in tree
            $nViewables++;
           if ($q1) {
               $dirList['.']['totImages']++;    // augment count of dissplayable inmage files in tree
               $nimgs++ ;
           }
           if (!array_key_exists($aext,$infoUseFiles)) $infoUseFiles[$aext]=0;
           $infoUseFiles[$aext]++;
        }
     }

     $apathInfo=returnSelector($apath,$treeName);
     if ($apathInfo['error']!='')  getJs\jsonReturnError($apathInfo['error']." : for [$apath] in [$treeName] ",$apathInfo);

//     $cacheDir=$apathInfo[$cacheDir];   //  won't exist yet (unless this is a revise). So use cacheDirTree
     $adirSay=$apathInfo['relSel'] ; // relative selector;
     $cacheDir=$cacheDirTree.'/'.ltrim($adirSay);

     if (count($readme_files)>0) {
         $aReadmeText=file_get_contents($readme_files[0]);  // readme file from actual dir (not a cache dir
     } else {
         $aReadmeText="$nViewables viewable files ($nimgs are image files)";           // set below if readme.txt created in this path's cache dir
     }

     $isDisabled=0;
     $myDesc=$aReadmeText  ; // use default if no prior
     if (array_key_exists($adirSay,$priorDirList)) { // look for preexisting values to use
        $a1=$priorDirList[$adirSay];
        if (array_key_exists('priorDisable',$a1)) $isDisabled=$a1['priorDisable'];
        if (array_key_exists('priorDesc',$a1)) $myDesc=$a1['priorDesc'];
     }

     if ($isDisabled==1) $dirList['.']['disabled']++;  // some summary stats
     if ($isDisabled==2) $dirList['.']['partiallyDisabled']++;

// THIS IS WHAT WE CARE ABOUT ! add info on this dir to dirList, which is returned by reference
    $dirList[]=['path'=>$apath,'dirname'=>$adirSay,'nFiles'=>$nfiles,'nImages'=>$nimgs,'nSubs'=>$nsubs,
          'cacheDir'=>$cacheDir,'subs'=>$subList,'isDisabled'=>$isDisabled,
         'byExt'=>$infoUseFiles,                         // array of count by type of image
         'readme'=>$aReadmeText,'dirDesc'=>$myDesc ] ;

     return $nfiles;
}


//==========
// return name of subdir (i.e.; cc   in /aa/bb/cc). Or false if this is a skip subdir

function   makeDirList_create_getSubdirs_noskip($adir,$skips=[]) {

   $adir2=str_replace('\\','/',$adir);
   if (strpos($adir,'/')!==false) {     // found a /... just take last element in path
       $oof=explode('/',$adir2);
       $adirUse= array_slice($oof,-1,1)[0];
   } else {     // no / in path used as is
      $adirUse= $adir ;
   }
   $adirUse=trim($adirUse);
   if (count($skips )===0) return $adirUse ;       // no skips to consider

   $skip1=strtolower($adirUse);
   if (array_key_exists($skip1,$skips)) {
      return false  ;// a skips directory (single name, case insensitive)
   }

   return $adirUse; ; // no skip match
}

//============================
// html menu of dirs in a tree... the header aover the table
// $disabledIcons=["&#128065;",'&#128683;',"&#8855;" ];          // "\uD83D\uDC41"  "\uD83D\uDEAB"     "\u2297"
function makeDirList_create_dirsTableHeader($treeName,$adminMode=0) {
 $stuff='';
  $stuff.='<div>';
  $stuff='<div id="switchTreeMenu"  arf="2"  name="nswitchTreeMenu"  style="display:block" class="cswitchTreeMenu"> '; // will be filled with current menu
  $stuff.='</div>';
  if ($adminMode!=1) {
       $stuff.='<input type="button" value="&#10068;" title="View help on selecting a directory, and switching trees"   class="helpButton"  onClick="doHelpVu(this)" topic="selectADirectory" > ';
       $stuff.='<span style="font-size:120%;font-weight:700">';
       $stuff.='<button class="cbuttonSwitchTree" title="Toggle the  ... `select a directory tree` menu" onClick="toggleSwitchTreeMenu(0)"> &#127794; <em>switch</em></button> ';
        $stuff.='For tree <tt>'.$treeName.'</tt>: <em> viewable directories </em>';
       $stuff.='</span> ';
   } else {
       $stuff.='<span style="font-weight:700">';
       $stuff.='Admin mode for tree <tt>'.$treeName.'</tt> &nbsp;&nbsp;&nbsp;';
       $stuff.='<input type="button" value="&#10068;" title="View help on `tree admin mode` options"   class="helpButton"  onClick="doHelpVu(this)" topic="treeAdminOptions" > ';
       $stuff.='   <button   title="Update the status of directories (apply changes made in the `&#128065;` column)" ';
         $stuff.='       name="doDisableDirButton"       onClick="doDisableDir(this)" treename="'.$treeName.'">Update dirStatus</button>';
       $stuff.='   <button   title="Update the descriptions of  directories (apply changes made in the `descriptions` column)" ';
         $stuff.='      name="doDescriptionsDirButton"  onClick="doDescriptionsDir(this)" treename="'.$treeName.'">Update dir descriptions</button>';
         
       $stuff.='<span id="dirListInitAllOuter" style="display:none">';
       $stuff.='  <input type="button" value="&#128994;ALL"  data-treename="'.$treeName.'"  onClick="doDirCacheJs(this,2)    " ';
       $stuff.='    title="Click to initialize all the selected  directories &#010;(that are marked with a &#128994;)" name="dirListInitializeAll" >';
       $stuff.='</span>';


//       $stuff.='   <input type="button" value="Update dirStatus" title="Update the status of directories (apply changes made in the `&#128065;` column)"  ';
//       $stuff.='      onClick="doDisableDir(this)" treename="'.$treeName.'">';
//       $stuff.='   <input type="button" value="Update dir descriptions" title="Update the descriptions of  directories (apply changes made in the `descriptions` column)"  ';
//       $stuff.='      onClick="doDescriptionsDir(this)" treename="'.$treeName.'">';

       $stuff.='</span> ';
   }

   $stuff.='<div id="idisableDirViewResults" style="display:none;background-color:#aabbaa;margin:3px 4em 3px 4em">...</div>';

    $stuff.="\n";
    if ($adminMode==1) {
       $stuff.=' <table id="dirListingTableAdmin" style="width:95%;overflow:auto;margin:3px 3px 3px 2em" rules="rows" cellpadding="4">';
    } else {
       $stuff.='<table id="dirListingTable" style="width:95%;overflow:auto;margin:3px 3px 3px 2em" rules="rows" cellpadding="4">';
    }

   $stuff.='<tr>';

   $stuff.='<th><div style="width:19em;overflow:auto;scrollbar-width: thin;">Directory</div></th>';


    if ($adminMode==1) {
      $stuff.= '<td style="width:5em;">&nbsp;';
      $stuff.=' <span style="font-style:oblique" title="Click to view files, and change file descriptions">';
      $stuff.='<input type="button"   value="&#128193;desc"  class="helpButton" title="Help on changing the descriptions of files in a directory" topic="changeFileDesc0"  onClick="doHelpVu(this)"> ';
       $stuff.='</span></td>';
    }else {
      $stuff.= '<td style="width:5em;">&nbsp;';
      $stuff.=' <span style="font-style:oblique;background-color:#dfdadf;" title="# files, mouseover for # of image files">#';
      $stuff.='</span></td>';
    }

   if ($adminMode==1) {
       $stuff.='<td><div style="width:2em"> ';
       $stuff.='<input type="button"  class="helpButton"  value="? &#128065;" title="Help on disabling a directory" topic="disableDir"  onClick="doHelpVu(this)"> ';
       $stuff.='</div></td>';
   }

   if ($adminMode==1) {
       $stuff.='<td><input type="button"  class="helpButton" value="?Initialize" title="Help on initializing a directory" topic="initalizeDir"  onClick="doHelpVu(this)"> ';
       $stuff.='  <input type="button" value="&#8615;&#8613;Mark"     ';
        $stuff.='    title="Select all directories between first and last selected&#010;If none selected, select all)" name="dirListMarkAll" >';
       $stuff.='</td>';
   }

   $stuff.='<td bgcolor="#dadde1"> ';
   if ($adminMode==1) {
      $stuff.='<input type="button"  class="helpButton"  value="?  " title="Help on changing directory descriptions" topic="changeDirDesc"  onClick="doHelpVu(this)"> ';
      $stuff.='<input type="button" value="&#11095;" title="Add original description (for the most recently selected directory description) " onClick="addOriginalDirDesc(this)" >';
   }
   $stuff.='Directory descriptions</td>';

   $stuff.='</tr>';
//   $stuff.='<td class="adminModeItem">Initialize</td><td>info</td></tr>';
   return $stuff;
}
//===============
// html table of dirs in this tree (extracts from dirList array)

function makeDirList_create_dirsTable($dirList,$mustHaveViewable=1,$adminMode=0) {

  $thisTree=$dirList['.']['treeName'];

  $dirnames=[];
  foreach ($dirList as $ith=>$avv) {
    if (array_key_exists('dirname',$avv)) {
        $dirnames[]=strtolower($avv['dirname']);
    } else {
       $dirnames[]='.' ;
    }
  }
  array_multisort($dirnames,SORT_ASC,SORT_STRING,$dirList); // alphabetical order (ci)


//  $disabledIcons=["&#128065;","&#10060;",'&#128683;'];
  $disabledIcons=["&#128065;",'&#128683;',"&#8855;" ];          // "\uD83D\uDC41"  "\uD83D\uDEAB"     "\u2297"
  $stuff='';
  $atree=$dirList['.']['treeName'];

  $priorLevels=[];

  $nameNiceLookup=[];
// make lookup table of "indent3ed" directory names. Uses the sorting
  foreach ($dirList as $ith=>$dirInfo) {
     if (array_key_exists('dirname',$dirInfo)) {  // skip a meta-data row
        $abdir=$dirInfo['dirname'];
        $arf1=str_replace('\\','/',strtolower($abdir));
        $arf2=explode('/',$arf1);
        $nameNiceLookup[$abdir]=['vName'=>$arf2,'use'=>$abdir,'levels'=>0] ;
     }
  }

  $priorLevels=[];

  foreach ($nameNiceLookup as $origName=>$vvname1) {
     $vvname=$vvname1['vName'];

     if (count($priorLevels)==0){ ;  // first used as is  -- use as setup
        $priorLevels=$vvname;
     } else if (count($vvname)==1)  { // a top level dir -- use as setup
         $priorLevels=$vvname;
     } else {                               // a 2+ level subdir, probably, but not necessarily, matching prior levels
        $goo='';  $noFinal=0; $nindents=0;
        for ($jj=0;$jj<count($vvname)-1;$jj++) {  // always show the "c"  in /a/b/c
           if ($jj>=count($priorLevels)) {  // vvname is a subdir of the prior
             $goo.='/'.$vvname[$jj] ;
             $noFinal=1;
           } else {
             if ($priorLevels[$jj]==$vvname[$jj]) {
                 $nindents++;
             } else {
                $goo.='/'.$vvname[$jj] ;
             }
           }     // if jj>count priorLevels
        }     // jj=0;$jj<count($vvname
        $priorLevels=$vvname;
        if ($noFinal==0) $goo.='/'.$vvname[count($vvname)-1];
        $nameNiceLookup[$origName]['use']=$goo;
        $nameNiceLookup[$origName]['levels']=$nindents;
     }  // if count(proirlevels)
  } // foreach nameniceloookup



// create rows of dirs -- with active "view files in this dir" button. The buttons are "indented by root subdir"
  foreach ($dirList as $ith=>$dirInfo) {
     if (!array_key_exists('dirname',$dirInfo)) {  // skip a meta-data row
        continue ;
     }

// nothing displayable? And mustHave something displayable? Don't show it in the list of directories (so client won't
// have button to click on to observe)

     if ($dirInfo['nFiles']==0 && $mustHaveViewable===1) continue ;  // skip directories with no image (or other) files
     $isDisabled=$dirInfo['isDisabled'];  //0: nromal, 1=disabled (not shown), 2=partiallyDisplayed   (button shown but inactive -- files not show)

     if ($isDisabled==1 && $adminMode!=1) continue ;

     $aadir= $dirInfo['dirname'];
     $rarf=str_repeat(' &hellip;&nbsp;',$nameNiceLookup[$aadir]['levels']);
     if ($rarf=='') $rarf=' &nbsp;';
     $aadirSay=$nameNiceLookup[$aadir]['use'] ;
     $aaIndent='<span style="background-color:#dadada;opacity:0.4" title="'.$aadir.' (in tree '.$thisTree.')">&nbsp;'.$rarf.'</span>'  ;

     $cacheDir=$dirInfo['cacheDir'];

// if not admin mode: skip fully disabled. DO show "partiallyDisabled" (show the dirlist button anyways" (2)

     $stuff.='<tr class="dirListingTableRow">';   // each row is for a directory in this tree (any depth)

// co1 1: dir name (indented button). If admin mode -- all, even if fully or partially disalbed

     $stuff.=' <td> <div style="width:19em;overflow:auto;scrollbar-width:thin"><span style="white-space: nowrap;"> ';
     $aadis='' ; $astyle=' ';
     $atitle='View, and retrieve ... image (and other) files in this directory';
     if ($isDisabled!=0) {
        if ($adminMode!=1 ) {  // non admin -- = isdisabled=1, never get here. 2: display but
           $aadis=' disabled ';
           $atitle.=' : This directory is partiallyDisabled: you can NOT view its files ';
           $astyle=' style="color:tan" ';
        } else {    // admin mode
            if ($isDisabled==1) {
               $atitle.=' : This directory is DISABLED (button is hidden, hence file list can not be shown) ';
               $astyle=' style="color:red" ';
            } else {
               $atitle.=' :  This directory is partiallyDisabled (button is visible, but the file list will not be shown)';
               $astyle=' style="color:tan" ';
            }
        }   // admnode
     }      // disabled
     $stuff.= $aaIndent.'<button name="dirListFileViewFiles" '.$astyle.' '.$aadis.' dir="'.$aadir.'"  value="'.$aadir.'" ';
     $stuff.='  treename="'.$atree.'" title="'.$atitle.'" how="0" > ';
     // onClick="getDirFileListJs(this)"> ';
     $stuff.=$aadirSay.'</button>'  ;
     $stuff.='</span>';
     $stuff.='</div></td>';      // col 1: the directory (with indented display. Note: div is used to control width


// col 2: # of files
     $ntot=$dirInfo['nFiles'];   $nimages=$dirInfo['nImages'];
     $stuff.=' <td style="width:5em;">&nbsp;';
     $stuff.='<span style="border-bottom:1px solid blue" data-_sortUse="'.$ntot.'" title="'.$nimages.' of these are images" class="fileCt">';
     if ($adminMode==1)   {
        $stuff.='<input type="button" value="&#128448;'.$ntot.'" name="dirListFileDescButton" title="Click to view & change file descriptions " ';
        $stuff.='      dir="'.$aadir.'"  treename="'.$atree.'"   >';
     } else {
         $stuff.=$ntot;
     }
     $stuff.='</span></td>';   // COL 2 # of files


// col 3a (admin mode only) : current "disable" status
     if ($adminMode==1)   {
         $stuff.='<td ><div style="width:2em"  name="currentDisableStatus" class="cdisableNotChanged" >';
         $stuff.='<input type="button"  name="dirListDisableButtons" ' ;
         $adicon= '&#9888;';    $atitle="unknown disabled status: $isDisabled ";
         $bclass='';
         if ($isDisabled==0)  {      // not disabled
             $adicon=$disabledIcons[0];
             $atitle='This directory is viewable ';
         } else if ($isDisabled==1) {
            $adicon=$disabledIcons[1];
              $atitle='This directory is not DISABLED (button is not shown) ';
         } else if ($isDisabled==2) {
            $adicon=$disabledIcons[2];
            $bclass=' class="cPartialDisableButton" ';
            $atitle='This directory is not partiallyDisabled (button is shown, but is inactive (file list will not be shown) ';
         }
         $stuff.=' value="'.$adicon.'"  '.$bclass.' which="'.$isDisabled.'" title="Toggle viewing status of this directory. Currently: '.$atitle.'" ';
         $stuff.='   tree="'.$atree.'" dirname="'.$aadir.'" origDisable="'.$isDisabled.'"  >';
         $stuff.='</div></td>'      ;
      }                            // disable butt


// col 3b : initialize button
//    &#9989; green check: initialized ,   &#9745; check in box: partially (filelist create),   &#9744; Nothing
     if ($adminMode==1)   {  // col 2b (admin mode only) : initialize
       $goo1= returnSelector('~'.$aadir,$atree)  ;
       $gooCachedir=$goo1['cacheDir'];
       if ($gooCachedir=='') getJs\jsonReturnError("Unable to find a cacheDir for tree= $atree, dir= $aadir ",$goo1);
       $dlist=glob($gooCachedir.'/*');
       $gotText=0;$gotThms=0;
       foreach ($dlist as $ith=>$afile) {
           $fname=strtolower(pathinfo($afile, PATHINFO_FILENAME ));

           if ($fname=='_filelist') $gotText++;
           if ($fname=='_buttonlist_text'  || $fname=='_buttonlist_thm40'  ||  $fname=='_buttonlist_thm66' || $fname=='_buttonlist_thm90') $gotThms++;
        }
 
        $useIcon='&#9744;';   $useTitle='Not initialized ';
        if ($gotText>0) {
            if ($gotThms<4) {
                $useIcon='&#9745;';
                $useTitle='Partially initialized'    ;
            } else {
                $useIcon='&#9989;';
                $useTitle='Initialized'  ;
            }
       }
//       getJs\jsonReturnError(" in cacheDir for tree= $atree, dir= $aadir ",$dlist);
        $stuff.='<td>';
        $stuff.='<div name="dirListInitialize0" treename="'.$atree.'"  dir="'.$aadir.'" > ';
        $stuff.='<input type="button" title="Initialize (create cache dir, create thumbnails and snapshots).&#010;Currently: '.$useTitle.'" ' ;
        $stuff.=' value="'.$useIcon.'" name="dirListInitialize"     > ';
        $stuff.='<span name="dirListInitialize2" style="display:none"></span>';
        $stuff.='</div></td>';    // onClick="doDirCacheJs(this,1)"
     }

// col 3c: description  (if admin mode, in a textarae)
      $stuff.='<td  bgcolor="#dadde1"> ';
      if ( $adminMode!=1) {
         $stuff.='<div style="font-size:80%;height:1.5em;overflow:auto">'.$dirInfo['dirDesc'].'</div>';
      } else {
         $origDesc=base64_encode($dirInfo['readme']);
         $stuff.='<textarea name="dirListDescArea"  data-changed="0" dirname="'.$aadir.'" origDesc="'.$origDesc.'"  ';    //  onChange="descDirViewSet(this)"
         $stuff.='  rows="1.5" cols="70" style="font-size:90%">'.$dirInfo['dirDesc'].'</textarea>';
      }
      $stuff.='</td>';
     $stuff.='</tr>';

  }                  // each dirLIst

  $stuff.='</table>' ;

  return $stuff;
}



//================
// make cache driectories for each directory in a tree. Possibly remove orphans
// dirlist is created by prior call to makeDirList_base

function makeDirList_makeCacheDirs($dirlist,$currentChosenTree,$removeUnusedCache ) {
 $stuff='';
  $cacheDir=$dirlist['.']['cacheDir'].'/';
  $stuff.='<ol type="decimal-leading-zero ">';
 $qok=true;
  $ncheck=0; $nset=0; $nfail=0;
  $dirnames_lookup=[];
  foreach ($dirlist as $ith=>$dinfo) {
      if ($ith==='.') continue ;
      $ncheck++;
      $stuff.='<li> <div style="font-size:80%"> ';
      $adirname=$dinfo['dirname'];
      $makeDir=$cacheDir.$adirname;
      $exists=(is_dir($makeDir)) ? 1 : 0;
      if ($exists==0) {
        $stuff.=" Creating cacheDir for $adirname= $makeDir  ";
 // mkDIr will create multiple levels at once! So higher level dir could be empty, but have sveral non empty sudirs
         $qok= @mkdir($makeDir,0777,true);
         if ($qok) {
            $nset++;
         } else {
            $nfail++;
         }
      }  else {
        $stuff.=" Already exists: cacheDir for $adirname= $makeDir  ";
        $stuff.='</div></li>';
      }
      $dirnames_lookup[$adirname]=1 ;

  }
  $stuff.='</ol>';

//stuff is a list of "dispostion of each viewable dir in this tree" reports.
// Next:  prepend header. Then  do orphan removal and append report on orphans removed
  $stuffZ='';
  $stuffZ.='<div style="border:3px ridge cyan;padding:5px">' ;
  $stuffZ.='<b>Status report ... </b><br>';       // header for the ol created baove
  $stuffZ.="In cachedir :<tt>$cacheDir</tt>.   $nset directories created, $nfail directories could not be created (for $ncheck non-empty directories in tree $currentChosenTree) ";

  $stuff=$stuffZ.'<div style="margin:10px 2em 10px 2em;padding:5px; border:1px dotted gray">'.$stuff.'</div>';  // prepend the header

  if ($removeUnusedCache==0) {     // done?!
      $stuff.='</div>';
      return $stuff;
  }

// look for orphans?
  $goo='<div style="font-size:110%;font-weight:700">Looking for orphan directories (in '.$cacheDir.')</div>';
  $goo.='<ol type="decimal-leading-zero"> ';
   $arf=get_subdir_list($cacheDir,2);

   $nkeeps=0; $nremoves=0;$nremoveFails=0;$nNotEmpty=0;

   foreach ($arf as $jj=>$selname2) {

      if ($jj===0) continue ;
      $selname=$selname2[1];
      if (array_key_exists($selname,$dirnames_lookup)) {
        $nkeeps++;
        $goo.="<li> Retaining:  ".$selname2[0] ;
        continue;
      }   // if past here, this cache dir does NOT exist in the tree. Or -- it does, but only has subdirs.

     $removeThisDir=rtrim($selname2[0],'/');
      $arf=glob($removeThisDir.'/*',GLOB_ONLYDIR);   // check for subdirs. If subdirs exists, do NOT try to remove.
      if (count($arf)>0) {
        $goo.="<li><em> Retaining (no files, but has ".count($arf)." subdirectories):</em>  ".$selname2[0] ;
        $nNotEmpty++;
        $nkeeps++;
        continue;
      }

      $goo.="<li><u> Removing orphan</u>  ".$selname2[0] ;  // empty, except for some files.

      $files = glob($removeThisDir.'/{,.}*', GLOB_BRACE);  // gets all the files  (skips subdirs)

      $ndel=0;

      foreach($files as $file){ // iterate over files in this cache directory
         if(is_file($file)) {
           unlink($file); // delete file
           $ndel++ ;
         }
      }   // foreach files

      $q3=@rmdir($selname2[0]);    // cache dir should now be empty (no files, never had subdirs). Remove it
      if ($q3===false) {            // shouldn't happen...
            $goo.=' . <b>Error</b>, unable to remove this directory ';
            $nremoveFails++;
      } else {
           $goo.=' (files removed='.$ndel.')';
           $nremoves++;
      }

   }   // foreach arf

   $goo.='</ol>';

  $stuff.=$goo ;
  $stuff.="<br> $nremoves orphan  directories removed, $nremoveFails could not be removed. ";
  $stuff.="<br> $nkeeps  directories retained, of which $nNotEmpty only have subdirectories. ";
  $stuff.='</div>';


  return $stuff ;

}

//==================
// return disabled status for all directories in a tree (as specified in its dirList. json file
// this assumes atree is a specified tree (check before calling); and cache directory exists
function dirList_currentlyDisabled($atree,$treeCacheDir,$disabledOnly=0) {

     $dlist=getDirListEntry('*',$atree) ;  // return as associative array
     if (array_key_exists('.error',$dlist)) getJs\jsonReturnError($dlist['.error'],$dlist['treeList']);

     foreach ($dlist as $adir=>$vv) {   // getDirList provides as associastive array
        if ($adir==='.') continue ;
        $adisable=$vv['isDisabled'];
        if ($disabledOnly==1) {    // skip non-dsiabled
            if ($adisable!=0)  $myres[$adir]=$adisable;    //1=disabled, 2= disabled but display dir name anyways (grayed out)
        } else {      // return stat6us of all
            $myres[$adir]=$adisable;
        }
     }
     return $myres ;

}

//===========================
// update disable status for directories in a tree

function dirList_changeStatus($atree,$disableList,$mustHaveViewable=1) {

    $dirList=getDirListEntry('*',$atree,1);  // returns transformed (associative array)   of trees
    if (array_key_exists('.error',$dirList)) getJs\jsonReturnError($dirList['.error'],$dirList['treeList']);

    $nMissing=0; $nchanges=0;
    $disabled=0; $partiallyDisabled=0; $isDisabled=0;
    $gotems=[];   $ndirs=0;

    foreach ($dirList as $asel=>$aentry) {
        if ($asel==='.') continue;  // leave as is
        $ndirs++;
        $wasValue=$aentry['isDisabled'];
        if (!array_key_exists($asel,$disableList)) {  // not changed by admin
           if ($wasValue==1) $disabled++;               //  both of these for summary stats
           if ($wasValue==2) $partiallyDisabled++;                // Note that 2 is less stringent
           continue ;
       }
       $newValue=$disableList[$asel];
       if ($newValue==1) $disabled++;  //  for summary stats
       if ($newValue==2) $partiallyDisabled++;
       $aentry['isDisabled']=$newValue;
       $dirList[$asel]=$aentry;
       if ($wasValue!=$newValue) $nchanges++ ;
    }
//    foreach ($disableList as $asel=>$xx) {         // disabkeList is all directories (visible to admin) in this tree
//       if (!array_key_exists($asel,$gotems)) $nMissing++;
//    }
    $dirList['.']['partiallyDisabled']=$partiallyDisabled;
    $dirList['.']['disabled']=$disabled ;
    $amess="$nchanges <b>status changes</b> in $atree. #disabled=$disabled, #partiallyDisabled=$partiallyDisabled. " ;
  //   if ($nMissing>0)$amess.="  $nMissing directories no longer in the directory list: the admin should refresh this tree.";
    $amess.=' &boxV; <input type="button" title="Click to reload wsGallery" value="reload" onClick="location.reload(true)" > to update this tree\'s <em>directory list</em> ';

    if ($nchanges>0)  setDirListEntry('**',$atree,$dirList,$mustHaveViewable,1); // unTransform, recreate htmlmenu , musthaveviewables as provided

    getJs\jsonReturnContent($amess);

    return $res ;
}

?>