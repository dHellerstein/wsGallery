//===============================
// direcotry view and retrieve stuff (for current or specifid  tree)
// and disable views of specified diretories
// for wsGallery

//============
// toggle, or force, view of  the 'dirList flContent box -- where the list of the currentTree's directories is displayed
// doshow is optional. 0 (default)= toggle, 1=force show, 2= force hide

function toggleDirVu(doshow,athis) {

   var doshow1='0';
   if (arguments.length<0) doshow='0';
   let atype=typeof(doshow);
   if (atype=='number' || atype=='string'){
      doshow=jQuery.trim(doshow);
   } else {           // a click handler? look for 'show' attribute. if not available, assume toggle
      let e1=wsurvey.argJquery(doshow);
      if (e1.length>0) {
        let aa=e1.wsurvey_attr('show',0)
        doshow=jQuery.trim(aa);
      }
   }
   if (doshow=='2') {     // special case
       wsurvey.flContents.hide(100,'dirList');
        return 1;
   }
   if (doshow=='1') {     // special case
        wsurvey.flContents.hide(100,'dirList',1);
        toggleSwitchTreeMenu(1);
        toggleDirVu_2(1,1.2);
        return 1;
   }

// else toggle
   var isvis =wsurvey.flContents.visible('dirList');
   if (isvis==0  || doshow==1 ) {
        wsurvey.flContents.show(100,'dirList',1);
        let dadir='';
        if (arguments.length>1) {
            let ethis=wsurvey.argJquery(athis);
            dadir=ethis.attr('data-last');
        }
        toggleSwitchTreeMenu(1);
        if (dadir!='') {              // scroll to most recently view directory
            zbuttons=wsurvey.flContents.find('dirList','[name="dirListFileViewFiles"]') ;
            zbuttons.removeClass('cThisDirChosen');
            let zbutton1=zbuttons.filter('[value="'+dadir+'"]');
            zbutton1.addClass('cThisDirChosen');
            wsurvey.flContents.scrollTo('dirList',zbutton1,0.70 ,100);
         }  //dadir
    } else {      // isvis or doshow
        wsurvey.flContents.hide(200,'dirList');
    }

// hide gallery/colletion buttons?
    toggleDirVu_2(2,1.3) ;


    return isvis;
}

//====================
// hide/show gallery or collection buttons (in dir menu)
function toggleDirVu_2(xx,fooid) {
  //  alert('fooid ' +fooid);
   let ss1=$(document).data('switchGallery'  );
   let collectionsList=$(document).data('collectionsAvail'  );
    $('#selectOtherGalleries2').show();

  window.setTimeout(function() {

   let afavorites=$(document).data('enableFavorites');

   e2e=$('#selectOtherGalleries2e');
   if (afavorites>0) {
       $('#selectOtherGalleries2e').show();
   } else {
       $('#selectOtherGalleries2e').hide();
   }

   if (ss1==1 && collectionsList!='') {        // show both
       $('#selectOtherGalleries2a').show();
       $('#selectOtherGalleries2b').show();
       $('#selectOtherGalleries2c').show();
       $('#selectOtherGalleries2d').show();
       let ff=collectionsList.split(',');
       $('#selectOtherCollectionutton').attr('title','Select one of the '+ff.length+' available collections.');

       return 1;
   }

   if (ss1==0 && collectionsList=='') {        // hide both
       $('#selectOtherGalleries2a').hide();
       $('#selectOtherGalleries2b').hide();
       $('#selectOtherGalleries2c').hide();
       $('#selectOtherGalleries2d').hide();
       return 1;
   }
   if (ss1==1 && collectionsList=='') {        // switch gallery, but not collectiosn
       $('#selectOtherGalleries2a').show();
       $('#selectOtherGalleries2b').show();
       $('#selectOtherGalleries2c').hide();
       $('#selectOtherGalleries2d').hide();
       return 1;
   }

   if (ss1==0 && collectionsList!='') {        // no switch gallery, but yes collectiosn
       $('#selectOtherGalleries2a').show();
       $('#selectOtherGalleries2b').hide();
       $('#selectOtherGalleries2c').hide();
       $('#selectOtherGalleries2d').show();
       let ff=collectionsList.split(',');
       $('#selectOtherCollectionutton').attr('title','Select one of the '+ff.length+' available collections ');

       return 1;
   }
   alert('toggleDirVu_2 should never get here ');
   return 0;
 },100);
 return 1;
}

//=====================
// show file list (on top by efault, or not if ontop=0)
function fileListShow(onTop) {
  if (arguments.length<1) onTop=1;
  wsurvey.flContents.show('gallery',5,onTop);
}
//=====================
// show file list (on top by efault, or not if ontop=0)
function tableauShow(onTop) {
  if (arguments.length<1) onTop=1;
  wsurvey.flContents.show('tableau',5,onTop);
}
//=====================
// toggle tabelau modes (size of the tableau and gallery flconttainers
function tableauMode(athis) {
  let ethis=wsurvey.argJquery(athis);
  let nowmode=ethis.attr('data-which');
  nowmode=1-parseInt(nowmode);
  ethis.attr('data-which',nowmode);
  if (nowmode==0) {
     doResizeViewers(0,2);
  } else {
       let s1={'top':'5%','left':'4%','width':'88%', 'height':'20%'};
        wsurvey.flContents.container.doResize('gallery',s1)
        let s4={'top':'31%','left':'2%','width':'93%','height':'65%'};
        wsurvey.flContents.container.doResize('tableau',s4)   ;
  }

}

//===================
// set pre-defines to "2", and showImages to 1-
function tableauModeCompact(athis) {
  setTableauLayout(0,2) ;
  tableauShowImageList(0,2);
  wsurvey.flContents.onTop('tableau',1);
}


//===============
// get list of directories for a tree, and display
// Feb 2022: treename is always 0.  Always use the .data('currentTree') value.
//          debug1: not currently used. Could be used for debugging
//          hideTreeList : not currently used. if 1, then hide the tree list menu after displaying stuff in dirList flContents
// Note: to toggle view of the currentTree's directory list (and not reload), use toggleDirVu
//
// loadTreeDirs is called in 3 places in  wsGallery.js
//   in init, in a button loaded in top of the dirLIst - to refresh the current dlirst. NOt that useful anymore  -- except to switch from admin to normal view
//   in init, at the end -- to load the current default tree. Treename=0 : use the "currenTree"
//   in switchCurrentTree buttons in the treeList menu

function loadTreeDirs(treeName,debug1,hideTreeList,adir,afile,useflag ) {

   if (arguments.length<1) treeName='';       // feb 2022: it should always be '0'
   if (arguments.length<2) debug1='';
   if (arguments.length<3) hideTreeList=0;
   if (arguments.length<4) adir='';
   if (arguments.length<5) afile='';
   if (arguments.length<6) useflag='';

   if (treeName=='' || treeName=='0') treeName=$(document).data('currentTree'); // loadTreeDirs -- always use currentTree (invocation=default, or after switchTree call

    var adata={'todo':'retrieveDirList','treeName':treeName,'hideTreeList':hideTreeList,'dir':adir,'file':afile,'useflag':useflag}  ;

    wsurvey.getJson.get('wsGalleryActions.php',adata, loadTreeDirsB ,' Retrieving list of files in a directory (using loadTreeDirs)');
    return 1;
}


//=========
// display list of dirs
function loadTreeDirsB(response,origData,otherArgs) {      // don't need  otherArg,tstatus,xhr)
 
   var hideTreeList=0;
   var useFlag=origData['useflag'];
   var isFirstCall=$(document).data('firstCall');
   var afile='',alayout='',adir='',athumb='',aFileListType='',aShowInfo='',aDesc='';
   if (isFirstCall==1) {
      adir=origData['dir'];           // show a requested driectory.
      afile=origData['file'];           // show a requested driectory.
      alayout=$(document).data('requestedLayout');  // if first call, auto layout?
      athumb=$(document).data('requestedThumbnail');  // if first call, auto layout?
      aFileListType=$(document).data('requestedFileListType');  // if first call, auto layout?
      aShowInfo=$(document).data('requestedShowInfo');
      aDesc=$(document).data('requestedDesc');
   }

    hh=wsurvey.getJson.check(response,0,'Callback from loadTreesDir');
    if (hh===false) return 0;
    let acontent;
    if (hh==null) {
        acontent='no directories available.';
    } else {
        acontent=hh['content'];
    }
    if (hh['status']=='na') {  // not avaialble

         wsurvey.flContents.contents('dirList',acontent);
         let mm=hh['treeSwitchMenu'];                   // show treelist
         $('#switchTreeMenu').html(mm);
         let ehh=$('[name="headerToggleSwitchTreeButton"]');
         ehh.css({"opacity":''})
         if ($(document).data('switchGallery')!='1') $('#selectOtherGalleries2').hide();
         return 1;
    }

// if here okay
     let basics=hh['basics'];
     wsurvey.flContents.contents('dirList',acontent);
     let mm=hh['treeSwitchMenu'];
     $('#switchTreeMenu').html(mm);
      let ehh=$('[name="headerToggleSwitchTreeButton"]');
      ehh.css({"opacity":''})
         if ($(document).data('switchGallery')!='1') $('#selectOtherGalleries2').hide();

      if (origData.hasOwnProperty('hideTreeList'))  hideTreeList=origData['hideTreeList']  ;

     let aheader=' :  In the <tt>'+basics.totDirs+' </tt> directories in tree <span class="headerEmphasizer" >'+basics['treeName']+'</span>: # files=<tt>'+basics.totFiles+' (including <tt>'+basics.totImages+'</tt> images) ';
     wsurvey.flContents.header('dirList',aheader);
     if (hideTreeList!=1) {
           toggleSwitchTreeMenu(1);
           let ehh=$('[name="headerToggleSwitchTreeButton"]');
          ehh.css({"opacity":''})

     } else {
         $('#switchTreeMenu').hide();
     }


   var didToggle=0;
// add click handlers
    $('#dirListingTable').on('click',dirListClickHandlerClient)  ;

    wsurvey.flContents.onTop('gallery',20);
    if (adir!='') {
         let dbuttons=wsurvey.flContents.find('dirList','[name="dirListFileViewFiles"]');
         let abutton=dbuttons.filter('[dir="'+adir+'"]');
         if (abutton.length==1) {
            abutton.trigger('click');
            toggleDirVu(2);
            didToggle=1;
         }
    }

   if (didToggle==0 && useFlag!='') $(document).data(useFlag,1);  // flag to invoker (that contents have been written);

// select a file? and a layout
  $(document).data('firstCall',0) ;

  window.setTimeout(function() {

    let ej=$('[name="imageJumpButtons"]');
    ej.hide();

// possible values: combo,v1,v2,rotating,tableau,singleImage
      let edrops=$('#dropdown_layouts');
      if (alayout=='dualviewers' ||  alayout=='dualViewersCombo' ||
        alayout=='' || alayout=="v0" ||
        alayout=="v1" || alayout=="v2") {  // dualViewers, combo

        let eLay=edrops.find('.cToggleScreenLayout');
        eLay.trigger('click');

        let etv=$('#toggleViewers_2');
        if (etv.length>0) {  // might have to wait for dom?
          let iwhich=etv.attr('which');
          let iwhichDo=0;
          if (alayout=='dualViewers1' || alayout=='v1') iwhichDo=1 ;
          if (alayout=='dualViewers2' || alayout=='v2') iwhichDo=2 ;
          let nclicks=Math.abs(iwhichDo);

          for (var inn=0;inn<nclicks;inn++) {  // a bit of a hack
              etv.trigger('click');
          }
          wsurvey.flContents.onTop("dirList",1);
         ej.show();

        }
      } else if (alayout.substr(0,3)=='rot') {
        let eLay=edrops.find('.clargeViewerRotating');
        eLay.trigger('click');
      } else if (alayout.substr(0,3)=='tab') {
        let eLay=edrops.find('.clargeViewerTableau');
        eLay.trigger('click');
        if (alayout.length>3) {
           let ipre=alayout.substr(3,1);
           if (!isNaN(ipre)) {
               ipre=parseInt(ipre);
               if (ipre>0 && ipre<5) setTableauLayout(0,ipre);
           }
        }
      } else if (alayout.substr(0,3)=='lar') {
        let eLay=edrops.find('.clargeViewerSingle');
        eLay.trigger('click');
        wsurvey.flContents.onTop("gallery",1);

      } else if (alayout.substr(0,3)=='sin') {

        let eLay=edrops.find('.cToggleScreenLayoutSingle');
        eLay.trigger('click');
        wsurvey.flContents.onTop("gallery",1);

      }
      if (athumb!='') {
         let edd=wsurvey.flContents.find('gallery','#divListWiththumbnails'),edd2=false ;
         if (athumb=='n') edd2=edd.find('#divListWiththumbnails_name');
         if (athumb=='s') edd2=edd.find('#divListWiththumbnails_small');
         if (athumb=='m') edd2=edd.find('#divListWiththumbnails_medium');
         if (athumb=='l') edd2=edd.find('#divListWiththumbnails_large');
         if (edd2!==false) edd2.trigger('click');
      }

      if (aFileListType!='') {
         if (isNaN(aFileListType)) aFileListType=1;
         aFileListType=parseInt(aFileListType) ;
          window.setTimeout(function() {
             chooseFileListType(false,aFileListType);
         },30);
      }
 
      window.setTimeout(function() {

         if (afile!='') {

            let fbuttons=wsurvey.flContents.find('gallery','#listOfFileInCurrentDir');
            let nbuttons=fbuttons.attr('nbuttons');
            let doems=loadTreeDirsB_list(afile,nbuttons );
            for (var iem=0;iem<doems.length;iem++) {
                let mjj2=doems[iem];
                let abutton=fbuttons.find('[buttonnumber="'+mjj2+'"]');
                if (abutton.length==1) {
                    let abutton2=abutton.find('button');
                    abutton2.trigger('click');              // this will call showThisFile in a standard fashion
                }
            }   // iem
         }  // afile
         if (alayout.substr(0,3)=='tab')  $('#iTightenUp').trigger('click');
         if (jQuery.trim(aShowInfo)=='1'){
            toggleViewInfo('',1,1);
         }

         if (jQuery.trim(aDesc)!=='') {
             $('#dirDescriptions').prepend(aDesc+'<hr>');
        }
        if (aShowInfo!=='' && aShowInfo>-1) {
          toggleViewInfo('',1,1,aShowInfo);
        }


        let askLayout=$(document).data('requestedLayout');
        if (askLayout =='') {
          let doLayout=$(document).data('screenLayout');
          let doLayoutClass=$(document).data('screenLayout_default');
          let arf=$('#dropdown_layouts');
          let arf2=arf.find(doLayoutClass);
          if (arf2.length==1) arf2.trigger("click") ;
          wsurvey.flContents.onTop('dirList');
        }

// load a colledtion?
        let acollection=$(document).data('requestedCollection');
        if (jQuery.trim(acollection)!='') {
           let aentry=$(document).data('requestedEntry');
           openCollection(acollection,aentry,afile);
        }

// load a colledtion?
        let afavorites=$(document).data('requestedFavorites');
        if (jQuery.trim(afavorites)!='') {
           doFavorites_getPublic(0,afavorites,1,afile) ;  // 2nd arg 1 means "display favorites after retrievint
        }

     },200) ;

    },500);  //

}

//=================
// make array of image numbers from csv

function loadTreeDirsB_list(alist,nbuttons) {
  let mylist=[];
  let ifiles=alist.split(',');
  let istart=0,iend=nbuttons-1;
  for (var jj in ifiles) {    // each of the csvs
     let ifiledo=ifiles[jj];
     if (ifiledo.indexOf('-')<0) {   //  not a range
        if (!isNaN(ifiledo))  mylist.push(parseInt(ifiledo));
        continue;
    }
    let oof=ifiledo.split('-');
    if (oof.length<2) oof[1]=nbuttons;
    istart=jQuery.trim(oof[0]); iend=oof[1];
    if (jQuery.trim(istart)=='' || isNaN(istart)) istart=0;
    if (jQuery.trim(iend)=='' || isNaN(iend)) iend=nbuttons-1;
    istart=parseInt(istart),iend=parseInt(iend);
    for (var mjj=istart;mjj<=iend;mjj++) mylist.push(mjj);
  }   
  return mylist;

}

//================  ==========================================
// dirlist click handler (several possible actions, depending on what was clicked ) -- client version
function dirListClickHandlerClient(evt) {

   let ethis=wsurvey.argJquery(evt);
   let aname=ethis.attr('name');
   if (aname=='dirListFileViewFiles') {  //  ignore if not dir button
      getDirFileListJs(evt);
      return 1;
   }           // dirlistdescarea



}