// ====================
//  admin js functions
// ====================

//===============
// enable admin mode -- when gear button clicked. Only permitted if logged on
function doAdmin1(forceShow ) {

  var adminEnable ;

  var tt=typeof($(document).data('logonStatus'));
  if (tt=='undefined') $(document).data('logonStatus',0);
  var logonStatus=$(document).data('logonStatus');
  if (logonStatus==0) {
     alert("To use admin mode, you must first logon ");
     return 1;
  }
  if (forceShow==1) {
    $(document).data('adminModeEnabled',1);
    adminEnable=1;
  } else {
       adminEnable=$(document).data('adminModeEnabled');
      if (adminEnable==1) {                                // dispale
         adminEnable=0;
         $(document).data('adminModeEnabled',0);
     } else {
         adminEnable=1;
         $(document).data('adminModeEnabled',1);
     }
  }
  if (adminEnable==0 ) {                    // now disabled
        wsurvey.flContents.hide(200,'admin');
        $('#itopBarRightEnable').hide();
        return 0;
  }
// othweise, get admin menu from server and display it in admin box
  $('#itopBarRightEnable').show();

   wsurvey.flContents.show(200,'admin');
   var data={'todo':'getAdminMenu'} ;
   wsurvey.getJson.get("wsGalleryActionsAdmin.php",data,doAdmin2c);
 
}


//=====================
// show admin menu in admin contentbox
function doAdmin2c(zdata) {

      var hh=wsurvey.getJson.check(zdata,0,'callBack from doAdmin');
      if (hh===false) return 0;  // not used
     $(document).data('skipSubDirs',hh['skipSubDirs']);

      let  eadmin=wsurvey.flContents.dom('#admin','m');
       eadmin.wsFlContents(hh['content']);
       eadmin.wsFlOnTop(1);
       let anote='';
       let aa= $(document).data('wsGallery_version');   // current version

       eadmin.wsFlHeader('Admin menu. <a title="view administrator notes, and information on current galleries and trees" class="blueButton" href="data/installNotes.php?ver='+aa+'" target="notes">Notes</a>'+anote);
       eadmin.wsFlShow(10);
     return 1 ;                  // not used
}
 


//===========
// tell server to create (or update/revise) the dir list for a tree
function makeTreeDirList(athis) {
   var stuff='';

   var ethis=wsurvey.argJquery(athis);
   var treename=ethis.wsurvey_attr('data-treeName','_default');
   var isUpdate=ethis.wsurvey_attr('data-isUpdate',0 );

    stuff='<div id="getAdminMenu_results" title="current progress displayed here " class="cGetAdminMenu_results" > progress displayed here ... </div>';

     stuff+=' <input type="button" value="?" title="More help on creating a directory listing"  onclick="doHelpVu(this)" topic="dirCreateListMore" class="helpButton"> ';
    stuff+=' <input  class="makeDirListGoButton" id="imakeTreeDirList_GoButton" type="button" value="Go!" ';
    stuff+='   title="Create  ... with the selected options" onClick="makeTreeDirList_Go(this)" data-treename="'+treename+'" data-update="'+isUpdate+'" data-preview="0"  > ';

     if(isUpdate==1) { stuff+='re-Create directory list ' } else { stuff+='Create directory tree '; }
    stuff+=' for the  <b>'+treename+'</b> <em>tree</em>';

    stuff+='&nbsp;&nbsp;&nbsp;<em>&hellip; or you can <input  class="xmakeDirListGoButton" id="imakeTreeDirList_GoButtonPreview"  title="preview directories that would be created in the wsGallery cache" type="button" value="preview" ';
    stuff+='   title="Create  ... with the selected options" onClick="makeTreeDirList_Go(this)" data-treename="'+treename+'" data-update="'+isUpdate+'" data-preview="1"   ></em> ';

    stuff+='<menu class="linearMenu" style="margin:3px 1em 3px 1em">';
    if (isUpdate==1) {
       stuff+='<li class="linearMenuLi2"><input type="checkbox" id="makeTreeDirList_retainDisabled" value="1" checked>';
       stuff+='<label for="makeTreeDirList_retainDisabled" title="Retain all the prior `disabled directories` settings"  >Retain <em>disabled directory</em> </label>';
       stuff+='<li class="linearMenuLi2"><input type="checkbox" id="makeTreeDirList_retainDescriptions" value="1" checked>';
       stuff+='<label for="makeTreeDirList_retainDescriptions" title="Retain all the prior `directory descriptions`"  >Retain <em>directory descriptions</em> </label>';
       stuff+='<li class="linearMenuLi2"><input type="checkbox" id="makeTreeDirList_removeUnusedCacheDirs" value="1"  >';
       stuff+='<label for="makeTreeDirList_removeUnusedCacheDirs" title="Remove directories from the cache that are no longer used ">Remove unused cache directories</label>';
    }

    stuff+='</menu>';

    let skips0=$(document).data('skipSubDirs');

    let skips=[];
    for (var sk in skips0) {
       skips.push(sk);
    }
    let askips=skips.join(',');

    stuff+='<div style="border:1px solid blue;margin:5px 2em 5px 3em"  id="makeTreeDirList_describeDirs">File containing directory descriptions: ';
    stuff+='<input type="text" size="40" value="describe.txt" title="filename containing a list of directory descriptions" id="makeTreeDirList_describeDirsFile">';
    stuff+='</div>';

    stuff+='<div style="border:1px solid blue;margin:5px 2em 5px 3em"  id="makeTreeDirList_skipSubDirsOuter">Skip these subdirectories: ';
    stuff+='<input type="text" size="80" value="'+askips+'" title="CSV of subdirectories to skip " id="makeTreeDirList_skipSubDirs">';
    stuff+='</div>';

    wsurvey.flContents.content('dirList',stuff,{'append':0,'onTop':1});
 // et2.html(stuff);
//    et2.show();
   window.setTimeout(function(){ $('#imakeTreeDirList_GoButton').focus();},100);
}

// --- 2nd step -- this does the work (called by button created above)
function makeTreeDirList_Go(athis) {
   var ethis=wsurvey.argJquery(athis);
   var removeUnusedCache=0,keepDisabled=1,keepDescriptions=1,kmess=' ',amess;
   var treename=ethis.wsurvey_attr('treeName,data-treename','_default');
   let isPreview=ethis.attr('data-preview');

   let describeFile=jQuery.trim($('#makeTreeDirList_describeDirsFile').val());
 
   var isUpdate=ethis.wsurvey_attr('Update,data-update',0 );
   if (isUpdate==1) {
       let ee=$('#makeTreeDirList_retainDisabled');
       let qee=ee.prop('checked');
       if (qee) {
          keepDisabled=1; kmess='Prior designation of disabled directory are <b>retained</b>. ';
       } else {
          keepDisabled=0; kmess='Prior designation of disabled directory are <b>not</b> retained. ';
       }
       let ee2=$('#makeTreeDirList_retainDescriptions');
       let qee2=ee2.prop('checked');
       if (qee2) {
          keepDescriptions=1; kmess+='Prior directory descriptions are <b>retained</b>. ';
       } else {
          keepDescriptions=0; kmess+='Prior directory descriptions  are <b>not</b> retained. ';
       }
        amess='re-Creating the directoryList (and cache) for <u>'+treename+'</u>.<br> '+kmess;
   } else {
       amess='Creating the directoryList (and cache) for  <u>'+treename+'</u>.<br>' ;
   }

   let ee2=$('#makeTreeDirList_removeUnusedCacheDirs');
   let qee2=ee2.prop('checked');
   if (qee2) {
      removeUnusedCache=1 ;
      amess+=' Unused cache directories will be deleted ';
   }

   let eskips=$('#makeTreeDirList_skipSubDirs');
   let askips=eskips.val();

// mustHaveViewable hardcoded to 1. Maybe change later (8 jan 2022)

    var ddata={'todo':'makeDirList','treeName':treename,'keepDisabled':keepDisabled,'keepDescriptions':keepDescriptions,
           'describeFile':describeFile,
          'mustHaveViewable':1,'timeAllowed':0,'removeUnusedCache':removeUnusedCache,'doResume':0,'doSkips':askips,'isPreview':isPreview};

   let et2=$('#getAdminMenu_results');
   let aspin=getSpinnerImg(25);         // get a <img ..> to a spinner (just for fun)
   let amess3='<div class="cdirListStatus" id="idirListStatus" title="status of directory creation for tree '+treename+'">'+aspin+' Please wait ...</div>';
   et2.html(amess+' '+amess3);
   et2.show();

    window.setTimeout(function(){
       $('#imakeTreeDirList_GoButton').prop('disabled',true);
       wsurvey.getJson.get("wsGalleryActionsAdmin.php",ddata,makeTreeDirList2,'makeTreeDirList_Go ');
    }, 150);  // delay a bit (so user sees please wait message)
   return 1;
}

// --- call back from srever
function makeTreeDirList2(zdata,origData) {

   var  hh= wsurvey.getJson.check(zdata,0,'makeTreeDirList callback') ;
   if (hh===false) return 0;
   if (typeof(hh['expired'])!=='undefined' && hh['expired']==1) {
      alert(hh['content']);
      return 1;
   }
   let treename=origData['treeName'],keepDisabled=origData['keepDisabled'],removeUnusedCache=origData['removeUnusedCache'] ;
   let  keepDescriptions=origData['keepDescriptions'],mustHaveViewable=origData['mustHaveViewable'],describeFile=origData['describeFile'];
   let isPreview=origData['isPreview'],askips=origData['doSkips'] ;


// an  "iterative" loop...  Call this back, assuming php uses resumeStatus to resume where it stopped to send back a status report
   if (hh['doResume']==1) {                  // if 0, a "final" return (not a "report status")
       let ee1=$('#idirListStatus') ;
       let rmessage=hh['resumeMessage'];
       let spinImage=getSpinnerImg(35);
       ee1.html(spinImage+' ' +rmessage);
       var ddata={'todo':'makeDirList','treeName':treename,'keepDisabled':keepDisabled,
                'mustHaveViewable':mustHaveViewable,'keepDescriptions':keepDescriptions,'describeFile':describeFile,
               'removeUnusedCache':removeUnusedCache,'doResume':1,'doSkips':askips,'isPreview':isPreview} ;
       window.setTimeout(function(){
             wsurvey.getJson.get("wsGalleryActionsAdmin.php",ddata,makeTreeDirList2,'makeTreeDirList2 (doresume)');
          }, 50);  // delay a bit (so user sees please wait message)
       return 1 ;
   }

// doresume=0 ... done!

   $('#imakeTreeDirList_GoButton').prop('disabled',false);

   let ee1=$('#idirListStatus') ;
   ee1.html(hh['resumeMessage']);

   let et1=$('#getAdminMenu_results');
   if (isPreview!=1) {
     let descSay='<br>No description file used ';
     let ovlist=hh['dirList']['.'];
     if (typeof(ovlist['describeFile'])!='undefined')  {
         let dFile=ovlist['describeFile'];
         let gotD=ovlist['describeFile_match'];
         let noGotD=ovlist['describeFile_noMatch'];
         descSay='<br>Description file <tt>'+dFile+'</tt> yielded '+gotD+' matches (and '+noGotD+' noMatches) ' ;
     }
     et1.html(hh['content']+'<hr>'+hh['cacheInfo']+descSay);
   } else {             // [creates,exists,removes]
     let cacheDir=hh['content'][3];
     let acreates=hh['content'][0];
     let acreatesM='<ol class="linearMenu"><li class="linearMenuLiSmall">'+acreates.join('<li class="linearMenuLiSmall"> ')+'</ol>';
     let aexists=hh['content'][1];
     let aexistsM='<ol class="linearMenu"><li class="linearMenuLiSmall">'+aexists.join('<li class="linearMenuLiSmall"> ')+'</ol>';
     let aremoves=hh['content'][2];
     let aremovesM='<ol class="linearMenu"><li class="linearMenuLiSmall">'+aremoves.join('<li class="linearMenuLiSmall"> ')+'</ol>';
     let tmess='<input type="button" value="&neArr;" title="Display this in new window"  ';
     tmess+='          onClick="wsurvey.displayInNewWindow(\'#getAdminMenu_results\')"> ';
       tmess+='Preview of directories created/existing/removed from: <tt>'+cacheDir+'</tt> &hellip;  ';
       tmess+='<table cellpadding="5" border="1">';
       tmess+='<tr><th valign="top">Create</th><td><div class="getAdminMenu_results_create">'+acreatesM+'</div></td></tr>';
       tmess+='<tr><th valign="top">Exist</th><td><div class="getAdminMenu_results_exist" >'+aexistsM+'</div></td></tr>';
       tmess+='<tr><th valign="top">Remove</th><td><div class="getAdminMenu_results_remove" >'+aremovesM+'</div></td></tr>';
     tmess+='</table>'+
     et1.html(tmess);
   }


   et1.css({'opacity':'1.0'});
   et1.show();


}
// --- call back from srever
function makeTreeDirList3(zdata,origData) {

   var  hh= wsurvey.getJson.check(zdata,0,'makeTreeDirList callback') ;
   if (hh===false) return 0;
   if (typeof(hh['expired'])!=='undefined' && hh['expired']==1) {
      alert(hh['content']);
      return 1;
   }
   wsurvey.dumpObj(hh,1,'list3');
}

//===============
// mark a descripiotn as being changedd
function updateDirDescMark(athis) {
   var ethis=wsurvey.argJquery(athis);
   ethis.attr('didChange',1); // marked as changed
}
//==============
// update descriptions (that have changed)
function updateFileDescriptions(athis) {
  var dachanges=[];
   var ethis=wsurvey.argJquery(athis);
   let atreename=ethis.attr('treename');
   let adir=ethis.attr('adir');

   var epar=ethis.wsFlClosest();
   let etexts=epar.wsFlFind('[name="fileDescs"]');
   let echanges=etexts.filter('[data-changed="1"]');

   for (var i0=0;i0<echanges.length;i0++) {
       let e1=$(echanges[i0]);
       let afile=e1.attr('afile');
       let newval=e1.val();
       let goo=[afile,newval] ;
       dachanges.push(goo);
   }

   let ddata={'todo':'updateFileDescs','changes':dachanges,'treeName':atreename,'dir':adir};

   wsurvey.getJson.get("wsGalleryActionsAdmin.php",ddata,updateFileDescriptions2,'updateFileDescriptions  ');



   return 1;


//=====================
// show admin menu in admin contentbox
function updateFileDescriptions2(zdata,origData) {

    var  hh=wsurvey.getJson.check(zdata,0,'Callback for updateFileDescriptions');
 
    if (hh===false) return 0;

    let dirSel=origData['dir'];

    let edr=$('#descriptionReport') ;
    edr.show();
    let edr2=edr.find('#descriptionReport2');
    edr2.show();

    acontent=' <input type="button" title="Click to reload wsGallery" value="reload" onClick="wsGallery_reload(this,5,0)" >  ';
    acontent+=hh['content'];
    edr2.html(acontent);
 //   eDescTexts.attr('didChange',0);  // reset change flag

 }
}

//====================
// save notes (for debugging)   Feb 2022 : mostly deprecated
function saveNotes(amess) {
   let    adminEnable=$(document).data('adminModeEnabled');
   if (adminEnable>0) {
       let messy=$(document).data('adminNotes')
        messy.push(amess);
       $(document).data('adminNotes', messy) ;
   }
}
function showNotes(a) {        // if here, admin mode enabed (else no button showsn)
  let dd=$(document).data('adminNotes' );
   var goo=dump(dd,'none',5);
   let stuff='<h4>Notes</h4>';
   stuff+='<pre>'+goo+'</pre>';
   wsurvey.flContents.contents('admin',stuff);

}


//==================  ==========================
//==================  ==========================

function doDescriptionsDir(athis) {
  var ethis=wsurvey.argJquery(athis);
  var atree1=ethis.wsurvey_attr('tree,treename','');
  var e1=ethis.wsFlClosest();
  let ee=e1.find('[name="dirListDescArea"]');
  let ee2=ee.filter('[data-changed="1"]');
  if (ee2.length==0) {
     alert('No dirDescription changes were made ');
     return 0; // nothing to change
  }
  var stuff=[];
  for (var ii=0;ii<ee2.length;ii++) {
      let aee=$(ee2[ii]);
      let adir=aee.attr('dirname');
      let adesc=aee.val();
      let xx=[adir,adesc];
      stuff[ii]=xx;
  }

  let adata={'todo':'updateDirDescs','list':stuff,'treename':atree1};

  wsurvey.getJson.get('wsGalleryActionsAdmin.php',adata,doDescriptionsDir1,'do descs');
}
function doDescriptionsDir1(zz,origData) {

    hh=wsurvey.getJson.check(zz,0,'callBack doDescriptionsDir1' )   ;
    let atree=origData['treename'];

    getDirCacheAdmin(0,atree,hh['content']);

}

//===============
// append original descrition of a dir (to dir descripiton textarea)
function addOriginalDirDesc(athis) {
  var ethis=wsurvey.argJquery(athis);
  let etable=$('#dirListingTableAdmin');
  let efocus=etable.data('lastFocus');
  let eorig=efocus.attr('origDesc');
  let eorigB=atob(eorig);
  efocus.append(' '+eorigB);
  efocus.trigger('change');
}

//===============
// append original descrition of a dir (to dir descripiton textarea)
function addDirDescList(athis) {
  var ethis=wsurvey.argJquery(athis);
  let etable=$('#dirListingTableAdmin');
  let foo='Enter directory descriptions. One directory per row using format: <tt>dirName  a description</tt>';
  foo+='<br><input type="button" value="Use these descriptions" title="Directories (one word) are case sensitive" onClick="addDirDescList2(1)">';
  foo='<textarea id="dirDescText" rows="7" cols="70" wrap="soft"> </textarea>';
  wsurvey.flContents.contents('gallery',foo,{'onTop':1,'header':'Specify directory descriptions','show':1});
}


//==================
// disable a tree  :
function doDisableTree(athis) {
    let ethis=wsurvey.argJquery(athis);
   let atreename=ethis.attr('treename');
   let isDisabled=ethis.attr('isDisabled');
   let adata={'todo':'disableATree','treename':atreename,'current':isDisabled};
   wsurvey.getJson.get('wsGalleryActionsAdmin.php',adata ,doDisableTree1,'doDisableTree   ');


 function doDisableTree1(zdata)  {
   var hh=wsurvey.getJson.check(zdata,0,'Callback from doDisableTree') ;
   if (hh===false) return 0;
   let acontent=hh['content'];
   let eparent=ethis.parent();
   let eaa=eparent.find('[name="atreename"]');
   eaa.toggleClass('cDisabledTree');


   doAdmin(1);
   window.setTimeout(function() {
       let hcontent=acontent+' &boxV; To update  <em>select a directory tree</em> ... <input type="button" value="reload wsGallery" onClick="wsGallery_reload(this,6,0)" >';
       $('#getAdminMenu_results').html(hcontent);},
       500);
   }
 }
 
//================  ==========================================
// dirlist change handler (several possible actions, depending on what was clicked

function dirListChangeHandler(evt) {
    let ethis=wsurvey.argJquery(evt);
    let aname=ethis.attr('name');

    if (aname=='dirListDescArea') {  // simple case: click in desription area -- so that the "lastFocus"
       ethis.attr('data-changed',1);
       ethis.addClass('cDescChanged')
       
       
 // highlignt updateDir description  button?
      let sibs=ethis.wsFlFind('.cDescChanged',1);
      if (sibs.length>0) {
         $('[name="doDescriptionsDirButton"]').addClass('cDirButton_active');
      } else {
        $('[name="doDescriptionsDirButton"]').removeClass('cDirButton_active');
      }

   }     // dirListDescArea

   return 1;
}


//================  ==========================================
// dirlist click handler (several possible actions, depending on what was clicked
function dirListClickHandler(evt) {
   let ethis=wsurvey.argJquery(evt);
   let aname=ethis.attr('name');

   if (aname=='dirListDescArea') {  // simple case: click in desription area -- so that the "lastFocus"
      let eparent=wsurvey.argJquery(evt,'delegateTarget');
      eparent.data('lastFocus',ethis);
      return 1;
   }           // dirlistdescarea

   if (aname=='dirListFileDescButton') {  // view the list of files and their descriptions button
       doChangeFileDescs(ethis) ;
       return 1;
   }

   if (aname=='dirListFileViewFiles') {  // view list of files (with showfile buttons)
       getDirFileListJs(ethis) ;
       return 1;
   }


   if (aname=='dirListDisableButtons') {  // disable a dir  button clicked
       disableDirViewSet(evt) ;
       return 1;
   }

   if (aname=='dirListInitialize') {        //     initialize directory button clicked (green or other  check)
     markToInitialize(ethis,1)          // in wsallery_dircache.js  -- mark this as one of the dirs to be intialized. ANd show a ball (that can be clicked for imemdiate init)
   }

   if (aname=='dirListInitializeNow') {        //     initialize just this directory button clicked (green or other  check)
       doDirCacheJs(ethis,1)               ;
   }

//   if (aname=='dirListInitializeAll') {        //     initialize just this directory button clicked (green or other  check)
//       doDirCacheJs(ethis,2)               ;  // febv 2022 : just one button, so use inline
//   }

   if (aname=='dirListMarkAll') {        //     initialize just this directory button clicked (green or other  check)
       dirListMarkAll(ethis)               ;
   }



   return 1;
}

//=========================
// list file descriptions
function doChangeFileDescs(ethis) {
   var treename=ethis.attr("treename");
   var galleryname=ethis.attr('galleryname')  ;
   var adir=ethis.attr('dir');

   let adata={'todo':'displayFileDescs','treename':treename,'dir':adir,'galleryname':galleryname};

   wsurvey.getJson.get('wsGalleryActionsAdmin.php',adata ,doChangeFileDescs1,'doChangeFileDescs   ');
   return 1;
}
             
 function doChangeFileDescs1(zdata,origData)  {
   var hh=wsurvey.getJson.check(zdata,0,'Callback from doChangeFileDescs') ;
   if (hh===false) return 0;
 
   let ah='Changing descriptions for files in:<span class="headerEmphasizer" > tree <em>'+origData['treename']+'</em> / dir <em>'+origData['dir']+'<em></span>';
   wsurvey.flContents.content('gallery',hh['content'],{'append':0,'show':1,'onTop':1,'header':ah});

   let ee=wsurvey.flContents.find('gallery','[name="fileDescChangeTable"]');

   ee.on('change',fileDescChangeText);    // need to use .on to detect target vs delegateTarget
   ee.on('click',fileDescClickButton);    // need to use .on to detect target vs delegateTarget

 }

// a viewfile button hit
// Note that this is a parent handler that capture all "changes".  So check if it is something you care about changing
function  fileDescClickButton(athis) {
   var  ethis=wsurvey.argJquery(athis,'target');
   var aname=ethis.attr('name');
   if (aname!='fileDescChangeTable_viewFile') return 1;
   showThisFile(athis)  ; // let showThisFile read the attributes (to display this image so you can make a descrition
}


// change to a file description. Check its html validity, mark as changed
// Note that this is a parent handler that capture all "changes".  So check if it is something you care about changing
function  fileDescChangeText(athis) {
  var  ethis=wsurvey.argJquery(athis,'target');
  var aname=ethis.attr('name');
  if (aname!='fileDescs') return 1;
  var afile=ethis.attr('afile');
  var ethisDel=wsurvey.argJquery(athis,'delegateTarget');
  var adir=ethisDel.attr('adir');
  var atree=ethisDel.attr('treename');
  ethis.addClass('cDescChanged');

  let aval=ethis.val();
  let avalCool= wsurvey.makeHtmlSafe(aval,1);
  ethis.val(avalCool[1]); // safe html!

  ethis.attr('data-changed',1);
}

function doExportDesc(athis,shorter) {

   if (arguments.length<2) shorter=1;

   let ethis=wsurvey.argJquery(athis) ;
   let etableDiv=ethis.wsFlFind('[name="fileDescChangeTable"]',1);
   let treename=etableDiv.attr('treename');
   let adir=etableDiv.attr('adir');
   let etable=etableDiv.find('table');
   let etrs=etable.find('tr');

   let infos={};
   for (var i1=0;i1<etrs.length;i1++) {
       let eatr=$(etrs[i1]);
       let ebutton=eatr.find('[name="fileDescChangeTable_viewFile"]');
       if (ebutton.length==0) continue  ; // could be header row
       let afile=ebutton.attr('file');

       let vfile=afile.split('/');
       let dafile=vfile.pop();
       let dadir='';
       if (vfile.length>0)dadir=vfile.join('/');

       let etexta=eatr.find('textarea');
       let aval0=etexta.val();
       let aval=aval0.replace(/\r?\n|\r/g," ") ;   // get rid of newlines

       if (shorter==0) {
          let edim=eatr.find('.fileDesc_dims')
          let adim=edim.text();
          let edate=eatr.find('.fileDesc_date')
          let adate=edate.text();
          infos[dafile]=[dadir,adim,adate,aval] ;
       } else {
          infos[dafile]=[dadir,aval] ;
       }
   }

  let dog=wsurvey.currentTime(1,1);
  let stuff=[];
  stuff.push('; Export of file descriptions for: tree='+treename+', directory='+adir);
  stuff.push('; '+dog);
  if (shorter==0) {
     stuff.push(';filename, wxh, data, description (can have commas)');
  } else {
     stuff.push(';filename, description (can have commas)');
  }
  for (var afile in infos) {
    let garg=[];
    let infos1=infos[afile];
    garg.push(afile);
    if (shorter==0) {
      garg.push(infos1[1]);  // skip dirname in [0]
      garg.push(infos1[2]);
      garg.push(infos1[3].replace(/\r?\n|\r/g," "));   // get rid of newlines
    } else {
      garg.push(infos1[1].replace(/\r?\n|\r/g," "));   // get rid of newlines
    }
    let say1=garg.join(',');
    stuff.push(say1);
  }
  let stuffSay=stuff.join('\n')+'\n';

   let goo='<div id="fileDescExport_area">';
   goo+='<input type="button" value="X" title="close this" onClick="wsurvey.flContents.container.close(this)"> ';
   if (shorter==1) {
      goo+='<input type="button" value="Longer" title="Add width x height, and creation date, columns" ';
      goo+='  onClick="doExportDesc(\'#gallery\',0)"> ';
   }
   goo+='<input type="button" value="Copy to clipboard " onClick="doExportDesc_copy(this)"><br>';
   goo+='<textarea cols="80" rows="20" id="fileDescExport_area2"  style="white-space: pre; overflow-wrap: normal; overflow-x: scroll;">'+stuffSay +'</textarea>';
   goo+='</div>';
   wsurvey.flContents.contents('snapBox3',goo,{'show':1,'append':0,'onTop':1,'header':'Export of descriptions for '+treename+' / ' +adir});
}
function  doExportDesc_copy(athis) {
   document.querySelector("#fileDescExport_area2").select();
   document.execCommand('copy');
}


// ====
// import from a text area (i.e.; paste of stuff preevously exported
function doImportDesc(athis) {
   let ethis=wsurvey.argJquery(athis) ;

   let etableDiv=ethis.wsFlFind('[name="fileDescChangeTable"]',1);
   let treename=etableDiv.attr('treename');
   let adir=etableDiv.attr('adir');
   let goo='<div id="fileDescExport_area">';
   goo+='<input type="button" value="X" title="close this" onClick="wsurvey.flContents.container.close(this)"> ';
   goo+='Enter descriptions here, and then  ';
   goo+='   <input type="button" value="Use them" title="match imported descriptions to files in update descriptions menu "  ';
   goo+='     onClick="doImportDesc_match(this)" >  ';
   goo+='<input type="button" class="smallButton" value="Details..." onClick="$(\'#doImportDesc_hint\').toggle()" title="Tips on how to enter ..." > ';
   goo+='<ul   id="doImportDesc_hint"  style="display:none" class="tightList">';
   goo+='<li> One description per line using: <tt>filename, description</tt> '
   goo+='<li> Empty lines, and lines beginning with a <tt>;</tt>, are ignored';
   goo+='<li>You can <button>export</button>  filenames and descriptions for a treename/directory.';
   goo+='<br>and after modifying them (with your favorite spreadsheet) cut and paste a CSV here! ';
   goo+='</ul>';
   let atitle='  title="Empty lines, and lines beginning with a ;, are ignored"  ';
   goo+='<textarea '+atitle+' cols="80" rows="20" id="fileDescImport_area2"  style="white-space: pre; overflow-wrap: normal; overflow-x: scroll"></textarea>';
   goo+='</div>';
   wsurvey.flContents.contents('snapBox3',goo,{'show':1,'append':0,'onTop':1,'header':'Import descriptions for '+treename+' / ' +adir});
}

function doImportDesc_match(athis) {

// read imported desacriptions
   let ee=$('#fileDescImport_area2');
   let aval=ee.val();
   let vvs=aval.split('\n');
   let vvs2={};
   for (var iv=0;iv<vvs.length;iv++) {
       let avv=jQuery.trim(vvs[iv]);
       if (avv=='' || avv.substr(0,1)==';') continue ;
       let avv2=avv.split(',');
       let aname=jQuery.trim(avv2.shift());
       let adesc=jQuery.trim(avv2.join(',')) ;  // readd commas
       vvs2[aname]=adesc
   }

// get current files (that have file description boxes)
   let etableDiv=wsurvey.flContents.find('gallery','[name="fileDescChangeTable"]');
   let treename=etableDiv.attr('treename');
   let adir=etableDiv.attr('adir');

   let etable=etableDiv.find('table');
   let etrs=etable.find('tr');
   let infos={};
   let nomatches=0;matches=0;
   for (var i1=0;i1<etrs.length;i1++) {
       let eatr=$(etrs[i1]);
       let ebutton=eatr.find('[name="fileDescChangeTable_viewFile"]');
       if (ebutton.length==0) continue  ; // could be header row
       let afile=ebutton.attr('file');
       let vfile=afile.split('/');
       let dafile=vfile.pop();

       if (!vvs2.hasOwnProperty(dafile)) {
            nomatches++;
           continue ; // no match
       }
       let etexta=eatr.find('textarea');
       etexta.val(vvs2[dafile]);
       etexta.trigger('change');
       matches++;
   }
   alert('Imported descriptions. #matches='+matches+', non-matches='+nomatches);

}

//==============  ======================================================
// toggle disable viewing status button    -- after one of the disable/enable buttons clicked
// called by   dirListClickHandler
//  var   disabledIcons=["&#128065;","&#10683;",'&#128683;'];
//  var   disabledIcons=["\uD83D\uDC41","\u274C","\uD83D\uDEAB"];

function disableDirViewSet(athis) {
  var   disabledIcons=["\uD83D\uDC41","\uD83D\uDEAB","\u2297"];
  var  adicon="\u26A0" ;       // ! in triangle
  if (arguments.length<2) iall=0;

 var ethis=wsurvey.argJquery(athis)
  var atitle;

  let iwhich=parseInt(ethis.wsurvey_attr('which',0));
  let origDisable=parseInt(ethis.wsurvey_attr('origDisable',iwhich));

  iwhich++;
  let bclass='';
  if (iwhich>2 || iwhich<0) iwhich=0;
  if (iwhich==0)  { // not disabled
       adicon= disabledIcons[0];
       atitle='This directory is viewable ';
  } else if (iwhich==1) {
       adicon= disabledIcons[1];
       atitle='This directory is DISABLED (is not shown) ';
  } else if (iwhich==2) {
      adicon= disabledIcons[2];
      bclass='cPartialDisableButton';
      atitle='This directory is partiallyDisabled (file list will not be shown) ';
  }

  ethis.attr('which',iwhich);
  ethis.attr('title',atitle)
  ethis.val(adicon);
  if (bclass=='') {
      ethis.removeClass('cPartialDisableButton');
  } else {
      ethis.addClass('cPartialDisableButton');
  }

  ethis1=ethis.closest('[name="currentDisableStatus"]');
 ;
  if (origDisable!=iwhich) {
     ethis1.addClass('cdisableChanged')
     ethis1.removeClass('cdisableNotChanged')
  } else {
     ethis1.addClass('cdisableNotChanged')
     ethis1.removeClass('cdisableChanged')
  }
  
 // highlignt updateDirstatus button?
  let sibs=ethis.wsFlFind('.cdisableChanged',1);

  if (sibs.length>0) {
     $('[name="doDisableDirButton"]').addClass('cDirButton_active');
  } else {
     $('[name="doDisableDirButton"]').removeClass('cDirButton_active');
  }

//  doDescriptionsDirButton doDisableDirButton
  return 1;
}

//-----
// diable viewing of this directory (in the list of directories displayed for a tree)
// finds the buttons that have been clicedk, determiens the state of these buttons, calls server with new state info
function doDisableDir(athis) {
  var ethis=wsurvey.argJquery(athis);
  var atree1=ethis.wsurvey_attr('tree,treename','');
  var ee1=$('[name="dirListDisableButtons"]');
  var disableStats={};
  var ilen=ee1.length;
  let nchange=0;
  for (var i1=0;i1<ilen;i1++) {
     let ae1=$(ee1[i1]);
     let atree=ae1.attr('tree');
     let which=ae1.attr('which');
     let origdisable=ae1.attr('origdisable');
     if (which==origdisable) continue ; // no change
     nchange++;
     let adir=ae1.attr('dirname');
     disableStats[adir]=which;
  }

  if (nchange<1) {
     alert('No status changes were selected ');
     return 0 ;// none selected
  }
   let eed=$('#idisableDirViewResults');
   eed.show();
   let sfoo='Updating '+nchange+' disable status in tree <b>'+atree1+'</b>. ';
   sfoo+='<input    type="button" value="reload wsGallery" onClick="wsGallery_reload(this,7,0)" > to update this tree\'s <em>directory list</em> ';
   eed.html(sfoo);
   var ddata={'todo':'doDisableDir','treeName':atree1,'disable':disableStats};
   
   wsurvey.getJson.get("wsGalleryActionsAdmin.php",ddata,doDisableDir2,'doDisableDir ')   ;
}

function doDisableDir2(zdata,origData ) {

   var hh=wsurvey.getJson.check(zdata,0,'Callback for doDisableDir2');
   if (hh===false) return 0;

   let atree=origData['treeName'];
   getDirCacheAdmin(0,atree,hh['content']);


}

//=============
// reload wsgallery  -- but wait up to 30 seconds for "update dir list" to finish
function wsGallery_reload(athis,ith,ict) {

  let e1=$('#getDirAdmin_status');
  if (e1.is(':visible') && ict<30) {
     if (ict==0  )  {
       ethis=wsurvey.argJquery(athis);
       ethis.val('wsGallery will reload in a few seconds ...');
     }
     window.setTimeout(function() {
         wsGallery_reload(athis,ith,ict+1);
     },1000) ;
     return 1;
  }
   location.reload(true);
}


//===============
// the collection specification routines
//========================

function  createCollection(athis){

// the layout changes...
     wsurvey.flContents.container.doResize('snapBox1','R');
     wsurvey.flContents.container.doResize('snapBox2','R');
     wsurvey.flContents.container.doResize('snapBox3','R');
     wsurvey.flContents.container.doResize('tableau','R');
     wsurvey.flContents.container.doResize('gallery','R');
     wsurvey.flContents.container.doResize('admin','R');
     wsurvey.flContents.container.doResize('singleImage','R');
     wsurvey.flContents.container.doResize('dirList','R');

     wsurvey.flContents.hide(2,'singleImage');
     wsurvey.flContents.hide(2,'tableau');
     wsurvey.flContents.hide(2,'dirList');
     wsurvey.flContents.hide(12,'gallery');

       let s1={'top':'5%','left':'1%','width':'48%', 'height':'35%'};
        wsurvey.flContents.container.doResize('admin',s1)

       let s2={'top':'2%','left':'51%','width':'47%','height':'41%'};
       wsurvey.flContents.container.doResize('snapBox1',s2)

       let s3={'top':'48%','left':'1%','width':'48%','height':'44%'};
       wsurvey.flContents.container.doResize('snapBox2',s3)

       let s4={'top':'51%','left':'51%','width':'47%','height':'41%'};
       wsurvey.flContents.container.doResize('snapBox3',s4)

     wsurvey.flContents.show(2,'admin');
     wsurvey.flContents.show(12,'snapBox3');
     wsurvey.flContents.show(12,'snapBox1');
     wsurvey.flContents.show(22,'snapBox2') ;
     wsurvey.flContents.content('snapBox3','');
     wsurvey.flContents.content('snapBox2','');

     let amess='';
     amess+='<div id="collectionSaveStatus" style="font-size:135%;background-color:#eee1d1;display:none"></div>';

     let hbutton0='<input type="button"   class="smallButton" value="&#65046;" title="Help on specifying a collection: specifying entries by hand " topic="specifyCollection_entriesByHand"   onClick="doHelpVu(this)" >' ;

     amess+='<input type="button" class="smallButton" value="&#10068;" title="Help on specifying a collection" topic="specifyCollection"   onClick="doHelpVu(this)" >' ;
     amess+=' <b><input type="button" value="&#128259;"  title="Specify a collection (reload)" onClick="createCollection(this)"> Specify a collection ...</b> ';
     amess+=' <em>or <input type="button" value="View existing collections" title="Display a list of collections: remove, edit, or view their files!"  onClick="collectionsView(this)"> ';

     amess+='<table><tr><th>Name </th><td><input type="text" size=25 name="collectionName" title="A name (single word) for this collection"></td></tr>';
     amess+='<tr><th>Description </th><td><input type="text" size=75 name="collectionDesc" title="A short (no html) description of this collection"></td></tr>';
     amess+='<tr><th>'+hbutton0+' Entries</th>';

     amess+='<td><textarea cols="90" rows="5" name="collectionEntries"  ';
     amess+='     title="Directories\nOne per row using CSV: gallery,tree,dir,localName,description" ';
     amess+='     style="white-space: pre; overflow-wrap: normal; zoverflow-x: scroll;">; created by   ';
     amess+='</textarea>';
     amess+='</td></tr> '
     amess+='<tr><td><input type="button" data-overwrite="0" id="collection_saveButton" value="Save entries" title="Be sure to specify a name!" onClick="createCollectionSave(this)"></td>';
     amess+='<td><b>Tip:</b> use the selection <span style="color:blue;border-bottom:2px dotted blue" data-which="#collectionSelectGalleryHelp" onClick="focusOnCollection(this)">tool</span> to find gallery/tree/directories...  </td>';
     amess+='</tr></table>';
     wsurvey.flContents.contents('admin',amess);

     let bmess='';
      bmess+='<div id="collectionGalleryShow0" style="margin:5px;max-height:5em;border:1px solid gold"> ';
      let hbutton='<input type="button" id="collectionSelectGalleryHelp" class="smallButton" value="&#10068;" title="Help on specifying a collection: select a gallery" topic="specifyCollection_gallery"   onClick="doHelpVu(this)" >' ;

       bmess+='<div id="colllectionSelectGalleryHeader" style="font-weight:700">'+hbutton+' Select which gallery: </div>';
      bmess+='<div id="collectionGalleryShow"  >...</div>';
      bmess+='</div>';
      bmess+='<div class="collectionTreeShowC" id="collectionTreeShow"> </div>';
      bmess+='<div class="collectionDirShowC" id="collectionDirShow"> </div>';

     wsurvey.flContents.contents('snapBox1',bmess,{'show':1,'header':'select a gallery and a tree'});

     otherGalleries(0,1);

     return 1;
}


//-===============
// save it
function createCollectionSave(athis) {
   let ethis=wsurvey.argJquery(athis);
   let dooverwrite=ethis.attr("data-overwrite");
   let ename=$('[name="collectionName"]');
   let vname=jQuery.trim(ename.val());
   let edesc=$('[name="collectionDesc"]');
   let vdesc=jQuery.trim(edesc.val());
   let eentries=$('[name="collectionEntries"]');
   let ventries=jQuery.trim(eentries.val());

    var adata={'todo':'saveCollection','name':vname,'desc':vdesc,'entries':ventries,'overwrite':dooverwrite}  ;
   wsurvey.getJson.get('wsGalleryActionsAdmin.php',adata,createCollectionSave2,'createCollectionSave ');
    return 1;
}
function createCollectionSave2(aresponse,origdata) {
    hh=wsurvey.getJson.check(aresponse,0,'createCollectionSave2');
    if (hh===false) return 1;
    let astatus=hh['content']['result'];
//wsurvey.dumpObj(hh,1,'foo2');
    $('#collectionSaveStatus').html(astatus).show();
    let ee1=$('[name="collectionName"]');
    ee1.val('');
    let ee1a=$('[name="collectionDesc"]');
    ee1a.val('');
    let ee1b=$('[name="collectionEntries"]');
    ee1b.val('');

}

//=================
// view current colelctions
function collectionsView(athis) {
    var adata={'todo':'listCollections'}  ;
    wsurvey.getJson.get('wsGalleryActions.php',adata,collectionsView2,'collectionsView ');
    return 1;
}
function collectionsView2(aresponse,origdata) {
    hh=wsurvey.getJson.check(aresponse,0,'collectionsView2');
    if (hh===false) return 1;
    let astatus=hh['content'];
    let bmess='<b>Available collections</b>';

    bmess+='<div style="border:3px solid blue;width:95%;overflow:auto">';

    bmess+='<table rules="cols" width="95%"><tr>';
    
    bmess+='<td valign="top"  width="40%">';
    bmess+='<div style="border:2px solid gold;overflow:auto;padding:3px 3px 1em 3px" id="collectionsView2_colA">';
    bmess+='<table rules="rows" cellpadding="4"><tr><th>Name</th> <th>Description</th></tr>';

    for (let ii in astatus) {
       let vv=astatus[ii];
       bmess+='<tr><td> ';
       bmess+='<span style="white-space:nowrap"><input type="button" style="color:red" value="&#9421;"  which="'+vv[0]+'" onclick="removeACollection(this)" title="delete this collection" >';
       bmess+='<input type="button" style="color:green" value="&#9998;"  which="'+vv[0]+'" onclick="editACollection(this)" title="edit this collection" >';
       bmess+='<input type="button" value="'+vv[0]+'" onclick="showACollection(this)" title="view the '+vv[2]+' entries in this collection" >';
       bmess+='</span> ';
       bmess+=' <span title="Created: '+vv[4]+'" style="font-style:oblique">'+vv[1]+'</span></td>';
       bmess+'</tr>';
    }
    bmess+='</table></div>';
    bmess+='</td>';

    bmess+='<td valign="top" width="55%" >  ';
    bmess+='<div title="Entries in chosen collection ..." style="border:2px solid yellow; overflow:auto;padding:3px 3px 1em 3px" id="collectionsView2_col2"> &hellip; </div>';
    bmess+='</td>';

    bmess+='</tr></table>';
    bmess+='</div>';

    wsurvey.flContents.content('snapBox1',bmess,{'header':'Currently available collections'});
    
    oof=wsurvey.flContents.current('snapBox1');
    let bheight=oof['height'];
    let btop=oof['top'];

    let ea=$('#collectionsView2_colA');
    let eaTop=ea.offset().top;
    let eaD1=eaTop-btop;
    let bheight2=bheight-(eaD1 );

    $('#collectionsView2_colA').height(bheight2);
    $('#collectionsView2_col2').height(bheight2);

     wsurvey.flContents.content('snapBox2','');
     wsurvey.flContents.content('snapBox3','');

}

//-===============
// =--- switch focus
function focusOnCollection(athis) {
     let ethis=wsurvey.argJquery(athis);
     let awhere =ethis.attr('data-which');
     let e1=$(awhere);
     e1.focus();
     e1.css({'font-size':'110%','background-color':'green'});
//     e1.css('outline', 'none !important')
//       .attr("tabindex", -1)
//       .focus();
    return 1 ;
}



//===============
// delete a collection
function removeACollection(athis) {
   let ethis=wsurvey.argJquery(athis);
   let acollection=ethis.attr('which');
   let qq=confirm('Are you sure you want to remove collection: '+acollection);
   if (!qq) return 1;
   var adata={'todo':'collection_remove','collection':acollection }  ;
   wsurvey.getJson.get('wsGalleryActionsAdmin.php',adata,removeACollection2,'removeACollection ');
 }
function removeACollection2(aresponse,origdata) {
    hh=wsurvey.getJson.check(aresponse,0,'removeACollection2');
    if (hh===false) return 1;
    collectionsView(0);
}

///============
// edit a collection
function editACollection(athis) {
   let ethis=wsurvey.argJquery(athis);
   let acollection=ethis.attr('which');
   var adata={'todo':'collection_edit','collection':acollection }  ;
   wsurvey.getJson.get('wsGalleryActionsAdmin.php',adata,editACollection2,'editACollection ');
 }
function editACollection2(aresponse,origdata) {
    hh=wsurvey.getJson.check(aresponse,0,'editACollection2');
    if (hh===false) return 1;
     createCollection(0);
     acontent=hh['content'];
     aentries='; Revision '+wsurvey.get_currentTime(11,1);
     if (acontent.hasOwnProperty('comments')) {
         aentries+="\n; "+acontent['comments'].join("\n; ");
     }
     for (let i1 in acontent['entries']) {
         aentry=acontent['entries'][i1];
         let goo=aentry[4]+':'+aentry[0]+','+aentry[1]+','+aentry[2]+','+aentry[3];
         aentries+="\n"+goo
    }
    $('[name="collectionName"]').val(hh['content']['name']);
    $('[name="collectionDesc"]').val(hh['content']['desc']);
    $('[name="collectionEntries"]').val(aentries);
    $('#collection_saveButton').attr('data-overwrite',1);
    $('#collection_saveButton').val('Update entries');

}

//=========
// display list of trees for a gallery (collection creation)
function createCollectionTrees(athis) {
     let ethis=wsurvey.argJquery(athis);
     let agallery=ethis.attr('data-gallery');
     let bmess='<b>Trees</b> in gallery:<tt>'+agallery+'</tt>';
     $('#collectionTreeShow').html(bmess).show();
    wsurvey.flContents.content('snapBox2','...');

   var adata={'todo':'collection_treeList','gallery':agallery }  ;
   wsurvey.getJson.get('wsGalleryActionsAdmin.php',adata,createCollectionTrees2,'createCollectionTrees ');
 }
function createCollectionTrees2(aresponse,origdata) {
    hh=wsurvey.getJson.check(aresponse,0,'createCollectionTrees2');
    if (hh===false) return 1;

// write buttons to collection-treelist
   let amess='',agallery=origdata['gallery'];
   amess+='Select a tree in gallery: <span style="font-size:110%;color:blue">'+agallery +'</span>';
    amess+='<ul class="linearMenu">';
    for (let aa in hh['content']) {
       let a1=hh['content'][aa];
       let a1id='galleryList_collection_trees_'+aa ;
       amess+='<li class="linearMenuLi2"><input name="collectionGalleryR" type="radio" data-tree="'+a1+'"  data-gallery="'+agallery+'" value="'+a1+'" id="'+a1id+'" onClick="createCollectionTreesGallery(this)">';
       amess+='<label for="'+a1id+'" title="Display list of directories in  this gallery"   ">'+a1+'</label> &nbsp;&nbsp;'
    }
    amess+='</ul>';

    $('#collectionTreeShow').html(amess).show();

}

//-----
// retrieve all dirs in a gallery (for collection)
function createCollectionTreesGallery(athis) {
     let ethis=wsurvey.argJquery(athis);
     let atree=ethis.attr('data-tree');
     let agallery=ethis.attr('data-gallery');
   var adata={'todo':'collection_dirList','gallery':agallery,'tree':atree}  ;
   wsurvey.getJson.get('wsGalleryActionsAdmin.php',adata,createCollectionTreesGallery2,'createCollectionTreesGallery ');
}

function createCollectionTreesGallery2(aresponse,origdata) {
    hh=wsurvey.getJson.check(aresponse,0,'createCollectionTreesGallery2');
    if (hh===false) return 1;

    let alist=hh[1]['.']['dirLookup'];
    let hbutton='<input type="button" id="collectionSelectGalleryHelp3" class="smallButton" value="&#10068;" title="Help on specifying a collection: select a directory" topic="specifyCollection_selectDir"   onClick="doHelpVu(this)" >' ;

    let amess='',agallery=origdata['gallery'],atree=origdata['tree'];
    amess+=hbutton+' Select a directory in a gallery/tree: <span style="font-size:110%;color:blue"><tt>'+agallery +'</tt> / <tt>'+atree+'</tt></span> ';
    amess+='<ul class="linearMenu">';

    let checkProblems=hh['checkProblems'] ;
  //  wsurvey.dumpObj(checkProblems,1,'checkp');
  let nproblems=0;
    for (let aa in alist) {
        let a1=alist[aa];
        let gotProblem='';
        if (checkProblems.hasOwnProperty(aa)) gotProblem=checkProblems[aa];
        let t1=hh[1][a1];
        let ddesc0=t1['dirDesc'];
        let ddesc=ddesc0.replace(/[\n\r\t\s]+/g, ' ')
        let nfiles=t1['nFiles'];
       let a1id='galleryList_collection_trees_dir_'+a1 ;
       amess+='<li class="linearMenuLi2">';
       if (gotProblem=='') {
          amess+='<input name="collectionGalleryR" type="radio" ';
          amess+='   data-gallery="'+agallery+'"  data-tree="'+atree+'" data-dir="'+aa+'" value="'+aa+'" id="'+a1id+'"  ';
          amess+='  data-desc="'+ddesc+'" ';
          amess+='   onClick="createCollectionTGD(this)">';
          amess+='<label for="'+a1id+'" title="Desc: '+ddesc+'"   >'+aa+' <span style="font-size:80%;font-family:monospace" title="# files in this directory">'+nfiles+'</span></label> &nbsp;&nbsp;'
       } else {
          nproblems++ ;
          amess+='<span title="Unable to add to collection: '+gotProblem+'\nDesc: '+ddesc+'" style="color:red">'+aa ;
          amess+=' <span style="font-size:80%;font-family:monospace " ';
          amess+='   title="# files in this directory">';
          amess+= nfiles+'</span>';
          amess+='</span> &nbsp;&nbsp;'
       }
    }
    amess+='</ul>';
    if (nproblems>0) {
       amess+='<div style="background-color:#dfdfdf">Note: there are '+nproblems+' directories that can not be used in a collection.';
       amess+='You should <tt>&#9881;&#65039; initalize</tt> these '+nproblems+' directories! ';
    }
    wsurvey.flContents.content('snapBox2',amess,{'header':' Select a directory in  <span style="font-size:110%;color:blue">'+agallery+' / '+atree +'</span>'});
}

//==============
// dir chosen from gallery/tree
function createCollectionTGD(athis){

     let ethis=wsurvey.argJquery(athis);
     let atree=ethis.attr('data-tree');
     let agallery=ethis.attr('data-gallery');
     let adir=ethis.attr('data-dir');
     let adesc=ethis.attr('data-desc');
     let hbutton='<input type="button" id="collectionSelectGalleryHelp2" class="smallButton" value="&#10068;" title="Help on specifying a collection: saving an entry a gallery" topic="specifyCollection_entrySave"   onClick="doHelpVu(this)" >' ;
      let anameDo=adir.replace(/[\\\/]+/g, '_')  ;
      let bmess='';
     bmess+=hbutton+' Entry for: <span style="font-size:110%;color:blue" title="gallery / tree / dir ">';
     bmess+=agallery+' / ' + atree+ ' / ' +adir +'</span>';
     bmess+=' &vellip; <span class="doGoButton"><a href="wsGallery_simple.php?';
     bmess+='useGallery='+agallery;
     bmess+='&useTree='+atree;
     bmess+='&useDir='+adir;
     bmess+='&useFile=0';
     bmess+='&headerLine=Collection+Preview:+files+in:+'+agallery+'+/+'+atree+'+/+'+adir ;
     bmess+='&autoAdjustSize=1';
     bmess+='" target="viewer" title="Preview the files in this gallery/tree/dir ... ">preview files</a></span>';

     bmess+='<table cellpadding="3">';
     bmess+='<tr><th>Entry name</th><td> <input type="text" size="30" title="Single word name for this entry" id="createCollectionTGD_name" value="'+anameDo+'"></td></tr>';
     bmess+='<tr><th>Entry desc</th><td> <input type="text" size="100" title="Short (no html) description this entry"  id="createCollectionTGD_desc" value="'+adesc+'"></td></tr>';
     bmess+='<tr><td colspan="2">';
     bmess+=' <input type="button" value="Add this entry!" onClick="createCollectionTGD_add(this)" ';
     bmess+=' data-gallery="'+agallery+'"  data-tree="'+atree+'" data-dir="'+adir+'"  >';
     bmess+='</td></tr></table>';
    wsurvey.flContents.content('snapBox3',bmess,{'header':' Add an entry '});


   return 1;
}

// add entry

function createCollectionTGD_add(athis) {
     let ethis=wsurvey.argJquery(athis);
     let atree=ethis.attr('data-tree');
     let agallery=ethis.attr('data-gallery');
     let adir=ethis.attr('data-dir') ;
     let aname=$('#createCollectionTGD_name').val();
     aname=jQuery.trim(aname);
     if (aname==''  ) {
        alert('You must provide a name for this entry. ');
        return 1;
     }
     aname=wsurvey.removeAllTags(aname);
     let aname2=aname.split(/[ ,]+/);      //https://stackoverflow.com/questions/10346722/how-to-split-a-string-by-white-space-or-comma?rq=1

     if (aname2.length!=1) {
        alert('You must provide a single word name for this entry ('+aname+'). ');
        return 1;
     }
     let adesc=jQuery.trim($('#createCollectionTGD_desc').val());
     adesc=wsurvey.removeAllTags(adesc);

     let aline=aname2[0]+':'+agallery;
     aline+=','+atree+','+adir+','+adesc ;
     
     let e3=wsurvey.flContents.find('admin','[name="collectionEntries"]');
     let e3val=e3.val();
     e3val+="\n" +aline;
     e3.val(e3val);

}

//==============
// show files of a collection (adminmode)
function collectionViewFiles_admin(athis) {
     let ethis=wsurvey.argJquery(athis);
     let atree=ethis.attr('data-tree');
     let agallery=ethis.attr('data-gallery');
     let adir=ethis.attr('data-dir') ;
     let acollection=ethis.attr('data-collection') ;
     let aentry=ethis.attr('data-entry') ;
     
     bmess='';
     bmess+='Collection <b>'+acollection+'</b> / entry  <b>'+aentry+'</b> ';
     bmess+='  <span style="font-size:80%" title="In gallery / tree  / dir ">('+agallery+' / '+atree+' / '+adir +')</span>';
     bmess+='<div id="icollectionViewFiles_admin"><em>Retrieving data ...</em></div>';
     wsurvey.flContents.content('snapBox2',bmess,{'header':'Files in '+acollection+' / '+aentry});

     var adata={'todo':'getCollectionFiles_admin','collection':acollection,'entry':aentry,
        'gallery':agallery,'tree':atree,'dir':adir }  ;
     wsurvey.getJson.get('wsGalleryActionsAdmin.php',adata,collectionViewFiles_admin2,'collectionViewFiles_admin ');
     return 1;
}
function collectionViewFiles_admin2(aresponse,origdata) {
    hh=wsurvey.getJson.check(aresponse,0,'collectionViewFiles_admin2');
    if (hh===false) return 1;
    let bb=hh['content']['all']['dirInfo'];
    let cmess='# of files='+bb['nFiles']+' (#images='+bb['nImages']+'). Disabled ='+bb['isDisabled'];
      cmess+=' &boxV; <input type="checkbox" id="collectionViewFiles_admin2_stretch" checked title="Check to shrink image to fit viewer">';
    cmess+='<label for="collectionViewFiles_admin2_stretch" title="Check to shrink image to fit viewer"  >&#128476;</label>';

    cmess+=' &boxV; <input type="checkbox" id="collectionViewFiles_admin2_external"  ';
    cmess+=' data-gallery="'+origdata['gallery']+'" data-tree="'+origdata['tree']+'" ' ;
    cmess+=' data-dir="'+origdata['dir']+'" data-ith="'+origdata['ith']+'" ';
    cmess+=' data-collection="'+origdata['collection']+'" ';
    cmess+=' data-entry="'+origdata['entry']+'" ';
    cmess+='   title="Check to view image in an external viewer">';
    cmess+='<label for="collectionViewFiles_admin2_external" title="Check to view image  in an external viewer""  >&#10138;</label>';

    let blist=hh['content']['buttons'];
   // wsurvey.dumpObj(blist,1,'admin2xxxb');

    let bsay='<ul class="linearMenu">';
    for (let ij in blist) {
        let bb1=blist[ij][0];
        bsay+='<li data-ith="'+ij+'" class="linearMenuLi">'+bb1;
    }
    bsay+='</ul>';
    $('#icollectionViewFiles_admin').html(cmess+bsay);
    $('#icollectionViewFiles_admin').on('click',listOfFileClickHandler_collectionAdmin);

    return 1;
}

// ================
// captures clicks on showFile buttons -- collection viewer
function listOfFileClickHandler_collectionAdmin(evt) {
     let ethis=wsurvey.argJquery(evt);
     if (ethis.prop('tagname')!=='button') ethis=ethis.closest('button');    // if click on img, need to go up to the button (that has the attribute info)
     let aname=ethis.attr('name');
     if (aname!='listOfFileInCurrentDir_button') return 1 ; // not showFile button click

      let eli=ethis.closest('li');
      let ith=eli.attr('data-ith')


     let eExt=$('#collectionViewFiles_admin2_external');
     let qExt= (eExt.prop('checked')) ? true : false;
     if (qExt) {          // show in external window
         let agallery=eExt.attr('data-gallery') ;
         let atree=eExt.attr('data-tree')   ;
         let adir=eExt.attr('data-dir')     ;
         let acollection=eExt.attr('data-collection')    ;
         let aentry=eExt.attr('data-entry')  ;
         let aline='Collection/Entry+Preview:+'+acollection+'/'+aentry ;
         let aurl='wsGallery_simple.php?useGallery='+agallery+'&useTree='+atree;
            aurl+='&useDir='+adir+'&useFile='+ith+'&headerLine='+aline;
            aurl+='&autoAdjustSize=1';
         window.open(aurl,'viewer','popup=1');
         return 1;
     }


     let ishrink= ($('#collectionViewFiles_admin2_stretch').prop('checked')) ? 3 : 1 ;
     showThisFile(ethis,1,ishrink,1) ;             // getSnapArg,iShrinkArg,fromCollection
}

//=============
// favorites functions
function deletePublicFavorites(athis) {
   var adata={'todo':'listPublicFavorites' }  ;
   wsurvey.getJson.get('wsGalleryActionsAdmin.php',adata,deletePublicFavorites2,'deletePublicFavorites ');
}
function deletePublicFavorites2(aresponse,origdata) {
     hh=wsurvey.getJson.check(aresponse,0,'deletePublicFavorites2');
    if (hh===false) return 1;
    let smessage=hh['content'];
    wsurvey.flContents.content('admin',smessage,{'onTop':1,'show':1});
}

//========
// delete a publci favorite
function deletePublicFavoritesDo(athis) {
   let ethis=wsurvey.argJquery(athis);
   let alist=ethis.val();
   var adata={'todo':'deleteAPublicFavorites','name':alist }  ;
   wsurvey.getJson.get('wsGalleryActionsAdmin.php',adata,deletePublicFavoritesDo2,'deletePublicFavoritesDo ');
}
function deletePublicFavoritesDo2(aresponse,origdata) {
     hh=wsurvey.getJson.check(aresponse,0,'deletePublicFavoritesDo2');
    if (hh===false) return 1;
    let smessage=hh['content'];
    $('#idelPublicFavoritesList').html(smessage);
    return 1;
}

//==============
// file notes
function editFileNotes(athis) {
     let ethis=wsurvey.argJquery(athis);
     let atree=ethis.attr('data-tree');
     let agallery=ethis.attr('data-gallery');
     let adir=ethis.attr('data-dir');
     let afile=ethis.attr('data-file');
     let bnumber=ethis.attr('data-bnumber');

      showFileNotes_retrieveAdmin(agallery,atree,adir,afile,bnumber);  //js2,allkeys]

}
//=============
// retrieve file notes for a file
function showFileNotes_retrieveAdmin(agallery,atree,adir,afile,bnumber) {

    var  myOrigin=window.location.protocol+'//'+window.location.hostname;
    if (window.location.port!='') myOrigin+=':'+window.location.port;

   let wsMainSel= $(document).data('wsgMainSel');
   let aurl= myOrigin+wsMainSel+"/galleries/"+agallery+'/'+atree+'/'+adir+'/'+afile+'.note';
   let adata={};
   let odata=[agallery,atree,adir,afile,bnumber];

   wsurvey.getJson.get([' '+aurl,'POST','text'],adata,[showFileNotes_retrieveAdmin2,odata,afile],'showFileNotes_retrieveAdmin');
   return 1;
}

// as a text call, do NOT use getJson auto error checking!
function showFileNotes_retrieveAdmin2(response,origData,otherArgs2,textStatus,jqXHR,errArgRet) {
   var hideTreeList=0,damess;
   let js2;

   if (errArgRet===false) {   // got file (not a 404 etc)
     damess=response;
     try {
        js2=JSON.parse(damess);
     } catch(e) {
         alert('Problem reading notes file (not in json format): '+e.name+' : ' +e.message) ;
         return 1;
     }

   } else {    // no file notes
      js2=[] ;
   }

   let allkeys0=[];
   for (let ij in js2) {
        let ajs2=js2[ij];
        let atime=ajs2['time'];
        let atimek=atime*1000  ; // convert to js time
        let saytime=wsurvey.get_currentTime(31,1,atimek);
        js2[ij]['sayTime']=saytime;

        let akey=ajs2['key'],akeysay='';
        if (jQuery.isArray(akey)) {
           jQuery.merge(allkeys0,akey);
           akeySay=akey.join(' &boxV; ');
        } else {
           akeySay=akey;
           allkeys0.push(akey);
        }
   }

  // clean up allkeys
  let allkeys=[];
  if (allkeys0.length>0) {
    let allkeys2={};
    for (let jj=0;jj<allkeys0.length;jj++) {
       let akey=jQuery.trim(allkeys0[jj]);
       let akeylc=akey.toLowerCase();
       if (!allkeys.hasOwnProperty(akeylc)) allkeys2[akeylc]=akeylc;
    }
    for (let bkey in allkeys2) {
       allkeys.push(allkeys2[bkey]);
    }
  }
  let nnotes=js2.length;
   let b3='';

   b3+=' <input   type="button" value="x" title="Close the edit file-notes menu\n Note: be sure to `save` first (if you have changes you want to retain)" ';
   b3+=' onClick="$(\'#singleImageOtherInfo\').hide()" > ';

   b3+='<input type="button" class="helpTopic_otherTopicButton" value="&#10068;"  ';
   b3+='   topic="editFileNotes" title="Editing notes for a file  ..."   onclick="doHelpVu(this,1)"> ';

   b3+='<input  id="saveTheFileNotes_button" type="button" value="Save" title="Save the revised file-notes (and keywords)\n Note: entries with empty notes and keywords are dropped" ';
   b3+=' onClick="saveTheFileNotes(this)" >';

  let amess='<div style="background-color:#dffdfe">'+b3+' <b>'+nnotes+' file-notes</b> for:<tt> ' +otherArgs2.join('</tt> /  <tt>')+'</tt></div>';
  
  amess+='<div id="saveFileNotes_status" style="background-color:#ddddcc;margin:3px 1em 3px 1em;display:none"></div>';

   amess+='<table  width="100%" cellpadding="3" rules="rows">';
  amess+='<tr><th  width="2%">Clear</th><th width="9%">From</th><th width="70%">Note</th><th width="15%" >Keywords</th></tr>';
   for (let irow in js2) {
       arow=js2[irow];
       let m2='<tr name="editThis">';
       m2+='<td width="2%"><input type="button" value="&#9003;" title="clear this note" onClick="clearAFileNote(this)"> </td>';
       m2+='<td width="9%"><span title="Submitted by @: '+arow['sayTime']+'">';
       m2+=' <span style="font-family:monospace;font-size:80%" name="editThisName">'+arow['name']+'</span>';
       m2+='<input type="hidden" name="editThisTime" value="'+arow['time']+'">';
       m2+='</td>';
       m2+='<td width="70%"><textarea name="editThisNote" rows="3" cols="60">'+arow['note']+'</textarea></td>';
       let bkey=arow['key'];
       if (!jQuery.isArray(bkey)) bkey=[bkey];
       m2+='<td  width="15%" ><textarea  name="editThisKey" rows="3" cols="20">'+bkey.join(', ')+'</textarea></td>';
       m2+='</tr>';
       amess+=m2;
   }

   let m2a='<tr><th>Keywords</th>';
   m2a+='<td colspan="3"><tt>'+allkeys.join(', ')+'</tt></td>';
   m2a+='</tr>';
   amess+=m2a;

   amess+='</table> <br> <em>end of notes</em>  '
  let aodata=otherArgs2.join(',');
   amess+='<input type="hidden" name="editThisStuff" value="'+aodata+'">';  // info used by callback

   let eput=wsurvey.flContents.find('singleImage','#singleImageOtherInfo');
   eput.html(amess).show()     ;
  wsurvey.flContents.show('singleImage');
  wsurvey.flContents.onTop('singleImage');
  wsurvey.flContents.scrollTop('singleImage',100,1 )  ;
  
   doResizeViewers(0,4);

  // wsurvey.dumpObj(js2,1,'js2');

}

///  clear this rows note and keywords
function clearAFileNote(athis) {
   let ethis=wsurvey.argJquery(athis);
   let etr=ethis.closest('tr');
   let enotes=etr.find('[name="editThisNote"]');
   enotes.val('');
   let ekeys=etr.find('[name="editThisKey"]');
   ekeys.val('');
  return 1;
}

//=====
//save all the file notes
function saveTheFileNotes(athis) {
//  let odata=[agallery,atree,adir,afile,bnumber]; is in  editThisStuff

  let erows=wsurvey.flContents.find("singleImage",'[name="editThis"]');
  if (erows.length==0) return 0;
  let allnotes=[],nremove=0;
  for (let ir=0;ir<erows.length;ir++) {
     arow=$(erows[ir]);
     let aname=arow.find('[name="editThisName"]').text();
     let atime=arow.find('[name="editThisTime"]').val();
     let anote=jQuery.trim(arow.find('[name="editThisNote"]').val());
     let akey=jQuery.trim(arow.find('[name="editThisKey"]').val());
     if (anote==''  && akey=='') {
         nremove++;
         continue;
     }
     let akeys=akey.split(',');
     for (let ii=0;ii<akeys.length;ii++) akeys[ii]=jQuery.trim(akeys[ii]) ;
     let akey2=akeys.join(',');

     let addme={'name':aname,'time':atime,'note':anote,'key':akeys};
     allnotes.push(addme);
  }

   let eother=wsurvey.flContents.find('singleImage','[name="editThisStuff"]');
   if (eother.length==0) return 0;
   let odata=eother.val();

   let adata={'todo':'saveAFileNotes','stuff':allnotes,'location':odata};

   wsurvey.getJson.get('wsGalleryActionsAdmin.php',adata,saveTheFileNotes2,'saveAFileNotes ');
}
function saveTheFileNotes2(aresponse,origdata) {

   hh=wsurvey.getJson.check(aresponse,0,'saveTheFileNotes2');
   if (hh===false) return 1;
   $('#saveFileNotes_status').html(hh['content']['message']).show();
   let ebb=$('#saveTheFileNotes_button');
   ebb.css({'opacity':0.5});
   ebb.prop("disabled",true);
}

