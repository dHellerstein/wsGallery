// javascript library for wsGallery -- works with wsGallery_get.php
// THis contains functions that simplify the use of wsGallery_get.php -- for retrieving information from a
// wsGallery "installation"

if (typeof(wsGallery)=='undefined')  {
    var wsGallery={};
}

//====================
// wsGallery "get" initialization
//   wsgName: name used for this wsGallery viewer.
//                If false, or 0, or '' : use the default -- the document.
//                Only ONE default is allowed per page
//   parentId  : jQuery selector pointing to the container that holds the wsGallery viewer
//                 If false, or 0, or '' : the $(document)
//                 This is NOT allowed if wsgName is not the default (false,0, or '')
//  opts :  an object with options. The only required option is 'callback'.
//          For other options, defaults are used
//
//  Thus: wsGallery.init(false,false,'myCallback');
//  is the same as: wsGallery.init(false,false,{'callback':'myCallback'});

//  wsgName is required. It must be unique. Or it can be false (or 0 or '')
//       It specifies where to store file and other information for this wsgName wsGallery viewer
//        If not specified, or is false,0, or '' : $(document) is used.
//        If $(document) is used -- only ONE wsGallery viewer is supported per page.
//  parentiD is required -- its the id of the container what will hold the various wsGallery menus
//           (The stuff returned by the wsGallery.getxxx functions
// opts must have a 'callback' index, that points to an existing javascript function
//   callback can be a string (the name of a javascript function), or a function object
//
// Shortcut: if opts is a string, or a function -- use its value as the callback.
//            all other options will be set to their defaults
//
// We recommend specifying parentId that points to a container -- it is somewhat sloppy to use the "document"
// as the parent id.

wsGallery.init=function(wsgName,parentId,opts0) {
   var funcuse,parentId,eparentId,wsgStuff;
   var opts={};    // wsGname specific
// correct number and type of agruments?
   if (arguments.length<3 ) {
      alert('wsGallery.init error: 3 arguments are required (wsgName,parentId, opts)');
      return 0 ;
   }
   if (wsgName!==false && typeof(wsgName)!='string' ) {
      alert('wsGallery.init error: 1st argument (wsgName) is not a string');
      return 1;
   }

   if (typeof(opts0)!='object' ) {
       opts['callback']=opts0 ;   // assume its the callback only shortcut
   } else {
      for (let aoo in opts0) {    // make a local copy -- if you don't there are problems when specifying multiple wsGalleryViewers
         opts[aoo]=opts0[aoo];
      }
    }


// wsgName is valid?
   if (wsgName===false || wsgName=='0'    || wsgName=='1' || jQuery.trim(wsgName)=='') wsgName=false; // use document as wsGalleryViewer
   if (wsgName!==false) {             // no numbers allowed (except 0) for wsgName
     wsgName=jQuery.trim(wsgName) ;
     if (!isNaN(wsgName)) {
      alert('wsGallery.init error: 1st argument (wsgName) can not be a number ');
      return 0;
     }
   }

// get the wsGallery  data storage (or init it)
   if (typeof($(document).data('wsGallery'))=='undefined') {
       wsgStuff={'0':{}};  // initializes. '0' will contain a list of currently open wsGalleryViewers.

   } else {
      wsgStuff=$(document).data('wsGallery');  // note that '0' is reserved for internal use
   }      // read wsgStuff

// check that wsgName is not being used
   if (wsgName==false) {     // only one default wsGallery per page
      if (wsgStuff.hasOwnProperty('1')) {
        alert('wsGallery.init error: wsgName not specified, but there already is a default wsGallery viewer ');
        return 0 ;
      }
      wsgName='1';    // 1 is for the default -- use the document as the wsGalleryViewer !
   }   else {
      if (wsgStuff.hasOwnProperty(wsgName)) {
          alert('wsGallery.init error: wsgName ('+wsgName+') already assigned. Use a different wsgName');
          return 0 ;
     }
   }    // wsg name check

// parentid check
   if (parentId===false || parentId==0 || jQuery.trim(parentId)=='') {
       if (wsgName!=='1') {
          alert('wsGallery.init error: default parentId only allowed with default wsgName');
          return 0 ;
     }
     eparentId=$(document);
   } else {
       eparentId=$(parentId);
       if (eparentId.length==0) {
          alert('wsGallery.init error: parentid ('+parentId+') does not exist )');
          return 0 ;
      }
      if (eparentId.length>1) {
        alert('wsGallery.init error: parentid ('+parentId+') is not unique ('+eparentId.length+')');
        return 0 ;
      }
      if (!eparentId.hasClass('wsGallery_main')) eparentId.addClass('wsGallery_main');
      eparentId.attr('data-wsgName_main',wsgName);
   }
   opts['wsgName_main']=wsgName;  // for finding the wsGalleryViewer dom object (ie; by using '[data-wsgName_main="wsgName"]'

// opts check and default set

// callback is only option that is required
   let acallback= (opts.hasOwnProperty('callback')) ? opts['callback'] : false ;
   if (acallback==false) {
        alert('wsGallery.init error: no callback specified');
        return 0 ;
   }
   if (typeof(acallback)=='string') {
      if (typeof(window[acallback])!='function') {
        alert('wsGallery.init error: callback ('+acallback+') is not a function ');
        return 0;
      }
      funcuse=window[acallback];   // is a function
   }   else {
     if (typeof(acallback)!=='function') {
        alert('wsGallery.init error: callback is not a function ');
        funcuse=acallback;
        return 0;
     }
   }

   opts['callback']=funcuse;

//  optional options (defaults used if not specified)

  if (!opts.hasOwnProperty('altDirDescs')) opts['altDirDescs'] = {}  ;
  if (!opts.hasOwnProperty('altFileDescs')) opts['altFileDescs'] = {};
  if (!opts.hasOwnProperty('descClass_inList'))  opts['descClass_inList'] ='desc_list' ;
  if (!opts.hasOwnProperty('descClass_viewer'))  opts['descClass_viewer']= 'desc_viewer' ;
  if (!opts.hasOwnProperty('descClass_inListSmall'))  opts['descClass_inListSmall']= 'desc_listSmall' ;
  if (!opts.hasOwnProperty('fileViewHeight'))  opts['fileViewHeight']= '' ;
  if (!opts.hasOwnProperty('fileViewWidth')) opts['fileViewWidth']= '' ;
  if (!opts.hasOwnProperty('showExternal'))  opts['showExternal']= 1 ;
  if (!opts.hasOwnProperty('showFull')) opts['showFull']= 1 ;
  if (!opts.hasOwnProperty('showDesc')) opts['showDesc']= 1 ;
  if (!opts.hasOwnProperty('showThumbnail'))   opts['showThumbnail'] = 'none';
  if (!opts.hasOwnProperty('selectGalleryList_class'))   opts['selectGalleryList_class'] = 'linearListGallery';
  if (!opts.hasOwnProperty('selectTreeList_class'))   opts['selectTreeList_class'] = 'linearListTree';
  if (!opts.hasOwnProperty('selectDirList_class'))   opts['selectDirList_class'] = 'selectDirList';
  if (!opts.hasOwnProperty('selectFileList_class'))   opts['selectFileList_class'] = 'selectFileList';

  if (!opts.hasOwnProperty('gallery_menu'))   opts['gallery_menu'] = '[name="content_galleries"]';
  if (!opts.hasOwnProperty('tree_menu'))   opts['tree_menu'] = '[name="content_trees"]';
  if (!opts.hasOwnProperty('dir_menu'))   opts['dir_menu'] = '[name="content_dirs"]';
  if (!opts.hasOwnProperty('file_menu'))   opts['file_menu'] = '[name="content_files"]';

 // basics done, so set up storage for this wsgName
   wsgStuff[wsgName]=opts;

   wsgStuff['0'][wsgName]=eparentId;     // list of wsgName

   $(document).data('wsGallery',wsgStuff);

// setup some event handlers?

   let noHandlers= (opts.hasOwnProperty('noHandlers')) ? opts['noHandlers'] : false ;
   if (noHandlers===true || noHandlers==1 || jQuery.trim(noHandlers)=='1')  {
      noHandlers=true ;
   } else {
       noHandlers=false;
   }

   if (noHandlers!==true)  {              // assigne event handlers.
     let adata1={'wsgName':wsgName};

     if (opts['gallery_menu']!==false) {
       let e1=eparentId.find(opts['gallery_menu']);
       if (e1.length==0) {
         alert('For '+wsgName+': event handlers can not be assigned to  getTreeList. no such element  '+opts['gallery_menu']);
         return false;
       }
       e1.on('click',adata1,wsGallery.getTreeList);
     }   // gallery_menu     getTreeList

     if (opts['tree_menu']!==false) {
       let e1=eparentId.find(opts['tree_menu']);
       if (e1.length==0) {
         alert('For '+wsgName+':   event handlers can not be assigned to getDirList. no such element  '+opts['tree_menu']);
         return false;
       }
       e1.on('click',adata1,wsGallery.getDirList);
     }     // tree_menu    getDirList

     if (opts['dir_menu']!==false) {
       let e1=eparentId.find(opts['dir_menu']);
       if (e1.length==0) {
         alert('For '+wsgName+': event handlers can not be assigned to getFileList. no such element: '+opts['dir_menu']);
         return false;
       }
       e1.on('click',adata1,wsGallery.getFileList);
     }      // dir_menu    getFileList


     if (opts['file_menu']!==false) {
       let e1=eparentId.find(opts['file_menu']);
       if (e1.length==0) {
         alert('For '+wsgName+': event handlers can not be assigned to viewAFile can not be assigned. no such element: '+opts['file_menu']);
         return false;
       }
       e1.on('click',adata1,wsGallery.viewAFile);
     }   // file_menu viewAFile

   }   // nohandlers


// load css file?

   let cssFile= (opts.hasOwnProperty('cssFile')) ? opts['noHandlers'] : 'wsGallery_get.css' ;
   if (cssFile===false || cssFile==0 || jQuery.trim(cssFile)=='')  {
     ;      // don't add
   } else {         // load the css file  https://www.geeksforgeeks.org/how-to-load-css-and-js-files-dynamically/
       let  head = document.getElementsByTagName('head')[0] ;
       let style = document.createElement('link') ;
       style.href = cssFile     ;
       style.type = 'text/css'  ;
       style.rel = 'stylesheet'  ;
       head.append(style);
   }


   return 1;
}

//=======================
// return object listing the currently open wsGalleyViewers
wsGallery.viewerList=function(varlist)  {
  if (arguments.length<1) varlist=[];
  if (varlist===false || varlist==0 ) varlist=[];

  let doAllVars=0;
  if (typeof(varlist)=='string' && varlist=='*') doAllVars=1;
  let egg= $(document).data('wsGallery')   ;
  if (typeof(egg)=='false') return {'nviewers':0,'list':{}}  // none specified

  let alist=egg['0'];
  let stuff={};
  for (let aname in alist ) {
     let a1={'wsgJquery':alist[aname]};
     let zz=egg[aname];
     if (doAllVars==1) {
         for (let aopt in zz) a1[aopt]=zz[aopt];
     } else {
       for (let iv=0;iv<varlist.length;iv++) {
          let av=varlist[iv];
          if (zz.hasOwnProperty(av)) a1[av]=zz[av];
       }
     }
     stuff[aname]=a1;
  }

  return stuff;
}


//==================
// return an option, or all options, for this wsgName
wsGallery.getParams=function(wsgName,avar,nofail) {
  if (arguments.length<3) nofail=0;
   sayWhere='getParams ';
   let dd=$(document).data('wsGallery');
   if (typeof(dd)=='undefined') {
      alert(sayWhere+' error: wsGallery not defined in document.data');
      return false;
   }
   if (!dd.hasOwnProperty(wsgName)) {
      console.trace(wsgName+' has not been specified (as a wsGallery viewer)');
      alert(sayWhere+' error ... '+wsgName+' has not been specified (as a wsGallery viewer)');
      return false;
   }

   let tt=dd[wsgName];
   if (arguments.length<2) return tt;  // return all of the par ams
   if (!tt.hasOwnProperty(avar)) {
      if (nofail==0) {
          alert('getParams ('+wsgName+') no such avar: '+avar)   ;
          wsurvey.dumpObj(tt,1,'for '+avar);
      }
      return false ;  // not an error
   }
   return tt[avar];

}

//==========
// helper function  -- set a wsGallery parameter

wsGallery.setParam=function(wsgName,avar,aval) {
   let sayWhere='wsGallery.setParam ';
   let dd=$(document).data('wsGallery');
   if (typeof(dd)=='undefined') {
      alert(sayWhere+' error: wsGallery not defined in document.data');
      return false;
   }
   if (!dd.hasOwnProperty(wsgName)) {
      alert(sayWhere+' error: '+wsgName+' has not been specified (as a wsGallery viewer)');
      return false;
   }
   let tt=dd[wsgName];
   tt[avar]=aval;
   dd[wsgName]=tt ;
   dd=$(document).data('wsGallery',dd);
   return 1 ;
}


//=================
// get list of galleries (available in this wsGallery installatipn)
// this is NOT called via a generated button.
// This must be called after .INIT on the wsgName
//    wsgName: the name for this wsGallery viewer

wsGallery.getGalleryList=function(wsgName,altCallback ) {

  if (arguments.length<2) altCallback=false;

  altCallback=wsGallery.getAltCallback(0,'getGalleryList',altCallback);

   if (typeof(wsgName)=='undefined'  || wsgName=='' || wsgName==0) wsgName='1'  ; //defautlt
   let params=wsGallery.getParams(wsgName);   // wsgName MUST be setup  by .init
   if (params===false) return false ;          // error message will be written by getOpts

   var ulClass=params['selectGalleryList_class'];

   let gdata={'todo':'galleryList' }  ;
   wsurvey.getJson.get('wsGallery_get.php',gdata,getGalleryList2,'getGalleryList' );     // use internal callback

   function getGalleryList2(response,origData) {

     let errors=[];
      var hideTreeList=0 ;
      let hh=wsurvey.getJson.check(response,0,'getGalleryList2') ;
      if (hh===false) return 1;
      let glist=hh['content'];

      let atime=wsurvey.get_currentTime(0);
      let ulId='wsGallery_galleries_'+atime;
      let amess='<ul data-wsgallery_id="'+ulId+'"   class="'+ulClass+'"> ';

      amess+='<li  ><em>Choose a gallery: </em> ';
      for (var j1 in glist) {
         let agallery=glist[j1];
         amess+=' <li><span class="wsGallery_notChosen"> ';
         amess+='   <input   class="wsGallery_button" type="button"  data-wsgname="'+wsgName+'" value="'+agallery+'" title="view trees/directories in this gallery" >';
         amess+='</span>';
      }
      amess+='</ul>';

      let ttList={};
      for (let m1=0;m1<glist.length;m1++) {
          let agg=glist[m1];
          ttList[agg]=1;
      }

      let eparentid;
      if (wsgName=='1') {
         eparentid=$(document);
      } else {
         eparentid=$('[data-wsgname_main="'+wsgName+'"]');
      }
      let stuff={'errors':errors,'what':'galleries','header':'','content':amess,'where':ulId,
                  'wsgName':wsgName,'list':ttList,'wsgJquery':eparentid};
      let afunc= (altCallback===false) ? wsGallery.getParams(wsgName,'callback'): altCallback ;
      afunc(stuff);

   }
}

//=================
// get list of trees in a gallery   -- called by clicking a "choose this gallery button"
// if button: athis is the evt argument.  agallery is the .val() of the button, wsgName is the data-wsgName attribute
// if 2 arg (direct call) : athis is an object which can have indices:
//      'gallery' to use (get its trees) (if not, 'main' is used)
//
// short cut (2 arg mode): if athis is astring, its value is used as the 'gallery'

wsGallery.getTreeList=function(athis,wsgName ) {
   let ethis,agallery,altCallback=false ;

   if (arguments.length<2) {
      ethis=wsurvey.argJquery(athis);
      if (!ethis.hasClass('wsGallery_button')) return false ; // something other than a button was clicked
      wsgName=ethis.attr('data-wsgName');
      agallery=ethis.val();
      wsGallery.highlightThisChoice(ethis);
   } else {              // 2 args
     if (typeof(wsgName)=='undefined' || wsgName=='' || wsgName==0) wsgName='1'  ; //defautlt
     if (typeof(athis)!=='object')  athis={'gallery':athis} ;  // assume a shortcut
     agallery= (athis.hasOwnProperty('gallery')) ? athis['gallery'] : 'main'   ;
     altCallback=wsGallery.getAltCallback(athis,'getTreeList');
  }

  if (typeof(wsgName)=='undefined' || wsgName=='' || wsgName==0) wsgName='1'  ; //defautlt
  let params=wsGallery.getParams(wsgName);   // wsgName MUST be setup  by .init
  if (params===false) return false ;          // error message will be written by getOpts
  var ulClass =params['selectTreeList_class'] ;

  let gdata ={'todo':'treeList','gallery':agallery }  ;    // get tress AND dirs in this tree (for use in next step)

  wsurvey.getJson.get('wsGallery_get.php',gdata,getTreeList2,'getTreeList');

 function getTreeList2(response,origData) {
      var hh,hideTreeList=0,sayErr='',errors=[],amess='';
      hh=wsurvey.getJson.check(response,0,'getTreeList2') ;

     if (hh===false) return 1;
     errors=hh['content']['errors'];

     wsGallery.setParam(wsgName,'treeList',hh['content']);     // used by wsGallery.getDirList

     let atime=wsurvey.get_currentTime(0);
     let ulId='wsGallery_trees_'+atime;
     amess+='<ul data-wsgallery_id="'+ulId+'"   class="'+ulClass+'"> ';

     let ttList={};
     for (let bbtree in  hh['content']['status']) {
         let bbVal= hh['content']['status'][bbtree];
         let adesc=bbVal['desc'];
         let ndirs =(typeof(bbVal['dirList'])=='undefined') ? 0 : bbVal['dirList'].length;
         ttList[bbtree]={'desc':adesc,'nDirs':ndirs};
     }

     let treeStatus=hh['content']['status'];
     for (var atree in hh['content']['trees']) {
        if (typeof(treeStatus[atree])!=='undefined') {
            let tt1=treeStatus[atree];
            let tt1Desc=tt1['desc'];
            let tt1Ndirs=tt1['dirList'].length;
            let atitle='Click to view  '+tt1Ndirs+'  dirs in this tree :: '+tt1Desc
            amess+='<li> <input  class="wsGallery_button" type="button" title="'+atitle+'" data-wsgName="'+wsgName+'" data-gallery="'+agallery+'" value="'+atree+'">  ';

        } else {   // no info available
           amess+='<li> <input  class="wsGallery_button" type="button" title="Click to list directories in this tree"  data-wsgName="'+wsgName+'" data-gallery="'+agallery+'" value="'+atree+'">  ';
        }
      }
      amess+='</ul>';
      let aheader='<span title="choose tree in gallery: '+agallery+'"><em>Choose a tree:</em></span>';

      let eparentid;
      if (wsgName=='1') {
          eparentid=$(document);
      } else {
          eparentid=$('[data-wsgname_main="'+wsgName+'"]');
      }
      let stuff={'what':'trees','errors':errors,'where':ulId,'content':amess,'header':aheader,
             'wsgName':wsgName,'list':ttList,'wsgJquery':eparentid};
      let afunc= (altCallback===false) ? wsGallery.getParams(wsgName,'callback') : altCallback ;
      afunc(stuff);

      return 1;

 }  //  getTreeList2 end

}  // wsGallery.getTreeList

//==========
// list of dirs in chosen tree  -- called by clicking on a " view this tree" button
// if 2 args, athis object should include gallery and tree (defaults used otherwise)

wsGallery.getDirList=function(athis,wsgName) {
   var   ethis, agallery,atree ;
   var errors=[],altCallback=false ;
   var altDesc,listClass,descC2 ;

   if (arguments.length<2) {
      ethis=wsurvey.argJquery(athis);
      if (!ethis.hasClass('wsGallery_button')) return false ; // something other than a button was clicked
      wsgName=ethis.attr('data-wsgName');
      if (typeof(wsgName)=='undefined' || wsgName=='' || wsgName==0) wsgName='1'  ; //defautlt
      atree=ethis.val();
      agallery=ethis.attr('data-gallery');
      wsGallery.highlightThisChoice(ethis);
   } else {              // 2 args
      if (typeof(wsgName)=='undefined'  || wsgName=='' || wsgName==0) wsgName='1'  ; //defautlt
      if (typeof(athis)!=='object')  athis={} ;  // assume a shortcut
      agallery= (athis.hasOwnProperty('gallery')) ? athis['gallery'] : 'main'   ;
      atree= (athis.hasOwnProperty('tree')) ? athis['tree'] : '_default'   ;
      altCallback=wsGallery.getAltCallback(athis,'getDirList');
   }

   let params=wsGallery.getParams(wsgName);   // wsgName MUST be setup  by .init
   if (params===false) {
      alert('getDirList: no params for wsgName '+wsgName);
      return false ;          // error message will be written by getOpts
   }
   altDesc= params['altDirDescs']     ;
   listClass=  params['selectDirList_class']  ;
   descC2= params['descClass_inListSmall']  ;

   let tlist=wsGallery.getParams(wsgName,'treeList',1);

   if (tlist===false)  {   // doesn't exist yet... try to make it
      let gdata ={'todo':'treeList','gallery':agallery }  ;    // get tress AND dirs in this tree (for use in next step)
      wsurvey.getJson.get('wsGallery_get.php',gdata,getDirList_makeTree,'getTreeList no tree');
       return 1;
  }

   getDirList_step2(tlist['trees'][atree],0) ;
   return 1;


 // -------
 // got parameters... so make the dir list
 // mode=0: tree list exists, 1 = tree list was created
   function getDirList_step2(useTree,mode) {   // create the list, and return using callback

     let amess='',aheader='';
     let atime=wsurvey.get_currentTime(0);
     let ulId='wsGallery_dirs_'+atime;

     amess+='<ul data-wsgallery_id="'+ulId+'" class="'+listClass+'"> ';  // ulclass controls display

     for (var adir in useTree) {
        amess+='<li   >';
        let nfiles=useTree[adir]['nFiles'];
        amess+='<input  class="wsGallery_button" type="button"  value="'+adir+'" data-gallery="'+agallery+'"  data-tree="'+atree+'" ';
        amess+='     data-wsgName="'+wsgName+'"  title="Click to view '+nfiles+' images (and other files) in this dir"  >';

      let dirDesc=(altDesc.hasOwnProperty(adir)) ? altDesc[adir] :   useTree[adir]['desc'] ;
      amess+='<span  class="'+descC2+'" >'+dirDesc+'</span>';
     }
     amess+='</ul>';
     aheader='<span style="font-style:oblique" title="directories in  tree ..." >Dirs: '+atree+'</span>';

     let eparentid;
     if (wsgName=='1') {
          eparentid=$(document);
     } else {
          eparentid=$('[data-wsgname_main="'+wsgName+'"]');
     }
     let stuff={'what':'dirs','errors':errors,'header':aheader,'content':amess,'where':ulId,
        'wsgName':wsgName,'list':useTree,'wsgJquery':eparentid};
     let afunc= (altCallback===false) ? wsGallery.getParams(wsgName,'callback') : altCallback;
     afunc(stuff);

     return 1;
 }     // getDirList_step2

 // -------
  function getDirList_makeTree(response,origData) {      // call this to try to make tree list, and the do dirlist

     let hhb=wsurvey.getJson.check(response,0,'getDirList_makeTree') ;
     if (hhb===false) return 1;
     let errorsb=hhb['content']['errors'];
     if (typeof(errorsb)!='undefined' && errorsb.length>0) {
        wsurvey.dumpObj(errorsb,1,'getTreeList2b errors');
        return 1;
     }
     tlist=hhb['content'];
     wsGallery.setParam(wsgName,'treeList',tlist);

     getDirList_step2(tlist['trees'][atree],1) ;
    return 1;
  }     // getDirList_makeTree

}     // wsGallery.getDirList

//==========   data-
// list of files  in chosen dir   -- called after clicking "get files in this dir" button
// if 2 args, athis object should include gallery and tree (defaults used otherwise); and MUST include dir

wsGallery.getFileList=function(athis,wsgName ) {
  var agallery,atree,adir,params,ethis,toget=['desc','uriSel' ];
  var altCallback=false ;

  if (arguments.length<2) {
      ethis=wsurvey.argJquery(athis);
      if (!ethis.hasClass('wsGallery_button')) return false ; // something other than a button was clicked
      wsgName=ethis.attr('data-wsgName');
      if (typeof(wsgName)=='undefined'  || wsgName=='' || wsgName==0) wsgName='1'  ; //defautlt
      adir=ethis.val();
      atree=ethis.attr('data-tree');
      agallery=ethis.attr('data-gallery');
      wsGallery.highlightThisChoice(ethis);
   } else {              // 2 args
     if (typeof(wsgName)=='undefined'  || wsgName=='' || wsgName==0) wsgName='1'  ; //defautlt
     if (typeof(athis)!=='object')  athis={} ;  // assume a shortcut
     agallery= (athis.hasOwnProperty('gallery')) ? athis['gallery'] : 'main'   ;
     atree= (athis.hasOwnProperty('tree')) ? athis['tree'] : '_default'   ;
     adir= (athis.hasOwnProperty('dir')) ? athis['dir'] : false   ;
     toget=(athis.hasOwnProperty('toget')) ? athis['toget'] : ['desc','uriSel' ]   ;
     if (toget===false || toget==0 || jQuery.trim(toget)=='') toget=['desc','uriSel' ]   ;
     if (typeof(toget)=='string' && jQuery.trim(toget)=='*') {
         toget=['desc','uriSel','name','uriSel','mimetype',
              'height','width','size','date','link','linkHandler','linkNoDim',
              'snapshot','thmSmall','thmMedium','thmLarge'];
     }
     altCallback=wsGallery.getAltCallback(athis,'getFileList');
   }

   if (adir===false || adir==0 || adir=='' ) {
     alert('getFileList: dir not specified');
     return false ;
   }

   params=wsGallery.getParams(wsgName);   // wsgName MUST be setup  by .init
   if (params===false) return false ;          // error message will be written by getOpts
   var fileDescs=params['altFileDescs']  ;
   var descC2=params['descClass_inList']   ;
   var selectFileClass=params['selectFileList_class']   ;
   var doshowDesc=params['showDesc']  ;
   var showThumb=params['showThumbnail'] ;
   var fileViewHeight=params['fileViewHeight'] ;
   var fileViewWidth=params['fileViewWidth']  ;
   let gdata={'todo':'list','tree':atree,'dir':adir,'gallery':agallery,'extras':'*','height':fileViewHeight,'width':fileViewWidth}  ;
   wsurvey.getJson.get('wsGallery_get.php',gdata,getFileList2,'getFileList');

 function getFileList2(response,origData) {
    var hideTreeList=0,errors=[];
    let hh=wsurvey.getJson.check(response,0,'getFileList2') ;
    if (hh===false) return 1;
    let errs=hh['content']['errors'];
    if (errs.length>0)    wsurvey.dumpObj(errs,1,'Errors!');
    let files=hh['content']['files'];
    wsGallery.setParam(wsgName,'fileList',files);
    getFileList2_step2(files,0)

 }
 //----------
 // create the ul of files
 function getFileList2_step2(doFiles,mode) {
    let errors=[];
    let atime=wsurvey.get_currentTime(0);
    let ulId='wsGallery_files_'+atime;

    let amess='';
    amess+='<ul  data-wsgallery_id="'+ulId+'"  name="wsGallery_getFilesInDir" class="'+selectFileClass+'"> ';  // select file class controls display

    for (var nth in doFiles) {
       let bfile=doFiles[nth];
       let filename=bfile['name'];
       fileDesc=wsGallery.makeFileDesc(bfile,0,doshowDesc,fileDescs) ;
       let dathumb='';
       if (showThumb=='small') {
          dathumb= (bfile.hasOwnProperty('thmSmall')) ? bfile['thmSmall'] : '' ;
       } else if (showThumb=='medium') {
          dathumb= (bfile.hasOwnProperty('thmMedium')) ? bfile['thmMedium'] : '' ;
       } else if (showThumb=='large') {
          dathumb= (bfile.hasOwnProperty('thmLarge')) ? bfile['thmLarge'] : '' ;
       }
       amess+='<li >';
       amess+='<table ><tr valign="top">';
       amess+='<td valign="top"><span style="font-size:80%;font-family:Courier, monospace">'+nth+'</span> ';
       amess+=dathumb+' ';
       amess+='</td><td>';
       amess+='<td>';
       amess+='<input  class="wsGallery_button" type="button"  data-nth="'+nth+'" value="'+filename+'" ';
       amess+='      data-wsgName="'+wsgName+'"  title="Click to view this file"   >';
       if (doshowDesc!=0) {
          amess+='<div class="'+descC2+'" > '+fileDesc+'</div>';
       } else {
          amess+='<div class="'+descC2+'" style="display:none" > '+fileDesc+'</div>';
       }
       amess+='</td></tr></table>';
    }
   amess+='</ul>';
   let asay='<span name="fileListHeader"  title="the files in this directory ...">';
     asay+='<span name="fileListHeaderSay"  style="font-style:oblique" >Files: '+adir+'</span>' ;
     asay+='<span name="fileListHeaderSayButtons">';
       asay+=' &nbsp;&nbsp;&nbsp; <input class="wsGallery_actionButton"  draggable="false" type="button" style="font-size:80%;color:brown" value="&larr;" title="View prior image" onClick="wsGallery.viewPriorImage(this,-1)"> ';
       asay+=' &nbsp;<input class="wsGallery_actionButton"  type="button"  draggable="false"  style="font-size:80%;color:brown" value="&rarr;" title="View next image" onClick="wsGallery.viewPriorImage(this,1)"> ';
     asay+='</span>'
   asay+='</span>'
   let ttList={};

   for (let mm=0;mm<doFiles.length;mm++) {
      let aDoFile=doFiles[mm];
      let att={};
      att['nth']=mm;
      let aname=aDoFile['name'];
      for (let k3=0;k3<toget.length;k3++) {
         let ak3=toget[k3];
         if (typeof(aDoFile[ak3])=='undefined') continue ;
         att[ak3]=aDoFile[ak3];
      }
      ttList[aname]=att ;
   }

   let eparentid;
   if (wsgName=='1') {
          eparentid=$(document);
   } else {
          eparentid=$('[data-wsgname_main="'+wsgName+'"]');
   }
   var stuff2={'what':'files','errors':errors,'header':asay,'content':amess,'where':ulId,
          'wsgName':wsgName,'list':ttList,'wsgJquery':eparentid};
   afunc= (altCallback===false) ? wsGallery.getParams(wsgName,'callback') : altCallback ;
   afunc(stuff2);

   return 1;

 }     // getFileList2_step2

}

//================== stuff
// view chosen file  -- called by clcking a "view this file" button

wsGallery.viewAFile=function(athis,wsgName) {
  var  params,ethis,nth,errors=[],doFile;
  var agallery,adir,atree ;
  var altCallback=false ;

   if (arguments.length<2) {
      ethis=wsurvey.argJquery(athis);
      if (!ethis.hasClass('wsGallery_button')) return false ; // something other than a button was clicked
      wsgName=ethis.attr('data-wsgName');
      if (typeof(wsgName)=='undefined'  || wsgName=='' || wsgName==0) wsgName='1'  ; //defautlt

      nth=ethis.attr('data-nth');

      wsGallery.highlightThisChoice(ethis);

   } else {              // 2 args
   
       agallery= (athis.hasOwnProperty('gallery')) ? athis['gallery'] : false   ;  // not used if fileList exists
       atree= (athis.hasOwnProperty('tree')) ? athis['tree'] : false   ;
       adir= (athis.hasOwnProperty('dir')) ? athis['dir'] : false   ;

      nth= (athis.hasOwnProperty('nth')) ? athis['nth'] : false   ;
      doFile=(athis.hasOwnProperty('file')) ? athis['file'] : false   ; // used if nth not specified
      altCallback=wsGallery.getAltCallback(athis,'viewAFile');

      if (typeof(wsgName)=='undefined'  || wsgName=='' || wsgName==0) wsgName='1'  ; //defautlt
      if (typeof(athis)!=='object')  athis={} ;  // assume a shortcut
      if (nth===false || jQuery.trim(nth)=='' ) {
        if (doFile===false) {
           alert('viewAFile: neither nth, or file, is specified');
           return false ;
        }
      }
   }

   params=wsGallery.getParams(wsgName);   // wsgName MUST be setup  by .init
   if (params===false) return false ;          // error message will be written by getParams

   let fileDescs=params['altFileDescs']  ;
   let descC1=params['descClass_viewer']   ;
   let doshowExternal=params['showExternal']   ;
   let doshowFull=params['showFull']  ;
   let doshowDesc=params['showDesc']   ;

   let fstuff0=wsGallery.getParams(wsgName,'fileList',1);
   if (fstuff0===false) {
      let fileViewHeight=params['fileViewHeight']   ;
      let fileViewWidth=params['fileViewWidth']   ;
      if (agallery===false || atree===false || adir===false) {
          alert('viewAFile error: direct call requires specifiying gallery, tree, and dir ');
          return 1;
      }
      let gdata={'todo':'list','tree':atree,'dir':adir,'gallery':agallery,'extras':'*',
               'height':fileViewHeight,'width':fileViewWidth}  ;
      wsurvey.getJson.get('wsGallery_get.php',gdata,viewAFile_makeList,'viewaFile 2');
      return 1;
   }

// else, got a fileList (from prior call?)

   viewAFile_step2(fstuff0);
   return 1;

//====
// create the element for viewing a file
 function viewAFile_step2(fstuff)  {
  let errors=[];
  if (nth===false) {                    // find doFile
    for (let j1=0;j1<fstuff.length;j1++) {
        let af=fstuff[j1];
        aname=af['name'];
        if (aname==doFile) {
           nth=j1;
           break;
        }
    }
    if (nth===false) {
       alert('No such file: '+doFile+' in  '+agallery+'/'+atree+'/'+adir);
       return 0;
    }
  }
  if (typeof(fstuff[nth])=='undefined') {
       alert('No such file number: '+nth+' in  '+agallery+'/'+atree+'/'+adir);
       return 0;
  }
   let thisFile=fstuff[nth];

   let uriSel=thisFile['uriSel'];
   let alink=thisFile['link'];
   let iheight=thisFile['height'];
   let iwidth=thisFile['width'];
   let alinkHandler=thisFile['linkHandler'];

   let alinkFull=thisFile['linkNoDim'];;        // no dimention version
   let fname=thisFile['name'];                 // typically matches value of button, but not necessarily
   if (thisFile['height']!='') {  // an image -- display the snapshot if available.
      if (typeof(thisFile['snapshot'])!='undefined' && thisFile['snapshot']!='') {  // snapshot exists
         alink=thisFile['snapshot'];
      }
   }
   let amess='<div data-nth="'+nth+'" title="for file: '+thisFile['name']+'">';

   amess+= '<div  name="showTheFile"  >'+alink+'</div></div>';

   let asay='';
   if (doshowExternal!=0) {         // view in extenral window button
      asay+=' <input class="wsGallery_actionButton"  type="button" value="&neArr;" data-which="external" ';
      asay+='     title="display in external window"  onclick="wsGallery.displayExternalWindow(this,'+doshowDesc+')"  ';
      let alinkEnc=encodeURI(alinkFull);      // not the snapshot
      asay+= ' data-link="'+alinkEnc+'" ' ;
      let aFileEnc=encodeURI(fname);
      asay+= ' data-file="'+aFileEnc+'" ' ;
      let urilSelEnc=encodeURI(uriSel);
      asay+= ' data-urisel="'+urilSelEnc+'" ' ;

      asay+='>   ';
   }

   if (doshowFull!=0) {     // toggle full screen button
      asay+=' <input class="wsGallery_actionButton"  type="button" value="&#11036;"  ';
      asay+='   title="toggle full screen (display full image)"  ';
      let aFileEnc=encodeURI(fname);
      asay+= ' data-file="'+aFileEnc+'" ' ;

      let alinkEnc=encodeURI(alinkFull);      // show the full image (not a snapshot)
       asay+= ' data-link="'+alinkEnc+'" ' ;
       asay+='  data-width="'+iwidth+'"  data-height="'+iheight+'" ';
      let urilSelEnc=encodeURI(uriSel);
      asay+= ' data-urisel="'+urilSelEnc+'" ' ;
      asay+=' data-handler="'+alinkHandler+'" ' ;
      asay+= ' name="fullScreenToggler"  onclick="wsGallery.toggleFullscreen(this )"    >   ';

   }

   asay+='<span id="viewColHeaderDesc" > Viewing <span title="'+thisFile['mimetype']+' @ '+thisFile['uriSel']+'" style="font-family:monospace">'+fname+'</span> ';
    let afileDesc=wsGallery.makeFileDesc(thisFile,1,doshowDesc,fileDescs);
    if (doshowDesc!=0) {
     asay+='<span title="Description" class="'+descC1+'"  >'+afileDesc+'</span>';
   } else {
     asay+='<span title="Description" class="'+descC1+'" style="display:none" >'+afileDesc+'</span>';
   }
   asay+='</span>' ;

   let eparentid;
   if (wsgName=='1') {
          eparentid=$(document);
   } else {
          eparentid=$('[data-wsgname_main="'+wsgName+'"]');
   }
   var stuff2={'what':'viewFile','errors':errors,'header':asay,'content':amess,'where':'',
           'wsgName':wsgName,'list':thisFile,'wsgJquery':eparentid};
   afunc=(altCallback===false) ? wsGallery.getParams(wsgName,'callback') : altCallback;
   afunc(stuff2);

   return 1;
 }  // viewAfile_step2

// =======
// filelist created
  function viewAFile_makeList(response,origData) {      // call this to try to make tree list, and the do dirlist

     let hhb=wsurvey.getJson.check(response,0,'viewAFile_makeList') ;
     if (hhb===false) return 1;
     let errorsb=hhb['content']['errors'];
     if (typeof(errorsb)!='undefined' && errorsb.length>0) {
        wsurvey.dumpObj(errorsb,1,'viewAFile_makeList errors');
        return 1;
     }

   let files=hhb['content']['files'];
   wsGallery.setParam(wsgName,'fileList',files);

   viewAFile_step2(files,1)   ;
    return 1;
 }       // viewAFile_makeList

}     // viewAfile


// ==============
// helper functions
// These are mostly used in 'semi-automatic' display of menus and the file viewer.
// An ambitious programmer could use several of these as templates, but be aware that they are designed
// to work with "buttons" created by the semi-automatic mode of the primary wsGallery_get.js funcionts
//
// Note that  some of these do NOT need to be public... maybe fix that later
// =================

//===========
// display in external window
// This is used as a click handler in  buttons included in the output generated by wsGallery.viewAFile
// (assuming that showExternal=1).
// The button clicked on must have several data-xxx attributes, which this function uses to determine
// what file to display "in an external window (or tab)"
// Note that is uses the wsurvey.util1.js function: wsurvey.displayInNewWindow

wsGallery.displayExternalWindow=function(athis,doshowDesc) {

  let adesc=$('#viewColHeaderDesc').html();

  let ethis=wsurvey.argJquery(athis);

  let afile=ethis.attr('data-file');
  afile=decodeURI(afile);

  let alink=ethis.attr('data-link');
  alink=decodeURI(alink);

  let uriSel=ethis.attr('data-urisel');
  uriSel=decodeURI(uriSel);

  let aclose='<input class="wsGallery_actionButton"  type="button" value="x" title="close this window" onClick="window.close()" >';
  if (doshowDesc>1) adesc=wsurvey.removeAllTags(adesc);
  let afileLink='<a href="'+uriSel+'" title="Open using original link. This may cause a file download (for files that the browser can not display) ">'+afile+'</a>';
  wsurvey.displayInNewWindow(0,{'content':alink,'name':'externalViewer','header':aclose+' <tt>'+afileLink+'</tt>: <em>'+adesc+'</em><br>'});

}

//===========
// toggle in and out of full screen
// This is used as a click handler in  buttons included in the output generated by wsGallery.viewAFile
// (assuming that showExternal=1).
// The button clicked on must have several data-xxx attributes, which this function uses to determine
// what file to display "in an external window (or tab)". And to implement several control buttons are
// also written to the full screen display.
// Notes:
//  * a mild hack is used -- a temporary element is created that displays the "full image", and this
//   container is then show in "full screen mode". When full screen exits, this temporary element is removed
//   * the image viewed in the file viewer is often smaller (typicall a 640x480 snapshot)
//   * uses the requestFullscreen javascript function
//
//===============
// toggle in and out of full screen
wsGallery.toggleFullscreen=function(athis,doexit) {
  if (arguments.length<2) doexit=0;

  if (doexit!==0) {               // speical call: exit full screen AND remove temp element
    if (document.fullscreenElement){
       document.exitFullscreen() ;
    }
    $('#'+doexit).remove();
    return 1;
  }

  let ethis=wsurvey.argJquery(athis);

  let afile=ethis.attr('data-file');
  afile=decodeURI(afile);

  let alink=ethis.attr('data-link');
  alink=decodeURI(alink);

  let uriSel=ethis.attr('data-urisel');
  uriSel=decodeURI(uriSel);

  let dwidth=parseInt(ethis.attr('data-width'));
  let dheight=parseInt(ethis.attr('data-height'));  // non-zero for images
  let ahandler=ethis.attr('data-handler');

// resize a video link

  let atime=wsurvey.get_currentTime(0);
  let ulId='wsGallery_temp_'+atime;

  let aremove='<input type="button" value="x" title="return..."  onclick="wsGallery.toggleFullscreen(0,\''+ulId+'\')">\n ';
  if (ahandler=='img') {    // full sizer button
     aremove+='<input type="button"   value="&#119978;" style="color:green;font-weight:900" title="reset to actual image size ('+dwidth+'x'+dheight+')"  ';
     aremove+=' onClick="wsGallery.toggleFullscreenResize(this) " data-where="'+ulId+'" >';
   }
   aremove+='  &nbsp; <input class="wsGallery_actionButton"  draggable="false" type="button" style="font-size:80%;color:brown" value="&larr;" title="View prior image" onClick="wsGallery.viewPriorImage(this,-1,1)"> ';
   aremove+=' &nbsp;<input class="wsGallery_actionButton"  type="button"  draggable="false"  style="font-size:80%;color:brown" value="&rarr;" title="View next image" onClick="wsGallery.viewPriorImage(this,1,1)"> ';

   let tmp1='\n\n<div id="'+ulId+'"> <br /> \n';
   tmp1+='<div style="background-color:white;margin:1em">'+aremove+' For file:<tt>'+afile+'</tt></div> <hr>\n';
   tmp1+='<div style="width:85%;height:85%;overflow:auto;padding:5px 1em 5px 2em;margin:4em 5px 5px 1em">' +alink+'</div> \n';
   tmp1+='</div>';
   $('body').append(tmp1);


// try to resize the temp version

   let goo=$('#'+ulId);
   let elem = document.querySelector('#'+ulId);
   $('#'+ulId).on('fullscreenchange',doingFullScreen);

   window.setTimeout(function() {             // give dom a moment to settle down (writing image to temp area)
     if (ahandler=='video') {             // tweak a video
       let goo2=goo.find('video');
       if (goo2.length>0) {
         let goo3=goo2[0];
         let aw=goo3.videoWidth;
         let ah=goo3.videoHeight;
         if (!isNaN(aw) && !isNaN(ah) ) {
           goo2.attr('width',aw);
           goo2.attr('height',ah) ;
         }
       }
     }
     if (ahandler=='object') {        // tweak an object (with embed). ypicall No intrinsic size, so just fill screen
       let goo2=goo.find('object');
       if (goo2.length>0) {     // original is a video -- resize the temp
          goo2.attr('width','90%');
          goo2.attr('height','90%') ;
       }
     }
     if (ahandler=='iframe') {        // tweak an iframe. Typicall No intrinsic size, so just fill screen
        let goo2=goo.find('iframe');
        if (goo2.length>0) {     // resize the temp
           goo2.attr('width','90%');
           goo2.attr('height','90%') ;
           goo2.css({'background-color':'white'});     // seems to help with text etc
        }
     }

     if (ahandler=='img' && dwidth>0 && dheight>0) {        // stretch to fill
        let goo2=goo.find('img');
        if (goo2.length>0) {
          let ascH=screen.availHeight, ascW=screen.availWidth  ;  // screen size
          if (!isNaN(ascW)  && !isNaN(ascH) && !isNaN(dwidth) && !isNaN(dheight) ) {
             let hratio=ascH/dheight;
             let wratio=ascW/dwidth;
             let ratio=Math.min(hratio,wratio);
             let useWidth=parseInt(0.85*dwidth*ratio) ;
             let useHeight=parseInt(0.85*dheight*ratio) ;
             goo2.attr('width',useWidth);
             goo2.attr('height',useHeight) ;
          }
        }
     }

    // now fullScreen this temp version
     if (!document.fullscreenElement) {
       let aopt={navigationUI:'show'};
       var apromise=elem.requestFullscreen();
       apromise
         .catch(err => {
            alert(`Error attempting to enable fullscreen mode: ${err.message} (${err.name})`);
        })
        .then(function() {
         //  alert('Success on fullscreen: '+aw+','+ah);
        });

     } else {
       document.exitFullscreen()  ;
     }

   },200);

  function doingFullScreen(evt) {
    let ethis=wsurvey.argJquery(evt);
    if (document.fullscreenElement) {
    } else {
      let aid=ethis.attr("id") ;
      wsGallery.toggleFullscreen(0,aid) ; // remove temp image
    }
  }  // doingfullscrren

}     // toggleFullscreen

//=====================
// reset 'full screen image (fit to full screen)' to original size (rather than size of full screen)
// wsGallery.toggleFullScreen creates elements that include inline calls to this function

wsGallery.toggleFullscreenResize=function(athis) {
   let ethis=wsurvey.argJquery(athis);
   let ulId=ethis.attr('data-where');
   let e1=$('#'+ulId);
   let e2=e1.find('img');
   let dwidth=e2.attr('data-width');
   let dheight=e2.attr('data-height');

   e2.attr('width',dwidth);
   e2.attr("height",dheight);
}


//===============
// view next or prior image
// note use of wsGallery_get -- to find outer container (ancestor of athis) ent that holds the various menu area
//  and wsGallery_getFilesInDir to find menu of files in this "outer container"

wsGallery.viewPriorImage=function(athis,idire,isfull) {
  if (arguments.length<3) isfull=0;
  let ethis=wsurvey.argJquery(athis);

// find "closest" sibling that is wsGallery_getFilesInDir
   let  e1=wsurvey.findRelative(ethis,'[name="wsGallery_getFilesInDir"]');
   if (e1===false) {
      alert('Unable to find  wsGallery_getFilesInDir (list of files) ') ;
      return false;
   }


  let e2=e1.find('.wsGallery_chosen');
  let nth=-1;
  if (e2.length!=0) {
       nth=parseInt(e2.attr('data-nth'));
  }

  nth=nth+idire;
  nth=Math.max(0,nth);
  let e3=e1.find('[data-nth="'+nth+'"]');
  if (e3.length>0) e3.trigger('click');
  if (isfull==1) {
    if (document.fullscreenElement)  document.exitFullscreen() ;
    window.setTimeout(function() {
       let zz=$('[name="fullScreenToggler"]');
       if (zz.length==1){
         console.log('fullscreen of '+nth);
         zz.trigger('click');
       } else {
         console.log('unable to full screen '+nth);
       }
    },100);
  }

}

//===========
// return file description.
// opts:
//  0: return desc. If empty, return a span with creation date, and wxh as ttile
//  1 : return decs AND creattion data,  wxh
wsGallery.makeFileDesc=function(bfile,opts,showDesc,useFileDescs) {
    let fname=bfile['name'];
    let filedesc = (useFileDescs.hasOwnProperty(fname)) ? useFileDescs[fname] :   bfile['desc'];
    if (showDesc>1) {
       let origlength=filedesc.length;
       filedesc=wsurvey.removeAllTags(filedesc);
       filedesc=filedesc.substr(0,showDesc);
       if (filedesc.length<origlength) filedesc+=' &hellip; ';
    }

    fileDesc=jQuery.trim(filedesc);
    let mdate=bfile['date'];
    let mdateSay=wsurvey.get_currentTime(31,1,mdate*1000);
    let awidth=bfile['width'];
    let aheight=bfile['height'];
    let fbytes=parseInt(bfile['size']/1000);

    if (opts==0) {
        let adim='File size: '+fbytes+'k ' ;
        if (awidth!='' && aheight!='') adim+=' ::  '+awidth+'x'+aheight;
        filedesc+='<span style="border-bottom:1px dashed blue" title="'+adim+'">'+mdateSay+'</span>';
    }

    if (opts==1) {
        let adim='<span title="no dimensions available. File size .. ">'+fbytes+'k </span> ' ;
        if (awidth!='' && aheight!='')  {
            adim='<span title="W x H (in pixels). File size '+fbytes+'k ">'+awidth+'x'+aheight+'</span> ' ;
        }
        filedesc+=mdateSay+' <em>'+adim+'</em>';
    }
   return filedesc;
}




//==============
// simulate click for a class="wsGallery_button" with value="awhat" in the container with data-wsgallery_id=awhere
// 3rd arg can be used if something other than 'click' is the event to invoke
// 4th arg can be used if something other than 'value' (attribute) is to be examined.
// return false if a matching elment found (and was "clicked"). False if no such element found
wsGallery.click=function(awhere,awhat,anevent,useAttr) {
   if (jQuery.trim(awhere)=='' || jQuery.trim(awhat)=='') return false ;  // nothing to search for
   if (arguments.length<3) anevent='click';
   if (arguments.length<4) useAttr='value';
   let e1=$('[data-wsgallery_id="'+awhere+'"]');
   let e2=e1.find('.wsGallery_button');
   if (e2.length==0) return false;
   e3=e2.filter('['+useAttr+'="'+awhat+'"]');
   if (e3.length==0) return false;
   window.setTimeout(function() {
      e3.trigger(anevent);
   },100);
   return true ;
}


//==============
// highlight clicked on input (in a <ul><li>....
wsGallery.highlightThisChoice=function(ethis) {
  ethis=wsurvey.argJquery(ethis);  // might be redundant.
   let eul=ethis.closest('ul');
   let ebuttons=eul.find('input');
   ebuttons.removeClass('wsGallery_chosen');
   ethis.addClass('wsGallery_chosen');
}

//===========
// check  callback in arghuments list (2 arg mode to getxxx functions)
// return false if doesn't exist
// alert if specified but not such function
// return function pointer if does exist
wsGallery.getAltCallback=function(athis1,awhere,altDirect) {
  let altCallback1;
  if (arguments.length==3) {
     altCallback1=altDirect;
  } else {
     altCallback1=(athis1.hasOwnProperty('callback')) ? athis1['callback'] : false   ;
  }
  if (altCallback1===false) return false;
  if (typeof(altCallback1)=='string') {
     if (typeof(window[altCallback1])!='function') {
        alert('callback ('+altCallback1+'), in call to '+awhere+', is not a function');
        return false;
     } else {
       return window[altCallback1];
     }
  }
  if (typeof(altCallback1)!='function') {
        alert('callback, in '+awhere+', is not a function');
        return false;
  } else {
    return  altCallback1;
  }

}

