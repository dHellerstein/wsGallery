<?php
// favorites -- is sent a locally saved favorites list, sends it back to client
  $curdir=getcwd();
  $curdir1=pathinfo($curdir, PATHINFO_DIRNAME);

     require_once("$curdir1/libs/php/wsurvey.uploadFiles.php");
      $fileList=wsurvey\uploadFiles\retrieve(1);
     // var_dump($fileList);exit;
      $a=json_encode($fileList);
      print  $a;
      exit;
?>