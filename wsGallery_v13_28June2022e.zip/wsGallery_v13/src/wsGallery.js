// for wsGallery

//========================
// init (onload)
function init() {

// note: use defaults
//        do NOT disable for: noCloser ,noHider,noRestoreSize,noTips,noZindexButton
//        do NOT enable for :  contentHistory_enable
//        do enable for: expandBox
// viewer box 1

  let wasErr=$(document).data('wasErr')

  let pupdate=$(document).data('paramUpdateNeeded')   ;
  if (pupdate==1)  {                                  // parameter update needed -- admin logon required
      wsurvey.getJson.prePend='src/';         // prepend this to all getJson.get() urls
      eAdm=wsurvey.flContent.create('admin',{
            'top':'6%','left':'4%','width':'53%','height':'73%','zIndex':233,
               'escapeOrder':'z','enableOnTop':'*','moveIcon':'&#9995;','classMain':'1 .SHADOW',
             'headerCloser':'&chi;,Close this admin window!',
             'headerP':'Admin',
             'callFunc':0});
     let amess='';
     amess+='<input id="logonButton_fix2" type="button" id="logonButton" value="Logon" title="Admin logon">';
     amess+='  ... you must logon to fix the following wsGallery parameters error: <tt>'+wasErr+'</tt>' ;
     wsurvey.flContents.contents('admin',amess);
     eAdm.wsFlContents(amess);

     let dd={'logonName':'wsGallery','whenCall':0,'pwd':'','callbackLogon':'wsGallery_logonCallback_params','todo':'fix'  };
     $('#logonButton_fix2').on('click',dd,wsurvey.adminLogon);

     return 0;
  }

// parameters okay. Spinners okay?

  let spinnerError=$(document).data('spinnerError')   ;
  if (spinnerError==1)  {                                  // spinnerE update needed -- admin logon required
      wsurvey.getJson.prePend='src/';         // prepend this to all getJson.get() urls
      eAdm=wsurvey.flContent.create('admin',{
            'top':'6%','left':'4%','width':'53%','height':'73%','zIndex':233,
               'escapeOrder':'z','enableOnTop':'*','moveIcon':'&#9995;','classMain':'1 .SHADOW',
             'headerCloser':'&chi;,Close this admin window!',
             'headerP':'Admin',
             'callFunc':0});
     let amess='';
     amess+='<input id="logonButton_fix3" type="button" id="logonButton" value="Logon" title="Admin logon">';
     amess+='  ... you must logon to fix the following wsGallery spinners error: <tt>'+wasErr+'</tt>' ;
     wsurvey.flContents.contents('admin',amess);
     eAdm.wsFlContents(amess);

     let dd={'logonName':'wsGallery','whenCall':0,'pwd':'','callbackLogon':'wsGallery_logonCallback_spinners','todo':'fix'  };
     $('#logonButton_fix3').on('click',dd,wsurvey.adminLogon);

      return 0;
 }



  let lockme=$(document).data('wsGallery_lockme');
  let requireLockme=$(document).data('requireLockme');


// admin logon required (for treelist init)
  let adminLogonRequired=$(document).data('adminLogonRequired');
  if  (adminLogonRequired!=1)  {              // logon not required (to fix treelists)? If rquired, deal with it bdlow
     if (wasErr!=='')  alert("Note: a problem was resolved: \n "+wasErr);
     if (lockme==0 && requireLockme==1) {                              // no lockme -- verify that you want to continue with this setup
        let qq=confirm('wsGallery warning: the data/lockme.txt file does not exist.  Are you sure you want to continue (and initialize cache directories)');
        if (qq===false) return 1;
        alert('Note to administrator: you should reenable data/lockme.txt!');
     }
   }

   let vv1=$(document).data('wsGallery_version');

   let ewgh1=$('#wsGallery_header1');
   ewgh1.attr('title','wsGallery verson: '+vv1);
   let ewgh1A=$('#wsGallery_header1A');
   let mainTitle=$(document).data('mainTitle');
   if (mainTitle!='') {
      ewgh1A.html(mainTitle);
      let mclass=jQuery.trim($(document).data('mainTitleClass'));
      if (mclass=='0') mclass='';
      if (mclass=='1') mclass='cMainTitle';
      if (mclass=='2') mclass='cMainTitle2';
      if (mclass!='') ewgh1A.addClass(mclass);
      $('#adminButtonsHeader').hide();
      $('#wsGallery_header1B').hide();
   }

// check screen size
  let minSizeViewing=$(document).data('minSizeViewing');
   let windowHeight=$(window).height();   // returns width of browser viewport
 
   let windowWidth=$(window).width();   // returns width of browser viewport
   let scHeight=screen.height;
   let scWidth=screen.width;
   if (scHeight< minSizeViewing || scWidth<minSizeViewing) {

       errmess='wsGallery works best on devices with a screen that has  width and height of at least '+minSizeViewing+' pixels! ';
       errmess+='\nThe screen WxH = '+scWidth+'x'+scHeight+').';
       errmess+='\nWould you like to use the compact viewer?';
       let qq=confirm(errmess);
       if (qq) {
         var  myOrigin=window.location.protocol+'//'+window.location.hostname;
         if (window.location.port!='') myOrigin+=':'+window.location.port;
         let wsMainSel= $(document).data('wsgMainSel');
         let aurl= myOrigin+wsMainSel+'/wsGallery_small.php';
         let asearch=window.location.search;
         if (jQuery.trim(asearch)!=='') aurl+=''+asearch;

         window.location=aurl;
         return 0;
       }

   } else {
     if (windowHeight< minSizeViewing || windowWidth<minSizeViewing) {
       let errmess='wsGallery works best if your viewport (the window wsGallery is using) is at least '+minSizeViewing+' pixels wide and high.';
       errmess+='\nTry exanding the wsGallery window (its current WxH = '+windowWidth+'x'+windowHeight+').';
       errmess+='\nWould you like to use the compact viewer?';
       let qq=confirm(errmess);
       if (qq) {
         var  myOrigin=window.location.protocol+'//'+window.location.hostname;
         if (window.location.port!='') myOrigin+=':'+window.location.port;
         let wsMainSel= $(document).data('wsgMainSel');
         let aurl= myOrigin+wsMainSel+'/wsGallery_small.php';
         let asearch=window.location.search;
         if (jQuery.trim(asearch)!=='') aurl+=''+asearch;
         window.location=aurl;
         return 0;
       }

     }     // wind height width
   }   // else


// ---------- create flcontent containers
// === admin container
   eAdm=wsurvey.flContent.create('admin',{
            'top':'6%','left':'4%','width':'53%','height':'73%','zIndex':233,
               'escapeOrder':'z','enableOnTop':'*','moveIcon':'&#9995;','classMain':'1 .SHADOW',
             'headerCloser':'&chi;,Close this admin window!',
             'headerP':'Admin',
             'callFunc':0});


// logon required?
  if (adminLogonRequired==1) {

// json erro handler
//     wsurvey.getJson.setErrFunc('jsonErrorShow');  // local function to call to dsisplay json errors
     wsurvey.getJson.prePend='src/';         // prepend this to all getJson.get() urls

     wsurvey.flContents.show('admin');
     let amess='';
     amess+='<input id="logonButton_fix" type="button" id="logonButton" value="Logon" title="Admin logon">';
     amess+='  ... you must logon to fix the following gallery initialization error: <tt>'+wasErr+'</tt>' ;
     wsurvey.flContents.contents('admin',amess);
     let dd={'logonName':'wsGallery','whenCall':0,'pwd':'','callbackLogon':'wsGallery_logonCallback_fix','todo':'fix'  };
     $('#logonButton_fix').on('click',dd,wsurvey.adminLogon);
     return 1;
   }  else {
      eAdm.wsFlHide(10);
   }

// if here, no admin logon required

// --- snapbox 1 (where images are displayed-- in dual mode this is the navigation impage

  let myGallery=$(document).data('galleryDir')  ;
  $('#wsGallery_myGallery').html('<span style="color:blue">&#127963;</span> ' +myGallery+' ');

    let v1header='' ;
    v1header+='<input type="button" id="targetHereViewer_1"  name="targetHereViewer"    value="&#127919;" ';
    v1header+='      title="Click to next image in this viewer" class="targetHere_off targetHereButton" data-which="1" onClick="targetHereSet(this)" >';

    v1header+=' <input type="button" class="csmallButton2" title="display info" onClick="displayViewerInfo(1)" value="&#8505;"> ';

    let  sea1=wsurvey.flContents.create('snapBox1',{
             'top':'4%','left':'1%','width':'40%','height':'35%', 'zIndex':13,
                'escapeOrder':'n','enableOnTop':'*','moveIcon':'&#9995;','classMain':'1 snapBox1_extra',
              'headerCloser':'&chi;,Close this window!',
              'headerP':'Viewer1. '+v1header,
              'callFunc':0 });

     let sea1m=wsurvey.flContents.dom(sea1,'c');
     sea1m.css({'overflow':'hidden'});
     sea1.wsFlContents('<span style="opacity:0.5" > Viewer #1</span>');
     sea1.wsFlShow(1);

// snapbox 2

     var hhs='';
     hhs+='<input type="button" id="targetHereViewer_2"   name="targetHereViewer"  value="&#127919;" ';
     hhs+='       title="Click to display next image in this viewer" class="targetHere_off targetHereButton" data-which="2" onClick="targetHereSet(this)" >';
     
     hhs+='<input type="button" class="smallButton" value="&#10068;" title="Help on zooming and scrolling" topic="zoomScroll"   onClick="doHelpVu(this)" >' ;
     hhs+='<input type="button" class="csmallButton2" title="display info" onClick="displayViewerInfo(2)" value="&#8505;"> ';
     hhs+='<input type="button" class="smallButton zoomViewers" value="&#7827;" title="zoom out" onClick="zoomViewer2(this)" zoom="0">' ;
     hhs+='<input type="button"  class="smallButton  zoomViewers" value="&#127487;" title="zoom in" onClick="zoomViewer2(this)" zoom="1">  ' ;
     hhs+='<input id="recenterZoomButton" type="button" class="smallButton  zoomViewers" value="&#10012;" title="reSet the within-image-location placed in the upper left corner of viewer 2" onClick="zoomViewer2(this)" zoom="2"> Viewer 2 &boxV; ' ;

// viewer box  2
    let sea2=wsurvey.flContents.create('snapBox2',{
               'top':'47%','left':'3px','width':'40%','height':'44%', 'zIndex':13,
                 'escapeOrder':'n','enableOnTop':'2','moveIcon':'&#9995;','classMain':'1 snapBox2_extra',
                 'headerCloser':'&chi;,Close this window!',
                 'headerP':hhs,
                 'callFunc':0 });
     let sea2m=wsurvey.flContents.dom(sea2,'c');
     sea2m.css({'overflow':'auto'});
     sea2.wsFlContents('<span style="opacity:0.5"> Viewer #2</span>');
     sea2.wsFlShow(1);

// viewer 3 (used in rotating layout)
     let hhs3='';
     hhs3+='<input type="button" id="targetHereViewer_3"   name="targetHereViewer"  value="&#127919;"  ';
     hhs3+='       title="Click to display next image in this viewer" class="targetHere_off targetHereButton" data-which="3" onClick="targetHereSet(this)" >';
     
     hhs3+='<input type="button" class="csmallButton2" title="display info" onClick="displayViewerInfo(3)" value="&#8505;"> ';
     let sea3=wsurvey.flContents.create('snapBox3',{
           'top':'53%','left':'52%','width':'43%','height':'40%','zIndex':14,
            'escapeOrder':'n','enableOnTop':'*','moveIcon':'&#9995;','classMain':'1 snapBox3_extra',
            'headerCloser':'&chi;,Close this window!',
            'headerP':'Viewer 3 '+hhs3,
            'callFunc':0 });
     let sea3m=wsurvey.flContents.dom(sea3,'c');
     sea3m.css({'overflow':'auto'});
     sea3.wsFlContents('<span style="opacity:0.5"> Viewer #3</span>');
     sea3.wsFlHide(1);
 
// tableau viewer
     let tbhead='Tableau view.';
     tbhead+='<input type="button" value="&#10068;" title="View help on: the tableau viewer" help" onClick="doHelpVu(this)"  class="helpButton" topic="usingTableau" > ';
     tbhead+='<input type="button" style="background-color:#23cffa;  " value="&#128194;" title="Show the file list (on top)" onClick="fileListShow()" >';
     tbhead+='<input type="button" style="font-size:110%;background-color:orange" value="&#8998;" title="Remove all images" onClick="tableauClear(this)" > ';
     tbhead+='<input id="iTightenUp" type="button" style="font-size:110%;background-color:#c7f3f9" value="&#129533;" title="Tighten up the display" onClick="tableauTighten(this)" > ';
     tbhead+='<span style="font-size:140%;color:brown">' ;
     tbhead+=' <span ict="0" title="# of files displayed"  id="tableauFileCt">0</span> files displayed ';
     tbhead+=' (<span title="including this # of images " ict="0" id="tableauImageCt">0</span> images) ';
     tbhead+='</span>';
     tbhead+='<span style="padding-left:1em;border-left:2px solid blue;font-size:100%;font-style:oblique"> Adjust grid-cell sizes ...</span>';
     tbhead+='<span style="font-size:125%">';
     tbhead+='<span onClick="$(\'#tableImage_wFactor\').val(1.0)" style="margin:3px 3px 3px 0.5em; border-bottom:1px solid blue;" ';
     tbhead+='   title="Adjust width of grid -- 1.0 = regular size&#010; Click here to reset to 1.0" ">  ';
     tbhead+=' Width: <input unselectable type="text" size="5" value="1.0" id="tableImage_wFactor" data-use="0" > </span>';
     tbhead+='<span onClick="$(\'#tableImage_hFactor\').val(1.0)"  style="margin:3px 3px 3px 0.62em; border-bottom:1px solid blue;"  ';
     tbhead+='     title="Adjust height of grid -- 1.0 = regular size&#010; Click here to reset to 1.0" ">  ';
     tbhead+=' Height: <input unselectable type="text" size="5" value="1.0" id="tableImage_hFactor" data-use="0" > </span>';
     tbhead+='  &boxV; ';
     tbhead+=' <input unselectable  type="button" value="&uarr;" title="Scroll to the the prior image in the  tableau viewing area" onClick="tableau_next(0,-1)"> ';
     tbhead+=' <input id="tableau_nowLoc" size="1"   unselectable title="View this image in the tableau (0 means `first image`).\n You can enter a value, or use  &lArr; and &rArr;" ';
     tbhead+='    onChange="tableau_next(this)"    style="background-color:#dfdad2;text-align:center;padding:3px 2px 3px 2px;font-size:120%" value="0"> ';
     tbhead+='   <input type="button" value="&darr;"   unselectable  title="Scroll to the next image in the  tableau viewing area" onClick="tableau_next(0,1)">  ';
     tbhead+='</span>';
     tbhead+=' &nbsp; &boxV; &nbsp; ';

     tbhead+=' <button class="doGoButton" title="Show all images using a small (~200px) snapshot"  onClick="tableauModeCompact(this)"><em>&forall;&#9641; Compact display</em></button> ';
     tbhead+='<em> ... or  ... </em>';
     tbhead+=' <button title="Choose one of the pre-defined tableau layouts"  onClick="$(\'#iTableauLayout\').toggle()"><em>&#8889; Pre-defines</em></button> ';
     tbhead+=' &nbsp;<button title="Select a list of images to view"  onClick="$(\'#iTableauSelectImages\').toggle()"><em>&#7591; selectImages</em></button> ';
     tbhead+=' &nbsp; <button title="Resize all of the currently displayed images -- to a custom size (width x height in pixels)" data-which="1" onClick="tableauResizeImages(this)"><em>&#10734;resizeAll</em></button> ';

     tbhead+='<div id="iTableauResize" class="cTableauLayout">';
     tbhead+='<input type="button" value="x"  onClick="$(\'#iTableauResize\').hide()">  ';
     tbhead+='<input type="button" value="&#10068;" title="View help on: resizing images in a tableau" onClick="doHelpVu(this)"  ';
     tbhead+= '     class="helpButton" topic="tableauResizeImages" > ';
     tbhead+='Width: <input type="text" size="10" value="200" title="width of images (in pixels).  " id="tableauResizeWidth">  x ';
     tbhead+='Height: <input type="text" size="10" value="200" title="height of images (in pixels).  " id="tableauResizeHeight">   &vellip; ';
     tbhead+='<input type="button" value="Resize! " title="resize all the images in the tableau" data-which="2" onClick="tableauResizeImages(this)">';
     tbhead+='<input type="button" value="Use full images " title="display full images in current tableau grid cells (with scrollbars)" data-which="3" onClick="tableauResizeImages(this)">';

     tbhead+='</div>';

     tbhead+='<div id="iTableauSelectImages" class="cTableauLayout">';
     tbhead+='<input type="button" value="x"  onClick="$(\'#iTableauSelectImages\').hide()">  ';
     tbhead+='<input type="button" value="&#10068;" title="View help on: specifying a list of images to display" help" onClick="doHelpVu(this)"  ';
     tbhead+= '     class="helpButton" topic="tableauSelectImages" > ';
     tbhead+=' You can specify images to display (in a CSV) and ';

     tbhead+='  <input type="button" value="Show them!" title="Click this after specifying a list of images (by number) to display" ';
     tbhead+='     onClick="tableauShowImageList(this)">';

     tbhead+='&nbsp;<input type="text" id="tableauImageNumbers" size="70" value="" ';
     tbhead+='        title="CSV of images (by number) to display. For a range, use `n1 - n2 `"> ';

     tbhead+=' &boxV;<b> Shortcuts:</b> ';
     tbhead+='  <input type="button" value="Show all!" title="Show all images & files" ';
     tbhead+='     onClick="tableauShowImageList(this,1)">';
     tbhead+='  <input type="button" value="Show all images !" title="Show all images (do not show non-image files)" ';
     tbhead+='     onClick="tableauShowImageList(this,2)">';

     tbhead+='</div>';


     tbhead+='<div id="iTableauLayout" class="cTableauLayout">';
     tbhead+='<input type="button" value="x"  onClick="$(\'#iTableauLayout\').hide()">  ';
     tbhead+='<input type="button" value="&#10068;" title="View help on: predefined tableau layouts" help" onClick="doHelpVu(this)"  class="helpButton" topic="tableauPredefines" > ';

     tbhead+='You can choose a layout of the tableau: <span id="whichTableauLayout">Default (1)</span>';
     tbhead+='<ul class="linearMenu">';
     tbhead+='<li class="linearMenuLi3"><input type="button" value="1" onClick="setTableauLayout(this)"> Multiple mid-sized snapshots per row ';
     tbhead+='<li class="linearMenuLi3"><input type="button" value="2" onClick="setTableauLayout(this)"> Multiple shrunken mid-sized (~200px) snapshots per row   ';
     tbhead+='<li class="linearMenuLi3"><input type="button" value="3" onClick="setTableauLayout(this)"> Two larger (~400px) snapshots per row  ';
     tbhead+='<li class="linearMenuLi3"><input type="button" value="4" onClick="setTableauLayout(this)"> Two larger (~400px) fullPhotos per row  ';
     tbhead+='</ul>';
     tbhead+='</div>';
// used in tableau layout
     eaTa=wsurvey.flContents.create('tableau',{
               'top':'16%','left':'2%','width':'88%','height':'75%','zIndex':16,
                'escapeOrder':'z','enableOnTop':'*','moveIcon':'&#9995;','classMain':'1 tableau_extra',
                'headerCloser':'&chi;,Close this window!',
                'headerP':tbhead,
                'callFunc':0 });

     let ss1='<div id="tableau_all" ithImg="0" class="ctableau_all gradientTan">';
     ss1+='<div style="font-size:60%;opacity:0.6" id="tableauViewerTopLine" > Tableau viewer. Click on an image to view file info; and for more options (download full version, remove from tableau, display in external window)</div>';
     eaTa.wsFlContents(ss1);
     eaTa.wsFlHide(1);

    let single2=wsurvey.flContents.create('singleImage',{
               'top':'5%','left':'1%','width':'98%','height':'91%', 'zIndex':333,
                 'escapeOrder':'z','enableOnTop':'1','moveIcon':'&#9995;','classMain':'1 snapBox2_extra',
                 'classContent':'1  gradientGray','classHeader':'1',
                 'headerCloser':'&chi;,Close this window!',
                 'headerP':'SingleViewer',
                 'callFunc':0 });
     let single2m=wsurvey.flContents.dom(single2,'c');
     single2m.css({'overflow':'auto'});

     let arf='';
      arf+='<div id="singleImageOtherInfo" class="cSingleImageOther"> </div>';
      arf+='<div id="singleImageContentOuter" class="cSingleImage">';

     let viewList='<button   onClick="singleImageGet(3)" title="view file list  " id="iSingleImageFilelist">&#128449;</button>';
     let priorFirst='<button class="cSingleImageButton" onClick="singleImageGet(0)" title="view first" id="iSingleImageFirst"> &#171;</button>';
     let prior1='<button class="cSingleImageButton" onClick="singleImageGet(-1)" title="view prior" id="iSingleImagePrior">&#9001;</button>';
     let nextLast='<button class="cSingleImageButton" onClick="singleImageGet(2)" title="view last" id="iSingleImageLast">&#187;</button>';
     let next1='<button class="cSingleImageButton" onClick="singleImageGet(1)" title="view next" id="iSingleImageNext">&#9002;</button>';

     let exitThis='<button class="cSingleImageButton" onClick="singleImageGet(4)" title="exit" id="iSingleImageExit">&#119883;</button>';
     let fullScreen='<button class="cSingleImageButton2" onClick="singleImageGet(5)" title="view using entire screen" id="iSingleImageFullScreen">&#10506;</button>';
     let rotateThis='<button class="cSingleImageButton2" onClick="singleImageGet(7)" title="rotate image (90 degrees clockwise, cumulative)" id="iSingleRotate1">&#8631;</button>';
     let fullView='<button class="cSingleImageButton2" onClick="singleImageGet(8)" title="full view (no shrinking, original image) " id="iSingleFullView">&#128998;</button>';
     let dualScreen='<button class="cSingleImageButton2" onClick="singleImageGet(6)" title="view using dual viewer (zoom & scroll capabilities)" id="iDualImageFullScreen">&#10697;</button>';
     let tableauScreen='<button class="cSingleImageButton2" onClick="singleImageGet(62)" title="view using tableau viewer (multiple image viewer)" id="iTableauViewer">&#9638;</button>';

     arf+='<div id="singleImageContentL" class="cSingleImageL">'+fullScreen+'<br>'+prior1+'<br>'+priorFirst+'<br>'+rotateThis+'<br>'+fullView+'</div>';
     arf+='<div id="singleImageContentM" class="cSingleImageM"> <span style="opacity:0.5"> Single image viewer</span></div>';
     arf+='<div id="singleImageContentR" class="cSingleImageR">'+viewList+'<br>'+next1+'<br>'+nextLast+'<br>'+dualScreen+'<br>'+tableauScreen+'<br>'+exitThis+'</div>';

     arf+='<br clear="all" />';
     single2.wsFlContents(arf);

     single2.wsFlShow(1);
     single2.wsFlHide(1);

// container for gallery: the list of displayable (image,etc) files
   var gheader='<button   title="View directory list (and highlight most recently viewed directory)" name="toggleDirVu_gallery" data-last="" onClick="toggleDirVu(0,this)">&#9636;</button> ';

   gheader+='<button  id="toggleViewers_2" title="Toggle the sizes of file and viewer boxes (3 presets)"  ';
   gheader+= '  which="0"  onClick="doResizeViewers2(this)"  class="cToggleScreenLayout" >&#10697;<button>';

    gheader+='<input id="tableauOnTop"  name="tableauButtons"  type="button" style="display:none;background-color:#23cffa;" value="&#9638;" title=".Show the tableau grid (of images and other files) on top" onClick="tableauShow()" >';
    gheader+='<input id="tableauMode"  name="tableauButtons" data-which="0"   type="button" style="display:none;background-color:#23cffa;color:#e95e08;  " value="&#11027;" title="Toggle between tableau modes&#010; small or large file-list" onClick="tableauMode(this)" >';
    gheader+='<input id="tableauGoCompact"  name="tableauButtons" data-which="0"   type="button" style="display:none;background-color:#13ffea;color:#a938e0;" value="&forall;&#9641;" title="Show all images using a small (~200px) snapshots" onClick="tableauModeCompact(this)" >';

    let egallery=wsurvey.flContents.create('gallery',{
            'top':'7%','left':'43%','width':'55%','height':'84%','zIndex':123,
            'escapeOrder':'z','enableOnTop':'*','moveIcon':'&#9995;','classContent':'1 gallery_extraContent','classMain':'1 gallery_extra',
            'headerCloser':'&chi;,Close this window!',
            'headerP':gheader,
            'callFunc':0});

     let tmpG='<div id="gallery_list" class="cgallery" ><span style="opacity:0.3">A menu of this directory\'s  image (and other) files) displayed here...</span></div>';
     egallery.wsFlContents(tmpG);
     egallery.wsFlHeader('Image (and other) files in directory ');

// container for list of collections
     let eDirCo=wsurvey.flContents.create('collectionList',{
              'top':'15%','left':'15%','width':'53%','height':'53%', 'zIndex':134,
              'escapeOrder':'z','enableOnTop':'*','moveIcon':'&#9995;','classMain':'1 dirList_extra',
              'headerCloser':'&chi;,Close this collection window!',
              'headerP':'Collection list','callFunc':0 });

     wsurvey.flContents.hide(eDirCo );

// container for list of directories

    hh1=' <input type="button" value="&#127794;" name="headerToggleSwitchTreeButton" title="Toggle the `select a directory tree`  ... menu" onClick="toggleSwitchTreeMenu(1)">';

 // feb 2022 : this loadTreeDirs, used in a refresh button in the dirLIst... may not that useful
    hh1+='<input type="button" value="&#8634;" title="Reload directory list for the currently selected tree (retrieve from server...)" onClick="loadTreeDirs(0,\'dirlist button\')"> Image directories ';

    let eDirL=wsurvey.flContents.create('dirList',{
              'top':'22%','left':'22%','width':'53%','height':'53%', 'zIndex':133,
              'escapeOrder':'z','enableOnTop':'*','moveIcon':'&#9995;','classMain':'1 dirList_extra',
              'headerCloser':'&chi;,Close this directories window!',
              'headerP':hh1,'callFunc':0 });

    let aspin=getSpinnerImg();
    eDirL.wsFlContents(aspin+' Please wait ... loading the file list for the current <em>tree</em>    &hellip;');




// == help container
     let hh2='<a href="wsGallery_vuHelp.php" title="View wsGallery help in a new window" target="helpWindow" class="helpTopic_otherTopicButton">&neArr;</a> ';
      hh2+='<button title="Help box is small. Click to expand to nearly fill the window." which="0" onClick="setHelpMenuExpand(this)">&#9725;</button>'; // &#11064; if in expanded mode
      hh2+='<input type="button" value="&#127982;" title="List of help topics" onclick="doHelpVuList(this)"> wsGallery Help. ';

     eHel=wsurvey.flContent.create('helpTopics',{
             'top':'50%','left':'12%','width':'63%','height':'40%','zIndex':233,'priorRetain':1,
             'escapeOrder':'z','enableOnTop':'*','moveIcon':'&#9995;','classMain':'1 .SHADOW',
             'headerCloser':'&chi;,Close this help window!',
            'headerP':hh2,
            'callFunc':0});
     let edump=$('#helpDump');
     eHel.wsFlContents(edump);
     eHel.wsFlHide(5);

// == savorites  container
  let hhF='<input type="button" value="&#10068;" title="View help on: working with favorites"  class="helpButton"  onClick="doHelpVu(this)" topic="favorites" > ';
  let eFaves=wsurvey.flContents.create('favorites',{
              'top':'2%','left':'55%','width':'43%','height':'19%', 'zIndex':334,
              'escapeOrder':'z','enableOnTop':'*','moveIcon':'&#9995;','classMain':'1',
              'headerCloser':'&chi;,Close this favorites window!',
              'headerP':hhF+' Favorites.','callFunc':0 });

      wsurvey.flContents.hide(eFaves );

// done with floatingContent container creation  ..........

  var dd={'logonName':'wsGallery','whenCall':0,'pwd':'','callbackLogon':'wsGallery_logonCallback','todo':'admin'  };

  $('#logonButton').on('click',dd,wsurvey.adminLogon);

  wsurvey.flContents.show('dirList',11);

  let afavorites=$(document).data('enableFavorites');

  let efavorites= $('#iFavorites');
  if (afavorites==0) {
     efavorites.css({'opacity':0.5});
     efavorites.attr('title','Favorites are DISABLED');
  }
  if (afavorites==1) {
     efavorites.attr('title','Click to read (or upload) a favorites-list');
     efavorites.addClass('cFavorites1');
  }
  if (afavorites==2) {
     efavorites.attr('title','Click to read (or upload), or create, a favorites-list');
     efavorites.addClass('cFavorites2');
  }
  if (afavorites==3) {
     efavorites.attr('title','Click to read (or upload), or create and save, a favorites-list');
     efavorites.addClass('cFavorites3');
  }


// dropdowns

let ddopts={'openerActive':'[name="whileDropdownOpen"]',
         'openerInactive':'[name="whileDropdownNotOpen"]',
          'zindex':2300,'leftOffset':'-3em','topOffset':'2.3o','closers':'*'};

wsurvey.dropdown('iToggleScreenLayoutShowDropdown','dropdown_layouts' ,ddopts) ;

if ($(document).data('showCompactLink')==1) $('#iCompactViewerLink').show();

// ------- hide the scroll image/ show location buttons (top of screen)
let ej=$('[name="imageJumpButtons"]');
ej.hide();

// json erro handler
wsurvey.getJson.setErrFunc('jsonErrorShow');  // local function to call to dsisplay json errors

wsurvey.getJson.prePend='src/';         // prepend this to all getJson.get() urls

// f1 handler
shortcut.add("F1",doF1Help,{
	'type':'keydown',
	'propagate':true,
	'disable_in_input':true,
	'target':document
});

shortcut.add("a",doFavoritesAdd,{
	'type':'keydown',
	'propagate':true,
	'disable_in_input':true,
	'target':document
});


shortcut.add("pageup",doPgupPgdn,{
	'type':'keydown',
	'propagate':true,
	'disable_in_input':true,
	'target':document
});
shortcut.add("pagedown",doPgupPgdn,{
	'type':'keydown',
	'propagate':true,
	'disable_in_input':true,
	'target':document
});


// and load the directory menu, for the current "default" tree, into the dirList! And if specified, display files in  requested dir
   let areqf=$(document).data('requestedFile');
   let dflag='loadTree_'+wsurvey.get_currentTime(0);

   $(document).data(dflag,0);
   window.setTimeout(function() {
     loadTreeDirs(0,'end of init()',0,$(document).data('currentDir'),areqf,dflag)   ; // read directory list  for the default tree  and display it.
     init_bb(0,dflag);
   },320);

}

function init_bb(mm,dflag) {
  if (mm>5) console.log(dflag+' is mm '+mm);  // waiting a while ...
   if (mm>100) {  // waited too long
       toggleDirVu_2(3,1.1);    // switch gallery and collection buttons display
       return 0;
   }
   let bchk=$(document).data(dflag);
   if (bchk==0) {  // not done, wait...
     mm++;
     window.setTimeout(function() {
       init_bb(mm,dflag);
       return 0;
     },20);
  } else {     // flag that loaddir is done

      toggleDirVu_2(3,1.1);    // switch gallery and collection buttons display

  }

} // ::::::::::::::::::::::: END OF INIT ::::::::::::::::::::

//-=--------------------------
// personal setting icon
function doSettings1(athis) {
  $('#logonButton').show();
  wsurvey.flContents.show('admin',11,1);
  
  let acc=Cookies.get();
 
  let amess='<div style="background-color:#dfeddf;padding:5px;border-radius:3px">';
  amess+='wsGallery personal settings. You can specify options to use with wsGallery. Leave a field empty to use the defaults.   ';
  amess+='<br> <input id="iDoSettings1_button"  type="button" value="Save" title="Save these options (using cookies) " onClick="doSettings1Save(this)" >';
  amess+='<span id="iDoSettings1_saveResults"  style="display:none;background-color:cyan"> </span>';

  amess+='<table cellpadding="8" style="margin:5px 1em 5px 2em;padding:6px" rules="rows">';
  amess+='<tr><th>Setting</th>';
  amess+=' <th>  ';
  amess+='<input type="button" value="&#10145;&#65039;" title="Uses these as personal defaults" onClick="doSettings1UseThese(this)"> ';
  amess+=' Currently using </th>';
  amess+='<th>';
  amess+='Current personal default ';
  amess+='<input type="button" value="&#9003;" title="clear all personal defaults" onClick="doSettings1Clear(this)"> ';
  amess+='</th>';
  amess+='</tr>';

  amess+='<tr><td>Gallery</td>  <td><span class="currentlyUsing"> '+$(document).data('currentGallery')+'</span></td>';
  let cookieGallery= (acc.hasOwnProperty('wsGallery_gallery')) ? acc['wsGallery_gallery'] : '' ;
  amess+='<td><input type="text" value="'+cookieGallery+'" title="Use this gallery " ';
  amess+='     name="personalSettingsDo" id="personalSettingsGallery"></td>';
  amess+='</tr>';

  amess+='<tr><td>Tree</td>  <td><span class="currentlyUsing">'+$(document).data('currentTree')+'</span></td>';
  let cookieTree= (acc.hasOwnProperty('wsGallery_tree')) ? acc['wsGallery_tree'] : '' ;
  amess+='<td><input type="text" value="'+cookieTree+'" title="Use tree (in this gallery  )"   ';
  amess+='    name="personalSettingsDo"  id="personalSettingsTree"></td>';
  amess+='</tr>';

  amess+='<tr><td>Directory</td>  <td><span class="currentlyUsing">'+$(document).data('currentDir')+'</span></td>';
  let cookieDir= (acc.hasOwnProperty('wsGallery_dir')) ? acc['wsGallery_dir'] : '' ;
  amess+='<td><input type="text" value="'+cookieDir+'" title="Use directory (in this gallery and tree)"  ';
  amess+='     name="personalSettingsDo"  id="personalSettingsDir"></td>';
  amess+='</tr>';

  amess+='<tr><td>screenLayout </td><td><span class="currentlyUsing">'+$(document).data('currentScreenLayout')+'</span> </td>';
  let cookieScreenLayout= (acc.hasOwnProperty('wsGallery_screenLayout')) ? acc['wsGallery_screenLayout'] : '' ;
  amess+='<td><input type="text" value="'+cookieScreenLayout+'" title="Use this screen layout.&#010;Valid choices: dual, rotate,tableau,single"  ';
  amess+='     name="personalSettingsDo"  id="personalSettingsScreenLayout"></td>';
  amess+='</tr>';

//  amess+='<tr><td>infoDisplay</td>  <td><td></tr>';
  amess+='<tr><td>Thumbnails  </td> <td><span class="currentlyUsing">'+$(document).data('currentThumbnails')+' </span> </td>';
  let cookieThumbnails= (acc.hasOwnProperty('wsGallery_thumbnails')) ? acc['wsGallery_thumbnails'] : '' ;
  amess+='<td><input type="text" value="'+cookieThumbnails+'" title="Use thumbnails.&#010;Valid choices: 0=no, 1=small, 2=medium,3=large"  ';
  amess+='     name="personalSettingsDo"  id="personalSettingsThumbnails"></td>';
  amess+='</tr>';

  let a1=$('#ichooseFileListType'),uld=1;
  if (a1.length>0) uld=a1.attr('how');
  let cookieListDisplay= (acc.hasOwnProperty('wsGallery_listDisplay')) ? acc['wsGallery_listDisplay'] : '' ;

  amess+='<tr><td>listDisplay  </td>';
  amess+='<td><span class="currentlyUsing">'+uld+' </span> </td>';
  amess+='<td><input type="text" value="'+cookieListDisplay+'" title="How to display the list of files.&#010;Valid choices: 1=buttons, 2=detailed list, 3=more detailed table"  ';
  amess+='     name="personalSettingsDo" id="personalSettingsListDisplay"> </td>';
  amess+='</tr>';

  let acompact= (acc.hasOwnProperty('wsGallery_compactLink')) ? acc['wsGallery_compactLink'] : '' ;
  amess+='<tr><td>showCompactLink    (0=no, 1=yes) </td>';
  amess+=' <td><span class="currentlyUsing">'+acompact+'</span> </td>';
  amess+='<td><input type="text" value="'+acompact+'" title="Display a link to the compact viewer (wsGallery_small.php): 0=no, 1=Yes   ';
  amess+='     name="personalSettingsDo" id="personalSettingsCompactLink"> </td>';
  amess+='</tr>';

  amess+='</table>';


 amess+='<hr><div style="font-size:80%"><em>Note: </em> personal settings are saved using cookies with a 17 day lifetime</div>';
 amess+='<div>Resolution specs: ';
   let windowHeight=$(window).height();   // returns width of browser viewport
   let windowWidth=$(window).width();   // returns width of browser viewport
   let scHeight=screen.height;
   let scWidth=screen.width;
   amess+='Screen: <tt>'+scWidth+'x'+scHeight+'</tt>.  Current window: <tt>'+windowWidth+'x'+windowHeight+'</tt>. ' ;
   let mxp=navigator.maxTouchPoints;
   amess+='Touch points=<tt>'+mxp+'</tt>. ';

   let auu=navigator.userAgentData;
   let isMobile='unknown';
//https://stackoverflow.com/questions/3514784/what-is-the-best-way-to-detect-a-mobile-device
   if (typeof(navigator.userAgentData)!='undefined'){
     isMobile= (navigator.userAgentData.mobile) ? 'mobile' : 'notMobile' ;
   }    else {
     const ua = navigator.userAgent;

     if (/(tablet|ipad|playbook|silk)|(android(?!.*mobi))/i.test(ua)) {
       isMobile="tablet";
     } else  if (/Mobile|Android|iP(hone|od)|IEMobile|BlackBerry|Kindle|Silk-Accelerated|(hpw|web)OS|Opera M(obi|ini)/.test(ua)) {
        isMobile="mobile";
     } else {
         isMobile="desktop";
      }

   }

   amess+=' Mobile: <tt>'+isMobile+'</tt>';

   amess+='</div>';
  wsurvey.flContents.contents('admin',amess);
  
  let switchSmall='<input type="button" value="CompactViewer" title="switch to the compact viewer" onClick="switchCompactViewer(this)">';
  wsurvey.flContents.header('admin',switchSmall);
}
//===========
// clear personal defaults
function doSettings1Clear(athis) {
  let ee=wsurvey.flContents.find('admin','[name="personalSettingsDo"]');
  ee.val('');
}

//===========
//switch to compact viewer
function switchCompactViewer(athis) {
    var  myOrigin=window.location.protocol+'//'+window.location.hostname;
   if (window.location.port!='') myOrigin+=':'+window.location.port;
   let wsMainSel= $(document).data('wsgMainSel');
   let aurl= myOrigin+wsMainSel+'/wsGallery_small.php';
   aurl+='?gallery='+$(document).data('currentGallery')+'&tree='+$(document).data("currentTree");
   aurl+='&dir='+$(document).data('currentDir');
   window.location=aurl;
  return 1;

}

//=============
// use current values as personal defaults
function doSettings1UseThese(athis) {
    let dlist={'personalSettingsGallery':'wsGallery_gallery',
           'personalSettingsTree':'wsGallery_tree',
           'personalSettingsDir':'wsGallery_dir',
           'personalSettingsScreenLayout':'wsGallery_screenLayout',
           'personalSettingsThumbnails':'wsGallery_thumbnails',
           'personalSettingsCompactLink':'wsGallery_compactLink',
           'personalSettingsListDisplay':'wsGallery_listDisplay'
         }
  for (let a1 in dlist) {
     let e1=$('#'+a1);
     let etr=e1.closest('tr');
     let espan=etr.find('.currentlyUsing');
     let aval=espan.text();
     e1.val(aval);
  }
}




//===========
// save personal defaults to cookies
function doSettings1Save(athis) {
  let dlist={'personalSettingsGallery':'wsGallery_gallery',
           'personalSettingsTree':'wsGallery_tree',
           'personalSettingsDir':'wsGallery_dir',
           'personalSettingsScreenLayout':'wsGallery_screenLayout',
           'personalSettingsThumbnails':'wsGallery_thumbnails',
           'personalSettingsCompactLink':'wsGallery_compactLink',
           'personalSettingsListDisplay':'wsGallery_listDisplay'
         }
  let nsets=0;
  for (let a1 in dlist) {
    let e1=$('#'+a1)
    let aws=dlist[a1];
    let aval=jQuery.trim(e1.val());
    if (aval=='') {
      Cookies.remove(aws)  ;
    } else {
     Cookies.set(aws,aval, { expires: 17 }  );
     nsets++;
    }
  }
  $('#iDoSettings1_saveResults').html(nsets+' settings saved ').show();
  $('#iDoSettings1_button').prop('disabled',true);

}

//=====================
// display info line in a viewre box
function displayViewerInfo(ibox) {
    let ee=wsurvey.flContents.find('snapBox'+ibox,'[name="iimageInfoSnap"]');
    if (ee.length>0) ee.show();
}

function foodo(akey) {
  alert('akey '+akey);
  return 1;
}

// ==================
// atarget this  viewer button hit
function targetHereSet(athis) {
   let ethis=wsurvey.argJquery(athis);
   let iwhich=ethis.attr('data-which');

// <!-- 9461=1, 9462=2,  9463=3,  &#127464; blue c   &#127275; circle c -->
   let ewhichIcons=['&#127464;','&#9461;','&#9462;','&#9463;'];
   let ewhich=$('#targetHereViewer_which');

   if (ethis.hasClass('targetHere_on')) {
        ethis.removeClass('targetHere_on');
        ethis.addClass('targetHere_off');
        ethis.attr('title','Click to display next image in this viewer ');

        ethis.attr('title','Next image will be displayed in next viewer! ');
        ewhich.attr('data-which',0);
        ewhich.html('&vellip;');
        ewhich.removeClass('targetHere_on');
        ewhich.addClass('targetHere_off');


   } else {
       let ee1=$('[name="targetHereViewer"]');
       ee1.removeClass('targetHere_on');
       ee1.addClass('targetHere_off');
       for (let ii=0;ii<ee1.length;ii++) {
           let aee=$(ee1[ii]);
           aee.attr('title','Click to display next image in this viewer ');
        }

        let iwhich=ethis.attr('data-which');
        ethis.removeClass('targetHere_off');
        ethis.addClass('targetHere_on');
        ethis.attr('title','Next image will be displayed in this viewer! ');

        ewhich.attr('data-which',iwhich);
        ewhich.html(ewhichIcons[iwhich]);
        ewhich.removeClass('targetHere_off');
        ewhich.addClass('targetHere_on');
        ewhich.attr('title','Next image displayed in viewer # '+iwhich);

   }
   return 1;
}

 //======================
// tableauResizeImages
// iTableauResize is where to write  menu
function tableauResizeImages(athis) {
   let ethis=wsurvey.argJquery(athis);
   let iwhich=ethis.attr('data-which');
   let eall=$('#tableau_all');

   if (iwhich==1) {  // setup form
       let hAll=eall.height();
       let wAll=eall.width();
       let zz=Math.min(hAll,wAll);
       let whUse=parseInt(wAll/4);
       let emenu=$('#iTableauResize');
       $('#tableauResizeWidth').val(whUse);
       let wh2=parseInt(0.75*whUse);
       $('#tableauResizeHeight').val(wh2);
       emenu.show();
       return 1;
   }
   let wUse=jQuery.trim($('#tableauResizeWidth').val()) ;
   let hUse=jQuery.trim($('#tableauResizeHeight').val()) ;
    if (iwhich==3) {  // special case: show full images in current grid cells
        wUse=''; hUse='';
    }
   if (wUse=='' && hUse=='') {   // full size
     let eimgs=eall.find('[name="imageRequesterTableau"]');
     for (let ie=0;ie<eimgs.length;ie++) {
       ee1=$(eimgs[ie]);
       ee1.height(''); ee1.width('');
        ee1.attr('height','');
        ee1.attr('width','');
       ee1.attr('reset','now!');
       let espan=ee1.closest('span');
       espan.css({'overflow':'auto'});
     }
  } else {       // custom size for img
      wUse=parseInt(wUse);    hUse=parseInt(hUse);
      if (wUse<5 || hUse<5)  return 0;  // ignore too small
      let wUse2=wUse+8, hUse2=hUse+8;
      let eimgs=eall.find('[name="imageRequesterTableau"]');
      for (let ie=0;ie<eimgs.length;ie++) {
        ee1=$(eimgs[ie]);
      //  ee1.height(wUse); ee1.width(hUse);
        ee1.attr('height',hUse);
        ee1.attr('width',wUse);
        let espan=ee1.closest('span');
        espan.css({'width':wUse2+'px','height':hUse2+'px','overflow':'hidden'});
       
      }
  }

   return 1;
}

//====================
// single image stuff
// iopt:
// -1:  view piror
// 0 : view first
// 1:  view next
// 2  : view last
// 3:  file list on top
// 4: exit singleImage (return to prior viewer)   
// 5: make full screen
// 6 : switch to dual image laoyt
// 7 : rotate
// 8  : show full (no shrinking, original pixels)

function singleImageGet(iopt) {
   if (iopt==3) {   // file list on top
     wsurvey.flContents.show('gallery',5,1);
     return 1;
   }

   if (iopt==4) {   // exit singleImageviewer
      let fromLayout=$(document).data('screenLayout_tempSingle');
      wsurvey.flContents.hide('singleImage',25);
      doResizeViewers(0,[fromLayout,1]);
      return 1;
   }

   if (iopt==5) {   // open singleImageviewer
     let earf=$('#singleImageContentM');
     let earf0=earf[0];
     openFullscreen(earf0);
     return 1;
   }

   if (iopt==6) {   // view using dual image viewer
     let eww=$('#iSingleImageViewerInfo');
     let iwhich=eww.attr('data-which');

     doResizeViewers(0,1,0 );

     let e3=wsurvey.flContents.find('gallery','[buttonnumber="'+iwhich+'"]');
     if (e3.length>0)  {
        let e4=e3.find('button');
        e4.trigger('click');
     }
      return 1;
   }

   if (iopt==62) {   // view using tablaue
     doResizeViewers(0,2  );
      return 1;
   }

   iTableauViewer

   if (iopt==7) {   // rotate clockwise
      let e1a=wsurvey.flContents.find('singleImage','[name="imageRequester"]');
      if (e1a.length==0) return 0;  // should never happen
      let deg=e1a.wsurvey_attrCi('rotated',0);
      if (isNaN(deg)) deg=0;
      deg=parseInt(deg)+90;
      if (deg>360) deg=0;
      e1a.attr('rotated',deg);
      e1a.animate({
            transform: deg
           }, {
             step: function(now, fx) {
                 $(this).css({
                       '-webkit-transform': 'rotate(' + now + 'deg)',
                        '-moz-transform': 'rotate(' + now + 'deg)',
                       'transform': 'rotate(' + now + 'deg)'
                    });
               }
         });
      return 1;
   }


// view full image
   if (iopt==8)  {
      let elist=$('#listOfFileInCurrentDir');
      let einfo=$('#iSingleImageViewerInfo');
      if (einfo.length==0) return 0;
      if (elist.length==0) return 0; // should not happen
      let iwhich=einfo.attr('data-which');

      let espan=elist.find('[buttonnumber="'+iwhich+'"]');
      if (espan.length==0) return 0;
      let ebutton=espan.find("button");
      if (ebutton.length==0) return 0;
      showThisFile(ebutton,1,1);

     return 1;
   }
// goto next prior ...


   let edir=wsurvey.flContents.dom('gallery','c')  ;
   let elist=edir.find('#listOfFileInCurrentDir');
   let nbuttons=parseInt(elist.attr('nbuttons'));
   let nbuttons0=nbuttons-1 ;

   if (iopt==0)  {  // get first image
     let enow=elist.find('[buttonnumber="0"]');
      if (enow.length>0) {
         edo=enow.find('button');
         edo.trigger('click');
      }
      return 1;
   }

   if (iopt==2)  {  // get last image
      let enow=elist.find('[buttonnumber="'+nbuttons0+'"]');
      if (enow.length>0) {
         edo=enow.find('button');
         edo.trigger('click');
      }
      return 1;
   }

   if (iopt==-1)  {  // get prior image
      let iget=0 ;  // if none chosen, get first
      let enow=elist.find('.thisImgInSnapshot');
      if (enow.length>0) {
        let ebutton=enow.closest('span');
        let iat=parseInt(ebutton.attr('buttonnumber'));
        if (iat<=0) return 1; // already showing first
        iget=iat-1;
      }
      let edo=elist.find('[buttonnumber="'+iget+'"]');
      if (edo.length>0) {
         let edo2=edo.find('button');
         edo2.trigger('click');
      }
      return 1;
   }

   if (iopt==1)  {  // get next image
      let iget=0 ;  // if none chosen, get first
      let enow=elist.find('.thisImgInSnapshot');
      if (enow.length>0) {
        let ebutton=enow.closest('span');
        let iat=parseInt(ebutton.attr('buttonnumber'));
        if (iat>=nbuttons0) return 1; // already at last
        iget=iat+1;
      }
      let edo=elist.find('[buttonnumber="'+iget+'"]');
      if (edo.length>0) {
         let edo2=edo.find('button');
         edo2.trigger('click');
      }
      return 1;
   }
    alert('unknown option in  singleImageGet '+iopt)

}

//===========================
// set the layour of the tableau
// 1: default        (1x 1, shrink, snapshot)
// 2: default shrunken   (0.4 x 1, shrink, snapshot)
// 3: 2 x snapshots       (0.94 x 2.1, shrink, snapshot)
// 4:  2 x fullPhotos   (0.94 x 2.1, shrink, full)

function setTableauLayout(athis,aval) {

   if (arguments.length<2) {
     let ethis=wsurvey.argJquery(athis);
     aval=ethis.val();
   }
   let e0=$('#shrinkToFit');
   let e1=$('#shrinkToFitLabel');
   let e2=e1.find('.mainOptsText');
   let etight=$('#iTightenUp');

   toggleShrinkToFit('',3);

   let isnap=2;
   if (aval==4) isnap=1;
   toggleSnapshotGet('',isnap) ;     // 1 full, 2 snap, 3 custom

   if (aval==1) {
     $('#tableImage_wFactor').val(1.0) ;
     $('#tableImage_hFactor').val(1.0) ;
   }
   if (aval==2) {
     $('#tableImage_wFactor').val(0.4) ;
     $('#tableImage_hFactor').val(1.0) ;
   }
   if (aval==3) {
     $('#tableImage_wFactor').val(0.94) ;
     $('#tableImage_hFactor').val(2.05) ;
   }
   if (aval==4) {
     $('#tableImage_wFactor').val(0.94) ;
     $('#tableImage_hFactor').val(2.05) ;
   }

  let et=$('#whichTableauLayout');
  let esays=['','Mid sized (1)','Shrunken mid sized (2)','Larger snapshot (3)','Larger full (4)'];
  et.html('. Current choice: '+esays[aval]);

}

// =========================
// process list of images
function tableauShowImageList(athis,iall) {       //athis not used
  if (arguments.length<2) iall=0;

   var v1,skipNoImage=0;
   let ea1=$('#listOfFileInCurrentDir');
   let nfiles=ea1.attr('nbuttons');
   if (iall==1) {
      v1='1-';
      if (nfiles>50) {
         let qq=confirm("There are "+nfiles+' files. Are you sure you want to display all of them?');
         if (!qq) return 0;
      }
   } else if (iall==2) {
      let efoo=$('#tableauImageCt');
      let nimages=efoo.attr('ict');
      if (nimages>30) {
         let qq=confirm("There are "+nfiles+' images. Are you sure you want to display all of them?');
         if (!qq) return 0;
      }
      v1='1-';
      skipNoImage=1;
   }  else {
       let e1=$('#tableauImageNumbers');
       v1=jQuery.trim(e1.val());
   }
   if (v1=='') return '';            // no images specified
   let vlist=v1.split(',');
   let imgList={};
   for (var iv=0;iv<vlist.length;iv++) {
       let av=jQuery.trim(vlist[iv]);
       let idash=av.indexOf('-');
       if (idash>=0) {
          let av2=av.split('-');
          let iv1=jQuery.trim(av2[0]) ;
          if (iv1==='') iv1=1;
          let iv2=nfiles;
          if (av2.length>1) iv2=jQuery.trim(av2[1]);
          if (iv2==='') iv2=nfiles;
          if (isNaN(iv1) ||  isNaN(iv2)  ) {  // error condisions
             alert('Bad range specification in imageList: '+av  );
             return '';
          }
          iv1=parseInt(iv1); iv2=parseInt(iv2);
          if (iv1<1 || iv2<iv1) {
             alert('Bad range values in imageList: '+av  );
             return '';
          }
          iv2=Math.min(nfiles,iv2);
          for (ii=iv1;ii<=iv2;ii++)  imgList[ii]=1;
      } else {
          if (isNaN(av) || av<1) {
             alert('A bad specification in imageList: '+av );
             return '';
          }
          iv1=parseInt(av);
          imgList[iv1]=1;
     }
   }  // each item in csv

  for (var ido in imgList) {
     let bbutton=ea1.find('[buttonNumber="'+ido+'"]');
     if (bbutton.length>0) {
         let bbutton1=bbutton.find('button');
         if (skipNoImage==1) {
            let isnotimg=bbutton1.attr('isnotimg');
            if (isnotimg!='') continue;
         }
         bbutton1.trigger('click');
     }
  }

 
 }

 
//=================
// 'a' key hit... add favorites (if favorites container is open
function doFavoritesAdd(evt) {
   let vvis=wsurvey.flContents.visible('favorites');
   if (vvis==0) return 0;
   doFavorites(this,1);
   window.setTimeout(function() {
      $('#iCreate_saveEntry').trigger('click');
   },50);
  return 1;
}

//===============
// f1 key hit.  Find a help topic in top (next to close on esc) and show that.
// if none, show main help
function doF1Help(evt) {
   let ethis=wsurvey.argJquery(evt);
   let enext=wsurvey.flContents.container.doEsc(0,1);
   let etopic=enext.find('[topic]');
   if (etopic.length==0)  {
       doHelpVu(0,1,'Intro') ;
       return 1;
   }
   let atopic=etopic.attr('topic');
       doHelpVu(0,1,atopic) ;
//   etopic.trigger('click');
  return 1 ;
}

//================
//pgup  (33) or pgdown(34) if
function doPgupPgdn(evt){
   let exx=wsurvey.flContents.find('gallery','#listOfFileInCurrentDir');
   if (exx.length==0) return true ; // ignore if filelist not visible
   if (evt.which==33) {
      doSlideShowNext(0,-1);
   } else {
      doSlideShowNext(0,1);
   }
   return 1;
}

//===========================
// toggle display of the options in the header of a file list -- show/ not show the text
function toggleTextInFileViewerOptions(athis) {
  ethis=wsurvey.argJquery(athis);
  let doclass=ethis.wsurvey_attr('do','');
  let astatus=parseInt(ethis.wsurvey_attr('status',0));
  astatus=1-astatus;
  ethis.attr('status',astatus);

  ee=ethis.wsFlFind('.'+doclass,1);  // siblings with doclass

  let eoof=$('#showTextInOptions');
  if (astatus==1) {
      ee.show();
      eoof.removeClass('redLineThrough');
  } else {
     ee.hide();
      eoof.addClass('redLineThrough');
  }
  return 1;
}

//==========================
// switch the current tree (the tree -- of the directories to view
// this changes variables locally and on the server
 // hideTl=1 : do NOT show the tree list (after switching the current tree)  Feb 2022 : not currently used

function switchCurrentTree(athis,atree,hideTL) {
   var atreeSay=atree;
   if (arguments.length<2) {
     let ethis=wsurvey.argJquery(athis);
     atree=ethis.attr('data-actual');
      atreeSay=ethis.text();
   }
   if (arguments.length<3) hideTL=0;

   var adata={'todo':'switchTree','treeName':atree,'hideTreeList':hideTL,'treeNameAlt':atreeSay }  ;
   wsurvey.getJson.get('wsGalleryActions.php',adata,switchCurrentTree2,'switchCurrentTree');


   function switchCurrentTree2(response,origData) {
      var hideTreeList=0;
      hh=wsurvey.getJson.check(response,0,'switchCurrentTree2: Unable to ... change currentTree to ['+atree+']');
      if (hh===false) return 1;

    if (origData.hasOwnProperty('hideTreeList'))    hideTreeList=origData['hideTreeList']  ;
      $(document).data('currentTree' ,atree);       // after successful switchCurrentTree: change the "currentTree" to be this   one!
      $(document).data('currentTreeAlt' ,atreeSay);       // used in title of buttons
      window.setTimeout(function(){
          loadTreeDirs(0,'switch tree',hideTreeList);
          wsurvey.flContents.onTop('dirList',1);
          toggleDirVu_2(1,1);  // collection/facvorit/gallery buttons
       },150);  // last step in switchCurrentTree: display list of directories in the "current  tree"  (loadTreeDirs is in wsgallery_dirvu.js)
      return 1;
   }        //switchCurrentTree2
}

//=--------------------------
function toggleSwitchTreeMenu(doit) {

   let e1=$('#switchTreeMenu');
   if (doit==1 || !e1.is(':visible')) {
      e1.show();
   } else {
      e1.hide();
      return 1;
   }

   wsurvey.flContents.scrollTop('dirList',55,0) ;
   let edom=wsurvey.flContents.dom('dirList','m');  // scroll to top of dirLIst (where the tree switch menu is)

   let currentTree=$(document).data('currentTree'); // highlight current tree
   let currentTreeStatus=$(document).data('currentTreeStatus');
   let e3=edom.find('.cswitchTreeMenu');
   let e4=e3.find('[treenameswitch]')  ;
   for (var ie4=0;ie4<e4.length;ie4++) {
      let ae4=$(e4[ie4]);
      ae4.removeClass('switchTreeMenu_currentTree');
      let tname=ae4.attr('treenameswitch');
      if (tname==currentTree) {
          ae4.addClass('switchTreeMenu_currentTree');
      }
      if (currentTreeStatus.hasOwnProperty(tname)) {
          if (currentTreeStatus[tname].hasOwnProperty('disable')) {
              let adisable=currentTreeStatus[tname]['disable'];
              if (adisable==1) {
                  ae4.prop('disabled',true);
                  ae4.css({'opacity':0.3});
                  let atitle=ae4.wsurvey_attr('title','');
                  ae4.attr('title',atitle+' : this tree is disabled. Directories and files are not viewable ');
              }  // disable =1
          }   // disable property
      }    // tname property
   }    // tweak dispaly of each tree button in treeswitch menu

// hide disabled trees 

   return 1;
 }

//=========
// a compressed list of diretories in current tree
function viewDirListCompressed(athis) {
  let edir=$('#iCompressedDirList');
  if (edir.is(":visible")) {
     edir.hide();
     return 1;
  }

  let aa=edir.attr('data-gotevent');
  if (typeof(aa)=='undefined') aa=0;

  if (aa==0) {  // click handler not yet assigned
      edir.on('click',viewDirListCompressedJump);
      edir.attr('data-gotevent',1);
  }
  let ee=wsurvey.flContents.find('dirList','[name="dirListFileViewFiles"]');
  let amess='<ul class="linearMenu">';
  for (let ie=0;ie<ee.length;ie++) {
     let aee=$(ee[ie]);
     let aval=aee.val();
     amess+='<li class="linearMenuLiSmall"><input type="button" class="jumpButtonClass" xonClick="viewDirListCompressedJump(this)" value="'+aval+'"></li>';
  }
  amess+='</ul>';
 $('#iCompressedDirList').html(amess).show();

}
function viewDirListCompressedJump(athis) {
  let ethis=wsurvey.argJquery(athis);
  if (!ethis.hasClass('jumpButtonClass')) return 1 ; // not a jump to dir button

  let adir=ethis.val()  ;
  $('#iCompressedDirList').hide();

  let edtable=$('#dirListingTable');
  let toff=edtable.offset();
  let toffTop=parseInt(toff.top);

  let oink1='[dir="'+adir+'"]' ;
  let eoink1=$(oink1);
  oinkOffset1=eoink1.offset();
  let oinkTop1=parseInt(oinkOffset1.top);
  let dtop=oinkTop1-toffTop;
  wsurvey.flContents.scrollTop('dirList',310,dtop);
  return 1;
}

//======================
// modes:
// # arguments
//     1 - click on screen layout buttons, to choose between 2 viewer, rotating viewer, tableau, and single Viewer
//     2  -  click on one of the dropdown buttons under the screen layout buttons
//     4 - click on a "2 viewer default" button

// iwhich (dual viewer presets):
//   0: small 1, medium 2, no 3, large filelist -- for quick review
//   1: small 1, large 2, no 3, medium filelist -- for slower review and consideraton
//   2: small 1 , larger 2, no 3, small filelist -- for detailed loks

// iwhich: (layout choice)
//   0: dual viewer (Default is 0)
//  1:  equisized 1, 2, 3, and filelist : for rotating through images (most recent 3 are visible, new selections replaced in a rotating fashon
//  2 : filelist at top, 1 big viewe 1 : for "tableau" mode.
//  3:  single image      2/3 screen single image (pre june 2022: was full screen single image)
//  4: single viewer  -- 4ull screen single image   (pre june 2022: was full 2/3 screen single image)
//
// a1, if specified, signals "choice of dualViecwer variant"
// resizers

function doResizeViewers(athis,iwhich,a1) {
   var ethis ,iwhich_noRedisplay=0 ;      // default is to display most recent image in new layout (but can be suppressed)
   var einfo2=$('#getImgInfo') ;
   var einfo2L=$('#getImgInfoL') ;  // label for "show image info" button (in filelist menu)
   var qinfo=einfo2.prop('checked');

   var  isDualViewer=0  ; // 1 means "choice between dual viewer defaults"
   let lenargs=arguments.length;

   let etargets=$('.targetHereButton');
   etargets.hide();  // only used in rotating viewer
   wsurvey.flContents.headerView('snapBox1','show') ;  // undo hiding if dual view

   if (lenargs==1)    {   // main screen layout buttons  0: dual viewer, 1: rotating, 2:tableau, 3: single 2/3, 4: single full
     ethis=wsurvey.argJquery(athis);
     iwhich=parseInt(ethis.attr('which'));
     iwhich++;
     if (iwhich>3) iwhich=0;    // june 2022: was 4 (but no longer support large single image as top level screenlayout
     $(document).data('screenLayout',iwhich);  // default is dual viewer
   }
   if (lenargs==2)    {   // main screen dropdown list buttons  0: 2 viewer, 1: rotating, 2:tableau, 3: singleLarge, 4=single pair
     if (jQuery.isArray(iwhich)) {
         iwhich_noRedisplay=iwhich[1];
         iwhich=iwhich[0];
     }
     $(document).data('screenLayout',iwhich);  // default is dual viewer (or singlePair)
   }

   if (lenargs>2) {      // doResizeViewers2 handles the button click and calls here
     $(document).data('screenLayout',0);  // default is dual viewer
     $(document).data('screenLayout_dual',iwhich);  // default is dual viewer
     isDualViewer=1  ;   // which read from args
  }
  if (iwhich==0) isDualViewer=1;

  if (isDualViewer) {
     $('#toggleViewers_2').show();
     $('#toggleViewers_2_alt').show();
     $('[name="imageJumpButtons"]').show();
     $('.cCurrentImageCursorSpot').show();

  } else {
    $('#toggleViewers_2').hide();
    $('#toggleViewers_2_alt').hide();
     $('[name="imageJumpButtons"]').hide();
     $('.cCurrentImageCursorSpot').hide();
  }

// note: if isDualViewer, button display taken care of in doViewerReset2

// main screen layout toggle button --- so change the button display
   if ( lenargs==1 || lenargs==2 || lenargs==3) {
      if (lenargs==2 || lenargs==3) ethis=$('#iToggleScreenLayout');
      let titleList=$(document).data('screenLayout_titleList');
      let titleBase=$(document).data('screenLayout_titleBase');
      let iconList=$(document).data('screenLayout_iconList');
      let classList=$(document).data('screenLayout_classList');
      xx=classList.join(' ');
      ethis.removeClass(xx);
      let nwhich= (lenargs>2) ? a1 : iwhich ;
      if (isDualViewer==1) nwhich=0  ;   // june 2022 hack fix

      ethis.addClass(classList[nwhich]);

      ethis.html(iconList[nwhich]);
      ethis.attr("title",titleBase+': '+titleList[nwhich]);
      ethis.attr("which",nwhich);

   }


// the layout changes...
     wsurvey.flContents.container.doResize('snapBox1','R');
     wsurvey.flContents.container.doResize('snapBox2','R');
     wsurvey.flContents.container.doResize('snapBox3','R');
     wsurvey.flContents.container.doResize('tableau','R');
     wsurvey.flContents.container.doResize('gallery','R');
     wsurvey.flContents.container.doResize('singleImage','R');

   $('[name="tableauButtons"]').hide();

   if (isDualViewer==1)  {  // dual viewer
     wsurvey.flContents.hide(2,'singleImage');
     wsurvey.flContents.hide(2,'tableau');
     wsurvey.flContents.hide(2,'snapBox3');
     wsurvey.flContents.show(12,'snapBox1');
     wsurvey.flContents.show(22,'snapBox2');

     $('#currentImageJumpButton').show();
     $('#currentImageContinuousScrollButton').show();
     $(document).data('currentScreenLayout','dual') ;  


// default is large file viewer and two almost equi sized image viewers
     if (iwhich==0) {   // dual viewers: resize to original (as done above) -- large file lister (1/2 screen), 2 1/4 screen viewers

        let dosaves={'shrink':'asis','snap':'full','viewer':'combo','info':1};    // combo mode may override thes
        let doenables={'shrink':0,'snap':1,'viewer':1,'info':1};
        daopts={'save':dosaves,'enable':doenables};
        doResizeViewers_setButtons(daopts);

     }

     if (iwhich==1)  {                  // expanded  viewer 2 and smaller filelist (similer layout as singleImage viewer

        let s2={'top':'6%','left':'64%','width':'33%', 'height':'57%'};
        wsurvey.flContents.container.doResize('gallery',s2)

        let sg={'top':'6%','left':'4%','width':'59%', 'height':'91%'};
        wsurvey.flContents.container.doResize('snapBox2',sg);

        let s1={'top':'69%','left':'64%','width':'33%', 'height':'27%'};
        wsurvey.flContents.container.doResize('snapBox1',s1)

        wsurvey.flContents.show('gallery',55);
        wsurvey.flContents.hide('singleImage',55);


        let qinfo=$('#getImgInfo').prop('checked');
        let einfos=$('[name="iimageInfoSnap"]');
        if (qinfo) {
           einfos.show();
        } else {
           einfos.hide();
        }

        let dosaves={'shrink':'asis','snap':'full','viewer':'combo','info':1}; // same as which=0
        let doenables={'shrink':0,'snap':1,'viewer':1,'info':1};
        daopts={'save':dosaves,'enable':doenables};
        doResizeViewers_setButtons(daopts);

    }           // dualViewer larger 2nd viewer

    if (iwhich==2) {     // custom (default large viewer2, small filelist and viewer1)

// top left width height ...
//        let s1={'top':'3%','left':'58%','width':'40%', 'height':'15%'};

       let s1_f=$(document).data('preset3_fileList').split(',');
       let sp3_f={'top':s1_f[0],'left':s1_f[1] , 'width':s1_f[2]  ,'height':s1_f[3] }  ;
        wsurvey.flContents.container.doResize('gallery',sp3_f);

//        let s2={'top':'4%','left':'1%','width':'50%','height':'20%'};
       let s1_1=$(document).data('preset3_viewer1').split(',');
       let sp3_1={'top':s1_1[0],'left':s1_1[1] , 'width':s1_1[2]  ,'height':s1_1[3] } ;
        wsurvey.flContents.container.doResize('snapBox1',sp3_1)  ;

//        let s3={'top':'31%','left':'1%','width':'94%','height':'60%'};
       let s1_2=$(document).data('preset3_viewer2').split(',');
       let sp3_2={'top':s1_2[0],'left':s1_2[1] , 'width':s1_2[2]  ,'height':s1_2[3] }  ;
        wsurvey.flContents.container.doResize('snapBox2',sp3_2)    ;

        $('#getImgInfo').prop('checked',false);  // suppress info display
        let einfos=$('[name="iimageInfoSnap"]');

        for (var i0=0;i0<einfos.length;i0++) {
          let aeinfo=$(einfos[i0]);
          let aeinfo1=aeinfo.wsFlClosest();
          if (aeinfo1.attr('id')=='snapBox1') aeinfo.hide();
        }

        let dosaves={'shrink':'asis','snap':'full','viewer':'combo','info':0};     // hide info
        let doenables={'shrink':0,'snap':1,'viewer':1,'info':1};
        daopts={'save':dosaves,'enable':doenables};
        doResizeViewers_setButtons(daopts);

       if (iwhich_noRedisplay==0) redisplayRecentImage(0);
//        $('#redisplayImage').trigger('click');  // rdisplay using this new layout

    }      // dualViewer largest dual view

  } else {     // not a dual view

     $('#currentImageJumpButton').hide();
     $('#currentImageContinuousScrollButton').hide();

    if (iwhich==1) {     // rotating viewer
     $(document).data('currentScreenLayout','rotating') ;

       let s1={'top':'5%','left':'1%','width':'48%', 'height':'35%'};
       wsurvey.flContents.container.doResize('gallery',s1)

       let s2={'top':'2%','left':'51%','width':'47%','height':'41%'};
       wsurvey.flContents.container.doResize('snapBox1',s2)

       let s3={'top':'48%','left':'1%','width':'48%','height':'44%'};
       wsurvey.flContents.container.doResize('snapBox2',s3)

       let s4={'top':'51%','left':'51%','width':'47%','height':'41%'};
       wsurvey.flContents.container.doResize('snapBox3',s4)

        wsurvey.flContents.show(12,'snapBox1');
        wsurvey.flContents.show(22,'snapBox2');
        wsurvey.flContents.show(32,'snapBox3');
        wsurvey.flContents.hide(42,'tableau');
        wsurvey.flContents.hide(42,'singleImage');
        let dosaves={'shrink':'shrink','snap':'snapshot','viewer':'viewer1','info':0}; // same as which=0
        let doenables={'shrink':1,'snap':1,'viewer':0,'info':1};
        daopts={'save':dosaves,'enable':doenables};
        doResizeViewers_setButtons(daopts);
         $('.cCurrentImageCursorSpot').show();

        etargets.show();  // select this viwer buttons

    }   // end of rotating viewer

    if (iwhich==2) {     // tableau viewer
         $(document).data('currentScreenLayout','tableau') ;

        let s1={'top':'5%','left':'1%','width':'88%', 'height':'34%'};
        wsurvey.flContents.container.doResize('gallery',s1)

        let s4={'top':'11%','left':'6%','width':'90%','height':'80%'};
        wsurvey.flContents.container.doResize('tableau',s4)

        $('#getImgInfo').prop('checked',false);  // suppress info display
        let einfos=$('[name="iimageInfoSnap"]');

        for (var i0=0;i0<einfos.length;i0++) {
           let aeinfo=$(einfos[i0]);
           let aeinfo1=aeinfo.wsFlClosest();
           if (aeinfo1.attr('id')=='snapBox2') aeinfo.hide();
           if (aeinfo1.attr('id')=='snapBox3') aeinfo.hide();
        }

        wsurvey.flContents.hide(12,'snapBox1');
        wsurvey.flContents.hide(22,'snapBox2');
        wsurvey.flContents.hide(32,'snapBox3');
        wsurvey.flContents.show(42,'tableau');  // filelist ('gallery') is still displayed
        wsurvey.flContents.hide(42,'singleImage');

        let dosaves={'shrink':'shrink','snap':'snapshot','viewer':'viewer1','info':0}; // same as which=0
        let doenables={'shrink':1,'snap':1,'viewer':0,'info':1};
        daopts={'save':dosaves,'enable':doenables};
        doResizeViewers_setButtons(daopts);
        wsurvey.flContents.onTop('gallery',1);
       $('[name="tableauButtons"]').show();

        if (iwhich_noRedisplay==0) redisplayRecentImage(0);
       tableauMode(0,1);  // file list above view (no overlap)

    }   // end of tableau viewer

    if (iwhich==4) {    // single full screen viewer with filelist (pre june 2022: was 3) -- semi deprecated
        $(document).data('currentScreenLayout','single') ;
        let s1={'top':'7%','left':'21%','width':'58%', 'height':'24%'};
        wsurvey.flContents.container.doResize('gallery',s1)
        wsurvey.flContents.show('gallery',55);
        wsurvey.flContents.show('singleImage',55);
        wsurvey.flContents.hide('snapBox2',15);
        wsurvey.flContents.hide('snapBox1',15);
        wsurvey.flContents.hide('snapBox3',15);
        wsurvey.flContents.hide('tableau',15);


        let dosaves={'shrink':'shrink','snap':'full','viewer':'viewer1','info':0}; // same as which=0
        let doenables={'shrink':1,'snap':1,'viewer':0,'info':1};
        daopts={'save':dosaves,'enable':doenables};
        doResizeViewers_setButtons(daopts);
        wsurvey.flContents.onTop('singleImage');

        if (iwhich_noRedisplay==0) {
           redisplayRecentImage(0);
        }
        wsurvey.flContents.onTop('singleImage',55);

        return 1;
    }      // end of singleImageLarge viewer


   if (iwhich==3) {                // single viewer  2/3 (june 2022: was 4)

        $(document).data('currentScreenLayout','single') ;

        let s1={'top':'7%','left':'64%','width':'35%', 'height':'84%'};
        wsurvey.flContents.container.doResize('gallery',s1)

        wsurvey.flContents.show('gallery',55);
        wsurvey.flContents.show('singleImage',55);

        let s1a={'top':'7%','left':'4%','width':'59%', 'height':'84%'};
        wsurvey.flContents.container.doResize('singleImage',s1a);

        wsurvey.flContents.hide('snapBox2',15);
        wsurvey.flContents.hide('snapBox1',15);
        wsurvey.flContents.hide('snapBox3',15);
        wsurvey.flContents.hide('tableau',15);

        let dosaves={'shrink':'shrink','snap':'snap','viewer':'viewer2','info':1};
        let doenables={'shrink':1,'snap':1,'viewer':0,'info':1};
        daopts={'save':dosaves,'enable':doenables};
        doResizeViewers_setButtons(daopts);
        wsurvey.flContents.onTop('snapBox2');
        wsurvey.flContents.onTop('gallery');

        if (iwhich_noRedisplay==0) {
           redisplayRecentImage(0);
        }
        wsurvey.flContents.onTop('singleImage');


// tweak size of single imge viewer "columns" -- wait .1 seconds for dom to settle
// goal is to make sure that left col is to the right of the middle col, and is not outsize of outer box
        window.setTimeout(function() {
           let mdid=0,emidLeft,emidRight,efbLeft,efbRight,essLeft,essRight;
           for (let m=0;m<20;m++) {    // give up after 10 shrinks
              let eenew=doResizeViewers_singleTweak(m);

              let emid=$('#singleImageContentM');
              let efb=$('#iSingleImageFilelist');
              let ess=$('#singleImageContentOuter');
              let emidRect=emid[0].getBoundingClientRect();
              let efbRect=efb[0].getBoundingClientRect();
              let essRect=ess[0].getBoundingClientRect();
              emidLeft=parseInt(emidRect.left), emidRight=parseInt(emidRect.right);
              efbLeft=parseInt(efbRect.left), efbRight=parseInt(efbRect.right);
              essLeft=parseInt(essRect.left), essRight=parseInt(essRect.right);
              if ((6+efbLeft)>emidRight && (6+efbRight)<essRight) {       // left edge of file box bfore reight edge of viewer box
                 mdid=m;
                 break;
              }

//             }
          }   // done with tweaking
          wsurvey.flContents.onTop('dirList');

        },200) ;  // timeout
     }   //  end of singleImagePair viewer

      return 1;


  }         // not dual layout

// resize control buttons?

   var ec1=$('#showTextInOptions');
   if (ec1.length>0) {
      let off1=ec1.offset();
      let top1=off1['top'];
      let ec2=$('#iNextPriorImageButtons');
      let off2=ec2.offset();
      let top2=off2['top'];
      let tdiff=Math.abs(top1-top2);
      if (tdiff>8)  { // on different lines, so try removing button text
        let zz1=ec1.attr('status');
        if (zz1==1) ec1.trigger('click');
      }
   }

  return 1;

}

// =================
// tweak size of single image viewer (to ensure that right col is visible
// returns new width
function doResizeViewers_singleTweak(ii) {
    let emiddle=$('#singleImageContentM');
    let emiddleWidth=emiddle.width();
    let emiddleNew=parseInt(94-ii);
    emiddle.css({'width':emiddleNew+'%'});
    return emiddleNew ;

}

//======================
// doresize viewers -- dual viewer presets
//   0: small 1, medium 2, no 3, large filelist -- for quick review
//   1: small 1, large 2, no 3, medium filelist -- for slower review and consideraton
//   2: small 1 , larger 2, no 3, small filelist -- for detailed loks
// resizers

//   let aiconList=["&#10697;","&#8862;","&#9638;","&#128618;",'&#9704;'] ;
//   let atitleList=["Dual viewers and a fileList ",
//                    "Rotating view (2x2 grid)",
//                     "Images added in a 2 column grid",
//                     "One image at a time covering most of screen",
//                     "One image on 2/3 screen, file list on  1/3"];
//   let aclassList=['cToggleScreenLayout','clargeViewerRotating','clargeViewerTableau','clargeViewerSingle','cToggleScreenLayoutSingle'];

//
function doResizeViewers2(athis) {
   var ethis=wsurvey.argJquery(athis);

   var iwhich=ethis.attr('which');
   iwhich++;
   if (iwhich>2|| iwhich<0) iwhich=0 ;

   ethis.attr('which',iwhich);
   let iconList_dual=$(document).data('screenLayout_iconList_dual');
   ethis.html(iconList_dual[iwhich]);

   let classList_dual=$(document).data('screenLayout_classList_dual');
   let xx=classList_dual.join(' ');
   ethis.removeClass(xx);
   ethis.addClass(classList_dual[iwhich]);

   let titleBase= $(document).data('screenLayout_titleBase_dual');
   let titleList_dual=$(document).data('screenLayout_titleList_dual');
   ethis.attr('title',titleBase+': '+titleList_dual[iwhich]);
 
   doResizeViewers(0,iwhich,1);    // does the work
   return 1;

}
//=================
// Change state and enableStatus of several filelist option buttons: shrink desired, snapshot desired, viewer desired
// Opts contains list of buttons to tweak.
//    It should contain two arrays: 'set' and 'enable'
//   Both of which can have the same indidces: 'shrink','snap','viewer','info'
//   enable: which
//  For set, the allowable values are:
//      'shrink':   -1=nochange, 1=asis, 2=stretch,3=shrink    (asis means "display image as recieved from server"
//       'snap' :   -1=nochange, 1=full (no resizing), 2=snapshot (640x480), 3=custom (ResizedImage)
//      'viewer':   -1=nochange, 0=combo, 1=viewer 1, 2 =viewer2, 3=external
//      'info':      -1=nochange, 0=disable, 1=enable     -- disavle ALSO closes info displays in viewers
// Note: shrink is 'browser side image transformations (if any), snap is server side image transformations (if any)
// For enable, the allowed values are the same for all 4
//               -1=do not change, 0=disable, 1=enable
// Note that for indices, -1 for  the same as NOT specifying one of these indices (no change)
// You can specify as many of these 4 as you want, in either index. Not specifying means "don't change"
// SO not specifying something (say, 'shrink') in either means 'shrink' is not changed
// return 1 on success, 0 on error (after an alert)
function doResizeViewers_setButtons(opts) {
  var sval,bVal ;
  var okIndices={'shrink':[-1,1,2,3],'snap':[-1,1,2,3],'viewer':[-1,0,1,2,3],'info':[-1,0,1]};
  var okTexts={'shrink':['nochange','asis','stretch','shrink'],
              'snap':['nochange','full','snapshot','custom'],
              'viewer':['nochange','combo','viewer1','viewer2','external'],
              'info':['nochange','disable','enable']};
  var daFuncs={'shrink':'toggleShrinkToFit','snap':'toggleSnapshotGet','viewer':'toggleWhichViewerGet','info':'toggleViewInfo'};

//  var aIds={'shrink':'#shrinkToFit','snap':'#getSnapshotImage','viewer':'#iWhichViewer','info':'#getImgInfo'};

  var mySave= (typeof(opts['save'])=='undefined') ? [] : opts['save'] ;
  var myEnable=(typeof(opts['enable'])=='undefined') ? [] : opts['enable'] ;
  let errs=[];
  for (aindx in okIndices) {   // set defaults
      if (typeof(mySave[aindx])=='undefined') mySave[aindx]=-1;
      if (typeof(myEnable[aindx])=='undefined') myEnable[aindx]=-1;
  }
  for (aindx in okIndices) {   // set defaults
      sval=mySave[aindx];
      let sval0=sval;
     if (isNaN(sval))  {  // maybe a synonym?
        sval=jQuery.trim(sval).toLowerCase();
        if (jQuery.trim(sval.substr(0,2))=='no') sval='nochange'  ;  // another synonym  (ie; no
        if (jQuery.trim(sval.substr(0,4))=='snap') sval='snapshot'  ;  // another synonym  (ie snap
        if (jQuery.trim(sval.substr(0,4))=='cust') sval='custom' ;  // another synonym (ie customResize
        if (jQuery.trim(sval.substr(0,4))=='full') sval='full' ;  // another synonym (i.e.; fullimage
        if (isNaN(sval)) {  // not one of the above matches
           let goob=jQuery.inArray(sval,okTexts[aindx]);
           if (goob>-1 ) sval=okIndices[aindx][goob] ; // a hack to use text synonym
           if (isNaN(sval)) {
              errs.push('Bad save (synonym) value for '+aindx+': '+sval0);
              continue;
          }
        }
     }
     sval=parseInt(sval);

     if (jQuery.inArray(sval,okIndices[aindx])<0 ) {
         errs.push('Bad save value for '+aindx+': '+sval0);
     } else {
        mySave[aindx]=sval;
     }
     bVal=jQuery.trim(myEnable[aindx]);
     if (bVal=='nochange') bVal=-1;
     if (bVal=='disable') bVal=0;
     if (bVal=='enable') bVal=1;
     bVal=parseInt(bVal);
     if (jQuery.inArray(bVal,[-1,0,1])<0)  {
        errs.push('Bad enable value for '+aindx+': '+bVal);
     } else {
       myEnable[aindx]=bVal;
     }

  }
  if (errs.length>0) {  // any mispec is fatal
      let say1=errs.join('\n');
      alert(say1);
      return 0;
  }

// got legit values. Now do them
   for (aindx in okIndices) {
      let asave=mySave[aindx];
      let aenable=myEnable[aindx];
      let afunc=daFuncs[aindx];
      if (asave<0 && aenable<0) continue ; // do nothing (eg, not mentioned in either save or enable)
      window[afunc]('',asave,aenable); // these deal with -1 values for asave, and the '' means "use default id of your button)
   }
   return 1 ;

}

///============================= was
// zoom in, or out, in viewer2. Or recenter
function zoomViewer2(athis) {
   var ethis=wsurvey.argJquery(athis) ;
   var eImgH2,eImgW2,origW,origH,outerXs,outerYs ;
   var iwhich=ethis.wsurvey_attr('zoom',1);

    ep1=ethis.wsFlClosest();
    eOuter=ep1.wsFlFind('.snapShotImgOuter');

   var eImg=eOuter.find('img');

   var eImgH=parseInt(eImg.height()),eImgW=parseInt(eImg.width());  // size of image currently (possibly after prior zooms)

   var origW=eImg.wsurvey_attr('origW','x');
   if (origW=='x')  {               // not set, so set to this w and h to be current
       origW=eImgW;
       origH=eImgH;
       eImg.attr('origW',origW);
       eImg.attr('origH',origH);
       outerXs=eOuter.scrollLeft();
       outerYs=eOuter.scrollTop();
       eImg.attr('outerXs',outerXs);
       eImg.attr('outerYs',outerYs);

    } else {
       origH=eImg.wsurvey_attr('origH','x');  // use in title
       outerXs=eImg.wsurvey_attr('outerXs' );
       outerYs=eImg.wsurvey_attr('outerYs' );
   }

   if (iwhich==2)  {                  // recenter. Changes the "scroll viewer button", so that clicking (or triggering) will zoom to current left edge
       outerXs=eOuter.scrollLeft();
       outerYs=eOuter.scrollTop();
       let  xPctInContainerNew=outerXs/eImgW ;
       let yPctInContainerNew =outerYs/eImgH ;
        let ecb=$('#currentImageJumpButton');
        ecb.attr('xpctat',xPctInContainerNew);
        ecb.attr('ypctat',yPctInContainerNew);
        let atitle='Viewer2 to: x='+parseInt(100*xPctInContainerNew)+'% / y='+parseInt(100*yPctInContainerNew)+'% ';
        ecb.val(atitle);
      return 1;
   }

// if here, zoom in or zoom out  -- and recenter at current scroll viewer 2 location (hack to slow down image creep
   if (iwhich==0)  { // zoom out
      eImgH2=Math.max(0.9*eImgH,20);
      eImgW2=Math.max(0.9*eImgW,20);
    } else {
      eImgH2=Math.min(1.1*eImgH,20000);
      eImgW2=Math.min(1.1*eImgW,20000);
    }
   eImgH2=parseInt(eImgH2);   eImgW2=parseInt(eImgW2);
   eImg.attr('width',parseInt(eImgW2));
   eImg.attr('height',parseInt(eImgH2));
   $('#currentImageJumpButton').trigger("click");
   var asrc=eImg.wsurvey_attr('src','n.a.');
   var title2= asrc+' \nZoomed to: '+eImgW2 + ' x '+eImgH2+ ' (original was: '+origW  + ' x '+origH+'). ';
   title2+='\nClick on image to scroll ';
   eImg.attr('title', title2 );


}
//=====================
// logoff, with -- note use of doLogoff2 callback
function doLogoff(athis) {    // after submitting password
  wsurvey.adminLogon_logoff('wsGallery','doLogoff2');
}
function doLogoff2(amode,acontent) {
    $('#logonButton').show();
    $('#logoffButton').hide();
    $('#showAdminEnableButton').hide();
    $(document).data('adminModeEnabled',0);
}


//=============================
// callback supplied to wsCheckLogon (in wsCheckLogonParams).  logon okay .. change some items
function wsGallery_logonCallback(amode,aLogonName,timeLeft) {    // after submitting password

  if (amode==0) {  // logon failure
        alert('try again');
         $('#fooa').css('border','4px solid blue');
        return 1;
   }



   let nowtime=Date.now();
   let expiryTime=nowtime+(timeLeft*1000);
   let expiryTime2=new Date(expiryTime);
   let expiryTimeStamp=expiryTime2.toLocaleString('en-US');

   $(document).data('logonStatus',timeLeft);    // sort of redundant with adminLogon created   wsurveyadminLogon_status_wsGallery
   let arf= $('#showAdminEnableButton');
   arf.show();
   $('#logonButton').hide();
   doAdmin(0) ;

   var elogoff=$('#logoffButton');
   elogoff.show();
   let atitle=elogoff.attr('origTitle');
   if (amode=='prior') {
        atitle=atitle+'  prior logon active until '+expiryTimeStamp;
   } else {
        atitle=atitle+'  new logon expires @ '+expiryTimeStamp;
   }
   elogoff.attr('title',atitle);

   wsurvey.flContents.hide('admin',10);
   $('#logonHere').hide();
   return 1;
}


//=============================
// callback supplied to wsCheckLogon (in wsCheckLogonParams).   adming logon to initialize a tree
function wsGallery_logonCallback_fix(amode,aLogonName,timeLeft) {    // after submitting password
  if (amode==0) {  // logon failure
        alert('try again');
         $('#fooa').css('border','4px solid blue');
        return 1;
   }

   wsurvey.flContents.contents('admin','<br> ... trying to fix ...',{'show':1,'append':1});

   var adata={'todo':'logonAdmin_fix'  }  ;
   wsurvey.getJson.get('wsGalleryActionsAdmin.php',adata,wsGallery_logonCallback_fix2,'wsGallery_logonCallback_fix');
 }
  function wsGallery_logonCallback_fix2(response,origData) {
      hh=wsurvey.getJson.check(response,0,'wsGallery_logonCallback_fix2');
      if (hh===false) return 1;
      let hcontent=hh['content'];
      let hstatus=hcontent[0];
      if (hstatus==false) {
         wsurvey.flContents.contents('admin','<br>Problem:<tt>'+hcontent['message']+'</tt>',{'show':1,'append':1});
         return 1;
      }

// if here succkess
      let amess='Treelist updated!';
      amess+='<br>Please <input type="button" value="Reload wsGallery" onclick="location.reload(true);">';

      amess+='<hr width="30%" > The following trees were initialized, in gallery <u>'+hcontent['gallery']+'</u>'

      amess+='<ul><li>'+hcontent[1].join('<li>')+'</ul>';
      amess+='<hr>Messages:';
      amess+='<ul><li>'+hcontent['messages'].join('<li>')+'<ul>';

      wsurvey.flContents.contents('admin',amess,{'show':1,'append':1});
      return 1;

}

//=================
//=============================
// callback supplied to wsCheckLogon  -- admin logon to fix wsGalelry parameters
function wsGallery_logonCallback_params(amode,aLogonName,timeLeft) {    // after submitting password
  if (amode==0) {  // logon failure
        alert('try again');
         $('#fooa').css('border','4px solid blue');
        return 1;
   }

   wsurvey.flContents.contents('admin','<br> ... trying to fix parameters ...',{'show':1,'append':1});

   var adata={'todo':'logonAdmin_fixParams'  }  ;
   wsurvey.getJson.get('wsGalleryActionsAdmin.php',adata,wsGallery_logonCallback_params2,'wsGallery_logonCallback_params');
 }
  function wsGallery_logonCallback_params2(response,origData) {
      hh=wsurvey.getJson.check(response,0,'wsGallery_logonCallback_params2');
      if (hh===false) return 1;
      let hcontent=hh['content'];
      if (hcontent[0]===false) {
        wsurvey.flContents.contents('admin','<br><b>Error updating wsGallery parameters.<br></b>'+hcontent[1],{'show':1,'append':1});
        return 1;
      }
      let bmess='<br>Please <input type="button" value="Reload wsGallery" onclick="location.reload(true);">';
         bmess+='<br><b>wsGallery parameters have been updated. ';
      wsurvey.flContents.contents('admin',bmess,{'show':1,'append':1});

}

//=============================
// callback supplied to wsCheckLogon  -- admin logon to fix spinner  parameters
function wsGallery_logonCallback_spinners(amode,aLogonName,timeLeft) {    // after submitting password
  if (amode==0) {  // logon failure
        alert('try again');
         $('#fooa').css('border','4px solid blue');
        return 1;
   }

   wsurvey.flContents.contents('admin','<br> ... trying to fix spinners ...',{'show':1,'append':1});

   var adata={'todo':'logonAdmin_fixSpinners'  }  ;
   wsurvey.getJson.get('wsGalleryActionsAdmin.php',adata,wsGallery_logonCallback_spinners2,'wsGallery_logonCallback_spinners');
 }
  function wsGallery_logonCallback_spinners2(response,origData) {
      hh=wsurvey.getJson.check(response,0,'wsGallery_logonCallback_spinners2');
      if (hh===false) return 1;
      let hcontent=hh['content'];
      let bmess='<br>Please <input type="button" value="Reload wsGallery" onclick="location.reload(true);">';
      bmess+='<br><b>wsGallery spinners have been updated (there are '+hcontent.length+' spinners available)';
      wsurvey.flContents.contents('admin',bmess,{'show':1,'append':1});

}


//============ ==========================================
// retrieve files in selected   dir, displayed using names or thumbnails. Several different layouts supported

function getDirFileListJs(athis) {
  
   var ethis=wsurvey.argJquery(athis);
  var adir=ethis.wsurvey_attr('dir','');

  let ett=$('[name="toggleDirVu_gallery"]');   // used to jump to button for this directory
   if (ett.length==1) ett.attr('data-last',adir);


  var ihow=ethis.wsurvey_attr('how',-1);     //0=text, 1=small, 2=medium, 3=large.. maybe in the futurwe 4=very large
// -if -1, use useThumbnails from parans.php

  if (ihow=='-1') ihow= $(document).data('useThumbnails');  // first time call ?

  var treeName=ethis.wsurvey_attr('treeName','');
  var showFileNames=[2,0,1,2,2];   // text,small,medium,big,bigger. 0=no, 1=snippet,2=full
  var showFileName=0;
  if (typeof(showFileNames[showFileName])!='undefined') showFileName=showFileNames[ihow];

    let aspin=getSpinnerImg();
  $('#thumbNailRetrieveNote').html(aspin+" Please wait while thumbnails are retrieved ...  ").show();

  let agallery=$(document).data('galleryDir');

  let adata={'todo':'getDirFileList','gallery':agallery,'dir':adir,'treeName':treeName,'how':ihow,'showFileName':showFileName};

  wsurvey.getJson.get('wsGalleryActions.php',adata,getDirFileListJs2,'getDirFileListJs');
}
// hh will contain the buttonlist (for immediate display)
function getDirFileListJs2(response,origData)  {   // ----------- callback

     var stuff='';
     hh=wsurvey.getJson.check(response,0,'getDirFileListJs callback ');
     if (hh===false) return 1;
      if (hh['status']=='na')  {  // missing dir
             wsurvey.flContents.contents('gallery',hh['content']) ;
              wsurvey.flContents.onTop('gallery');
             return 1;
     }

     toggleDirVu(2);

     $(document).data('currentThumbnails',origData['how']) ;
     $(document).data('currentGallery',origData['gallery']) ;
     $(document).data('currentTree',origData['treeName']) ;
     $(document).data('currentDir',origData['dir']) ;
     $(document).data('currentFiles_dir',hh['dir']) ;
     $(document).data('currentFiles_treeName',hh['treename']) ;
     $(document).data('currentFiles_dirDesc',hh['dirDesc']) ;
     $(document).data('currentFiles_buttons',hh['buttonList']) ; // use to change menu layout
     $(document).data('currentFiles_snapshots',hh['snapList']) ; // use to change menu layout

     $(document).data('currentFiles_stats',hh['fileStats']) ; // use to change menu layout

     let nbuttons=hh['buttonList'].length;

     let cacheMessage=hh['cacheMessage'];
     if (typeof(saveNotes)=='function')   saveNotes(cacheMessage);

     let adir=hh['dir'], treeName=hh['treename'];

     let dirDesc=hh['dirDesc'], fileStats= hh['fileStats'];
     let messageHeader=hh['messageTop'];  //  craeted by php doGetDirFileList_header


// build html menu (of buttons) using buttonList (dependson   'method of bdisplay
     stuff+=messageHeader;
     stuff+='<div id="listOfFileInCurrentDir" class="listOfFileInCurrentDirC" nButtons="'+nbuttons+'">';         // now the list of files (as buttons or thumbnails)

     let uset=$(document).data('useThumbnails');     // implement wsGallery_params.php useThumbnail parameter

     let s3=showFileList_buttonView(hh['gotButtonCache'] ) ; // always shows first as button layout
       stuff+=s3;
      stuff+='</div>' ;

      wsurvey.flContents.contents('gallery',stuff) ;
      wsurvey.flContents.onTop('gallery');

      $(document).data('currentFiles_stats',fileStats);
      $(document).data('currentDir_desc',dirDesc);
      let agallery=$(document).data('galleryDir');

      let  gheader=' <input type="button" value="&#10068;" title="Help for: viewing an image" onClick="doHelpVu(this)"  class="helpButton"  topic="viewFiles" > ';

      var hhsay='';
<!-- 9461=1, 9462=2,  9463=3,  &#127464; blue c   &#127275; circle c -->
      hhsay+='<span title="Files in ... .." style="padding-left:1em;border:1px solid cyan">';

      hhsay+='<button  id="targetHereViewer_which"  name="targetHereWhich"  title="File display in next viewer"  ';
      hhsay+='        class="targetHere_off targetHereButton" data-which="0">&vellip;</button> ';

      hhsay+='directory:<span class="headerEmphasizer" > '+adir;

      let altTreeName=$(document).data('currentTreeAlt');
      let treetitle='';
      if (altTreeName!=treeName) treetitle= ' title="This tree\'s alternate name: '+altTreeName+'" ';
      hhsay+='</span> &nbsp; &nbsp; | tree: ';
      hhsay+=' <span class="treeNameInFileListHeader" style="font-size:120%;font-weight:700" '+treetitle+'>'+treeName+'</span>';
      hhsay+=' (<em>in the </em> <span class="cMyGallery" > '+agallery+'</span> gallery) ';

      hhsay+='</span> ';

      wsurvey.flContents.header('gallery',gheader+hhsay);
      
      let igoo=$(document).data('useListDisplay') ;

      chooseFileListType(0,igoo);

      var eii=$('#iToggleScreenLayout'), aii=eii.attr('which');  //0:dual, 1:rotate, 2:tableau, 3: rotate,4: singlePair
      window.setTimeout( function(){
        $('#getImgInfo').trigger('click')     ;  // will show the 'directory description'


// click handler
     $('#listOfFileInCurrentDir').on('click',listOfFileClickHandler);

// some dropdowns
    let ddopts={'openerActive':'[name="whileDropdownOpen"]',
         'openerInactive':'[name="whileDropdownNotOpen"]','delayOnEnter':1000,
          'zindex':2300,'leftOffset':'-5em','topOffset':'1o+5','closers':'*'};
     let gg=wsurvey.dropdown('iopenerWhichViewer','dropdown_whichViewer',ddopts);

      ddopts={'openerActive':'[name="whileDropdownOpen"]',
         'openerInactive':'[name="whileDropdownNotOpen"]','delayOnEnter':1000,
          'zindex':2300,'leftOffset':'-2em','topOffset':'1o+5','closers':'*'};
       gg=wsurvey.dropdown('iopenerGetSnapshot','dropdown_showSnapshot',ddopts);

      ddopts={'openerActive':'[name="whileDropdownOpen"]',
         'openerInactive':'[name="whileDropdownNotOpen"]','delayOnEnter':1000,
          'zindex':2300,'leftOffset':'-3em','topOffset':'1o+5','closers':'*'};
       gg=wsurvey.dropdown('iopenerShrink','dropdown_shrink',ddopts);


       let ej=$('[name="imageJumpButtons"]');
       if (aii==0) {       // locatin in image buttons used with dual viewer
           ej.show();
       } else {
           ej.hide();
           if (aii==0) $('#currentImageCursorSpot').hide();
       }

 // fix some stuff given other parameter values
        if (aii==1)  {       // rotating -- change file list options to avoid issues
          let dosaves={'shrink':'shrink','snap':'snapshot','viewer':'viewer1','info':0}; // same as which=0
          let doenables={'shrink':1,'snap':1,'viewer':0,'info':1};
          daopts={'save':dosaves,'enable':doenables};
          doResizeViewers_setButtons(daopts);
        }
        if (aii==2)  {       // tableau -- change file list options to avoid issues
          let dosaves={'shrink':'shrink','snap':'snapshot','viewer':'viewer1','info':0}; // same as which=0
          let doenables={'shrink':1,'snap':1,'viewer':0,'info':1};
          daopts={'save':dosaves,'enable':doenables};
          doResizeViewers_setButtons(daopts);
        }

        if (aii==4 || aii==3)  {       // singlePair -- change file list options to avoid issues
          let dosaves={'shrink':'shrink','snap':'snap','viewer':'viewer2','info':1};
          let doenables={'shrink':1,'snap':1,'viewer':0,'info':1};
          daopts={'save':dosaves,'enable':doenables};
          doResizeViewers_setButtons(daopts);
          wsurvey.flContents.onTop('snapBox2');
          wsurvey.flContents.onTop('gallery');
       }

       let enableF= $(document).data('enableFavorites') ;
       if (enableF!=0) $('#iFavorites').show();

      }
      ,120); // read info


}     //getDirFileListJs2


// ================
// captures clicks on showFile buttons
function listOfFileClickHandler(evt) {
     let ethis=wsurvey.argJquery(evt);
     if (ethis.prop('tagname')!=='button') ethis=ethis.closest('button');    // if click on img, need to go up to the button (that has the attribute info)
     let aname=ethis.attr('name');
     if (aname!='listOfFileInCurrentDir_button') return 1 ; // not showFile button click
     
     showThisFile(ethis) ;             // in listOfFileClickHandler-- called when a button in a file-list is clicked
}


//=======================
// cursor in viewer functions
// --------------------

// disable mouse enabled scroll within image
function doScrollSnapShotUp(evt) {
  $(document).data('mouseScrollInImage',0);
  let aloc=getCursorLocationInImage(evt)          ;
  $(document).data('mouseupLocationInImage',aloc);
  var abox=aloc[5];
  let xpctInContainer=aloc[0],  ypctInContainer=aloc[1];
  let xGoto=aloc[2],   yGoto=aloc[3];
  let eOuter=aloc[5];
  let sayXpct=(100*xpctInContainer).toFixed(0), sayYpct=(100*ypctInContainer).toFixed(0);
  $('#currentImageCursorSpot').hide();
  let doContinuous=$('#currentImageContinuousScrollButton').attr('which');


  if (abox=='snapBox1'  ) {     // update the 'Scroll viewer 2' button
      let ecbb=$('#currentImageJumpButton');
      ecbb.attr('xpctAt',xpctInContainer);
      ecbb.attr('ypctAt',ypctInContainer);
      let newval='viewer2 to: x='+ sayXpct+'% / y='+ sayYpct+'%   ';
      ecbb.val(newval);
     if (doContinuous==1)  $('#currentImageJumpButton').trigger("click");
   }
   $(document).data('mouseDownLocationInImage',[]);


  return  1;
}

function doScrollSnapShotDown(evt) {
  $(document).data('mouseScrollInImage',1);
  doScrollSnapShotMove(evt) ;

  var whichBox=$('#iWhichViewer').val();
  let doContinuous=$('#currentImageContinuousScrollButton').attr('which');

  if (whichBox==0  )  {  // combo
       let aloc=getCursorLocationInImage(evt)          ;
       $(document).data('mouseupLocationInImage',aloc);
       var abox=aloc[5];
       if (abox=='snapBox1' && doContinuous==1) {     // make the scroll viewer 2 button  -- and click it!
          $('#currentImageJumpButton').trigger('click'); // continuous enabled -- trigger it!
       }
       let clickedBox=aloc[5];
       if (clickedBox=='snapBox2') {
           var eOuter=aloc[6];
           var scLeft=eOuter.scrollLeft(),scTop=eOuter.scrollTop();
           aloc.push(scLeft);
           aloc.push(scTop);
           $(document).data('mouseDownLocationInImage',aloc);  // used in relative scrolls
       }
  }

  return  1;
}

//==================
// event handler for mousemove ina snapshot image
function doScrollSnapShotMove(evt) {

  let whichViewer=$('#iWhichViewer').val();
  var scrollOk=$(document).data('mouseScrollInImage');

// return [xpctInContainer,ypctInContainer,xImgGoto,yImgGoto,afile,abox,eOuter,eImg];
  let aloc=getCursorLocationInImage(evt);

  let xpctInContainer=aloc[0],  ypctInContainer=aloc[1];

  if (xpctInContainer>0.93 || ypctInContainer>0.93) return 1 ; // in a scroll bar, so ignore

  let xGoto=aloc[2],   yGoto=aloc[3];
  let eOuter=aloc[6],abox=aloc[5];

  if (whichViewer!=0) {                // scroll in image as proportion of where mouse is in outer container
     let viewBox= (abox=='snapBox1') ? 'viewer1' : 'viewer2';
     let sayXpct=(100*xpctInContainer).toFixed(0), sayYpct=(100*ypctInContainer).toFixed(0);

     $('#currentImageCursorSpot').html(viewBox+' x:'+sayXpct+'% / y:'+ sayYpct+'%').show();

     if (scrollOk==0) return 0 ;
     eOuter.scrollLeft(xGoto);
     eOuter.scrollTop(yGoto);
     return 1;
   }

// scroll from point of mousedown
    if (scrollOk==0 || abox=='snapBox1') return 0 ;

    var scrollOk=$(document).data('mouseScrollInImage');

    var cX=evt.pageX, cY=evt.pageY  ;                 // mouse click location
    var wasLoc= $(document).data('mouseDownLocationInImage' ) ;
    if (wasLoc.length==0) return 1;
    var wasX=wasLoc[8],wasY=wasLoc[9], containerXdown= wasLoc[10],containerYdown=wasLoc[11];

    var diffX=wasX-cX,diffY=wasY-cY ;
    var containerXnew=containerXdown+diffX,containerYnew=containerYdown+diffY;

    eOuter.scrollLeft(containerXnew);
    eOuter.scrollTop(containerYnew);

}

//=====================
// get relative location of cursor in an image (due to actions of a mouse)
//  Or, if > 1 arg: use specified "outer container" and "pcts" (eOuter should be jquery object pointing to outer container around image)
// return [xpctInContainer,ypctInContainer,xImgGoto,yImgGoto,afile,abox,eOuter,eImg];
// 0,1  : x  and y pctInContanier : (x and y of the container that holds the image:  as % of container width and height
// 2,3 : xImgPx yImgPx : x and y of the image: the x pixel and y pixel that corresposne th pctInContainer measures
// 4: afile: image file name
// 5: abox: snapshot box containing this container
// 6: eOuter : container image is nested in (jquery object)
// 7 : eImge : the image (jquer yobject)
// 8: cursor x (relative to window upper left)
// 9: cursor y

function   getCursorLocationInImage(evt,eOuter,xpctInContainer,ypctInContainer) {
  var cx=0,cy=0;
  if (arguments.length<2)  {  // typical -- a mouse click.
     eOuter=wsurvey.argJquery(evt,'delegateTarget');    // the div that contains the image
     var wOuter=eOuter.width(),hOuter=eOuter.height();          // its size
     var offx=eOuter.offset().left ; offy=eOuter.offset().top; // location of div
     var cx=evt.pageX, cy=evt.pageY  ;                 // mouse click location
     var relx=parseInt(cx-offx); var rely=parseInt(cy-offy);  // position in div of mouse click
     xpctInContainer=relx/wOuter; ypctInContainer=rely/hOuter;  // mouse click  in div as % of container width and height
  }   // else, used specified

  var eImg=eOuter.find('img');
  var eImgH=eImg.height(),eImgW=eImg.width();  // size of image
  var afile=eImg.wsurvey_attr('whichimg','n.a.');
  var abox='n.a.';
  var eMove=eOuter.wsFlClosest();
  abox=(eMove.length>0) ?  eMove.wsurvey_attr('id','n. a.') : 'n.a.' ;
  var xImgGoto=xpctInContainer*eImgW, yImgGoto=ypctInContainer*eImgH ;  // the location in image pixels corresponding to  mouse Click location in outer container

  let aret=[xpctInContainer,ypctInContainer,xImgGoto,yImgGoto,afile,abox,eOuter,eImg,cx,cy];
  return aret;

}

//====================
// scroll viewer 2 to lcation selected by cursor in viewer w
function autoScrollSnapBox2(athis) {
   let ethis=wsurvey.argJquery(athis);
   let xpctInContainer=0, ypctInContainer=0 ;
   let aloc2;

   xpctInContainer=ethis.wsurvey_attr('xpctAt',-1),ypctInContainer=ethis.wsurvey_attr('ypctAt',-1);
 
   if (xpctInContainer<0 || ypctInContainer<0) {
        let aloc= $(document).data('mouseupLocationInImage');
        if (aloc.length==0) return 1;
       xpctInContainer=aloc[0]; ypctInContainer=aloc[1] ;
   }
   let ev1=$('#snapBox2');
   let eOuter=ev1.find('.snapShotImgOuter');
   if (eOuter.length>0) {
         aloc2=getCursorLocationInImage(0,eOuter,xpctInContainer,ypctInContainer)
   }
   xGoto=aloc2[2],yGoto=aloc2[3];
   eOuter.scrollLeft(xGoto);
   eOuter.scrollTop(yGoto);
}

//=================
// toggle value of continuos scroll button
function enableContinuouScroll(athis) {
   ethis=wsurvey.argJquery(athis);
   var iwhich=ethis.attr('which');
   if (iwhich==1)  {   // enabled
      ethis.attr('which',0);
      ethis.addClass('currentImageContinuousScrollButtonOff');
  } else {
      ethis.attr('which',1);
      ethis.removeClass('currentImageContinuousScrollButtonOff');
  }
}

// ================= end of cursor in veiwer functions ---------------


//======================
//  toggle which viewer to use
function selectWhichViewer(evt) {
   var evt1=$(evt.delegateTarget);
   var evt1p=evt1.parent();
   var iwhich=evt1p.attr('which');
   var ei=evt1p.find('input');
   var ival=parseInt(ei.val());
   ival2= (ival<3) ? ival+1 : 0;
   ei.val(ival2);

   var dsay=['Combo','viewer 1','viewer 2','external'];
   $('#iWhichViewerB').html(dsay[ival2]);

   $('#iautoLoadExternal').hide();
   if (ival2==3)    $('#iautoLoadExternal').show();

   if (ival2==0)  {                       // combo -- enable some buttons
     $('#currentImageContinuousScroll').show();
     $('#recenterZoomButton').prop('disabled',false)

   } else {
     $('#currentImageContinuousScroll').hide();
     $('#recenterZoomButton').prop('disabled',true)
  }
   evt.preventDefault();

   let eshrink=$('#shrinkToFit');
   let eshrinkP=eshrink.closest('span');
   let elabel=eshrinkP.find('label');

   eshrinkP.removeClass('viewDirOptions_nocheck');
   if (ival2==0 || ival2==3) {       // fit not allowed in combo mode (stretch used in veiwer 1, full in viewer 2); or external mode
      eshrink.prop('disabled',true);
      eshrinkP.addClass('viewDirOptions_nocheck');
   } else {
      eshrink.prop('disabled',false);
   }
}


// ===========================================
// controllers for fileList control buttons (option seletion)

//=====================
// Info view: 0: disable, 1:enable. This effects the button AND various description containers. 

function toggleViewInfo(athis,ido,ienable,infoType) {
 var eViewInfo,doShow ;

  if (arguments.length>1) {  // use specified arg
        if (ido<0) return 1;  // -1 means do nothing
        doShow=ido ;
        if (doShow>1) doShow=1;
        if (typeof(athis)=='string' && athis=='') {
            eViewInfo=$('#getImgInfo');
        } else {
            eViewInfo=wsurvey.argJquery(athis) ;
        }
        if (eViewInfo.length==0) return 0 ; // no such button (maybe no file list is shown)
        if (doShow=>0)  eViewInfo.val(doShow);
        if (arguments.length<4) infoType=1;

  } else {          // toggle
        eViewInfo=wsurvey.argJquery(athis);
        doShow=eViewInfo.val();
        doShow++;
        if (doShow>1) doShow=0;
        eViewInfo.val(doShow);
        infoType=-1;
  }
  infoType=parseInt(infoType);
  if (arguments.length<2) ienable=1;
  ienable=parseInt(ienable);
  var espan=eViewInfo.closest('span');
  var elabel=espan.find('label');

  let einfos=$('[name="iimageInfoSnap"]');  // info viewer in viewer boxes

  if (doShow==0) {   // do NOT show info
     espan.removeClass('viewDirOptions_check'); // undim button
     elabel.attr('title',' File (and directory) information is NOT displayed. Click to display! ');
     espan.addClass('redLineThrough');
     $('#dirDescriptionsOuter').hide();
      for (var i0=0;i0<einfos.length;i0++) {
         let aeinfo=$(einfos[i0]);
         let aeinfo1=aeinfo.wsFlClosest();
         if (aeinfo1.attr('id')=='snapBox1')   aeinfo.hide();
         if (aeinfo1.attr('id')=='snapBox2') aeinfo.hide();
         if (aeinfo1.attr('id')=='snapBox3') aeinfo.hide();
     }

   } else {           // show info
     eViewInfo.prop("checked",false);
     elabel.attr('title',' File (and directory) information IS displayed. Click to hide! ');
      espan.removeClass('redLineThrough');  // dim button, but do not disable it
      espan.addClass('viewDirOptions_check');
      $('#dirDescriptionsOuter').show();
      for (var i0=0;i0<einfos.length;i0++) {
         let aeinfo=$(einfos[i0]);
         let aeinfo1=aeinfo.wsFlClosest();
         if (aeinfo1.attr('id')=='snapBox1') aeinfo.show();
         if (aeinfo1.attr('id')=='snapBox2') aeinfo.show();
         if (aeinfo1.attr('id')=='snapBox3') aeinfo.show();
     }

     if (infoType>-1 && infoType<5) {
        toggleDirDesc(false,infoType);
     }
     if (infoType==-1) toggleDirDesc(false,-1);
   }

   if (ienable<0) return 1;
   if (ienable==0) {
       eViewInfo.prop('disabled',true); // this is usually the case
   } else {
       eViewInfo.prop('disabled',false); // don't touch checkbox status
   }

   return 1;
}


//=====================
// shrink mode:  1=asis, 2=stretch,3=shrink    (asis means "display image as recieved from server"
 //
function toggleShrinkToFit(athis,ido,ienable) {
 
    var stuff='',arg2=0,nowGet,eShrink,sayit;
    if (arguments.length>1) {  // use specified arg
        nowGet=parseInt(ido);
        if (nowGet>3  ) nowGet=1;  // just in case
        if (typeof(athis)=='string' && athis=='') {
            eShrink=$('#shrinkToFit');
        } else {
           eShrink=wsurvey.argJquery(athis) ;
        }
        if (eShrink.length==0) return 0 ; // no such button (maybe no file list is shown)
        if (nowGet>0) eShrink.val(nowGet);  // -1 means do nothing

    } else {          // toggle
        eShrink=wsurvey.argJquery(athis);
        nowGet=eShrink.val();
        nowGet++;
        if (nowGet>3) nowGet=1;
        eShrink.val(nowGet);
    }
 
    if (arguments.length<2) ienable=1;  // default is to enable
    ienable=parseInt(ienable);
    eparent=eShrink.closest('span');
    elabel=eparent.find('label');

    let textOkay=$('#showTextInOptions').attr('status');
    let astyle= (textOkay==0) ? ' style="display:none;" ': ' ';
    sayit='';
    if (nowGet==1) sayit='&#11036;<span '+astyle+'  title="asIs: no attempt to fit to viewer. Image will be scrollable." class="mainOptsText">asIs</span> ';
    if (nowGet==2) sayit='&#9641;<span '+astyle+'  title="Stretch. Stretched to fill  viewer. Original aspect ratio may NOT be maintained " class="mainOptsText">Stretch</span> ';
    if (nowGet==3) sayit='&#128476; <span '+astyle+'  title="Shrink. Shrink to fit inside viewer (maintains aspect ratio). Viewer may have blank areas." class="mainOptsText">Shrink</span>';
    if (sayit!='')  elabel.html(sayit);

// enable?.
   if (ienable<0) return 1;  // -1 means no change to enable (default is to enable)
 
   if (ienable==0)  { // disable
      eShrink.prop('disabled',true);
      eparent.addClass('viewDirOptions_nocheck');
   } else {  // enable  (the default)
     eShrink.prop('disabled',false);
     eparent.removeClass('viewDirOptions_nocheck');
    }

    return 1;
}


//=====================
// which viewer:  0=combo, 1=viewer 1,2 =viewer2, 3=external
function toggleWhichViewerGet(athis,ido,enableViewer) {
    var stuff='',arg2=0,doView,eViewer,sayit;

    if (arguments.length>1) {  // use specified arg
        doView=ido ;
        if (doView>3 ) doView=0;  // just in case
        if (typeof(athis)=='string' && athis=='') {
            eViewer=$('#iWhichViewer');
        } else {
           eViewer=wsurvey.argJquery(athis) ;
        }
        if (eViewer.length==0) return 0 ; // no such button (maybe no file list is shown)
        if (doView>=0) eViewer.val(doView);  // -1 means do nothing
    } else {          // toggle
        eViewer=wsurvey.argJquery(athis);
        doView=eViewer.val();
        doView++;
        if (doView>3) doView=0;
        eViewer.val(doView);
    }

    if (arguments.length<2) enableViewer=1;
    enableViewer=parseInt(enableViewer);
    let eparent=eViewer.closest('span');
    let elabel=eparent.find('label');

    let textOkay=$('#showTextInOptions').attr('status');
    let astyle= (textOkay==0) ? ' style="display:none;" ': ' ';
     sayit='';
    if (doView==0) sayit='&#74787;C<span '+astyle+' title="Combo mode: display in both viewer 1 and 2. \n Click on viewer 1 to auto scroll to same spot in viewer 2" class="mainOptsText">ombo</span>';
    if (doView==1) sayit='&#128437;<span '+astyle+'  title="Display in Viewer 1"  class="mainOptsText">Viewer</span> &#9461;';
    if (doView==2) sayit='&#128437;<span '+astyle+'  title="Display in Viewer 2" class="mainOptsText">Viewer</span> &#50;&#65039;&#8419;';
    if (doView==3) sayit='&#128468;eX<span '+astyle+'  title="External view: file display in new window" class="mainOptsText">ternal</span>';
    if (sayit!='') elabel.html(sayit);

     if (enableViewer==1) {
          eViewer.prop('disabled',false);
          elabel.css('opacity','1.0');
     } else if (enableViewer==0) {
          eViewer.prop('disabled',true);
          elabel.css('opacity','0.5');
     }        // other values (ie -1) are ignored
// SPECIAL action (disable  shrink in certain viewer modes!
    if (doView==0 || doView==3 ) {      // disable shrink in combo or external.
       toggleShrinkToFit('',-1,0);     // -1 don't change the setting, 0 means disable
     } else {
 
       toggleShrinkToFit('',-1,1);
     }
     return 1;
}

//========================
// toggle between fullImage (1), snapShot (2), and customSize (3) image retrieval from server. This has no impact on "other" files
// if custom, display the width and height small menu
function toggleSnapshotGet(athis,ido,ienable) {     // 1 full, 2 snap, 3 custom
    var stuff='',arg2=0,nowSnap,eSnap;

    if (arguments.length>1) {  // use specified arg
        nowSnap=ido ;
        if (typeof(athis)=='string' && athis=='') {
            eSnap=$('#getSnapshotImage');
        } else {
           eSnap=wsurvey.argJquery(athis) ;
        }
        if (nowSnap>3) nowSnap=1;
        if (eSnap.length==0) return 0 ; // no such button (maybe no file list is shown)
        if (nowSnap>0) eSnap.val(nowSnap);  // -1 means do nothing

    } else {          // toggle
        eSnap=wsurvey.argJquery(athis);
        nowSnap=eSnap.val();
        nowSnap++;
        if (nowSnap>3) nowSnap=1;
        eSnap.val(nowSnap);
    }
    if (arguments.length<2) ienable=1;
    ienable=parseInt(ienable);

    let eparent=eSnap.closest('.viewDirOptions');
    let elabel=eparent.find('label');

    let ecust=$('#customSize_WxH');
    ecust.hide();

    let textOkay=$('#showTextInOptions').attr('status');
    let astyle= (textOkay==0) ? ' style="display:none;" ': ' ';
    stuff='';
    if (nowSnap==1)    stuff+='&#11034;F<span '+astyle+' title="The actual image (no resizing)" class="mainOptsText">ullImage</span> ';
    if (nowSnap==2)    stuff+=' &#12276;S<span '+astyle+' title="SnapShot=640x 480" class="mainOptsText">napShot</span> ';
    if (nowSnap==3)  {
      stuff+=' &#12275; <span id="customSize_w" '+astyle+' class="mainOptsText" title="Specified width (pixels)">W</span> '
      stuff+=' <span title="Custom size (WxH)" > x </span> ';
      stuff+=' <span id="customSize_h" '+astyle+' class="mainOptsText" title="Specified height (pixels)">H</span> '
    }
    if (stuff!='')       elabel.html(stuff);

     if (nowSnap==3) {
        ecust.show();
       let hdef=$(document).data('customImageHeight');
       let wdef=$(document).data('customImageWidth');
       $('#customSize_width').val(wdef);
       $('#customSize_height').val(hdef);
    }

    if (ienable<0) return 1;

    if (ienable==1) {
          eSnap.prop('disabled',false);
          elabel.css('opacity','1.0');
    } else {
          eSnap.prop('disabled',true);
          elabel.css('opacity','0.5');
          if (nowSnap==3) ecust.hide();
     }

}

// onchange handler for w and h for custom
function toggleSnapshotGet_wh(athis) {

    var ethis=wsurvey.argJquery(athis);
    let awhich=ethis.attr('which') ; // h or w

    if (awhich=='calc') {   // calcualte height = 0.75 of width (4/3 aspect ratio)
       let eparent=ethis.closest('#customSize_WxH');
       let einputs=eparent.find('input');
       let ewidth=einputs.filter('[which="Width"]');
       let awide=$(ewidth[0]).val();
       if (awide=='' || isNaN(awide)) awide=1024;
       awide=parseInt(awide); if (awide<=1) awide=1024;
       let aheight=parseInt(0.75*awide);
       let eheight=einputs.filter('[which="Height"]');
       $(eheight[0]).val(aheight);
       return 1;
    }

    if (awhich=='save') {
       let eparent=ethis.closest('#customSize_WxH');
       let einputs=eparent.find('input');
       for (var ii=0;ii<einputs.length;ii++) {
           let ainput=$(einputs[ii]);
           let awhich2=ainput.attr('which');
           let aval2=ainput.val();
           if (isNaN(aval2)) {      // should never happen
              alert('A non-numeric, or bad, value for '+awhich2+': '+aval2);
              return 1;
           }
           aval2=parseInt(aval2);
           $(document).data('customImage'+awhich2,aval2);
           if (awhich2=='Width') {
             $('#customSize_w').html(aval2);
           } else {
             $('#customSize_h').html(aval2);
           }
       }         // einputs 

       eparent.hide();
       return 1;
    }
    
// else, an onchange
    let aval=ethis.val();
    let adef=ethis.attr('defVal');
    let cval=jQuery.trim(aval);
    if (cval=='') cval=adef;
    if (isNaN(cval)|| cval<=0) {
      alert('Non-numeric, or bad, value for '+awhich+': '+cval);
      ethis.val(adef);
      return 1;
    }
    cval=parseInt(cval);
 //   $(document).data('customImage'+awhich,cval);
    ethis.val(cval);
    return 1;
}


//=================
// toggle size of dirDesc box (in list of image & other files)
// 0: small dir description, suppressed file description
// 1:  small dir descrition
// 2: small file description
// 3: small dir and small file description
// 4: large dir and large file descirption

function toggleDirDesc(athis,iwhich) {
  let ethis;
  if (arguments.length<2) {
    ethis=wsurvey.argJquery(athis);
    iwhich=parseInt(ethis.attr('which'));
    iwhich++;
  } else {
      ethis=$('#iWhichDescription');
  }
  iwhich=parseInt(iwhich);
  if (iwhich>4 || iwhich<-1) iwhich=0;

  var e1=$('#dirDescriptions');
  var e2=$('#fileDescriptions');
  e1.hide();
  e2.hide();

  if (iwhich==0 || iwhich==1 || iwhich==3 || iwhich==4) e1.show() ;
  if (iwhich==2 || iwhich==3 || iwhich==4) e2.show();
  e1.removeClass('dirDescriptionsBigger');
  e2.removeClass('dirDescriptionsBigger');
  e2.removeClass('dirDescriptionsTiny');

  if (iwhich==4) {
    e1.addClass('dirDescriptionsBigger');
    e2.addClass('dirDescriptionsBigger');
  }
  if (iwhich==0)  e2.addClass('dirDescriptionsTiny');

  if (ethis.length>0) ethis.attr('which',iwhich);

  let descDos=['Currently: 2 line dir description, no file description ',
               'Currently: 2 line dir description, 2 line file description (displayed when a file is chosen)',
               'Currently: no dir description, 2 line file description (updated when a file is chosen)',
               'Currently: 2 line dir description, 2 line file description  updated when a file is chosen)',
               'Currently: multi-line dir description, multi-line file description (updated when a file is chosen)'
          ] ;

  let atitle=ethis.attr('title');
  let oof=atitle.split('::');
  oof[1]=descDos[iwhich];
  atitle=oof.join('::');
  ethis.attr('title',atitle);
  return 0;
}

// ====================
// do a slide dhow
// iwhich: 1=random, 2= order
function doSlideShow(athis,iwhich,nowAt,ndid,allButtons ) {
  if (arguments.length<2) iwhich=1;
  if (arguments.length<3) delay=4000 ; // milliseconds
  if (arguments.length<4) nowAt=0 ; // milliseconds
  if (arguments.length<5) ndid=0 ; // milliseconds
  if (arguments.length<5) allButtons=[] ; // milliseconds


  if (ndid==0)  { // first call
    let ebutton=wsurvey.argJquery(athis);
    ebutton.addClass('showThisSlideshow');
      let zz2=$('#slideShowOuter');
      zz2.addClass('slideShowOn');

  }

  var ess=$('#doSlideShow');
  if (!ess.prop('checked')) {
      let zz=$('[name="viewDirOptions_slideshow"]');
      zz.removeClass('showThisSlideshow');
      let zz2=$('#slideShowOuter');
      zz2.removeClass('slideShowOn');
      return 1;  // stop slideshow
  }

  var edelay=$('#doSlideShowDelay');
  if (edelay.length>0) delay=edelay.val();
  delay=parseFloat(delay)*1000;   // convert to milliseconts
  if (delay<10) delay=4000;
                      7

  if (allButtons.length==0)  {           // generate a list of buttons that can be triggerd (to display an image)
    var qImagesOnly=true ;
    var eImagesOnly=$('#doSlideShowImageFilesOnly');
    if (eImagesOnly.length>0) qImagesOnly=eImagesOnly.prop('checked');
    var allButtonsUse=$('.buttonSnapshot');     // all the "show this image" buttons
    for (var nm1=0;nm1<allButtonsUse.length;nm1++) {
        let abut=$(allButtonsUse[nm1]);
        if (qImagesOnly===false) {  // use all of them
             allButtons.push(abut);
       } else {
            if (abut.wsurvey_attr('isnotimg','')=='')  allButtons.push(abut);  // don't do non images
       }
    }
     if (allButtons.length==0) {
         if (qImagesOnly) alert('There are no image files in this directory');
         return 0;  // nothing to use in slideshow
     }
     $('#doSlideShow_fileCt').html('&hellip; using '+allButtons.length+' images ');
  }

  var abutton=$(allButtons[nowAt]);  // which button to trigger (To invokde a display)

  abutton.trigger('click');         // THIS CAUSES THE NEW FILE TO BE DISPLAYED!!!!

  ndid++;
  if (iwhich==2 ){
       nowAt++;
       if (nowAt<allButtons.length) {
          window.setTimeout(function() {doSlideShow(athis,iwhich,nowAt,ndid,allButtons)},delay);
          return 0;
       }   else {
          $('#doSlideShow').prop('checked',false);
          $('#divDoSlideShow').hide();
       }
  }
// otherwise, random
  nowAt=parseInt(Math.random()*allButtons.length) ;
  window.setTimeout(function() {doSlideShow(athis,iwhich,nowAt,ndid,allButtons)},delay);
  return 0;

}

//============
// go to next, or prior, file in the list of files
// if image only, and next or prior is not image, do it again. Up to 100 times (and then give up)
function doSlideShowNext(athis ,ido) {

  if (arguments.length<2){
     let ethis=wsurvey.argJquery(athis);
     ido=parseInt(ethis.attr('do'));   // 1 = forward, -1 backward
   }

   var eio=$('#doSlideShowImageFilesOnly');
   var qMustBeImage=eio.prop('checked');  // image files only checked

   let ediv=$('#listOfFileInCurrentDir'); // contains all the buttons, no matter what format (list table etc) they are displayed under
   let eul=ediv.find('ul');
   let nButtons=ediv.attr('nButtons');  // total number of show-this-file buttons
    ediv.css({'border':'1px solid black'});
   var bnumber=0,ok=0,enextb ;  // default

  var eRecent=ediv.find('.thisImgInSnapshot');
  if (eRecent.length==1) {             // something has been shown
      let er1=eRecent.closest('span');
      bnumber=parseInt(er1.attr('buttonNumber')) ;   // button # last shown
      bnumber=bnumber+ido ;        // the next one (or prior)
      bnumber=Math.min(Math.max(0,bnumber),nButtons-1); // keep in bounds
   }     // else start at first (0th)
   if (ido>0) {  // next
     for (var ifoo=bnumber; ifoo<nButtons;ifoo++)  { // might have to look for the next image
       let enext=ediv.find('[buttonNumber="'+ifoo+'"]'); // find the next (or prior) button at bnumber
       if (enext.length==0)    return 1;  // some kind of error, givupe
       enextb=enext.find('button');      // finds the button within the span
       if (qMustBeImage)  {                          //   must be image?
           let isnotimg=enextb.attr('isnotimg');
           if (isnotimg!='') continue ;     // try the next buttonnumber
           ok=1;
           break;
       }  else {
         ok=1 ;  // not image acceptab;e
         break;
       }
     } // for
   } else {
     for (var ifoo=bnumber; ifoo>=0;ifoo--)  { // might have to look for the next image
       let enext=ediv.find('[buttonNumber="'+ifoo+'"]'); // find the next (or prior) button at bnumber
       if (enext.length==0)    return 1;  // some kind of error, givupe
       enextb=enext.find('button');      // finds the button within the span
       if (qMustBeImage)  {                          //   must be image?
           let isnotimg=enextb.attr('isnotimg');
           if (isnotimg!='') continue ;     // try the next buttonnumber
           ok=1;
           break;
       } else {
          ok=1;  // not image acceptable
         break;
       }
     } // for
   }   // ido
   if (ok==0) return 0;  // at end or begnning reached, but nothing to click
 

    //wsurvey.flContents.scrollTop('gallery');
    let eulTop=eul.offset().top;
    let enextOffTop=enextb.offset().top ;
    let enextRel=enextOffTop-eulTop  ;  // position of button in the ul

    let edivScrollTop=ediv.scrollTop();
    let edivHeight=parseInt(ediv.height());
    let enextHeight=parseInt(enextb.height());
    let edivScrollBottom=edivScrollTop+edivHeight ;
    let mfrac=0.5 ;

    if (enextRel>(edivScrollTop+enextHeight) && enextRel<(edivScrollBottom-enextHeight)) {     // in currently "viewable" area ... do nothing?
    } else{
        if (enextRel>=edivScrollBottom+enextHeight)  { // to far down -- move scroll-view area down
         let adiff=parseInt(mfrac*edivHeight)+enextRel-edivScrollBottom ;
         let sdo=parseInt( edivScrollTop+adiff) ;
          ediv.scrollTop(sdo);
      } else {                   // to far down -- move scroll-view area up
         let adiff=parseInt(mfrac*edivHeight)+edivScrollTop-enextRel ;
          sdo=parseInt(edivScrollTop-adiff);
          ediv.scrollTop(sdo);
      }
    }


// scroll list (to keep current selection in view)
/*   let a0=ediv.offset();
   let a0top=parseInt(a0.top);
   let a0bottom=a0top+parseInt(ediv.height());
   let eNowScrollTop=a0top+parseInt(ediv.scrollTop());
   let eNowHeight=parseInt(ediv.height());
   let eNowScrollBottom=eNowScrollTop+ eNowHeight;
   let a2=enextb.offset();
   let a2top=parseInt(a2.top);
//   if (a2top>(eNowScrollTop+4) && a2top<(eNowScrollBottom-4) ) {  // fits
//      alert(a0top+','+eNowScrollTop+','+eNowScrollBottom+' :  ' + a2top  );
//  } else {
//      let sto=(a2top-eNowScrollBottom)+32;
//      alert(a0top+','+eNowScrollTop+','+eNowScrollBottom+' :  ' + a2top+' ... '+sto );
//      ediv.scrollTop(sto)
//   }
*/

   enextb.trigger('click');  // this is the one to show! ANd clicking will set it up for the next prior/next slide
   return 1
}



//===================
// toggle view of help menu, and display chosen topic
// showCOntent has problems with events. so use movebox directly
// helpTopicBig is in the wsGalleryHelp.html file that contains the help stuff (which is included in wsGallery.php
// athis: the dom event from call to this. If 3 args, this is ingored
//  noclose : optional. If not specified, call here toggles display of help box(closes if open, etc)
//             0 : force close if visible. Otherwise, open. This is the default
//             1 : do NOT force a close if visible
//             2:  no force close, but do force close of menu. Otherwise,    $(document).data('helpMenu_autoClose' )   is used
//             3: force close always
function doHelpVu(athis,noclose,topic,closeMenu ) {
  if (arguments.length<2) noclose=0;
  if (arguments.length<3) topic='';   // redundant, but wth
  if (arguments.length<4) closeMenu=-1;  // use current default

  let isVis=wsurvey.flContents.visible('helpTopics')  ;

  if (noclose==3) {         // force hide
    wsurvey.flContents.hide(10,'helpTopics');
    return 1;
  }
  if (isVis==1 && noclose==0)  {               // hide it
    wsurvey.flContents.hide(10,'helpTopics');
     return 1;
  }

  wsurvey.flContents.show('helpTopics',10,1);

  var allHelp=$('.helpTopic');      // the various help blurbs
  allHelp.hide();  // hide them (open the desired one in a moment ..)

  if (arguments.length<3) {      // gee the topic
     var ethis=wsurvey.argJquery(athis);
     var topic=ethis.wsurvey_attr('topic','Intro');
  }

   var sptopic='<span id="helpTopicHeaders" class="chelpTopicHeader">'+topic+'</span>';
   wsurvey.flContents.header('helpTopics',sptopic);                // change header line of showCOntent box

   var ehelp=$('#help_'+topic);
   if (ehelp.length==0) {
      alert("Error: no help for topic "+topic);
      return 1;
   }

   ehelp.show();   // now dispaly the showCOntent box... with just this help topic vsible
   if (noclose==2) {
      $('#ihelpTopicListOfTopics').hide();  // close menu
   }  else {           // else, use global instructions
       let doClose= $(document).data('helpMenu_autoClose');
       if (doClose==1) $('#ihelpTopicListOfTopics').hide();  // close menu
   }
   return 1;
}

//========
// list of help topics
// athis: not used
//  force: optional If 1-force display, 2-force hide
function doHelpVuList(athis,force) {
    var stuff='';
    var adesc,awhat,aid;
   var howShow=$(document).data('helpMenu_howShow');  // list or table
   var autoClose=$(document).data('helpMenu_autoClose');  // 0 or 1 (1=auto close list of topics after topic clicked on

    if (arguments.length<2) force=0;
    var logonStatus=$(document).data('logonStatus');
    var adminModeEnabled=$(document).data('adminModeEnabled');
    var eh1=$('#ihelpTopicListOfTopics');

    let isvis=eh1.is(':visible');
    if (force==2) {
       eh1.hide();
       return 1;
    }
    if (isvis==true  && force!=1 ) {
      eh1.hide();
      return 1;
    }

// else, show, and create list .. possibly from cache

    eh1.show();

// check for cache
    if (howShow=='table') {
       if (adminModeEnabled==0) {
           stuff= $(document).data('helpMenu_asTable');  // 0 or 1 (1 = close after selection)
       } else {
           stuff= $(document).data('helpMenu_asTableAdmin');  // 0 or 1 (1 = close after selection)
       }
     } else {
       if (adminModeEnabled==0) {
          stuff=$(document).data('helpMenu_asList');  // 0 or 1 (1 = close after selection)
       } else {
          stuff=$(document).data('helpMenu_asListAdmin');  // 0 or 1 (1 = close after selection)
       }
    }
    if (stuff!='') {   // use the cache!
      eh1.html(stuff);
      ehh=wsurvey.flContents.dom('helpTopics');
      if (ehh!==false) {
         let ehhm=ehh['contents'];
         ehhm.scrollTop(0);
      } else {
        $(document.body).scrollTop(0);
      }
      return 1;
    }

// if here, create and save tocache
    stuff+='<div style="padding:2px;font-size:90%">';
    stuff+='<input type="button" value="x" title="Close this list" onClick="$(\'#ihelpTopicListOfTopics\').hide()">';
    if (howShow=='table') {
        stuff+='<button title="Viewing topic menu: as a table.&#010;Click to view as a list"  which="table" onClick="setHelpMenuListView(this)" >&#120035;</button>';
    } else {
        stuff+='<button title="Viewing topic menu: as a list.&#010;Click to view as a table"  which="list" onClick="setHelpMenuListView(this)" >&#120027;</button>';
    }
    if (autoClose==1) {
       stuff+=' <input type="button" id="helpTopics_menuStaysOpen" class="redLineThrough" value="&#10050;"  which="1" ';
       stuff+='      title="Menu of topics closes after selecting a topic.&#010; Click this to toggle between `close menu` and `keep menu open`"   onClick="setHelpMenuAutoClose(this)">';
    } else {
       stuff+=' <input type="button" id="helpTopics_menuStaysOpen"  value="&#10050;"  which="0" ';
       stuff+='       title="Menu of topics stays open after selecting a topic.&#010; Click this to toggle between `close menu` and `keep menu open`" onClick="setHelpMenuAutoClose(this)">';
    }
    stuff+=' <span style="font-weight:700">Choose a help topic &hellip; </span>';
    stuff+='</div>';
    eh1.html(stuff);
    eh1.show();
    if (howShow=='table') {
       stuff+='<div class="helpShowTableDiv"> <table cellpadding="5" rules="rows"   >';
    } else {
       stuff+='<ul class="helpShowList" >'
    }

    let ehelps=$('.helpTopic');
    for  (i1=0;i1<ehelps.length; i1++ ){
       let e2=$(ehelps[i1]);
       aid=e2.wsurvey_attr('id','');
       if (aid=='') continue;
       let isAdmin=e2.wsurvey_attr('isAdmin',0);
       if (isAdmin==1 && logonStatus==0) continue ;// don't show admin help to clients
       awhat=aid.substr(5);
       let espan=e2.find('.helpTopic_topLine');
       if (espan.length>0) {
           let espan1=$(espan[0]);
           adesc=espan1.html();
       } else {
           adesc='... ';
       }
       if (howShow=='table') {
          stuff+='<tr><td><input type="button" topic="'+awhat+'"   onClick="doHelpVu(this,1)" value="'+awhat+'" title="view this help topic"></td>';
          if (isAdmin==0) {
              stuff+='<td>'+adesc+'</td></tr>';
          } else {
             stuff+='<td><span style="color:orange" title="an administrative action">&#9098;</span> ' +adesc+'</td></tr>';
          }

        } else {     //  list
           if (isAdmin==0) {
             stuff+='<li><input type="button" topic="'+awhat+'"  onClick="doHelpVu(this,1)" value="'+awhat+'" title="Help for: '+adesc+'">&nbsp;</li>';
           } else {
             stuff+='<li><input type="button" topic="'+awhat+'"  onClick="doHelpVu(this,1)" value="&#9098;'+awhat+'" title="Help for admin action: '+adesc+'">&nbsp;</li>';
           }
        }  // table or list
    }   // this topic
    if (howShow=='table' ) {
       stuff+='</table></div>';
    } else  {
       stuff+='</ul>';
    }
    eh1.html(stuff);


    if (howShow=='table') {
       if (adminModeEnabled==0) {
            $(document).data('helpMenu_asTable',stuff);
       } else {
            $(document).data('helpMenu_asTableAdmin',stuff);  // 0 or 1 (1 = close after selection)
       }
     } else {
       if (adminModeEnabled==0) {
          $(document).data('helpMenu_asList',stuff);  // 0 or 1 (1 = close after selection)
       } else {
          $(document).data('helpMenu_asListAdmin',stuff);  // 0 or 1 (1 = close after selection)
       }
     }

    ehh=wsurvey.flContents.dom('helpTopics' );
    if (ehh!==false) {
       let ehhm=ehh['contents'];
       ehhm.scrollTop(0);
    } else {
        $(document.body).scrollTop(0);
    }

}


//=======================
// &#9725;</button>'; // &#10064;;
function setHelpMenuExpand(athis) {
   var ethis=wsurvey.argJquery(athis) ;
   var which=parseInt(ethis.wsurvey_attr('which','0'));  // 0=unexpadned, 1= expanced
   which=1-which;
   ethis.attr('which',which);
   if (which==1) {
     ethis.html('&#10064;');
     ethis.attr('title','Help box is expanded. Click to reset to original (lower third of window) ');
   } else {
     ethis.html('&#9725;');
     ethis.attr('title','Help box is small. Click to expand to nearly fill the window');
   }

//   e1=wsurvey.flContents.dom('helpTopics')['main'];
   wsurvey.flContents.container.doExpand('helpTopics',2);

 }

//========================
// set toggle help topics menu: as table or list stays open global

function setHelpMenuListView(athis) {
   var ethis=wsurvey.argJquery(athis) ;
   var which= ethis.wsurvey_attr('which','table' );
   which =(which=='table') ? 'list' : 'table';
   $(document).data('helpMenu_howShow',which);  // list or table
   doHelpVuList(0,1);
 }


//========================
// set toggle help topics menu stays open global

function setHelpMenuAutoClose(athis) {
   var ethis=wsurvey.argJquery(athis) ;
   var which=parseInt(ethis.wsurvey_attr('which',''));
   which=1-which;
   ethis.attr('which',which);
   $(document).data('helpMenu_autoClose',which);

   ethis.removeClass('redLineThrough');
   if (which==1)  {
      ethis.addClass('redLineThrough');
      ethis.attr("title", 'Menu of topics closes after selecting a topic.\nClick this to toggle between `close menu` and `keep menu open` ');
   } else {
      ethis.attr("title", 'Menu of topics stays open after selecting a topic.\nClick this to toggle between `close menu` and `keep menu open` ');
   }
   return 1;
}


//================
// toggle view of a help topic subbox
// look for which or topic attribute -- its value is what to open
// if no such attributes, find element with helpTopic_subMenu class and open it.
//    This find works by finding closest .helpTopic (might be self), and lookind for chile with class of helpTopic_subMenu
function helpTopicToggle1(athis) {
   var ethis=wsurvey.argJquery(athis) ;
   var which=ethis.wsurvey_attr('which topic','');

   if (which=='') {
      let eparent=ethis.closest('.helpTopic');
      ewhich=eparent.find('.helpTopic_subMenu');
   }    else {
      ewhich=$('#'+which);
   }

   if (ewhich.length==0) {
      alert("Can not find ("+which+") submenu in: "+ethis.prop('outerHTML'));
      return 1;
   }

   ewhich.toggle();

   return 1;
}

//=============
// recdisplay most recently seelcted image
function redisplayRecentImage(athis) {
//  var ethis=wsurvey.argJquery(athis);
  var mostRecent=$('.thisImgInSnapshot');
  if (mostRecent.length==0) return 0 ; // nothing chosen
  mostRecent.trigger('click');
  return 1;
}

//=================
// toggle info
function tableauInfoShow(athis) {
   let ethis=wsurvey.argJquery(athis);
   let e1=ethis.closest('[name="tableau_span"]');
   let e2=e1.find('[name="iimageInfoSnap"]');
   e2.toggle();
}

//================
// remove chosen image from tableau
function removeFromTableau(athis) {
     let ethis=wsurvey.argJquery(athis);
     let isimage=ethis.attr('data-isimage');

     let e1=ethis.closest('[name="tableau_span"]');
     $(e1).remove();

     let e3=$('#tableauFileCt');
     let act=e3.attr('ict');
     act--;
     e3.attr('ict',act);
     e3.html(act);

     if (isimage==1) {
       let e3=$('#tableauImageCt');
       let act=e3.attr('ict');
       act--;
       e3.attr('ict',act);
       e3.html(act);
     }
}



//=====================
// tighten up the tableau display
function tableauTighten(athis) {
   let ethis=wsurvey.argJquery(athis);
   let e1=ethis.wsFlClosest();
   eall=e1.wsFlFind('[name="tableau_span"]');

   let oof=[];
   for (var m=0;m<eall.length;m++) {
      let ae1=$(eall[m]);
      let afile=ae1.attr('title');
      let h1o=ae1.outerHeight();
      let w1o=ae1.outerWidth();
      let eImg=ae1.find('img');
      let ihA=eImg.height();
      let imgH=parseInt(eImg.height()),imgW=parseInt(eImg.width());
      let oof1=[afile,'wxh',w1o,h1o,'  image wxh ',imgW,imgH] ;
      oof.push(oof1);
   }
  var  sum_w=0,sum_h=0,sum_iw=0,sum_ih=0;

   for (var ii in oof) {
      let  a1=oof[ii];
      if (!isNaN(a1[2]))    sum_w+=parseInt(a1[2]) ;
      if (!isNaN(a1[3]))  sum_h+=parseInt(a1[3]) ;
      if (!isNaN(a1[5]) && a1[5]>0) { sum_iw+=parseInt(a1[5]) } else { sum_iw+=parseInt(a1[2])    }
      if (!isNaN(a1[6]) && a1[6]>0 )  { sum_ih+=parseInt(a1[6]) } else { sum_ih+=parseInt(a1[3])    }
   }
   let nct=oof.length;

   let avg_w=sum_w/nct,avg_h=sum_h/nct;
   let avg_iw=sum_iw/nct,avg_ih=sum_ih/nct;

   let useW=avg_w,useH=avg_h;
   if (avg_iw<(avg_w-10) ) useW=avg_iw+12;
   if (avg_ih<(avg_h-10) ) useH=avg_ih+12;
   useW=parseInt(useW); useH=parseInt(useH);
   let goo="container: avg w x h = "+avg_w.toFixed(0)+' x ' +avg_h.toFixed(0)+' | image: avg '+avg_iw.toFixed(0)+ ' x' + avg_ih.toFixed(0);
   goo+=' || Resize each container to '+useW + 'x ' + useH  ;
   $('#tableauViewerTopLine').html(goo);
// now set the w and h input boxes (to replicate this size)
   let eInW=$('#tableImage_wFactor'), aInW=parseFloat(eInW.attr('data-use'));
   let eInH=$('#tableImage_hFactor'), aInH=parseFloat(eInH.attr('data-use'));
// this resets the "scaling factors", for future imageBoxes add to the tablea
// it uses the "cleaned up" sizes AND  proportions of "default imageBox size" (that are based on 
//  fixed proportions (less than 1/2) of the 'tableau' container
   if (aInW>0 && aInH>0 )  {  // skip if not yet set
     let newW=useW/aInW,newH=useH/aInH;
     eInW.val(newW.toFixed(4));
     eInH.val(newH.toFixed(4));
    }

// no resize all of the imageBoxes
   for (var ii=0;ii<eall.length;ii++) {
       let aeall=$(eall[ii]);
       if (useW>0) aeall.outerWidth(useW+'px');
       if (useH>0) aeall.outerHeight(useH+'px');
   }

}


//==================
// remove all images in the tableau
function tableauClear(athis) {
   let ethis=wsurvey.argJquery(athis);
   e2=ethis.wsFlFind('.ctableau_all',1);
   let e3=e2.find('[name="tableau_span"]');

   let q=confirm('Are you sure you want to remove '+e3.length+' views ');
   if (q) {
      e3.remove();
      let t1=$('#tableauImageCt');
      t1.attr('ict',0); t1.html(0);
      let t2=$('#tableauFileCt');
      t2.attr('ict',0); t2.html(0);
   }
   $('#tableau_nowLoc').val(0);

   return 1;
}

//==================
// remove all images in the tableau
function tableau_next(athis,idire) {
  var ict;
  let e1=$('#tableau_all');
  if (arguments.length<2) {
      let ethis=wsurvey.argJquery(athis);
      ict=parseInt(ethis.val());
  } else {
     ict=parseInt(e1.attr('ithimg'));
     idire=parseInt(idire);
     ict=ict+idire;
  }
  ict=Math.max(0,ict);
  let e2=e1.find('[name="tableau_span"]');
  ict=Math.min(ict,e2.length-1);
  e1.attr('ithimg',ict);
  let eat=$(e2[ict]);
  $('#tableau_nowLoc').val(ict);

  eat.get(0).scrollIntoView({ behavior: 'smooth' });

  return 1;
}

// ================
// to handle external window communciation
 window.addEventListener("message",
   function(event) {
     var  myOrigin=window.location.protocol+'//'+window.location.hostname;
     if (window.location.port!='') myOrigin+=':'+window.location.port;

     if (event.origin!=myOrigin) {
       alert('eventListener problem (parent): mismatch origins. '+event.origin +' (should be '+myOrigin+')' ) ;
       return 1;
     }

      let adata=event.data;
      let astatus=adata.status;
      if (astatus==1)   {     // child is awake. Send it some data
           let newdata= $(document).data('externalViewerInfo');
           let wwExternalViewer=$(document).data('externalViewerWindow');
            wwExternalViewer.postMessage(newdata, myOrigin);
            return 1;
      }      //  status=1
      if (astatus==3)   {     //  not implemtned
              $('#foo1').html('loading in child ');
      }
      return; // otherwise do nothing
    },  // event
    false);

//=================
// method of displaying list of files
// how: current method.
//  1=buttons (text or thumbnails).
//  2= list (button, info)
//  3= sortable table (name, size, date)

function   chooseFileListType(athis,how) {
   var howSay=['','buttons','list','table'];
   var ethis;
   if (athis!==false) ethis=wsurvey.argJquery(athis);
   if (arguments.length<2) {
     how=parseInt(ethis.wsurvey_attr('how',0));
     how++;
   }
   if (how>3 || how<1) how=1;
   if (arguments.length<2)   ethis.attr('how',how);

//  if (athis!==false) { // june 2022 deprecated
//    let vpf=ethis.attr('valuePrefix');
//    let nh1=vpf+' '+howSay[how];
 // ethis.val(nh1);
//  }

  if (how==1)   { // button view
    showFileList_buttonView(hh['gotButtonCache'],'listOfFileInCurrentDir');
   return 1;
 }

  if (how==2)   { // 3 or so buttons, with some descriptioves, per rpw
    showFileList_listView(hh['gotButtonCache'],'listOfFileInCurrentDir');
    return 1;
 }
   if (how==3)   { // table view
     showFileList_tableView(hh['gotButtonCache'],'listOfFileInCurrentDir');
   return 1;
 }


 return 'xx';

}

//==========================
// display 'view this file' buttons as a stream of buttons
function    showFileList_buttonView(buttonsCached,writeId,buttonList) {
    if (arguments.length<2) writeId='';
    if (arguments.length<1) buttonsCached='n.a.' ;
     stuff='';
    if (arguments.length<3) buttonList=$(document).data('currentFiles_buttons');
    let adir=$(document).data('currentFiles_dir' ) ;

     stuff+='<ul  fromCache="'+buttonsCached+'" class="linearMenu buttonParent"> ';
     for (var i1=0;i1<buttonList.length;i1++) {
        let abutton0=buttonList[i1];
        let afile=abutton0[1];
        let abutton=abutton0[0];
        let iisay=parseInt(i1)+1;

        let tstuff= '<li class="linearMenuLi"><span title="File #'+iisay+' (in this directory)" data-file="'+afile+'" data-dir="'+adir+'" buttonNumber="'+i1+'" >'+abutton+'</span></li>'      // either read from cache, or just now created
        stuff+=tstuff;
     }
     stuff+='</ul>'
     if (writeId=='') return stuff;

     let exx=$('#'+writeId);
     if (exx.length>0) exx.html(stuff);  // should alwasy be true
     return 1;

}

//==========================
// display 'view this file' buttons as a linear list
function    showFileList_listView(buttonsCached,writeId) {
    if (arguments.length<2) writeId='';
    if (arguments.length<1) buttonsCached='n.a.' ;
     stuff='';
     let buttonList=$(document).data('currentFiles_buttons');
      let fileStats=$(document).data('currentFiles_stats');

     let lookups={},fileStats2=[];
     for (var i1=0;i1<buttonList.length;i1++) {
       let abutton0=buttonList[i1];
       buttonList[i1][2]=[]  ;  // default is no stats for this file
       let aname=abutton0[1];
       lookups[aname]=i1;
     }
     for (var cname in fileStats) {
        if (typeof(lookups[cname])=='undefined') continue ;// no info on this (should not happen)
         let ith=lookups[cname];
         buttonList[ith][2]=fileStats[cname];
     }

//   20150718_143820pp.png:  object(7): {
//      size:  number: 5115094
//    time:  number: 1639868302
//      date:  string(23): "December 18 2021 22:58 "
//      desc:  string(0): ""
//      width:  number: 3264
//      height:  number: 1836
//      mimetype:  string(9): "image/png"

     stuff+='<ul  fromCache="'+buttonsCached+'" class="selectFileMenu"> ';
     var inrow=0;
     let bgcolors=['','#eee9ee;','#e9eee9;','#f5faf3;','#f1f3f4;']
     for (var i1=0;i1<buttonList.length;i1++) {

       let abutton0=buttonList[i1];
       let abutton=abutton0[0];
       let afile=abutton0[1];
       let astats=abutton0[2];

       let amimetype=astats['mimetype'];      amimetype2= amimetype.replace(/^.*[\\\/]/, '')    ;     // get the stuff after / (i.e.; jpeg in image/jpeg
       let adate=astats['date']
       let atime=astats['time'];
       let dateM=new Date(atime*1000);
       let dd=dateM.getDate();
       let yy=dateM.getFullYear();
       let mm=dateM.toLocaleString("en-us", { month: "short" });
       let dateOnly=dd+mm+yy;

       if (isNaN(astats['height']) || astats['height']=='') {
           wxhsay='n.a.';
           hxw=astats['size']+' bytes' ;
       } else {
           let aheight=astats['height'], awidth=astats['width'];
           wxhsay=parseInt(awidth)+' x '+parseInt(aheight);
           hxw=parseInt(awidth)*parseInt(aheight);
       }
       let filesize=astats['size'];
       let fs1=filesize/1000; let fs2=fs1.toFixed(0); let fs3=wsurvey.addComma(fs2);
       let fileSizeSay=fs3+'k';
       var descr=jQuery.trim(astats['desc']); if (descr=='') descr='n.a.'   ;
       let descrTitle=wsurvey.removeAllTags(descr);
       let descUse=descr   ; // let overflow doit .substr(0,10);
       let tstuff='';
        inrow++; if (inrow>3) inrow=1;
        let abgcolor=bgcolors[inrow] ;
        if (inrow==1)  tstuff+= '<li class="selectFileMenuLi">  ';
        tstuff+= ' <span style="display:inline-block;min-width:31%;background-color:'+abgcolor+';margin:3px 0.25em 3px 0.25em;padding:2px .25em 2px .25em"> ';
        tstuff+= '<span  buttonNumber="'+i1+'" style="display:inline-block;border:1px dotted #fefaff;min-width:10em"> '+abutton+'</span>';
        tstuff+= ' <span class="cselectFileMenuLi_2" title="'+adate+'">'+dateOnly+'</span>';
        tstuff+= ' <span class="cselectFileMenuLi_2" title="Total pixels='+wsurvey.addComma(hxw)+'">'+wxhsay+'</span>';
        tstuff+= ' <span  title="'+descrTitle+'"  class="cselectFileMenuLi_3"  >'+descUse+'</span>';
        tstuff+=' <div name="keywords_listType2" class="ckeywords_listType2" title="keywords" data-file="'+afile+'"  ><u>Keywords: ... </u> ...</div>';
        tstuff+='</span>'
        if (inrow==3)   tstuff+='</li>'      // either read from cache, or just now created
        stuff+=tstuff;
     }
     stuff+='</ul>'

//        tstuff+= ' <span class="cselectFileMenuLi_1" title="'+amimetype+'">'+amimetype2+'</span>';
//        tstuff+= ' <span class="cselectFileMenuLi_2"  title="Total bytes='+addComma(filesize)+'">'+fileSizeSay+'</span>';
//     stuff+='<ul  fromCache="'+buttonsCached+'" class="selectFileMenu"><li  class="selectFileMenuLi">  ';
//     let tstuff=buttonList.join('<li class="selectFileMenuLi">')      // either read from cache, or just now created
//     stuff+= tstuff;
//     stuff+='</ul>'

      if (writeId=='') return stuff;

     let exx=$('#'+writeId);
     if (exx.length>0) exx.html(stuff);  // should alwasy be true
     return 1;


}


//==========================
// display 'view this file' buttons as a table
// if admin mode, allow for changing descripts
function    showFileList_tableView(buttonsCached,writeId) {
    if (arguments.length<2) writeId='';
    if (arguments.length<1) buttonsCached='n.a.' ;
     stuff='';

     var buttonList=$(document).data('currentFiles_buttons');
      var fileStats=$(document).data('currentFiles_stats');
     var dirSel=$(document).data('currentFiles_dir') ;
     var dirDesc=$(document).data('currentFiles_dirDesc') ;
     var treeName=$(document).data('currentFiles_treeName') ;

   stuff+='<table cellpadding="4" rules="rows" id="listOfFileInCurrentDir_table"> ';
   stuff+='<tr  buttonParent ><th>File</th><th style="min-width:4em">mime</th><th style="min-width:4em">Date</th>';
   stuff+='  <th style="min-width:4em">w x h </th><th style="min-width:4em">Size</th>';
   stuff+='<th style="min-width:8em"> <span style="border-bottom:1px solid blue" title="Sort of this column will sort by the original order (it will NOT sort on the contents of the description)"> ';
   stuff+='Description </span> ';
   stuff+='</th>';
   stuff+='</tr>';
   let lookups={},fileStats2=[];
   for (var i1=0;i1<buttonList.length;i1++) {
       let abutton0=buttonList[i1];
       buttonList[i1][2]=[]  ;  // default is no stats for this file
       let aname=abutton0[1];
       lookups[aname]=i1;
   }
   for (var cname in fileStats) {
        if (typeof(lookups[cname])=='undefined') continue ;// no info on this (should not happen)
         let ith=lookups[cname];
         buttonList[ith][2]=fileStats[cname];
   }

   for (var i1=0;i1<buttonList.length;i1++) {
       let hxw,wxhsay;
       let abutton0=buttonList[i1];
       let abutton=abutton0[0];
        let fname=abutton0[1];
        let jj1=fname.lastIndexOf('.');
        let fnameOnly=fname.substr(0,jj1);

       let astats=abutton0[2];
       let amimetype=astats['mimetype'];      amimetype2= amimetype.replace(/^.*[\\\/]/, '')    ;     // get the stuff after / (i.e.; jpeg in image/jpeg
       let adate=astats['date'],atime=astats['time'];
       let dateOnly=wsurvey.getWord(adate,[1,3],'' )  ;
       if (isNaN(astats['height']) || astats['height']=='') {
           wxhsay='n.a.';
           hxw=15551111111111111115 ;  // sort to end
       } else {
           let aheight=astats['height'], awidth=astats['width'];
           wxhsay=parseInt(awidth)+' x '+parseInt(aheight);
           hxw=parseInt(awidth)*parseInt(aheight);
       }
       let filesize=astats['size'];
       let fs1=filesize/1000; let fs2=fs1.toFixed(1); let fs3=wsurvey.addComma(fs2);
       let fileSizeSay=fs3+'k';
       let desc=jQuery.trim(astats['desc']); if (desc=='') desc='n.a.'
       stuff+='<tr><td  data-_sortUse="'+fnameOnly+'"><span  buttonNumber="'+i1+'">'+abutton+'</span></td>';
       stuff+='<td data-_sortUse="'+amimetype+'" ><span  title="'+amimetype+'"  data-_sortUse="'+amimetype+'" style="font-size:75%">'+amimetype2+'</td>';
       stuff+='<td data-_sortUse="'+atime+'"  ><span  title="'+adate+'" style="font-size:75%">'+dateOnly+'</td>';
       stuff+='<td  data-_sortUse="'+hxw+'"><span title="width x height"  style="font-size:75%">'+wxhsay+'</td>';
       stuff+='<td data-_sortUse="'+filesize+'" ><span  style="font-size:75%">'+fileSizeSay+'</td>';

       stuff+='<td data-_sortUse="'+i1+'" ><span title="Description"   style="font-size:85%;font-style:oblique">';
           stuff+=desc;

       stuff+='</td>';  // original order sort
       stuff+'</tr>';
    }
    stuff+='</table>';
      if (writeId=='') return stuff;

     let exx=$('#'+writeId);
     if (exx.length>0) {
         exx.html(stuff);  // should alwasy be true
         wsurvey.sortTable.init('listOfFileInCurrentDir_table')  ;
     }
     return 1;


}


//================
// randomly retrieve a spinner image, return as <img xxx). Or retrieve the "nth" (whatever that may be
// by default 25 pixel random
function getSpinnerImg(ksize,nth) {
    let spinList=$(document).data('spinnerList');
 
    if (spinList.length==0)   return '';

    if (arguments.length<1) ksize=25;
    if (arguments.length<2) {
      let ii=Math.random()*spinList.length ;
      nth=parseInt(ii);
     }
     let aimgFile=spinList[nth];
     let  aimg='<img alt="spinner" src="'+aimgFile+'" height="'+ksize+'px" width="'+ksize+'px">';
     return aimg ;
}

//=======================
// stub function -- load wsGalleryAdmin.js and wsGallery_dirCache.js when first called. Otherwise, call doAdmin1 (in wsGalleryAdmin.js)
function doAdmin(aparam) {

  if (typeof(doAdmin1)!=='function') {      // name in wsGalleryAdmin.js
     doAdminLoad(aparam);
     return 1;
 }
 doAdmin1(aparam) ;
}

function doAdminLoad(aparam) {   //  load admin only js librarries -- src/wsGalleryAdmin.js
    $.getScript('src/wsGalleryAdmin.js')
      .done(function(script,textStatus) {
         if (typeof(doAdmin1)!='function') {
            alert('wsGalleryAdmin.js loaded, but doAdmin1 ('+typeof(doAdmin1)+') is missing ('+textStatus+') ');
            return 1;
         }
          console.log('src/wsGalleryAdmin.js loaded: '+textStatus);
          doAdminLoad2(aparam);
      }).
      fail(function(jqxhr,textStatus,anerr) {
          alert(' Problem retrieving src/wsGalleryAdmin.js: '+textStatus+' :  ' +anerr);
          return 1;
      });
}

 function doAdminLoad2(aparam) {   //  load admin only js librarries -- src/wsGallery_dirCache.js
      $.getScript('src/wsGallery_dirCache.js')
      .done(function(script,textStatus) {
        if (typeof(doDirCacheJs)!='function') {
            alert('wsGallery_dirCache.js loaded, but doDirCacheJs  ('+typeof(doDirCacheJs)+') is missing  ('+textStatus+')');
            return 1;
         }
          console.log('src/wsGallery_dirCache.js loaded: '+textStatus);
          doAdmin1(aparam);   // full success!
      }).
      fail(function(jqxhr,textStatus,anerr) {
          alert(' Problem retrieving src/wsGallery_dirCache.js: '+textStatus+' :  ' +anerr);
      });
 }

// --------------------------
// --- error repotiong function used by wsurvey.getJson
function jsonErrorShow(amess) {
    wsurvey.flContents.show('gallery',10,1);
    wsurvey.flContents.contents('gallery',amess);
  return 1
}

//=============
// view list of galleries
function otherGalleries(athis,iwhich) {
   if (arguments.length<2  ) {
     iwhich=0;
   }
   let nowGallery= $(document).data('galleryDir');
   var adata={'todo':'galleryList','nowGallery':nowGallery,'which':iwhich}  ;
   wsurvey.getJson.get('wsGalleryActions.php',adata,otherGalleries2,'otherGalleries ');
}
function otherGalleries2(aresponse,origdata) {
    hh=wsurvey.getJson.check(aresponse,0,'otherGalleries2');
    if (hh===false) return 1;
    let iwhich=origdata['which'];
    if (iwhich==0) {
      let gheader=' <input type="button" value="&#10068;" title="Help for: selecting a gallery" onClick="doHelpVu(this)"  class="helpButton"  topic="selectGallery" > ';

       wSurvey.flContents.content('gallery',hh['content'],{'header':gheader+' Select a gallery ...'});
       return 1;
    }

// build collection mode (the tool)....
// write buttons to collection-treelist
    let amess='<ul class="linearMenu">';
    for (let aa in hh['content']) {
       let a1=hh['content'][aa];
       let a1id='galleryList_collection_'+aa ;
       amess+='<li class="linearMenuLi2"><input name="collectionGalleryR" type="radio" data-gallery="'+a1+'" value="'+a1+'" id="'+a1id+'" onClick="createCollectionTrees(this)">';
       amess+='<label for="'+a1id+'" title="Display trees in this gallery"  data-gallery="'+a1+'">'+a1+'</label> &nbsp;&nbsp;'
    }
    amess+='</ul>';

    $('#collectionGalleryShow').html(amess).show();

}

//=======
// switch gallery button
function switchGallery(athis) {
   let ethis=wsurvey.argJquery(athis);
   let nowGallery= $(document).data('galleryDir');
   let agallery=ethis.val();
   var adata={'todo':'gallerySwitch','newGallery':agallery,'nowGallery':nowGallery}  ;
   wsurvey.getJson.get('wsGalleryActions.php',adata,switchGallery2,'switchGallery ');
}
function switchGallery2(aresponse,origdata) {
    hh=wsurvey.getJson.check(aresponse,0,'switchGallery2');
    if (hh===false) return 1;
    wSurvey.flContents.content('gallery',hh['content']['message']);
    var ahref=window.location.href;
    var aa=ahref.split('?');
    var newref=aa[0]+'?gallery='+hh['content']['newGallery'];
    window.setTimeout(function() {
      window.location.href=newref;
    },50);
     var  myOrigin=window.location.protocol+'//'+window.location.hostname;
     if (window.location.port!='') myOrigin+=':'+window.location.port;

}

//===============
// show file ntes
function showFileNotes(athis) {

  let enableNotes=$(document).data('enableNotes');
  if (enableNotes==0) return 0  ;  // should never hapen

   let eview=$('#viewTheNotes');
   if (eview.length==0) {
      alert('Error: no element with id=viewTheNotes');
      return 0;
   }

   if (eview.is(':visible') && athis!==2) {  // toggle to hide
      eview.hide();
      return 0;
   }

   let agallery='',atree='',adir='',afile='',bnumber='',aFDesc='',gotFile=0,addmess='';

   let e1=wsurvey.flContents.find('gallery','#listOfFileInCurrentDir') ;
   let efile=e1.find('.thisImgInSnapshot');
   if (efile.length>0) {
     gotFile=1;
     agallery=efile.attr('galleryname');
     atree=efile.attr('treename');
     let espan=efile.closest('span');
     adir=espan.attr('data-dir');
     afile=espan.attr('data-file');
     bnumber=espan.attr('buttonnumber');
     let eFDesc=$('#fileDescriptions');
     aFDesc=eFDesc.text();
   }

     if (enableNotes==2) {
        addmess=' <input type="button"  ';
        addmess+=' data-gallery="'+agallery+'" data-tree="'+atree+'" data-dir="'+adir+'"  data-file="'+afile+'"  data-bnumber="'+bnumber+'" ';
        addmess+=' value="&Ascr;dd!" title="add a note (for this file)" onClick="addFileNote(this)" > ' ;
     }

   let bmess='';
   bmess+='<div style="background-color:#dfdfdf;">';
   bmess+='<div style=";height:2.0em;overflow:auto;width:95%;white-space:nowrap;scrollbar-width: thin;">';
   bmess+=' <input type="button" value="x" title="close notes viewer" onClick="$(\'#viewTheNotes\').hide()" > ';
   bmess+='<input type="button" class="smallButton" value="&#10068;" title="Help on file-notes" topic="fileNotes"   onClick="doHelpVu(this)" > ' ;
   bmess+=' <input type="button" value="&#11119;" title="refresh: retrieve info on most recently viewed file"  onClick="showFileNotes(2)" > ';
   bmess+=addmess ;

   bmess+='Notes for:   ';
   if (gotFile==1) {
     bmess+= ' <span span  style="white-space:nowrap;font-family:monospace;border:1px dotted black" title="Description: '+aFDesc+'">';
     bmess+=agallery+' /  '+atree+' / ' +adir+' / ' + afile;
     bmess+='</span>';
   } else {
     bmess+='<span span  style="font-family:monospace;border:1px dotted black" title="Select a file! ">';
     bmess+= ' No currently selected file'   ;
     bmess+='</span>';
   }
   bmess+='</div>'
   bmess+='</div>';

   bmess+='<div id="viewTheNotes_2" class="cViewTheNotes_2" title="notes for this file">';
     bmess+='<em>Please wait for notes to be retrieved ...</em>';
   bmess+='</div>';

   eview.html(bmess).show();

   window.setTimeout(function() {
      showFileNotes_retrieve(agallery,atree,adir,afile,bnumber);
   },20);

   return 1;

}

//==============
// add a note for a file
function addFileNote(athis)  {
   var ethis=wsurvey.argJquery(athis) ;
   let agallery=ethis.attr('data-gallery');
   let  atree=ethis.attr('data-tree');
   let  adir=ethis.attr('data-dir');
   let  afile=ethis.attr('data-file');
   let  bnumber=ethis.attr('data-bnumber');
   let bmess='';
   bmess+='<input type="button" value="&#10066;" title="toggle size of this file list area" onClick="wsurvey.flContents.container.doExpand(\'gallery\',2)"> ' ;
   bmess+='<input type="button" id="addFileNote_button" value="Add  note!" title="Enter your name (optional) and your note ...  and click here" ';
   bmess+=' data-gallery="'+agallery+'" data-tree="'+atree+'" data-dir="'+adir+'"  data-file="'+afile+'"  data-bnumber="'+bnumber+'" ';
   bmess+=' onClick="addFileNoteDo(this)" >';
   bmess+='<span id="addFileNoteStatus" style="display:none;background-color:#dcfaec;padding:3px 1em 3px 1em"></span>';
   bmess+='<table style="overflow:auto"  rules="rows" cellpadding="3">';
   bmess+='<tr><td valign="top">Name: </td>';
   bmess+='<td valign="top"> <input type="text" size="80"  id="addFileNote_name" title="Optional: Your name " ></td></tr>';
   bmess+='<tr><td valign="top">Note:</td><td valign="top"><textarea title="Enter your note here. Simple HTML allowed" rows="6" cols="100" id="addFileNote_textarea"> </textarea>';
   bmess+='</td></tr>';
   bmess+='<tr><td valign="top">Keywords:</td><td valign="top"><input type="text" size="80"  title="Enter keywords (comma seperated).}    " id="addFileNote_key">  ';
   bmess+='</td></tr>';
   bmess+='</table>';
   $('#viewTheNotes_2').html(bmess);
   return 1;
}

//=============
// add a file note
function  addFileNoteDo(athis) {
     var ethis=wsurvey.argJquery(athis) ;
   let eadd=$('#addFileNote_textarea');
   let aadd=eadd.val();
   let aadd2=wsurvey.makeHtmlSafe(aadd,1);
   let aadd3=aadd2[1];

   let ename=$('#addFileNote_name');
   let aname=ename.val();
   let aname3=wsurvey.removeAllTags(aname);

      let ekey=$('#addFileNote_key');
   let akey=ekey.val();
   let akey3=wsurvey.removeAllTags(akey);

   let agallery=ethis.attr('data-gallery');
   let  atree=ethis.attr('data-tree');
   let  adir=ethis.attr('data-dir');
   let  afile=ethis.attr('data-file');
   let  bnumber=ethis.attr('data-bnumber');
   let adata={'todo':'addFileNote','gallery':agallery,'tree':atree,'dir':adir,'file':afile,'bnumber':bnumber,
     'name':aname3,'note':aadd3,'key':akey3} ;
   wsurvey.getJson.get('wsGalleryActions.php',adata,addFileNoteDo2,'addFileNoteDo ');
}

function addFileNoteDo2(aresponse,origdata) {
    hh=wsurvey.getJson.check(aresponse,0,'addFileNoteDo2');
    if (hh===false) return 1;
    let acontent=hh['content'];
    if (acontent['status']=='error') {
       alert('Unable to update file-notes: '+acontent['stuff']);
       return 1;
    }
    $('#addFileNoteStatus').html(acontent['stuff']).show();
    let eb1=$('#addFileNote_button');
    eb1.css({'opacity':0.5});
    eb1.prop('disabled',true);
    return 1;
 

}

//=============
// retrieve file notes for a file
function showFileNotes_retrieve(agallery,atree,adir,afile,bnumber) {
    var  myOrigin=window.location.protocol+'//'+window.location.hostname;
    if (window.location.port!='') myOrigin+=':'+window.location.port;

   let wsMainSel= $(document).data('wsgMainSel');
   let aurl= myOrigin+wsMainSel+"/galleries/"+agallery+'/'+atree+'/'+adir+'/'+afile+'.note';
   adata={};
   wsurvey.getJson.get([' '+aurl,'POST','text'],adata,[showFileNotes_retrieve2,'',afile],'showFileNotes_retrieve');
   return 1;
}

// as a text call, do NOT use getJson auto error checking!
function showFileNotes_retrieve2(response,origData,otherArgs2,textStatus,jqXHR,errArgRet) {
   var hideTreeList=0,damess;
   if (errArgRet===false) {
     damess=response;
   } else {
     damess='No notes available for <tt>'+errArgRet+'</tt> ';
     $('#viewTheNotes_2').html( damess  ) ;
     return 1;
   }

   let js2;
   try {
      js2=JSON.parse(damess);
   } catch(e) {
      alert('Problem reading notes file (not in json format): '+e.name+' : ' +e.message) ;
      return 1;
   }

   let zz=[];
   let allkeys=[];
   for (let ij in js2) {
       let ajs2=js2[ij];
       let atime=ajs2['time'];
       let atimek=atime*1000  ; // convert to js time
       let saytime=wsurvey.get_currentTime(31,1,atimek);
       let aname=jQuery.trim(ajs2['name']);
       if ( aname=='') aname='n.a.';
       let anote=ajs2['note'];
       let akey=ajs2['key'],akeysay='';
       if (jQuery.isArray(akey)) {
           jQuery.merge(allkeys,akey);
           akeySay=akey.join(' &boxV; ');
       } else {
          akeySay=akey;
          allkeys.push(akey);
       }
       let lmess='<tr><td valign="top" width="20%"><span title="submitted by.\n Submitted @  '+saytime+'" style="font-family:monospace">'+aname+'</span></td> ';
       lmess+='<td valign="top"> <span class="fileNoteLine" title="Keywords: '+akeySay +'" >';
       lmess+='<div style="max-height:5em;padding:4px;overflow:auto" title="Keywords: '+akey +'" >'+anote+'</div>';
       lmess+='</td></tr>';
       zz.push(lmess);
   }

// clean up allkeys
  let allkeys3=[];
  if (allkeys.length>0) {
    let allkeys2={} ;
    for (let jj=0;jj<allkeys.length;jj++) {
       let akey=jQuery.trim(allkeys[jj]);
       let akeylc=akey.toLowerCase();
       if (!allkeys.hasOwnProperty(akeylc)) allkeys2[akeylc]=akeylc;  // show as lowercase
    }
    for (let bkey in allkeys2) {
       allkeys3.push(allkeys2[bkey]);
    }
  }
  allkeys3.sort();
  damess='';
  damess+='<table style="width:99%" cellpadding="1" rules="rows">';
  damess+=zz.join(' ');
  damess+='</table>';
  if (allkeys.length>0) {
     damess+='<div style="padding:5px;background-color:#dfafdf;margin:3px 1em 3px 1em" title="All keywords (from all notes) for this file">';
     damess+='<b title="keywords are converted to lower case and sorted">Keywords:</b>  <tt> '+allkeys3.join(' </tt>&boxV;<tt>')+'</tt> ';
     damess+='</div>';
  }

  $('#viewTheNotes_2').html( damess  ) ;
  return 1;

}

//=============
// view all keywords for files in a dir
function viewKeywordsDir(athis) {
   var  myOrigin=window.location.protocol+'//'+window.location.hostname;
   if (window.location.port!='') myOrigin+=':'+window.location.port;

   let ethis=wsurvey.argJquery(athis);
   let  atree=ethis.attr('data-tree');
   let  adir=ethis.attr('data-dir');
   let agallery=ethis.attr('data-gallery');

   let wsMainSel= $(document).data('wsgMainSel');
   let aurl= myOrigin+wsMainSel+"/galleries/"+agallery+'/'+atree+'/'+adir+'/_keyword.json' ;

   let adata={};
   $('#iShowDirKeywords_status').show();
   wsurvey.getJson.get([' '+aurl,'POST','text'],adata,[viewKeywordsDir2,'',adir],'viewKeywordsDir');
   return 1;

}

function viewKeywordsDir2(response,origData,otherArgs2,textStatus,jqXHR,errArgRet) {
   var hideTreeList=0,damess;
   let js2;

   if (errArgRet===false) {
     damess=response;
     try {
      js2=JSON.parse(damess);
     } catch(e) {
       alert('Problem reading _keywords.json file (not in json format): '+e.name+' : ' +e.message) ;
       return 1;
     }

   } else {
     js2={};
   }

   $('#iShowDirKeywords_status').html('... processing keywords .. ').show();     // this may just flash on screen (quick processing)
 
   chooseFileListType(0,2);

   let ee1=wsurvey.flContents.find('gallery','[name="keywords_listType2"]');
   ee1.show();
   for (let iee=0;iee<ee1.length;iee++) {
       aee=$(ee1[iee]);
       let dfname=aee.attr('data-file');
       if (js2.hasOwnProperty(dfname)) {
           let klist=[];
           for (let kzz in js2[dfname]) klist.push(js2[dfname][kzz]);
           let klistSay=klist.join('&nbsp;&boxV; ');
            aee.html('<u>Keywords: '+ klistSay);
       }
   }
   
   $('#iShowDirKeywords_status').hide();

}

