; wsGallery tree specification file.
;
;  For security reasons: this must be edited by a site administrator. It is not editable via wsGallery.php       
;
; Changes should be made in the user changable  section
; Note that lines beginning with a ";" are comments, and are ignored. Empty lines are also ignored.
;
; The use of trees allows one to specify what subdirectories (and their files) can be viewed by the public.
; It also allows the admin to provide access to subdirectories outside of the normal path supported by the hosting web server.
;     CAUTION:
;         Specifying a tree `outside of the normal path` can be a security risk.
;         It can be used to access  any file in the file space (of whatever account is hosting the web domain).
;         For example: any drive on a Windows machine hosting the website.
;         THUS: wsGallery should NOT be installed if one can not control access to this configuration file!
;
; For details, please see wsGallery/wsGallery_readMe.txt, or wsGallery/data/wsGallery_treeList_original.php
;
;; ============================== begin user changeable parameters

.showTree:

_default:  , ~/images/,The default tree for wsGallery


;; ============================== end of user changeable parameters
