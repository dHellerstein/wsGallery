<?php
session_start() ;
ob_start();

// improve var_dump outpout
ini_set('xdebug.var_display_max_depth', -1);
ini_set('xdebug.var_display_max_children', -1);
ini_set('xdebug.var_display_max_data', -1);

use wSurvey\getJson as getJs  ;

// wsGallery "ajax" front end
// Uses wsGallery file architecture as created by wsGallery.php
// In particular, it uses the "cache" files in the wsGallery/galleries directory.
// Thus: it will NOT create anything; it only pulls stuff from these cache files.
// This means that if the admin did NOT "initialize" a directory, then limited (if any) information will be returned
// when this is called using "ajax" techniques.
// See wsGallery_get.txt for usage deatils

$rootdir=$_SERVER['DOCUMENT_ROOT'] ;
$nowtime=time();
$curDir=getcwd();
$webRoot=dirname($_SERVER['PHP_SELF']);

require_once($curDir.'/libs/php/wsurvey.getJson.php');
require_once($curDir.'/src/wsGalleryLibUtils.php');

$todo= trim(extractRequestVar('todo','list'));

$res=['errors'=>[],'warnings'=>[],'dir'=>false,'dirDesc'=>'','files'=>[],'gallery'=>false,'nfiles'=>false,'nimages'=>false,
   'tree'=>false,'treeDesc'=>false];

$errors=[];

if ($todo=='galleryList' )   {
  $curDir=getcwd();
    $d1=str_replace('\\','/',$curDir);
   $galleriesDir=$d1.'/galleries';
   $subdirList = glob($galleriesDir . '/*' , GLOB_ONLYDIR);
   $alist=[];
   foreach ($subdirList as $ii=>$adir ) {
     $alist[]=$adirName=pathinfo($adir,PATHINFO_FILENAME);
   }
   getJs\jsonReturnContent($alist);
   exit;

}
// not  galleryList -- read the gallerynbame

$galleryName= trim(extractRequestVar('gallery',false));
if ($galleryName==false) $galleryName='main';
 if ($galleryName===false) {
   $errors[]='gallery not specified';
 } else if (strpos($galleryName,'..') !==false) {
   $errors[]="Illegal gallery name: $galleryName";
}  else {
    $galleryName=str_replace('\\','/',$galleryName);
    $res['gallery']=trim($galleryName,'/');
}

// ------- if todo=treeList, don't need treename or dirname
if ($todo=='treeList' || $todo=='dirList')   {       // dirLIst for past compatablity

  $treeName=trim(extractRequestVar('treeName',''));
  $stuff=doTreeList($galleryName,$treeName,$webRoot,$curDir,$errors);
  getJs\jsonReturnContent($stuff);
  print "never here!" ;
 }

//--- not a treeList request


$treeName=strtolower(trim(extractRequestVar('tree',false)));
if ($treeName==false) $treeName='_default';
 if ($treeName===false) {
   $errors[]='tree not specified';
 } else if (strpos($treeName,'..') !==false) {
   $errors[]="Illegal tree name: $treeName";
} else {
    $treeName=str_replace('\\','/',$treeName);
    $res['tree']=trim($treeName,'/');
}

$dirName= extractRequestVar('dir',false) ;
 if ($dirName===false) {
   $errors[]='dir not specified';
 } else if (strpos($dirName,'..') !==false) {
   $errors[]="Illegal dir name: $dirName";
} else {
    $dirName=str_replace('\\','/',$dirName);
    $dirName=trim($dirName,'/');
    $res['dir']=$dirName;
}

$galleryDir=$curDir.'/galleries/'.$galleryName;
if (!is_dir($galleryDir)) {
   $errors[]="No such gallery directory: $galleryName ";
   $res['errors']=$errors;
   getJs\jsonReturnContent($res);
}
$treeDir=$galleryDir.'/'.$treeName ;
if (!is_dir($treeDir)) {
   $errors[]="No such tree directory (in gallery=$galleryName): $treeName ";
   $res['errors']=$errors;
   getJs\jsonReturnContent($res);
}


$dirDir=$treeDir.'/'.$dirName ;
if (!is_dir($dirDir)) {
   $errors[]="No such  directory (in gallery/tree=$galleryName/$treeName): $dirName ";
   $res['errors']=$errors;
   getJs\jsonReturnContent($res);
}
if (count($errors)>0) {
  $res['errors']=$errors;
   getJs\jsonReturnContent($res);
}

 $dirListFile=$treeDir.'/dirList.json';
 if (!is_file($dirListFile)) {
     $errors[]="Missing dirList file for gallery/tree=$galleryName/$treeName. Administrator should refresh/create this treee ";
     $res['errors']=$errors;
     getJs\jsonReturnContent($res);
  }
  $dirList0=@file_get_contents($dirListFile);
  $dirList=json_decode($dirList0,true);

  $treeDesc=$dirList[1]['.']['desc'];
  $dirLookup=$dirList[1]['.']['dirLookup'];
  if (!array_key_exists($dirName,$dirLookup)){
     $errors[]="No such directory ($dirName) in this tree: $galleryName/$treeName. Administrator should refresh/create this tree ";
     $res['errors']=$errors;
     getJs\jsonReturnContent($res);
  }
  $idir=$dirLookup[$dirName];
  $adir=$dirList[1][$idir];
  $nFiles=$adir['nFiles'];   // might be replaced by acutal cont in filelist
  $nImages=$adir['nImages'];
  $dirDesc=$adir['dirDesc'];

$fileListFile=$dirDir.'/_fileList.json';
if (!is_file($fileListFile)) {
   $errors[]="Missing _fileList file for gallery/tree/dir=$galleryName/$treeName/$dirName. Administrator should initialize this directory ";
   $res['errors']=$errors;
   getJs\jsonReturnContent($res);
}
$fileList0=@file_get_contents($fileListFile);
$fileList=json_decode($fileList0,true);

// if here, the reqesrted galllery/tree/dir DOES exist -- and a fileList was found for it .
// So do something with it!

//   ------------
// send a file; given gallery/tree/dir
if ($todo=='sendFile') {
   $afile=trim(extractRequestVar('file',false)) ;
   $afile=trim($afile,'/');
   $useFile=resolveFile($afile,$fileList,$galleryName,$treeName,$dirName);
   if ($useFile[0]===0) {
     header($_SERVER["SERVER_PROTOCOL"] . " 400 Bad Request"  );
     header("x-wsGallery: ".$useFile[1]);
     $errors[]=$useFile[1] ;
     $res['errors']=$errors;
     getJs\jsonReturnContent($res);
     exit;
   }
   $realFileName=$useFile[0];
   $arecord=$useFile[1];
   $finfo=$arecord['fileInfo']  ;
   $mimetype=$finfo['mimetype'];
   $modDate=$finfo['time'];
   $size=$finfo['size'];
   $desc=$finfo['desc'];

   header('Content-Type: '.$mimetype);
   header( 'Content-Length: ' . $size );
   header("x-wsGallery: For  $afile  in gallery/tree/dir $galleryName $treeName $dirName. Desc=".htmlentities($desc));
   readfile($realFileName);   // returns the file to the client
   exit;
}

//   ------------

// return a json'ized array of the contents, and info, of this file
if ($todo=='contents') {

   $afile=  trim(extractRequestVar('file',false)) ;
   $afile=trim($afile,'/');
   $useFile=resolveFile($afile,$fileList,$galleryName,$treeName,$dirName);

   if ($useFile[0]===0) {
     header($_SERVER["SERVER_PROTOCOL"] . " 400 Bad Request"  );
     header("x-wsGallery: ".$useFile[1]);
     $errors[]=$useFile[1] ;
     $res['errors']=$errors;
     getJs\jsonReturnContent($res);
     exit;
   }

   $realFileName=$useFile[0];
   $arecord=$useFile[1];

   $finfo=$arecord['fileInfo']  ;
   $goo0=@file_get_contents($realFileName);
   $goo= base64_encode($goo0);   // otherwise problems with binary files
   $finfo['fileName']=$afile;         // don't send actual location
   $rets=['info'=>$finfo,'contents'=>$goo]  ;
   header("x-wsGallery: Contents and info for  $afile");
   getJs\jsonReturnContent($rets);
   exit;
}


//   -----------------
// return a link (such as an <img> or a <iframe> or a <video>) that will display a file  -- when the link is copied to the dom

if ($todo=='link')  {  // create a link that retrieve this (such as a <img >)
   $afile=  trim(extractRequestVar('file',false)) ;
   $afile=trim($afile,'/');
   $useFile=resolveFile($afile,$fileList,$galleryName,$treeName,$dirName,1);
   if ($useFile[0]===0) {
     header($_SERVER["SERVER_PROTOCOL"] . " 400 Bad Request"  );
     header("x-wsGallery: ".$useFile[1]);
     $errors[]=$useFile[1] ;
     $res['errors']=$errors;
     getJs\jsonReturnContent($res);
     exit;
   }
   $arecord=$useFile[1];

   if (!array_key_exists('uriSel',$arecord)) {
     $errors[]="uriSel not defined for this file. Administrator should reinitialize this dir ";
     $res['errors']=$errors;
     getJs\jsonReturnContent($res);
   }

   $params=getParamsFile($curDir);  // get generic parameters (imgexts,otherxts). exit on error

// info on this file
   $relSel=$arecord['relSel'];

   $finfo=$arecord['fileInfo']  ;
   $mimetype=$finfo['mimetype'];
   $modDate=$finfo['time'];
   $size=$finfo['size'];
   $adesc=htmlentities(nl2br(trim($finfo['desc'])));
   $aext=strtolower($arecord['relSelFileExt']);
   $uriSel=$arecord['uriSel'];

   $includeExternal=trim(extractRequestVar('external includeExternal','0'));   // could be a '<br>' (to have break). Or 1 to just include
   if ($includeExternal==='' || $includeExternal==='0') $includeExternal=false;
   if ($includeExternal==='1') $includeExternal=' ';
   if ($includeExternal==='2') $includeExternal='<br>';

   $sugWidth=trim(extractRequestVar('width',''));       // used for non-images
   $sugHeight=trim(extractRequestVar('height',''));

// note only return the html element that is desired (a string) -- to display inline
   $daLink=makeLink($relSel,$params,$uriSel,$adesc,$afile,$galleryName,$treeName,$dirName,$aext,$finfo,$includeExternal,$sugWidth,$sugHeight) ;
   if ($daLink===false) {
     $errors[]="Unsupported file type ($aext) for $afile (in gallery/dir $galleryName $dirName)";
     $res['errors']=$errors;
     getJs\jsonReturnContent($res);
   }  // else, use daLink as is

   header("x-wsGallery: link to retrieve $afile ");
   print $daLink[0];     // just return the string to use as an inline (html) element. No other info (so no info on linkHandler)
   exit;
}    // todo=link



// ================ 'list' :
// return a jsonized list of files in the directory (with information on each file)

$extras=extractRequestVar('extras','');
$extras=trim(strtoupper($extras));
$doAll=0;
if (strpos($extras,'*')!==false) $doAll=1;

if ($doAll==1 || strpos($extras,'LINK')) {
   $params=getParamsFile($curDir);  // get generic parameters (imgexts,otherxts). exit on error
}

$sugWidth=trim(extractRequestVar('width',''));       // used for non-images
$sugHeight=trim(extractRequestVar('height',''));

$cacheDir=rtrim($fileList['pathSelectorInfo']['cacheDir'],'/');

$filesGot=$fileList['fileList'];
$res=['gallery'=>$galleryName,'tree'=>$treeName,'dir'=>$dirName,'files'=>[]];
$res['nFiles']=count($filesGot);
$res['nImages']=$nImages;
$res['treeDesc']=$treeDesc;
$res['dirDesc']=$dirDesc;

if ($doAll==1 || Strpos($extras,'SNAPSHOT')!==false)  {
     $snapList=[];
     $snapFile=$cacheDir.'/_snapshots.json' ;
     if (is_file($snapFile)) {
         $s1=@file_get_contents($snapFile);
         $snapList0=json_decode($s1,true);
         foreach ($snapList0 as $aname=>$aa) {
             if ($aname=='.') continue;
             $snapList[$aname]=$aa['img'];
         }
     }
 }
if ($doAll==1 || strpos($extras,'THMSMALL')!==false)  {
     $thm40list=[];
     $thm40file=$cacheDir.'/_buttonList_thm40.json' ;
     if (is_file($thm40file)) {
         $s1=@file_get_contents($thm40file);
         $thm40list0=json_decode($s1,true);
         foreach ($thm40list0 as $ii=>$aa) {
            $aname=$aa[1];
            if ($aname=='.') continue;
            $thm40list[$aname]=$aa[2] ;
         }
     }
 }
 if ($doAll==1 || strpos($extras,'THMMEDIUM')!==false)  {
     $thm66list=[];
     $thm66file=$cacheDir.'/_buttonList_thm66.json' ;
     if (is_file($thm66file)) {
         $s1=@file_get_contents($thm66file);
         $thm66list0=json_decode($s1,true);
         foreach ($thm66list0 as $ii=>$aa) {
            $aname=$aa[1];
            if ($aname=='.') continue;
            $thm66list[$aname]=$aa[2] ;
         }
     }
 }
  if ($doAll==1 || strpos($extras,'THMLARGE')!==false)  {
     $thm90list=[];
     $thm90file=$cacheDir.'/_buttonList_thm90.json' ;
     if (is_file($thm90file)) {
         $s1=@file_get_contents($thm90file);
         $thm90list0=json_decode($s1,true);
         foreach ($thm90list0 as $ii=>$aa) {
            $aname=$aa[1];
            if ($aname=='.') continue;
            $thm90list[$aname]=$aa[2] ;
         }
     }
 }


foreach ($filesGot as $ij=>$zfile) {
  $goo=[];
  $relSel=$zfile['relSel'];
  $afile=$zfile['relSelFile'];
  $aext=$zfile['relSelFileExt'];
  $finfo=$zfile['fileInfo'];
  $uriSel=$zfile['uriSel'];
  $adesc=htmlentities(nl2br(trim($finfo['desc'])));

  $goo['name']=$afile;
  $goo['uriSel']=$zfile['uriSel'];
  $goo['mimetype']=$finfo['mimetype'];
  $goo['height']=$finfo['height'];
  $goo['width']=$finfo['width'];

  if ($doAll==1 || strpos($extras,'SIZE')!==false) $goo['size']=$zfile['fileInfo']['size'] ;
  if ($doAll==1 || strpos($extras,'DATE')!==false) $goo['date']=$zfile['fileInfo']['time'] ;
  if ($doAll==1 || strpos($extras,'DESC')!==false) $goo['desc']=$adesc ;
  if ($doAll==1 || strpos($extras,'LINK')!==false)  {
     $a1=makeLink($relSel,$params,$uriSel,$adesc,$afile,$galleryName,$treeName,$dirName,$aext,$finfo,false,$sugWidth,$sugHeight) ;
     $goo['link']=$a1[0];
     $goo['linkHandler']=$a1[1];
     $goo['linkNoDim']=$a1[2];
  }
  if ($doAll==1 || strpos($extras,'SNAPSHOT')!==false)  {
     $goo['snapshot']= (array_key_exists($afile,$snapList)) ? $snapList[$afile] :  '' ;
  }
  if ($doAll==1 || strpos($extras,'THMSMALL')!==false)  {
     $goo['thmSmall']= (array_key_exists($afile,$thm40list)) ? $thm40list[$afile] :  '' ;
  }
  if ($doAll==1 || strpos($extras,'THMMEDIUM')!==false)  {
     $goo['thmMedium']= (array_key_exists($afile,$thm66list)) ? $thm66list[$afile] :  '' ;
  }
  if ($doAll==1 || strpos($extras,'THMLARGE')!==false)  {
     $goo['thmLarge']= (array_key_exists($afile,$thm90list)) ? $thm90list[$afile] :  '' ;
  }

  $res['files'][]=$goo ;

}
$res['errors']=$errors;
getJs\jsonReturnContent($res);


exit ;

///==========
// return parameters info
function getParamsFile($curDir) {

   $paramsFileName=$curDir.'/data/params.json' ;
   if (!is_file($paramsFileName)) {
     $errors[]="No params file $paramsFileName  ";
     $res['errors']=$errors;
     getJs\jsonReturnContent($res);
   }
   $paramsFile=@file_get_contents($paramsFileName);
   $params=json_decode($paramsFile,true);
   return $params;
}

//===================
// create an Hmtl "link" (for inline display of a file)
function makeLink($relSel,$params,$uriSel,$adesc,$afile,$galleryName,$treeName,$dirName,$aext,$finfo,$includeExternal=false,$sugWidth='',$sugHeight='') {
   $aext=strtolower($aext);

// is this an image?
   $imgExts=$params['imgExts'];

   if (array_key_exists($aext,$imgExts)) {  // a supproted image
       $width=$finfo['width'];
       $height=$finfo['height'];
       $imgHW=' ';
       if ($width!=='' && $height!=='') {   // should always exists for images
          $imgHW='  width="'.$width.'"  height="'.$height.'" ';
          $imgHWnoDim='  data-width="'.$width.'"  data-height="'.$height.'" ';
      } else {
           $imgHW=' data-note="No width or height for this image ';
           $imgHWnoDim=' data-note="No width or height for this image ';
      }

      $amess="Image $afile in gallery/dir $galleryName $dirName. $adesc ";
      $theImg='<img ';

      $theImgNoDim=$theImg.' src="'.$uriSel.'" '.$imgHWnoDim;       // the difference!
      $theImg=$theImg.' src="'.$uriSel.'" '.$imgHW;

      $theImg.=" title=\"$amess\" " ;
      $theImgNoDim.=" title=\"$amess\" " ;

      $theImg.=' >';
      $theImgNoDim.=' >';

      if ($includeExternal!==false)  {
         $theImg.=$includeExternal.'<a title="Show in an external window, or in a tab"  ';
         $theImg.='  href="'.$uriSel.'" target="externalViewer">'.$relSel.'</a>';
         $theImgNoDim.=$includeExternal.'<a title="Show in an external window, or in a tab"  ';
         $theImgNoDim.='  href="'.$uriSel.'" target="externalViewer">'.$relSel.'</a>';
      }
      return [$theImg,'img',$theImgNoDim] ;    // 8 april 2022 : theImgNoDim not used (but will use later)
   }

// if here, not an imgexts. Maybe an otherexts?

   $otherExts=$params['otherExts'];
 //  if ($sugWidth!='' &&  ctype_digit($sugWidth) ) $sugWidth.='px';        // px by default
 //  if ($sugHeight!='' &&  ctype_digit($sugHeight) ) $sugHeight.='px';

   if (!array_key_exists($aext,$otherExts)) return false ;  // not  supproted non-image

   $aother=$otherExts[$aext];
   $handler=$aother[0];
   $more1=$aother[1];
   $more2=$aother[2];

   if ($handler=='v')  {       // video. By default: mov, mp4 . And less usefully mpeg mpg and avi
         $useWidth= ($sugWidth!=='')  ? ' width="'.($sugWidth).'" ' : '' ;
         $useHeight= ($sugHeight!=='')  ? ' height="'.($sugHeight).'" ' : '' ;
         $theImg=' <video controls="controls" imgFile="'.$afile.'"    name="'.$uriSel.'"  type="'.$more1.'" ' .$useWidth.' '.$useHeight.'  >';
         $theImgNoDim=' <video controls="controls" imgFile="'.$afile.'"  name="'.$uriSel.'"   type="'.$more1.'"  >';

         $theImg.='  <source  src="'.$uriSel.'">';
         $theImgNoDim.='  <source  src="'.$uriSel.'">';

         $theImg.="Your browser does not support the ".$more1." video format...   Try the link below (run outside of the browser)"   ;
         $theImgNoDim.="Your browser does not support the ".$more1." video format...   Try the link below (run outside of the browser)"   ;

         $theImg.='<a   title="Show in an external window, or in a tab"  href="'.$uriSel.'" target="externalViewer">'.$relSel.'</a>';
         $theImgNoDim.='<a   title="Show in an external window, or in a tab"  href="'.$uriSel.'" target="externalViewer">'.$relSel.'</a>';

         $theImg.='</video>';
         $theImgNoDim.='</video>';
         if ($includeExternal!==false)   {
             $theImg.=$includeExternal.'<a   title="Show in an external window, or in a tab"  href="'.$uriSel.'" target="externalViewer">'.$relSel.'</a>';
             $theImgNoDim.=$includeExternal.'<a   title="Show in an external window, or in a tab"  href="'.$uriSel.'" target="externalViewer">'.$relSel.'</a>';
         }
         return [$theImg,'video',$theImgNoDim] ;
  }

  if ($handler=='e')  {     // usually pdf (object / embed)
       $useWidth= ($sugWidth!=='')  ? ' width="'.$sugWidth.'" ' : ' ';
       $useHeight= ($sugHeight!=='')  ? ' height="'.$sugHeight.'" ' : '' ;
       $arfDim='<object data="'.$uriSel.'" type="'.$more1.'" '.$useWidth.' '.$useHeight.' >';
       $arfNoDim='<object data="'.$uriSel.'" type="'.$more1.'">';     // user might want to add width/height attributes

       $arf=' <embed src="'.$uriSel.'" type="'.$more1.'"> ';        // used in both dim and nodim version
       $arf.=' <p>This browser does not support '.$more1.'. Use the link (below) to download.' ;
       $arf.='</embed>  ';
       $arf.='<a   title="Show in an external window, or in a tab"  href="'.$uriSel.'" target="externalViewer">'.$relSel.'</a>';
       $arf.='</object>';
       $arfDim.=$arf;
       $arfNoDim.=$arf ;

       if ($includeExternal!==false) {
         $arfDim.=$includeExternal.'<a   title="Show in an external window, or in a tab"  href="'.$uriSel.'" target="externalViewer">'.$relSel.'</a>';
         $arfNoDim.=$includeExternal.'<a   title="Show in an external window, or in a tab"  href="'.$uriSel.'" target="externalViewer">'.$relSel.'</a>';
      }
      return [$arfDim,'object',$arfNoDim];
  }

  if ($handler=='i')  {       // image. Not used by default, but could be used with tif, img, etc
       $useWidth= ($sugWidth!=='')  ? ' width="'.($sugWidth).'" ' : '' ;
          $useWidthNoDim= ($sugWidth!=='')  ? ' data-width="'.($sugWidth).'" ' : '' ;
       $useHeight= ($sugHeight!=='')  ? ' height="'.($sugHeight).'" ' : '' ;
          $useHeightNoDim= ($sugHeight!=='')  ? ' data-height="'.($sugHeight).'" ' : '' ;
       $theImg=' <img   alt="For image: '.$afile.'" '.$useHeight.' '.$useWidth.'  src="'.$uriSel.'"  >';
       $theImgNoDim=' <img   alt="For image: '.$afile.'" '.$useHeightNoDim.' '.$useWidthNoDim.'  src="'.$uriSel.'"  >';
       if ($includeExternal!==false) {
          $theImg.=$includeExternal.'<a   title="Show in an external window, or in a tab"  href="'.$uriSel.'" target="externalViewer">'.$relSel.'</a>';
          $theImgNoDim.=$includeExternal.'<a   title="Show in an external window, or in a tab"  href="'.$uriSel.'" target="externalViewer">'.$relSel.'</a>';
      }
      return [$theImg,'img',$theImgNoDim];
  }

  if ($handler=='l')  {       // generic link
          $theImg='<a title="Show in an external window, or in a tab" ';
          $theImg.='   href="'.$uriSel.'" target="externalViewer">'.$relSel.'</a>';
          return [$theImg,'link',$theImg] ;          // no dims in this, so use same for both
          exit;
  }

  if ($handler=='f')  {       // iframe
       $useWidth= ($sugWidth!=='')  ? ' width="'.($sugWidth).'" ' : '' ;
       $useHeight= ($sugHeight!=='')  ? ' height="'.($sugHeight).'" ' : '' ;

      if ($more1=='text' || $more1=='html')  {  // text file (html or plain)

         $theImgNoDim='<iframe name="viewerIframe" ';
         $theImg='<iframe name="viewerIframe" '.$useWidth.' '.$useHeight;

         $theImg.=' src="'.$uriSel.'" title="Displaying '.$relSel.'" >'.$relSel.'">';
         $theImgNoDim.=' src="'.$uriSel.'" title="Displaying '.$relSel.'" >'.$relSel.'">';

         $theImg.='</iframe>';
         $theImgNoDim.='</iframe>';

         if ($includeExternal!==false)  {
            $theImg.=$includeExternal.'<a href="'.$uriSel.'" target="externalViewer">'.$relSel.'</a>';
            $theImgNoDim.=$includeExternal.'<a href="'.$uriSel.'" target="externalViewer">'.$relSel.'</a>';
         }

         return [$theImg,'iframe',$theImgNoDim];

      }  else {        // some other iframe format

        $uriSel='/'.ltrim($uriSel,'/');  // just to be sure
        $goo0=strtoupper($_SERVER['SERVER_PROTOCOL']);
        $sproto=(strpos('HTTPS',$goo0)!==false) ? 'https:' : 'http:' ;
        $goo1=$_SERVER['SERVER_NAME'];
        $goo2=$_SERVER['SERVER_PORT'];
        if ($goo2!='80') {
          $fullHref=$sproto.'//'.$goo1.':'.$goo2.$uriSel ;
        } else {
          $fullHref=$sproto.'//'.$goo1.$uriSel ;
        }
        $theImg='<iframe name="viewerIframe" title="Accessing '.$fullHref.'" ';
        $theImg.=' src=" '.$more1.$fullHref.'"  ' ;     // call external handler with full url

        $theImgNoDim=$theImg."> ";
        $theImg=$theImg.' '.$useWidth.' '.$useHeight."> ";

        $theImg.='</iframe>';
        $theImgNoDim.='</iframe>';
        if ($includeExternal!==false)  {
            $theImg.=$includeExternal.'<a href="'.$uriSel.'" target="externalViewer">'.$relSel.'</a>';
            $theImgNoDim.=$includeExternal.'<a href="'.$uriSel.'" target="externalViewer">'.$relSel.'</a>';
        }
        return [$theImg,'iframe',$theImgNoDim]        ;
      }     // iframe other format
    }   // iframe


   return false;

}   /// makeLink

//================
// find this file in the filelist
function resolveFile($afile,$fileList,$galleryName,$treeName,$dirName) {

   if ($afile===false) {
     return [0,"No file specified: for sendFile from gallery/tree/dir=$galleryName/$treeName/$dirName. "];
   }
   $afile=trim($afile);
   if (!array_key_exists('relSelLookup',$fileList)) {
     return [0,"Missing relSelLookup in _fileList; for gallery/tree/dir=$galleryName/$treeName/$dirName. Administrator should re-initialize this directory "];
   }
   if (!array_key_exists($afile,$fileList['relSelLookup'])) {
     return [0,"No such file ($afile): in gallery/tree/dir=$galleryName/$treeName/$dirName. Administrator should re-initialize this directory "];
   }
   $ith=$fileList['relSelLookup'][$afile];
   $arecord=$fileList['fileList'][$ith];
   $relSelFile=$arecord['relSelFile'];
   if ($relSelFile!=$afile) {
      return [0,"Mismatch ($afile ne $relSelFile): in gallery/tree/dir=$galleryName/$treeName/$dirName. Administrator should re-initialize this directory "];
   }
   $realFileName=$arecord['realFileName'];
   if ($realFileName===false) {
      return [0,"Unable to find actual file ($afile): in gallery/tree/dir=$galleryName/$treeName/$dirName. Administrator should re-initialize this directory "];
   }
   if (!is_file($realFileName)) {
      return [0,"File does not exist ($afile): in gallery/tree/dir=$galleryName/$treeName/$dirName. Administrator should re-initialize this directory "];
   }

   return [$realFileName,$arecord];  // success!
}  // end of resolveFIle


//===============
// return a tree/dir list
function doTreeList($galleryName,$treeName,$webRoot,$curDir,$errors) {

   $retDo=[];          // this is returned .. initialize
   $retDo['trees']=[] ;
   $retDo['status']=[] ;

    $adir=rtrim($curDir,'/');
    $adir.='/galleries/'.trim($galleryName,'/');

    if (!is_dir($adir)) {
      $retDo['status']="No such gallery: $galleryName  ";
      return $retDo;
    }

   $afile=$adir.'/treelist.json';

   if (!is_file($afile))  {
      $retDo['status']="No info for tree: $adir  ";
      return $retDo;
   }
   $afile1=@file_get_contents($afile);
   $alist=json_decode($afile1,true);

   $afileStatus=$adir.'/treelistStatus.json';  // could use disabled or partiallyDisabled values in ['.'] of a tree's dirlist.json
   $alistStatus=[];
   if (is_file($afileStatus))  {
     $afile1Status=@file_get_contents($afileStatus);
     $alistStatus=json_decode($afile1Status,true);
   }

   $ntrees=0;
   $retDo=[];
   $tArray=[];
   $status=[];
   $tlist=[] ;


// find each tree
   foreach ($alist as $aname=>$astuff) {
       if (is_numeric($aname)) continue;
       if ($treeName!='') {
           if ($treeName!=$aname) continue;
       }
       $goo=[];
       if (array_key_exists($aname,$alistStatus) && $alistStatus[$aname]['disable']==1) {
         continue ;  // ignore disabled galleries
      }
      $tlist[]=$aname;
      $goo['gallery']=$galleryName;
      $goo['stdWwwDir']=$astuff['stdWwwDir'];
      $goo['desc']=$astuff['desc'];
      $goo['dirList']=false;
      $goo['error']=false;
      $status[$aname]=$goo;
   }
   if (count($tlist)==0) {
     $retDo['status']=false;
     $retDo['trees']=false;
     return $retDo;
  }
   $status['/']=$tlist;
   $retDo['trees']=$tArray;

   foreach ($tlist as $ii=>$treeName) {
      $dfile=$adir.'/'.$treeName.'/dirList.json' ;
      if (!is_file($dfile)) {
        $retDo['trees'][$treeName]=false;
        $status[$treeName]['error']="Missing directory listing (for tree=$treeName) in gallery: $galleryName  ";
        continue;
      }
      $dlist0=@file_get_contents($dfile);
      $dlist1=json_decode($dlist0,true);

      $dlist=[]; $dArray=[];
      foreach ($dlist1[1] as $ith=>$dstuff) {
         if ($ith==='.') continue;
         if ($dstuff['isDisabled']!=0 ) continue;      // 1=full, 2=no file view
         $dname=$dstuff['dirname']  ;
         $dlist[]=$dname;
         $goo2=[];
         $goo2['nFiles']=$dstuff['nFiles'];
         $goo2['nImages']=$dstuff['nImages'];
         $goo2['desc']=$dstuff['dirDesc'];
         $dArray[$dname]=$goo2;
      }  // this dir in this tree
      $status[$treeName]['dirList']=$dlist;
      $retDo['trees'][$treeName]=$dArray;

   }  // this tree
   $retDo['status']=$status;
 ;


   return $retDo;
}
