//===============================
// direcotry initi -- cache creation etc
// for wsGallery
// Two sets:
//   doDirCacheJs -- create a menu, and then "initialize" a directory tree (created cached versions of filelists, thumbnails, snapthos)
// getDirCacheAdmin -- retrieve list of dirs in a tree, display in dirList flContents

// ====================
// intialize the caching elements of  directory (descritions, thumbnails, etc)
// istart=1: first call -- show the control panel    : single dir
//       2 :  first call -- show the control panel : multiple dirs
//       Otherwise: auto do the various steps
//
// Called from   wsGallery_dirList.php (istart=1 and istart=2, and wsGallery_dirCache.php (istart=0: the GO button)
// This invokes dirCache in  wsGalleryActionsAdmin.php  -- once to "start" (create menu), and after a button in this menu is clicked-- start the process
// the process involves several steps, each of them can take several "timeout/resume" calls
// After the "show menu", and then the "start proces" -- The steps do NOT  involve a call to dodirecache.js.
// Instead, .get to wsgalleryactionsadmin.php

function doDirCacheJs(athis,istart) {

   var e1=wsurvey.argJquery(athis) ;
   var adata;
   var adir=e1.attr('dir');
   var treename=e1.attr('treename');
   var isMulti=e1.attr('data-ismulti');

   if (istart==1) {           //  create an html control panel (with the Go button)
      let earf=e1.closest('[name="dirListInitialize0"]');
      if (earf.length==0) return false ; // should never happen
      adir=earf.attr('dir');
      treename=earf.attr('treename');
      adata={'todo':'dirCache','action':'start','dir':adir,'treename':treename,'isMulti':0 };
      wsurvey.getJson.get('wsGalleryActionsAdmin.php',adata, doDirCache_makeMenu ,'doDirCacheJs (start)');
      return 0;
  }

    if (istart==2) {           // get the control panel  -- multiple dirs mode "

      treename=e1.wsurvey_attr('treename,data-treename');

       let etable=$('#dirListingTableAdmin');
      let einits0=etable.find('[name="dirListInitializeNow"]');
      let einits=einits0.filter(':visible');
      if (einits.length==0) return false ;  // should never happen
      let oos=[];
      for (var iee=0;iee<einits.length;iee++) {
          let ainit=$(einits[iee]);
          let ainit0=ainit.closest('[name="dirListInitialize0"]');
          let adir=ainit0.wsurvey_attr('dir,data-dir','');  // could also check for treename, but lets trust its the same as in the ALL button!
          oos.push(adir);
      }
      let nInitDirs=einits.length;

      let stuff='Initialzing <tt>'+nInitDirs+'</tt directories in tree <em>'+treename+'</em>';
      stuff='<table cellpadding="5" rules="rows" id="doDirCache_multiStatus">';
      stuff+='<tr><td>Dir</td><td>Status</td></tr>';
      for (var jj=0;jj<oos.length;jj++) {
         let adir=oos[jj];
         stuff+='<tr><td><span name="doDirCache_multiStatus_row_dir" data-dir="'+adir+'"><tt>'+adir+'</tt></td>';
         stuff+='<td><div name="doDirCache_multiStatus_row_status"> ... </div></td>';
         stuff+='</tr>';
      }
      stuff+='</table>';
      wsurvey.flContents.contents('snapBox3',stuff, {'show':1,'onTop':1,'header':'Directory initialization ... '});

      adata={'todo':'dirCache','action':'start','dir':oos.join(','),'treename':treename,'isMulti':1 };
      wsurvey.getJson.get('wsGalleryActionsAdmin.php',adata,doDirCache_makeMenu,'doDirCacheJs (start)');

      return 0;


  }  // end of  istart = 2

// -- if here, start the initialization of a single, or several, directory

         
    let econtrols=$('[name="chkDirCacheControlTable_steps"]');
    let  goo=econtrols.filter(':checked');
    let nnot=econtrols.length-goo.length;
    if (nnot>0)  {
       qq=confirm('Are you sure you want to skip creation of '+nnot+' items? This may cause problems (broken links) for future users');
       if (!qq) return 0;
    }
    econtrols.prop('disabled',true);  // disable -- can't change while processing!
     var otherArgs={'isMulti':0,'reportFilelist':''};     // the Go button has a data-multi attribute (0= 1 dir, 1=multi dirs)
     var isMulti=e1.attr('data-ismulti');
     if (isMulti==1) {
        let vvs=adir.split(',');
        adir=vvs[0];
        otherArgs={'isMulti':1,'nToDo':vvs.length,'nextToDo':0,'list':vvs,'reportFileList':'','totSize':0,'totFiles':0};
     }

   let e1P=wsurvey.flContents.find(e1,'[name="doDirCache_doButtons"]',1);
    e1P.prop('disabled',true);  // disable the go button
//    e1.prop('disabled',true);  // disable the go button
    e1P.css("opacity",'0.5');
    
    let oof1=wsurvey.adminLogon_status('wsGallery') ; // local check

    if (oof1[1]!='yes') {                          // could happen if timing is just right (expiry happened just now
        alert('You are not currently logged on ... please logon and try again ');
        return 1;
    }
    if (oof1[0]<500) { // not enough -- extend it!
        wsurvey.adminLogon_extend(500,'wsGallery','Extend time in  doDirCacheJs');
    }

     let eRemoveAll=$('#doDirCache_clearAll');
    let iRemoveAll= (eRemoveAll.prop("checked")) ? 1 : 0;

    let eOverwrite=$('#doDirCache_noOverwrite');
    let iOverwrite= (eOverwrite.prop("checked")) ? 1 : 0;

    let eretain=$('#doDirCache_retainFileDescs');
    let iRetainFileDesc = (eretain.prop("checked")) ? 1 : 0;

    var adata={'todo':'dirCache','action':'cacheInit','dir':adir,'treename':treename,'timeAllowed':0,
           'removeAll':iRemoveAll,'overWrite':iOverwrite,'retainFileDesc':iRetainFileDesc};
    wsurvey.getJson.get('wsGalleryActionsAdmin.php',adata,[doDirCacheJs2,otherArgs],'doDirCacheJs2 (start)');

}         // doDirCacheJs

// write control panel (for this dir initialization) to  admin flContent
// this is ONLY called if istart=1 or 2
function doDirCache_makeMenu(zdata,origData)  {

   var hh=wsurvey.getJson.check(zdata,0,'Callback from doDirCacheJs') ;
   if (hh===false) return 0;
   if (hh['status']=='nologon') {
         ('To do this admin action (directory initialization), you must be logged on');
        $('#logonButton').show().focus() ;
        return 1;
   }
   var isMulti=origData['isMulti'];
   let action=origData['action'];

    let eadmin=wsurvey.flContents.dom('#gallery','m');
    eadmin.wsFlShow();
    eadmin.wsFlOnTop(1);
    eadmin.wsFlHeader(hh['header']);
    eadmin.wsFlContents(hh['content']);
    if (isMulti==0) {
      let eoof=wsurvey.flContents.find('gallery','#iDoGoButton');
      eoof.focus();
      eoof.css({'font-size':'150%'});
    }

    if (isMulti==1) {
       let eopts=eadmin.find('[name="chkDirCacheControlTable_steps"]');
       for (var k1=0;k1<eopts.length;k1++) {
           let aopt=$(eopts[k1]);
           aopt.prop('disabled',true);
           aopt.css({'opacity':0.5});
           let atitle=aopt.attr('title');
           atitle+='\n Initalizing multiple directories: this step can NOT be disabled!';
           aopt.attr('title',atitle);
       }
       wsurvey.flContents.container.doResize('gallery',{'left':'5%','top':'10%'});
       wsurvey.flContents.onTop('snapBox3',1);

    }   // startmulti

  }     // doDirCache_makeMenu

 // write results of an action, and do next one  -- this handles timeout/resume sequence of calls

 // this can be called as a callback from at getJson.get()
 //    for  xample: on clicking GO, with action=cacheinit -- or to start a step (say, thm40), or to resume a timeout/resumt
 // In that case : the a
 // Or, it can be  called d
 // Or,
function doDirCacheJs2(zdata,origData,otherArgs)  {

    var hh=wsurvey.getJson.check(zdata,0,'Callback: doDirCacheJs2 ') ;

    if (hh===false)return 0;
    if (hh['status']=='nologon') {
        alert('To do this admin (... directory initialization) action, you must be logged on');
        $('#logonButton').show.focus() ;
        return 1;
     }


// check before each stage of each dir ....
    let oof1=wsurvey.adminLogon_status('wsGallery') ; // local check
    if (oof1[1]!='yes') {                          // could happen if timing is just right (expiry happened just now
        alert('You are not currently logged on -- please logon and try again ');
        return 1;
    }
    if (oof1[0]<500) { // not enough -- extend it!
        wsurvey.adminLogon_extend(500,'wsGallery','Extending logon time in doDirCacheJs2');
    }
    if (typeof($(document).data('zFails'))=='undefined') $(document).data('zFails',[]);


// any errors?
  let zfailsThis= (typeof(hh['fails'])=='undefined') ? false :  hh['fails'];

  if (zfailsThis!==false  ) {
     let zfails=[];
     for (var az in zfailsThis) {
           let azAction=zfailsThis[az]['action'];
           let azMessage=zfailsThis[az]['message'];
           let azz=[az,azAction,azMessage ];
           zfails.push(azz);
      }
      let zfailsOld=$(document).data('zFails');
      if (typeof(zfailsOld)=='undefined') zfailsOld=[];

       for (var mmz=0;mmz<zfails.length;mmz++) {
          ammz=zfails[mmz];
          zfailsOld.push(ammz);
       }
       $(document).data('zFails',zfailsOld);

   }

 // do next step
    window.setTimeout(function(){ doDirCacheJs2b(1)},50) ;

//   =-----------------------------    doDirCacheJs2b is internal to  doDirCacheJs2. THus, origData AND otherArgs is exposed

    function doDirCacheJs2b(afoo) {   // this does the work (the above is semi deprecated, but retained for now)

      var adata,thisTerm,newDesc,q1 ;  // note that hh is pulled from parent function (that calls this internal function)

//      var zaction=hh['action'].toLowerCase();      // the action just completed -- lc just to be sure
        var zaction=origData['action'].toLowerCase();      // the action just completed -- lc just to be sure

      var recentResult=hh['content'];
      var adir=hh['dir'] ;
      var treeName=hh['treeName'];

// check generic user controls.
      var qstop=$('#iDirCacheControl_stop').prop('checked');
        iOverwrite=origData['overWrite'];

// start step and cacheInit done -- show results and to to cacheInit / step
// zaction is the just COMPLETED action -- not the "next one to do"

// cache dir step done -- show results and do filelist steo

     if (zaction=='cacheinit')  {   // the  first step: cacheInit direcotry (is required)
        $('#iDirCacheControlTable_cacheInit').html(recentResult).addClass('cDirCacheControlTableCol2D');     // show results
        if (qstop) {
           $('#iDirCacheControlErr').html('Processing stopped before basic cache initializations ('+recentResult+')')
           return 1;
        }

          thisTerm='About to create fileLists, and buttons, in cache subdirectory ...'      ;
          $('#iDirCacheControlTable_desc').html(thisTerm);
          window.setTimeout(function() {
            origData['action']='fileList' ; origData['doResume']=0;origData['timeAllowed']=0;
             wsurvey.getJson.get('wsGalleryActionsAdmin.php',origData,[doDirCacheJs2,otherArgs],'doDirCacheJs (fileList)');
          },25);
          return 1;
     }

// filelist step completed, or in ready to resume state.  next is thm40   ......----------------.
     if (zaction=='filelist')  {            // filelist created (with descriptive info, etc)   -- but maybe this is a "resume" return?

        let doResume=hh['doResume'];

        if (doResume==1) {
            let aspin=getSpinnerImg(30);
            $('#iDirCacheControlTable_desc').html(aspin+' '+recentResult).addClass('cDirCacheControlTableCol2D'); // results from server
        } else {
           $('#iDirCacheControlTable_desc').html(recentResult).addClass('cDirCacheControlTableCol2D'); // results from server
           otherArgs['reportFileList']=hh['content'] ;  // basic results
        }

        if (doResume==1) {
           if (qstop) {
              $('#iDirCacheControlErr').html('Processing stopped while doing basic cache creation (filelists, etc) ('+recentResult+')')  ;
              return 1;
          }
          window.setTimeout(function() {
             origData['action']='fileList' ; origData['doResume']=1;origData['timeAllowed']=0 ;        // timealowed =0 (force show of file, buttons, etc)
             wsurvey.getJson.get('wsGalleryActionsAdmin.php',origData,[doDirCacheJs2,otherArgs],'doDirCacheJs (filelist resume)');
          },25);
          return 0;
        }

 // if here, not a resume.  so Get thum40
        if (qstop) {
           $('#iDirCacheControlErr').html('Processing stopped after basic cache creation (filelists, etc) ('+recentResult+')')  ;
           return 1;
        }
        q1=$('#chkDirCacheControlTable_thm40').prop("checked");  // skip thm40 step?
        if (!q1) {
           recentResult='Skip: create thm40 creation in cache subdirectory ...'
           zaction='thm40' ;  // hack to go to post-readme step
        } else{
           thisTerm='About to create thm40 in cache subdirectory ...'
           $('#iDirCacheControlTable_thm40').html(thisTerm);
           window.setTimeout(function() {
              origData['action']='thm40' ; origData['doResume']=0; origData['timeAllowed']=4 ;
              wsurvey.getJson.get('wsGalleryActionsAdmin.php',origData,[doDirCacheJs2,otherArgs],'doDirCacheJs (thm40)');
           },50);
           return 1;
        }
     }       // fileList

// comppleted thm40 thunbmails. .. (or a resume?)    ---------------------
      if (zaction=='thm40')  {            // thm40 done, next is thm66
         let doResume=hh['doResume'];
        if (doResume==1) {
            let aspin=getSpinnerImg(30);
           $('#iDirCacheControlTable_thm40').html(aspin+' '+recentResult).addClass('cDirCacheControlTableCol2D'); // results from server
        } else {
           $('#iDirCacheControlTable_thm40').html(recentResult).addClass('cDirCacheControlTableCol2D'); // results from server
        }

        if (doResume==1) {
           if (qstop) {
              $('#iDirCacheControlErr').html('Processing stopped while creating thm40 thumbails ('+recentResult+')')  ;
              return 1;
          }
          window.setTimeout(function() {

              origData['action']='thm40'; origData['doResume']=1;
              wsurvey.getJson.get('wsGalleryActionsAdmin.php',origData,[doDirCacheJs2,otherArgs],'doDirCacheJs (thm40 resume)');
          },60);
          return 0;
        }          // if here, not a resume.  so Get thum66
        if (qstop) {
           $('#iDirCacheControlErr').html('Processing stopped before 66x66 thumbnails')
           return 1;
        }
        q1=$('#chkDirCacheControlTable_thm66').prop("checked");
        if (!q1) {
          recentResult='Skipped: create 66x66 thumbnails ...'
          zaction='thm66';
       } else {
          let thisTerm='About to create  66x66 thumbnails ...'
          $('#iDirCacheControlTable_thm66').html(thisTerm);
          window.setTimeout(function() {
             origData['action']='thm66'; origData['doResume']=0;
              wsurvey.getJson.get('wsGalleryActionsAdmin.php',origData,[doDirCacheJs2,otherArgs],'doDirCacheJs (thm66)');
          },60);
       }      //q1
     }       // thm40

// comppleted thm66 thunbmails. .. (or a resume?)   --------------------
      if (zaction=='thm66')  {            // thm66 done, next is thm90
        let doResume=hh['doResume'];
        if (doResume==1) {
            let aspin=getSpinnerImg(30);
           $('#iDirCacheControlTable_thm66').html(aspin+' '+recentResult).addClass('cDirCacheControlTableCol2D'); // results from server
        } else {
           $('#iDirCacheControlTable_thm66').html(recentResult).addClass('cDirCacheControlTableCol2D'); // results from server
        }

        if (doResume==1) {
           if (qstop) {
              $('#iDirCacheControlErr').html('Processing stopped while creating thm66 thumbails ('+recentResult+')')  ;
              return 1;
          }
          window.setTimeout(function() {
             origData['action']='thm66'; origData['doResume']=1;
              wsurvey.getJson.get('wsGalleryActionsAdmin.php',origData,[doDirCacheJs2,otherArgs],'doDirCacheJs (thm66 resume)');
          },60);
          return 0;
        }

      if (qstop) {
         $('#iDirCacheControlErr').html('Processing stopped before 90x90 thumbnails')
         return 1;
      }
       q1=$('#chkDirCacheControlTable_thm90').prop("checked");
       if (!q1) {
          recentResult='Skipped: create 90x90 thumbnails ...'
          zaction='thm90';
       } else {
          let thisTerm='About to create  90x90 thumbnails ...'
          $('#iDirCacheControlTable_thm90').html(thisTerm);
         window.setTimeout(function() {
             origData['action']='thm90'; origData['doResume']=0;
//             var adata={'todo':'dirCache','action':'thm90','dir':adir,'overwrite':iOverwrite,'treename':treeName,'doResume':0,'timeAllowed':0  };
              wsurvey.getJson.get('wsGalleryActionsAdmin.php',origData,[doDirCacheJs2,otherArgs],'doDirCacheJs (thm90)');
          },60);
       }      //q1
     }       //  thm66


// comppleted thm90 thunbmails. .. (or a resume?)  ------------------
    if (zaction=='thm90')  {            // thm90 done, next is snap
        let doResume=hh['doResume'];
        if (doResume==1) {
            let aspin=getSpinnerImg(30);
           $('#iDirCacheControlTable_thm90').html(aspin+' '+recentResult).addClass('cDirCacheControlTableCol2D'); // results from server  -- in process
        } else {
           $('#iDirCacheControlTable_thm90').html(recentResult).addClass('cDirCacheControlTableCol2D'); // results from server
        }

        if (doResume==1) {
           if (qstop) {
              $('#iDirCacheControlErr').html('Processing stopped while creating thm90 thumbails ('+recentResult+')')  ;
              return 1;
          }
          window.setTimeout(function() {
              origData['action']='thm90'; origData['doResume']=1;
              wsurvey.getJson.get('wsGalleryActionsAdmin.php',origData,[doDirCacheJs2,otherArgs],'doDirCacheJs (thm90 resume)');
          },60);
          return 0;
        }          // doresume=1

       if (qstop) {
          $('#iDirCacheControlErr').html('Processing stopped before snapshots')
          return 1;
       }
       q1=$('#chkDirCacheControlTable_snap').prop("checked");
       if (!q1) {
          recentResult='Skipped: create snapshots...'
          zaction='snap';
       } else {
          let thisTerm='About to create  snapshots ...'
          $('#iDirCacheControlTable_snap').html(thisTerm);
          window.setTimeout(function() {
             origData['action']='snap'; origData['doResume']=0;
              wsurvey.getJson.get('wsGalleryActionsAdmin.php',origData,[doDirCacheJs2,otherArgs],'doDirCacheJs (snapshot)');
          },60);
       }      //q1
     }       //  thm90

// comppleted snapshots .. (or a resume?)  ------------------------
     if (zaction=='snap')  {            // snap done, that is the almost last...
        let doResume=hh['doResume'];
        if (doResume==1) {
            let aspin=getSpinnerImg(30);
           $('#iDirCacheControlTable_snap').html(aspin+' '+recentResult).addClass('cDirCacheControlTableCol2D'); // results from server    -- in process
        } else {
           $('#iDirCacheControlTable_snap').html(recentResult).addClass('cDirCacheControlTableCol2D'); // results from server
        }

        if (doResume==1) {
           if (qstop) {
              $('#iDirCacheControlErr').html('Processing stopped while creating snapShots ('+recentResult+')')  ;
              return 1;
          }
          window.setTimeout(function() {
              origData['action']='snap'; origData['doResume']=1;
              var adata={'todo':'dirCache','action':'snap','dir':adir,'overwrite':iOverwrite,'treenaMe':treeName,'doResume':1};
              wsurvey.getJson.get('wsGalleryActionsAdmin.php',origData,[doDirCacheJs2,otherArgs],'doDirCacheJs (snapshot resume)');
          },60);
          return 0;
        }   // doresume=1

        if (qstop) {
            $('#iDirCacheControlErr').html('Processing stopped before summary')
            return 1;
         }

         q1=$('#chkDirCacheControlTable_summary').prop("checked");
         if (!q1) {
            recentResult='Skipped: create summary...'
            zaction='summary';
         } else {
            let thisTerm='About to create  summary ...'
            $('#iDirCacheControlTable_summary').html(thisTerm);
            window.setTimeout(function() {
               origData['action']='summary'; origData['doResume']=0;
                wsurvey.getJson.get('wsGalleryActionsAdmin.php',origData,[doDirCacheJs2,otherArgs],'doDirCacheJs (summary)');
            },30);
         }      //q1
     }    // zaction=snap

// final step: summary
     if (zaction=='summary')  {            // summary done, that is the last... so done! No need to check stop button
     $('#iDirCacheControlTable_summary').html(recentResult).addClass('cDirCacheControlTableCol2D'); // results from server

       if (otherArgs['isMulti']==0) {          // just one dir
           let sayr='<div style="background:#ddeeed;margin:5px 3em 5px 3em">';
           sayr+='<div style="color:green;font-size:110%">Done with initialization: directory <tt>'+adir+'</tt> in tree <em>'+treeName+'</em>. </div>';
           sayr+='<ul type="tightList">';
           sayr+='<li>If you add files, you can rerun this.  ';
           sayr+='<li>You can <input type="button" title="Click to reload wsGallery ..." value="reload wsGallery" onClick="wsGallery_reload(this,2,0)" >  ';
           sayr+='<li>If you add  (or remove) a lot of files , consider updating this tree\'s summary information by using   &#9881;&#65039; <button>refresh</button>   </span>';
           sayr+='<li><input type="button" value="Close ..." onClick="wsurvey.flContents.container.close(this)" >';
           sayr+=' and return to the <b>admin mode for  tree <tt>'+treeName+'</tt></b> menu  ';
           sayr+='</ul>';
           sayr+='</div>';

           let zfailsOld=$(document).data('zFails');
           if (zfailsOld.length>0) {
               let arf='Errors processing images:<br>';
               for (var kk=0;kk<zfailsOld.length;kk++) {
                   var azk=zfailsOld[kk];
                   arf+='<br>(<span title="action in  file">'+azk[1]+' <tt>'+azk[0]+'</tt></span>) <em>'+azk[2]+'</em>';
               }
               sayr+='<div style="xwhite-space:pre;margin:5px 3em;padding:5px;background-color:#dfdfef;max-height:7em;overflow:auto">';
               sayr+=arf;
               sayr+='</div>';
           }
           $(document).data('zFails',[]);

           $('#iDirCacheControlErr').html(sayr);
           q1=$('#chkDirCacheControlTable_desc').prop("checked");
           return 1;
       }


 // is multi=1
       let dlist=otherArgs['list'];
       let ndone=otherArgs['nextToDo'];    // when here, next to do is 'one just done'
       let justDid=dlist[ndone];
       let areport='<ol type="a"><li>'+otherArgs['reportFileList']+'<li>&hellip;'+hh['content'];
       areport+='</ol>  ';
       let zfailsOld=$(document).data('zFails');
       if (zfailsOld.length>0) {
               let arf='Errors processing images:<br>';
               for (var kk=0;kk<zfailsOld.length;kk++) {
                   var azk=zfailsOld[kk];
                   arf+='<br>(<span title="action">'+azk[0]+'</span>) <tt>'+azk[1]+'</tt>';
               }
               areport+='<div style="white-space:pre;margin:5px 3em;padding:5px;background-color:#dfdfef;max-height:5em;overflow:auto">';
               areport+=arf;
               areport+='</div>';
       }
       $(document).data('zFails',[]);

       let e3=wsurvey.flContents.find('snapBox3','#doDirCache_multiStatus');
       let erows=e3.find('[name="doDirCache_multiStatus_row_dir"]');
       let erow1=erows.filter('[data-dir="'+justDid+'"]');
       let etr=erow1.closest('tr');
       let estatus=etr.find('[name="doDirCache_multiStatus_row_status"]');
       estatus.html(areport);

       ndone++;      // get the next one?

       if (ndone>=dlist.length) {       // all done!
           let sayr='<div style="background:#ddeeed;margin:5px 3em 5px 3em">';
           sayr+='<div style="color:green;font-size:110%">Done with initialization of '+dlist.length+' directories  in tree <em>'+treeName+'</em>.';
           sayr+=' <tt>('+wsurvey.addComma(otherArgs['totSize'])+' bytes in ' +otherArgs['totFiles']+' files) </tt> ';
           sayr+='<div style="font-size:80%;margin:3px 2em 3px 2em;background-color:#dfdfdf">'+dlist.join(' | ')+' </div>';
           sayr+='<ul type="tightList">';
           sayr+='<li>If you add files, you can rerun this.  ';
           sayr+='<li>You can <input type="button" title="Click to reload wsGallery .. .. " value="reload wsGallery" onClick="wsGallery_reload(this,3,0)" >  ';
           sayr+='<li>If you add  (or remove) a lot of files , consider updating this tree\'s summary information by using   &#9881;&#65039; <button>refresh</button>   </span>';
           sayr+='<li><input type="button" value="Close ..." onClick="wsurvey.flContents.container.close(this)" >';
           sayr+=' and return to the <b>admin mode for  tree <tt>'+treeName+'</tt></b> menu  ';
           sayr+='</ul>';
           sayr+='</div>';
           let zfailsOld=$(document).data('zFails');
           if (zfailsOld.length>0) {
               let arf='Errors processing images:<br>';
               for (var kk=0;kk<zfailsOld.length;kk++) {
                   var azk=zfailsOld[kk];
                   arf+='<br>(<span title="action">'+azk[0]+'</span>) <tt>'+azk[1]+'</tt>';
               }
               sayr+='<div style="white-space:pre;margin:5px 3em;padding:5px;background-color:#dfdfef;max-height:7em;overflow:auto">';
               sayr+=arf;
               sayr+='</div>';
           }
           $(document).data('zFails',[]);
           $('#iDirCacheControlErr').html(sayr);
           q1=$('#chkDirCacheControlTable_desc').prop("checked");
           return 1 ;
       }

// more to do...
       let adirb=dlist[ndone ];

       let goof=[];
       for (var mm=0;mm<dlist.length;mm++) {
          if (mm==ndone) {
               goof.push('<span style="display:inline-block;white-space:nowrap;font-weight:700;margin:0.1em 0.1em 4px 1em;padding:3px 3px 3px 3px;border:2px solid green" title="Now initializing this directory!">'+dlist[mm]+'</span> ');
          } else  if (mm<ndone) {
                goof.push('<span style="display:inline-block;white-space:nowrap;margin:0.1em .1em 4px 0.1em;padding:3px 3px 3px 3px;border:1px solid #afdfdf;opacity:0.7" title="Initialized!">'+dlist[mm]+' </span> ');
          } else {
                goof.push('<span style="display:inline-block;white-space:nowrap;margin:0.1em .1em 4px 0.1em;padding:3px 3px 3px 3px;border:2px solid #afadbf; " title="... to be initialized. ">'+dlist[mm]+' </span> ');
          }
       }
       let nowTimeX=parseInt(Date.now()/1000);
        let eReport=$('#doDirCachePhp_makeMenu_multi');
        let eR1=eReport.find('[name="nToBeInitStatus"]');
        let dstart=parseInt(eR1.attr('data-start'));
        let ddone=parseInt(eR1.attr('data-done'));
        let dTot=eR1.attr('data-total');

        let totEps=nowTimeX-dstart;
        let totEpsSay=wsurvey.seconds_ToTime(totEps);

        let ddone1=ddone+1;
        eR1.attr('data-done',ddone1);

        let mess1=ddone1+' / '+dTot+' : eps='+totEpsSay ;
        eR1.html(mess1);

        let eR2=eReport.find('[name="nToBeInitList"]');
        let eprior=eR2.find('[data-ict="'+ddone+'"]');
        eprior.removeClass('cToBeInit_done  cToBeInit_now cToBeInit_later');
        eprior.addClass('cToBeInit_done') ;
        eprior.attr('title','Initialization complete');
        let enow=eR2.find('[data-ict="'+ddone1+'"]');
        enow.removeClass('cToBeInit_done  cToBeInit_now cToBeInit_later');
        enow.addClass('cToBeInit_now') ;
        enow.attr('title','Being initialized ...');


//       let agoof='Directories to be initialized: <span class="cToBeInitStatus"  data-total="'+goof.length;
//       agoof+=' data-done="0" data-start="'+nowTime+'" name="nToBeInitStatus">0 of '+goof.length+' : eps=0:00:00</span> ' ;
//       agoof+='<div>'+goof.join(' ')+'</div>';
//       $('#doDirCachePhp_makeMenu_multi').html(agoof);

// get ready to do the next one
       origData['action']= 'cacheInit';
       origData['dir']=adirb;
       origData['resume']=0 ;
        otherArgs['reportFileList']='';
        otherArgs['nextToDo']=ndone;
        otherArgs['totSize']+=hh['summaryStats'][0];
        otherArgs['totFiles']+=hh['summaryStats'][1];
        let gug='';
        gug+=' current stats: ' +otherArgs['totSize'];
        gug+=' and ' +otherArgs['totFiles'] ;
        let ew=$('.cDirCacheControlTableCol2');  // clear step reports
        ew.html(' ');
      wsurvey.getJson.get('wsGalleryActionsAdmin.php',origData,[doDirCacheJs2,otherArgs],'doDirCacheJs2 (start # '+ndone+')');
      return 1;


   }        //summary done

  }  // doDirCacheJs2b  function
}     // doDirCacheJs  function


//=====================
// mark a dir (in a tree) to be initialized
// &#128994; large green cicle
// &#128998; large blue square
function markToInitialize(athis) {
   let ethis=wsurvey.argJquery(athis);
   let eparent=ethis.closest('[name="dirListInitialize0"]');
   if (eparent.length==0) return false ;   // should never happen
   let treename=eparent.attr('treename');
   let adir=eparent.attr('dir');
   let e2=eparent.find('[name="dirListInitialize2"]');
   if (e2.length==0) return false ;   // should never happen
   let e3=e2.find('[name="dirListInitializeNow"]'); // already selected, or selected and removed? Toggle
   if (e3.length>0) {
       let e4=e3.closest('span');
       if (e4.is(':visible')) {
           e4.hide();
       } else {
           e4.show();
       }
   } else {
       let ss='<input type="button" class="csmallButton2"  value="&#128994;" name="dirListInitializeNow"  ';
       ss+='        title="Click to custom initialize this directory.&#010;Or, use the `&#128994;ALL` button to initialize this, and other marked, directories"> ';
       e2.html(ss).show();
   }

// now count them all
   let etable=eparent.closest('#dirListingTableAdmin');
   let einits0=etable.find('[name="dirListInitializeNow"]');
   let einits=einits0.filter(':visible');
   let nInitDirs=einits.length;

   let egoo=$('#dirListInitAllOuter');
   if (nInitDirs ==0) {
       egoo.hide();
   } else {
     let newTitle="Click to initialze the "+nInitDirs+" selected  directories \n(that are marked with a \uD83D\uDFE2)"  ;
     let egooB=egoo.find('input');
     egooB.attr('title',newTitle);
     egoo.show();
   }

}

//=======================
// seelct all dirs between first and last current selected. OR seelet all
function dirListMarkAll(ethis) {
   let etable=ethis.closest('#dirListingTableAdmin');
   let einits0=etable.find('[name="dirListInitialize0"]');

   let i1=-1;i2=einits0.length;           // defaults is makr all

   for (var i1a=0;i1a<einits0.length;i1a++) {
       let einit=$(einits0[i1a]);
       let einit2=einit.find('[name="dirListInitialize2"]');
       if (einit2.is(':visible')) {
            i1=i1a;
            break;
       }
   }
   if (i1>-1) {   // something marked... find last
      for (var i2a=einits0.length-1;i2a>i1;i2a--) {      // don't go below i1
         let einitb=$(einits0[i2a]);
         let einit2b=einitb.find('[name="dirListInitialize2"]');
         if (einit2b.is(':visible')) {
             i2=i2a;
             break;
         }
      }
   }

// mark between. If no marks, mark all. If just one, mark everything below

   for (var jj=i1+1;jj<i2;jj++) {
         let einitc=$(einits0[jj]);
         let einit2c=einitc.find('[name="dirListInitializeNow"]');
         if (!einit2c.is(':visible')) {
            let einit2cB=einitc.find('[name="dirListInitialize"]');
            einit2cB.trigger("click");
         }
   }

}


//===================
// retrieve a list of dirs in a tree, suitable for updating
function getDirCacheAdmin(athis,atreename,amessage) {
    if (arguments.length<2) {
      let ethis=wsurvey.argJquery(athis);
      atreename=ethis.attr('treename');
      aenable='';
    }
   let aspin=getSpinnerImg(30);

//   console.log('Retrieving dirList for '+atreename);
   $('#getDirAdmin_status').html(aspin+' .. retrieving dirList for '+atreename).show();
   wsurvey.flContents.scrollTop('admin',10,0);
    if (arguments.length<3) amessage='';
    let adata={'todo':'getDirCacheAdmin','treename':atreename,'message':amessage};
    wsurvey.getJson.get('wsGalleryActionsAdmin.php',adata ,getDirCacheAdmin1,'updatedir cache ');

    let ehh=$('[name="headerToggleSwitchTreeButton"]');
    ehh.css({"opacity":0.2})
}


 function getDirCacheAdmin1(zdata,origData)  {

   $('#getDirAdmin_status').hide();
   var hh=wsurvey.getJson.check(zdata,0,'Callback from getDirCacheAdmin') ;
   if (hh===false) return 0;
   let acontent=hh['content'];
   let basics=hh['basics'];
   wsurvey.flContents.contents('dirList', acontent);
   let aheader=' : In the <tt>'+basics.totDirs+' </tt> directories in tree <span class="headerEmphasizer" >'+basics['treeName']+'</span>: # files=<tt>'+basics.totFiles+' (including <tt>'+basics.totImages+'</tt> images) ';
   wsurvey.flContents.header('dirList',aheader);

   if (origData['message']!='')  $('#switchTreeMenu').html(origData['message']);

   $('#dirListingTableAdmin').data('lastFocus',0);
   $('#dirListingTableAdmin').on('click',dirListClickHandler) ;  // passes to the appropriate handler
   $('#dirListingTableAdmin').on('change',dirListChangeHandler) ;  // passes to the appropriate handler


 }


