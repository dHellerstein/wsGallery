; ====================================================================================================
;
; wsGallery parameters specification file
;  For security reasons: this must be edited by a site administrator. It is not editable via wsGallery.php
; See wsGallery_readMe.txt for descriptions
;
; ============================== begin user changeable parameters
imgExts:    png , gif , jpg , jpeg , bmp , xbm

otherExts:    mov  v   video/quicktime  , mp4 v video/mp4
 otherExts:   mpg v , mpeg v  ,  avi v
 otherExts:    pdf e application/pdf
 otherexts:   txt  frame text  text , text f text  text
 otherExts:   htm f text  html  , html  f text html
 otherExts:   xls f   https://view.officeapps.live.com/op/embed.aspx?src=
 otherExts:   xlsx f  https://view.officeapps.live.com/op/embed.aspx?src=
 otherExts:   ppt f  https://view.officeapps.live.com/op/embed.aspx?src=
 otherExts:   pptx f  https://view.officeapps.live.com/op/embed.aspx?src=
 otherExts:   doc f https://view.officeapps.live.com/op/embed.aspx?src=
 otherExts:   docx f  https://view.officeapps.live.com/op/embed.aspx?src=

onTheFlyThumbnails: 1
onTheFlySnapshots: 1
noCache: 0

skips:  trash,tmp,temp,$RECYCLE.BIN

