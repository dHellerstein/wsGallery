
// ====================
//  admin js functions
// ====================

//===============
// enable admin mode -- when gear button clicked. Only permitted if logged on
function doAdmin1(forceShow ) {

  var adminEnable ;

  var tt=typeof($(document).data('logonStatus'));
  if (tt=='undefined') $(document).data('logonStatus',0);
  var logonStatus=$(document).data('logonStatus');
  if (logonStatus==0) {
     alert("To use admin mode, you must first logon ");
     return 1;
  }
  if (forceShow==1) {
    $(document).data('adminModeEnabled',1);
    adminEnable=1;
  } else {
       adminEnable=$(document).data('adminModeEnabled');
      if (adminEnable==1) {                                // dispale
         adminEnable=0;
         $(document).data('adminModeEnabled',0);
     } else {
         adminEnable=1;
         $(document).data('adminModeEnabled',1);
     }
  }
  if (adminEnable==0 ) {                    // now disabled
        wsurvey.flContents.hide(200,'admin');
        $('#itopBarRightEnable').hide();
        return 0;
  }
// othweise, get admin menu from server and display it in admin box
  $('#itopBarRightEnable').show();
   wsurvey.flContents.show(200,'admin');
   var data={'todo':'getAdminMenu'} ;
   wsurvey.getJson.get("wsGalleryActionsAdmin.php",data,doAdmin2c);
 
}


//=====================
// show admin menu in admin contentbox
function doAdmin2c(zdata) {

      var hh=wsurvey.getJson.check(zdata,0,'callBack from doAdmin');
      if (hh===false) return 0;  // not used
      let  eadmin=wsurvey.flContents.dom('#admin','m');
             eadmin.wsFlContents('xx');
       eadmin.wsFlContents(hh['content']);
       eadmin.wsFlOnTop(1);
       eadmin.wsFlHeader('Admin menu');
       eadmin.wsFlShow(10);
     return 1 ;                  // not used
}

//===========
// tell server to create (or update/revise) the dir list for a tree
function makeTreeDirList(athis) {
   var stuff='';

   var ethis=wsurvey.argJquery(athis);
   var treename=ethis.wsurvey_attr('data-treeName','_default');
   var isUpdate=ethis.wsurvey_attr('data-isUpdate',0 );

    stuff='<div id="getAdminMenu_results" title="current progress displayed here " class="cGetAdminMenu_results" > progress displayed here ... </div>';

    stuff+=' <input  class="makeDirListGoButton" id="imakeTreeDirList_GoButton" type="button" value="Go!" ';
    stuff+='   title="Create  ... with the selected options" onClick="makeTreeDirList_Go(this)" data-treename="'+treename+'" data-update="'+isUpdate+'"  > ';
     if(isUpdate==1) { stuff+='re-Creating directory list ' } else { stuff+='Creating directory tree '; }
    stuff+=' for the  <b>'+treename+'</b> <em>tree</em>';
    stuff+='<menu class="linearMenu" style="margin:3px 1em 3px 1em">';
    if (isUpdate==1) {
       stuff+='<li class="linearMenuLi2"><input type="checkbox" id="makeTreeDirList_retainDisabled" value="1" checked>';
       stuff+='<label for="makeTreeDirList_retainDisabled" title="Retain all the prior `disabled directories` settings"  >Retain <em>disabled directory</em> </label>';
       stuff+='<li class="linearMenuLi2"><input type="checkbox" id="makeTreeDirList_retainDescriptions" value="1" checked>';
       stuff+='<label for="makeTreeDirList_retainDescriptions" title="Retain all the prior `directory descriptions`"  >Retain <em>directory descriptions</em> </label>';
       stuff+='<li class="linearMenuLi2"><input type="checkbox" id="makeTreeDirList_removeUnusedCacheDirs" value="1"  >';
       stuff+='<label for="makeTreeDirList_removeUnusedCacheDirs" title="Remove directories from the cache that are no longer used ">Remove unused cache directories</label>';

    }
    stuff+='</menu>';

    wsurvey.flContents.content('dirList',stuff,{'append':0,'onTop':1});
 // et2.html(stuff);
//    et2.show();
   window.setTimeout(function(){ $('#imakeTreeDirList_GoButton').focus();},100);
}

// --- 2nd step -- this does the work (called by button created above)
function makeTreeDirList_Go(athis) {
   var ethis=wsurvey.argJquery(athis);
   var removeUnusedCache=0,keepDisabled=1,keepDescriptions=1,kmess=' ',amess;
   var treename=ethis.wsurvey_attr('treeName,data-treename','_default');

   var isUpdate=ethis.wsurvey_attr('Update,data-update',0 );
   if (isUpdate==1) {
       let ee=$('#makeTreeDirList_retainDisabled');
       let qee=ee.prop('checked');
       if (qee) {
          keepDisabled=1; kmess='Prior designation of disabled directory are <b>retained</b>. ';
       } else {
          keepDisabled=0; kmess='Prior designation of disabled directory are <b>not</b> retained. ';
       }
       let ee2=$('#makeTreeDirList_retainDescriptions');
       let qee2=ee.prop('checked');
       if (qee) {
          keepDescriptions=1; kmess+='Prior directory descriptions are <b>retained</b>. ';
       } else {
          keepDescriptions=0; kmess+='Prior ddirectory descriptions  are <b>not</b> retained. ';
       }
        amess='re-Creating the directoryList (and cache) for <u>'+treename+'</u>.<br> '+kmess;
   } else {
       amess='Creating the directoryList (and cache) for  <u>'+treename+'</u>.<br>' ;
   }
   let ee2=$('#makeTreeDirList_removeUnusedCacheDirs');
   let qee2=ee2.prop('checked');
   if (qee2) {
      removeUnusedCache=1 ;
      amess+=' Unused cache directories will be deleted ';
   }

// mustHaveViewable hardcoded to 1. Maybe change later (8 jan 2022)

    var ddata={'todo':'makeDirList','treeName':treename,'keepDisabled':keepDisabled,'keepDescriptions':keepDescriptions,
          'mustHaveViewable':1,'timeAllowed':0,'removeUnusedCache':removeUnusedCache,'doResume':0};
 
   let et2=$('#getAdminMenu_results');
   let aspin=getSpinnerImg(25);         // get a <img ..> to a spinner (just for fun)
   let amess3='<div class="cdirListStatus" id="idirListStatus" title="status of directory creation for tree '+treename+'">'+aspin+' Please wait ...</div>';
   et2.html(amess+' '+amess3);
   et2.show();

    window.setTimeout(function(){
       $('#imakeTreeDirList_GoButton').prop('disabled',true);

        wsurvey.getJson.get("wsGalleryActionsAdmin.php",ddata,makeTreeDirList2,'makeTreeDirList_Go ');
        }, 150);  // delay a bit (so user sees please wait message)
   return 1;
}

// --- call back from srever
function makeTreeDirList2(zdata,origData) {

   var  hh= wsurvey.getJson.check(zdata,0,'makeTreeDirList callback') ;
   if (hh===false) return 0;

   let treename=origData['treeName'],keepDisabled=origData['keepDisabled'],removeUnusedCache=origData['removeUnusedCache'] ;
   let  keepDescriptions=origData['keepDescriptions'],mustHaveViewable=origData['mustHaveViewable'];   ;

// an  "iterative" loop...  Call this back, assuming php uses resumeStatus to resume where it stopped to send back a status report
   if (hh['doResume']==1) {                  // if 0, a "final" return (not a "report status")
       let ee1=$('#idirListStatus') ;
       let rmessage=hh['resumeMessage'];
       let spinImage=getSpinnerImg(35);
       ee1.html(spinImage+' ' +rmessage);
        var ddata={'todo':'makeDirList','treeName':treename,'keepDisabled':keepDisabled,
                'mustHaveViewable':mustHaveViewable,'keepDescriptions':keepDescriptions,
               'removeUnusedCache':removeUnusedCache,'doResume':1};
        window.setTimeout(function(){
             wsurvey.getJson.get("wsGalleryActionsAdmin.php",ddata,makeTreeDirList2,'makeTreeDirList2 (doresume)');
          }, 50);  // delay a bit (so user sees please wait message)
        return 1 ;
   }
   let ee1=$('#idirListStatus') ;
   ee1.html(hh['resumeMessage']);

   let et1=$('#getAdminMenu_results');
   et1.html(hh['content']+'<hr>'+hh['cacheInfo']);
   et1.css({'opacity':'1.0'});
   et1.show();
}



//===============
// mark a descripiotn as being changedd
function updateDirDescMark(athis) {
   var ethis=wsurvey.argJquery(athis);
   ethis.attr('didChange',1); // marked as changed
}
//==============
// update descriptions (that have changed)
function updateFileDescriptions(athis) {
  var dachanges=[];
   var ethis=wsurvey.argJquery(athis);
   let atreename=ethis.attr('treename');
   let adir=ethis.attr('adir');

   var epar=ethis.wsFlClosest();
   let etexts=epar.wsFlFind('[name="fileDescs"]');
   let echanges=etexts.filter('[data-changed="1"]');

   for (var i0=0;i0<echanges.length;i0++) {
       let e1=$(echanges[i0]);
       let afile=e1.attr('afile');
       let newval=e1.val();
       let goo=[afile,newval] ;
       dachanges.push(goo);
   }

   let ddata={'todo':'updateFileDescs','changes':dachanges,'treeName':atreename,'dir':adir};

   wsurvey.getJson.get("wsGalleryActionsAdmin.php",ddata,updateFileDescriptions2,'updateFileDescriptions  ');



   return 1;


//=====================
// show admin menu in admin contentbox
function updateFileDescriptions2(zdata,origData) {

    var  hh=wsurvey.getJson.check(zdata,0,'Callback for updateFileDescriptions');
 
    if (hh===false) return 0;

    let dirSel=origData['dir'];

    let edr=$('#descriptionReport') ;
    edr.show();
    let edr2=edr.find('#descriptionReport2');
    edr2.show();

    acontent=' <input type="button" title="Click to reload wsGallery" value="reload" onClick="location.reload(true)" >  ';
    acontent+=hh['content'];
    edr2.html(acontent);
 //   eDescTexts.attr('didChange',0);  // reset change flag

 }
}

//====================
// save notes (for debugging)   Feb 2022 : mostly deprecated
function saveNotes(amess) {
   let    adminEnable=$(document).data('adminModeEnabled');
   if (adminEnable>0) {
       let messy=$(document).data('adminNotes')
        messy.push(amess);
       $(document).data('adminNotes', messy) ;
   }
}
function showNotes(a) {        // if here, admin mode enabed (else no button showsn)
  let dd=$(document).data('adminNotes' );
   var goo=dump(dd,'none',5);
   let stuff='<h4>Notes</h4>';
   stuff+='<pre>'+goo+'</pre>';
   wsurvey.flContents.contents('admin',stuff);

}


//==================  ==========================
//==================  ==========================

function doDescriptionsDir(athis) {
  var ethis=wsurvey.argJquery(athis);
  var atree1=ethis.wsurvey_attr('tree,treename','');
  var e1=ethis.wsFlClosest();
  let ee=e1.find('[name="dirListDescArea"]');
  let ee2=ee.filter('[data-changed="1"]');
  if (ee2.length==0) {
     alert('No dirDescription changes were made ');
     return 0; // nothing to change
  }
  var stuff=[];
  for (var ii=0;ii<ee2.length;ii++) {
      let aee=$(ee2[ii]);
      let adir=aee.attr('dirname');
      let adesc=aee.val();
      let xx=[adir,adesc];
      stuff[ii]=xx;
  }

  let adata={'todo':'updateDirDescs','list':stuff,'treename':atree1};
  wsurvey.getJson.get('wsGalleryActionsAdmin.php',adata,doDescriptionsDir1,'do descs');
}
function doDescriptionsDir1(zz,origData) {

//  wsurvey.dumpObj(zz,1,'dir1');
    hh=wsurvey.getJson.check(zz,0,'callBack doDescriptionsDir1' )   ;
    let atree=origData['treename'];

    getDirCacheAdmin(0,atree,hh['content']);

}

//===============
// append original descrition of a dir (to dir descripiton textarea)
function addOriginalDirDesc(athis) {
  var ethis=wsurvey.argJquery(athis);
  let etable=$('#dirListingTableAdmin');
  let efocus=etable.data('lastFocus');
  let eorig=efocus.attr('origDesc');
  let eorigB=atob(eorig);
  efocus.append(' '+eorigB);
  efocus.trigger('change');

}


//==================
// disable a tree  :
function doDisableTree(athis) {
    let ethis=wsurvey.argJquery(athis);
   let atreename=ethis.attr('treename');
   let isDisabled=ethis.attr('isDisabled');
   let adata={'todo':'disableATree','treename':atreename,'current':isDisabled};
   wsurvey.getJson.get('wsGalleryActionsAdmin.php',adata ,doDisableTree1,'doDisableTree   ');

}
 function doDisableTree1(zdata)  {
   var hh=wsurvey.getJson.check(zdata,0,'Callback from doDisableTree') ;
   if (hh===false) return 0;
   let acontent=hh['content'];
   doAdmin(1);
   window.setTimeout(function() {
       let hcontent=acontent+' &boxV; To update  <em>select a directory tree</em> ... <input type="button" value="reload wsGallery" onClick="location.reload(true)" >';
       $('#getAdminMenu_results').html(hcontent);},
       500);

 }
 
//================  ==========================================
// dirlist change handler (several possible actions, depending on what was clicked

function dirListChangeHandler(evt) {
    let ethis=wsurvey.argJquery(evt);
    let aname=ethis.attr('name');

    if (aname=='dirListDescArea') {  // simple case: click in desription area -- so that the "lastFocus"
       ethis.attr('data-changed',1);
       ethis.addClass('cDescChanged')
       
       
 // highlignt updateDir description  button?
      let sibs=ethis.wsFlFind('.cDescChanged',1);
      if (sibs.length>0) {
         $('[name="doDescriptionsDirButton"]').addClass('cDirButton_active');
      } else {
        $('[name="doDescriptionsDirButton"]').removeClass('cDirButton_active');
      }

   }     // dirListDescArea

   return 1;
}


//================  ==========================================
// dirlist click handler (several possible actions, depending on what was clicked
function dirListClickHandler(evt) {
   let ethis=wsurvey.argJquery(evt);
   let aname=ethis.attr('name');

   if (aname=='dirListDescArea') {  // simple case: click in desription area -- so that the "lastFocus"
      let eparent=wsurvey.argJquery(evt,'delegateTarget');
      eparent.data('lastFocus',ethis);
      return 1;
   }           // dirlistdescarea

   if (aname=='dirListFileDescButton') {  // view the list of files and their descriptions button
       doChangeFileDescs(ethis) ;
       return 1;
   }

   if (aname=='dirListFileViewFiles') {  // view list of files (with showfile buttons)
       getDirFileListJs(ethis) ;
       return 1;
   }


   if (aname=='dirListDisableButtons') {  // disable a dir  button clicked
       disableDirViewSet(evt) ;
       return 1;
   }

   if (aname=='dirListInitialize') {        //     initialize directory button clicked (green or other  check)
     markToInitialize(ethis,1)          // in wsallery_dircache.js  -- mark this as one of the dirs to be intialized. ANd show a ball (that can be clicked for imemdiate init)
   }

   if (aname=='dirListInitializeNow') {        //     initialize just this directory button clicked (green or other  check)
       doDirCacheJs(ethis,1)               ;
   }

//   if (aname=='dirListInitializeAll') {        //     initialize just this directory button clicked (green or other  check)
//       doDirCacheJs(ethis,2)               ;  // febv 2022 : just one button, so use inline
//   }

   if (aname=='dirListMarkAll') {        //     initialize just this directory button clicked (green or other  check)
       dirListMarkAll(ethis)               ;
   }



   return 1;
}

//=========================
// list file descriptions
function doChangeFileDescs(ethis) {
   var treename=ethis.attr("treename");
   var adir=ethis.attr('dir');

   let adata={'todo':'displayFileDescs','treename':treename,'dir':adir};
   wsurvey.getJson.get('wsGalleryActionsAdmin.php',adata ,doChangeFileDescs1,'doChangeFileDescs   ');
   return 1;
}
             
 function doChangeFileDescs1(zdata,origData)  {
   var hh=wsurvey.getJson.check(zdata,0,'Callback from doChangeFileDescs') ;
   if (hh===false) return 0;
 
   let ah='Changing descriptions for files in:<span class="headerEmphasizer" > tree <em>'+origData['treename']+'</em> / dir <em>'+origData['dir']+'<em></span>';
   wsurvey.flContents.content('gallery',hh['content'],{'append':0,'show':1,'onTop':1,'header':ah});

   let ee=wsurvey.flContents.find('gallery','[name="fileDescChangeTable"]');

   ee.on('change',fileDescChangeText);    // need to use .on to detect target vs delegateTarget
   ee.on('click',fileDescClickButton);    // need to use .on to detect target vs delegateTarget

 }

// a viewfile button hit
// Note that this is a parent handler that capture all "changes".  So check if it is something you care about changing
function  fileDescClickButton(athis) {
   var  ethis=wsurvey.argJquery(athis,'target');
   var aname=ethis.attr('name');
   if (aname!='fileDescChangeTable_viewFile') return 1;
   showThisFile(athis)  ; // let showThisFile read the attributes
}


// change to a file description. Check its html validity, mark as changed
// Note that this is a parent handler that capture all "changes".  So check if it is something you care about changing
function  fileDescChangeText(athis) {
  var  ethis=wsurvey.argJquery(athis,'target');
  var aname=ethis.attr('name');
  if (aname!='fileDescs') return 1;
  var afile=ethis.attr('afile');
  var ethisDel=wsurvey.argJquery(athis,'delegateTarget');
  var adir=ethisDel.attr('adir');
  var atree=ethisDel.attr('treename');
  ethis.addClass('cDescChanged');

  let aval=ethis.val();
  let avalCool= wsurvey.makeHtmlSafe(aval,1);
  ethis.val(avalCool[1]); // safe html!

  ethis.attr('data-changed',1);
}

function doExportDesc(athis,shorter) {

   if (arguments.length<2) shorter=1;

   let ethis=wsurvey.argJquery(athis) ;
   let etableDiv=ethis.wsFlFind('[name="fileDescChangeTable"]',1);
   let treename=etableDiv.attr('treename');
   let adir=etableDiv.attr('adir');
   let etable=etableDiv.find('table');
   let etrs=etable.find('tr');

   let infos={};
   for (var i1=0;i1<etrs.length;i1++) {
       let eatr=$(etrs[i1]);
       let ebutton=eatr.find('[name="fileDescChangeTable_viewFile"]');
       if (ebutton.length==0) continue  ; // could be header row
       let afile=ebutton.attr('file');

       let vfile=afile.split('/');
       let dafile=vfile.pop();
       let dadir='';
       if (vfile.length>0)dadir=vfile.join('/');

       let etexta=eatr.find('textarea');
       let aval0=etexta.val();
       let aval=aval0.replace(/\r?\n|\r/g," ") ;   // get rid of newlines

       if (shorter==0) {
          let edim=eatr.find('.fileDesc_dims')
          let adim=edim.text();
          let edate=eatr.find('.fileDesc_date')
          let adate=edate.text();
          infos[dafile]=[dadir,adim,adate,aval] ;
       } else {
          infos[dafile]=[dadir,aval] ;
       }
   }

  let dog=wsurvey.currentTime(1,1);
  let stuff=[];
  stuff.push('; Export of file descriptions for: tree='+treename+', directory='+adir);
  stuff.push('; '+dog);
  if (shorter==0) {
     stuff.push(';filename, wxh, data, description (can have commas)');
  } else {
     stuff.push(';filename, description (can have commas)');
  }
  for (var afile in infos) {
    let garg=[];
    let infos1=infos[afile];
    garg.push(afile);
    if (shorter==0) {
      garg.push(infos1[1]);  // skip dirname in [0]
      garg.push(infos1[2]);
      garg.push(infos1[3].replace(/\r?\n|\r/g," "));   // get rid of newlines
    } else {
      garg.push(infos1[1].replace(/\r?\n|\r/g," "));   // get rid of newlines
    }
    let say1=garg.join(',');
    stuff.push(say1);
  }
  let stuffSay=stuff.join('\n')+'\n';

   let goo='<div id="fileDescExport_area">';
   goo+='<input type="button" value="X" title="close this" onClick="wsurvey.flContents.container.close(this)"> ';
   if (shorter==1) {
      goo+='<input type="button" value="Longer" title="Add width x height, and creation date, columns" ';
      goo+='  onClick="doExportDesc(\'#gallery\',0)"> ';
   }
   goo+='<input type="button" value="Copy to clipboard " onClick="doExportDesc_copy(this)"><br>';
   goo+='<textarea cols="80" rows="20" id="fileDescExport_area2"  style="white-space: pre; overflow-wrap: normal; overflow-x: scroll;">'+stuffSay +'</textarea>';
   goo+='</div>';
   wsurvey.flContents.contents('snapBox3',goo,{'show':1,'append':0,'onTop':1,'header':'Export of descriptions for '+treename+' / ' +adir});
}
function  doExportDesc_copy(athis) {
   document.querySelector("#fileDescExport_area2").select();
   document.execCommand('copy');
}


// ====
// import from a text area (i.e.; paste of stuff preevously exported
function doImportDesc(athis) {
   let ethis=wsurvey.argJquery(athis) ;

   let etableDiv=ethis.wsFlFind('[name="fileDescChangeTable"]',1);
   let treename=etableDiv.attr('treename');
   let adir=etableDiv.attr('adir');
   let goo='<div id="fileDescExport_area">';
   goo+='<input type="button" value="X" title="close this" onClick="wsurvey.flContents.container.close(this)"> ';
   goo+='Enter descriptions here, and then  ';
   goo+='   <input type="button" value="Use them" title="match imported descriptions to files in update descriptions menu "  ';
   goo+='     onClick="doImportDesc_match(this)" >  ';
   goo+='<input type="button" class="smallButton" value="Details..." onClick="$(\'#doImportDesc_hint\').toggle()" title="Tips on how to enter ..." > ';
   goo+='<ul   id="doImportDesc_hint"  style="display:none" class="tightList">';
   goo+='<li> One description per line using: <tt>filename, description</tt> '
   goo+='<li> Empty lines, and lines beginning with a <tt>;</tt>, are ignored';
   goo+='<li>You can <button>export</button>  filenames and descriptions for a treename/directory.';
   goo+='<br>and after modifying them (with your favorite spreadsheet) cut and paste a CSV here! ';
   goo+='</ul>';
   let atitle='  title="Empty lines, and lines beginning with a ;, are ignored"  ';
   goo+='<textarea '+atitle+' cols="80" rows="20" id="fileDescImport_area2"  style="white-space: pre; overflow-wrap: normal; overflow-x: scroll"></textarea>';
   goo+='</div>';
   wsurvey.flContents.contents('snapBox3',goo,{'show':1,'append':0,'onTop':1,'header':'Import descriptions for '+treename+' / ' +adir});
}

function doImportDesc_match(athis) {

// read imported desacriptions
   let ee=$('#fileDescImport_area2');
   let aval=ee.val();
   let vvs=aval.split('\n');
   let vvs2={};
   for (var iv=0;iv<vvs.length;iv++) {
       let avv=jQuery.trim(vvs[iv]);
       if (avv=='' || avv.substr(0,1)==';') continue ;
       let avv2=avv.split(',');
       let aname=jQuery.trim(avv2.shift());
       let adesc=jQuery.trim(avv2.join(',')) ;  // readd commas
       vvs2[aname]=adesc
   }
// wsurvey.dumpObj(vvs2,1,'imports');
// get current files (that have file description boxes)
   let etableDiv=wsurvey.flContents.find('gallery','[name="fileDescChangeTable"]');
   let treename=etableDiv.attr('treename');
   let adir=etableDiv.attr('adir');

   let etable=etableDiv.find('table');
   let etrs=etable.find('tr');
   let infos={};
   let nomatches=0;matches=0;
   for (var i1=0;i1<etrs.length;i1++) {
       let eatr=$(etrs[i1]);
       let ebutton=eatr.find('[name="fileDescChangeTable_viewFile"]');
       if (ebutton.length==0) continue  ; // could be header row
       let afile=ebutton.attr('file');
       let vfile=afile.split('/');
       let dafile=vfile.pop();

       if (!vvs2.hasOwnProperty(dafile)) {
            nomatches++;
           continue ; // no match
       }
       let etexta=eatr.find('textarea');
       etexta.val(vvs2[dafile]);
       etexta.trigger('change');
       matches++;
   }
   alert('Imported descriptions. #matches='+matches+', non-matches='+nomatches);
//   wsurvey.dumpObj(vvs2,1,'descMatch');

}

//==============  ======================================================
// toggle disable viewing status button    -- after one of the disable/enable buttons clicked
// called by   dirListClickHandler
//  var   disabledIcons=["&#128065;","&#10683;",'&#128683;'];
//  var   disabledIcons=["\uD83D\uDC41","\u274C","\uD83D\uDEAB"];

function disableDirViewSet(athis) {
  var   disabledIcons=["\uD83D\uDC41","\uD83D\uDEAB","\u2297"];
  var  adicon="\u26A0" ;       // ! in triangle
  if (arguments.length<2) iall=0;

 var ethis=wsurvey.argJquery(athis)
  var atitle;

  let iwhich=parseInt(ethis.wsurvey_attr('which',0));
  let origDisable=parseInt(ethis.wsurvey_attr('origDisable',iwhich));

  iwhich++;
  let bclass='';
  if (iwhich>2 || iwhich<0) iwhich=0;
  if (iwhich==0)  { // not disabled
       adicon= disabledIcons[0];
       atitle='This directory is viewable ';
  } else if (iwhich==1) {
       adicon= disabledIcons[1];
       atitle='This directory is DISABLED (is not shown) ';
  } else if (iwhich==2) {
      adicon= disabledIcons[2];
      bclass='cPartialDisableButton';
      atitle='This directory is partiallyDisabled (file list will not be shown) ';
  }

  ethis.attr('which',iwhich);
  ethis.attr('title',atitle)
  ethis.val(adicon);
  if (bclass=='') {
      ethis.removeClass('cPartialDisableButton');
  } else {
      ethis.addClass('cPartialDisableButton');
  }

  ethis1=ethis.closest('[name="currentDisableStatus"]');
 ;
  if (origDisable!=iwhich) {
     ethis1.addClass('cdisableChanged')
     ethis1.removeClass('cdisableNotChanged')
  } else {
     ethis1.addClass('cdisableNotChanged')
     ethis1.removeClass('cdisableChanged')
  }
  
 // highlignt updateDirstatus button?
  let sibs=ethis.wsFlFind('.cdisableChanged',1);

  if (sibs.length>0) {
     $('[name="doDisableDirButton"]').addClass('cDirButton_active');
  } else {
     $('[name="doDisableDirButton"]').removeClass('cDirButton_active');
  }

//  doDescriptionsDirButton doDisableDirButton
  return 1;
}

//-----
// diable viewing of this directory (in the list of directories displayed for a tree)
// finds the buttons that have been clicedk, determiens the state of these buttons, calls server with new state info
function doDisableDir(athis) {
  var ethis=wsurvey.argJquery(athis);
  var atree1=ethis.wsurvey_attr('tree,treename','');
  var ee1=$('[name="dirListDisableButtons"]');
  var disableStats={};
  var ilen=ee1.length;
  let nchange=0;
  for (var i1=0;i1<ilen;i1++) {
     let ae1=$(ee1[i1]);
     let atree=ae1.attr('tree');
     let which=ae1.attr('which');
     let origdisable=ae1.attr('origdisable');
     if (which==origdisable) continue ; // no change
     nchange++;
     let adir=ae1.attr('dirname');
     disableStats[adir]=which;
  }

  if (nchange<1) {
     alert('No status changes were selected ');
     return 0 ;// none selected
  }
   let eed=$('#idisableDirViewResults');
   eed.show();
   let sfoo='Updating '+nchange+' disable status in tree <b>'+atree1+'</b>. ';
   sfoo+='<input type="button" value="reload wsGallery" onClick="location.reload(true)" > to update this tree\'s <em>directory list</em> ';
   eed.html(sfoo);
   var ddata={'todo':'doDisableDir','treeName':atree1,'disable':disableStats};
   wsurvey.getJson.get("wsGalleryActionsAdmin.php",ddata,doDisableDir2,'doDisableDir ')   ;
}

function doDisableDir2(zdata,origData ) {

   var hh=wsurvey.getJson.check(zdata,0,'Callback for doDisableDir2');
   if (hh===false) return 0;

   let atree=origData['treeName'];
   getDirCacheAdmin(0,atree,hh['content']);


}
