<?php

// utilities for wsGallery


// =============================================
// useful variables
$icon_pencil='&#9998;';
$icon_statue='&#128511';
$icon_telescope= '&#128301;';
$icon_moneybag= '&#128176;';
$icon_trophy= '&#127942;';
$icon_horse= '&#128014;';
$icon_infoPlain='&#8505';  // block i
$icon_info='&#128712;';     // block i in circle
$icon_runner='&#127939;';
$icon_ledger='&#128210;';
$icon_scroll='&#128220;';
$icon_question='&#9072;';
$icon_whiteQuestion='&#10068;';
$icon_pencil='&#9998;';     // simple pencil, pointing lower right
$icon_pencilFlat='&#9999;';     // simple pencil, horiz pointing right
$icon_lowerLeftPencil='&#128393;';       // nicer pencil point toward lower left
$icon_memo='&#128221;';
$icon_note='&#9834;';  // single note
$icon_doubleNote='&#9836;';  // double note
$icon_circleI='&#9406';
$icon_empty='&#10672;';
$icon_calc='&#128425;';
$icon_abacus=' &#129518;';
$icon_notePad='&#128466;&#65039;';
$icon_notePage='&#128456;';
$icon_testTube='&#129514;';
$icon_crystalBall='&#128302;';
$icon_paintBrush='&#128396;';
$icon_eye='&#128065;';
$icon_fishEye='&#9673;';
$icon_bulb='&#128161;';
$icon_horiz_trafficLight="&#128677;";
$icon_magnify='&#128270;';
$icon_gearWheel='&#9881;&#65039;';   // 9881 or 9965 are simpler
$icon_del='&#9249;';
$icon_noEntry='&#9940;';
$icon_greenCheck='&#9989;';
$icon_checkInBox='&#9989;';
$icon_checkMark='&#10003;';
$icon_thinCheck='&#128504;';
$icon_envelope='&#9993;';
$icon_redX='&#10060;';
$icon_hourGlass='&#9203;';
$icon_horiz5='&#9636;';
$icon_screen='&#8418;';



//=====================   ================
// read wsGallery parameters,
function makeWsGalleryParams($a1) {

  $lookups=['skip'=>'skip','skips'=>'skip','skipSubs'=>'skip','skipsubs'=>'skip',
         'imgext'=>'imgExts','imgexts'=>'imgExts','img'=>'imgExts','imageExts'=>'imgExts','imageexts'=>'imgExts',
           'otherext'=>'otherExts','otherexts'=>'otherExts','other'=>'otherExts',
           'ontheflythumbnails'=>'onTheFlyThumbnails','ontheflythumbnail'=>'onTheFlyThumbnails',
           'thumb'=>'onTheFlyThumbnails','thumbnails'=>'onTheFlyThumbnails','thumbnail'=>'onTheFlyThumbnails',
           'ontheflysnapshot'=>'onTheFlySnapshots','ontheflysnapshots'=>'onTheFlySnapshots',
           'snapshot'=>'onTheFlySnapshots','snap'=>'onTheFlySnapshots','snapshots'=>'onTheFlySnapshots',
           'nocache'=>'noCache','nocaching'=>'noCache'];

   $defVals=[];  // the defaults

   $defVals['skip']=['snps'=>'','trash'=>'','tmp'=>'','temp'=>'','$recycle.bin'=>''];

   $defVals['imgExts']=['png'=>'','gif'=>'','jpg'=>'','jpeg'=>'','bmp'=>'','xbm'=>''];
   $defVals['otherExts']=['mov'=>['v','video/quicktime',''],
                          'mp4'=>['v','video/mp4',''],
                          'mpg'=>['v','video/mpeg',''],
                         'mpeg'=>['v','video/mpeg',''],
                          'avi'=>['v','video/x-msvideo',''],
                          'pdf'=>['e','application/pdf',''],
                          'txt'=>['f','text','text'],
                         'text'=>['f','text','text'],
                          'htm'=>['f','text','html'],
                         'html'=>['f','text','html'],
                          'xls'=>['f','https://view.officeapps.live.com/op/embed.aspx?src=',''],
                         'xlsx'=>['f','https://view.officeapps.live.com/op/embed.aspx?src=',''],
                          'ppt'=>['f','https://view.officeapps.live.com/op/embed.aspx?src=',''],
                         'pptx'=>['f','https://view.officeapps.live.com/op/embed.aspx?src=',''],
                          'doc'=>['f','https://view.officeapps.live.com/op/embed.aspx?src=',''],
                         'docx'=>['f','https://view.officeapps.live.com/op/embed.aspx?src=',''] ] ;

// other possibilities
//                      'tif'=>['i','',''],
//                      'js'=>['i','text','text'],

   $defVals['onTheFlyThumbnails']='1';   // 0 or 1 : 0 to suppress (use generic icons if no cached thumbnail)
   $defVals['onTheFlySnapshots']='1';   // 0 or 1 : 0 to suppress (use full images if no cached snapshots
   $defVals['noCache']='0';   // 0 or 1 : 1 to suppress caching

   $foundVals=[];

 //  $curDir=getCwd();
  $wsMainDir=$_SESSION['wsGallery_mainDir'];

   $paramsFile=$wsMainDir.'/wsGallery_params.php';
   if (!is_file($paramsFile)) {
        print "<br><b>Error</b>: missing parameters file   ($paramsFile). See wsGallery_readMe.txt for discussion. ";
        exit;
   }
  $paramsStuff=@file($paramsFile, FILE_IGNORE_NEW_LINES  ); // read the _treelist file
  foreach ($paramsStuff as $ith=>$aline) {

      $aline=trim($aline);
      if ($aline=='' || substr($aline,0,1)==';') continue ; // ignroe empty and comment lines
      $icolon=strpos($aline,':');
      if ($icolon===false) {
         print "<br><b>Error</b> in   parameters file ($paramsFile), bad row= $aline";
         exit;
      }
      $vv=explode(':',$aline,2);   // 2nd term can be multiple words. Often in a csv
      if (count($vv)==1) {
         print "<br><b>Error</b> in   parameters file ($paramsFile), bad row= $aline";
         exit;
      }
      $pnameB=strtolower(trim($vv[0]));
      if (!array_key_exists($pnameB,$lookups)) {
         print "<br><b>Error</b> unknown parameter (<tt>".trim($vv[0])."</tt>) in  parameters file ($paramsFile), bad row= $aline";
         exit;
      }
      $pname=$lookups[$pnameB];    // the internal var name (camelback).
      $pValue=trim($vv[1]);         // stuff after :
      if ($pValue=='') continue ;  // '' is same as not specifying (use default)

// these 3 are simple
      if ($pname=='onTheFlyThumbnails' || $pname=='onTheFlySnapshots' ||   $pname=='noCache' ) {
          if ($pValue!=='1' && $pValue!='0') {
             print "<br><b>Error</b> misspecified parameter (<tt>$pnameA</tt> must be 0 or 1) in  parameters file. Must be 0 or 1. ($paramsFile), bad row= $aline";
          } else {
             $foundVals[$pname]=$pValue;
          }
          continue ;
      }       // onthefly xx and nocache

      if ($pname=='skip')  {       // simple -- just the extensions (no handler);
        $goob=explode(',',$pValue);
        if (!array_key_exists($pname,$foundVals)) $foundVals[$pname]=[];  // initialize
        foreach ($goob as $ifoo=>$bext) {
            $bext1=str_replace(['"',"'",'<','>',','],'',$bext);  // no . or quotes or <> needed
            $bext2=strtolower(trim($bext1));
            $foundVals[$pname][$bext2]=1;
        }
        continue ;
      }

      if ($pname=='imgExts')  {       // simple -- just the extensions (no handler);
        $goob=explode(',',$pValue);
        if (!array_key_exists($pname,$foundVals)) $foundVals[$pname]=[];  // initialize
        foreach ($goob as $ifoo=>$bext) {
 
            $bext1=str_replace(['"',"'",'.','<','>',','],'',$bext);  // no . or quotes or <> needed
            $bext2=strtolower(trim($bext1));
            if ($bext2=='') continue;
            $foundVals[$pname][$bext2]=1;
        }
        continue ;
      }

// must be otherExts

      $goob=explode(',',$pValue);
      $otherHandler=['e'=>1,'v'=>1,'i'=>1,'l'=>1,'f'=>1];

      foreach ($goob as $ii=>$aval0) {                   // each csv piece has several componetnets
         $aval=trim($aval0);
         if ($aval=='') continue      ; // a ,, or a trailing ,
          $vvA=preg_split("/[\s]+/", $aval );    // break into pieces (by space)
           $p1=trim($vvA[0]);
          $aext0=str_replace(['"',"'",'.','<','>',','],'' , $p1);  // first piece MUST be an extension. no . or quotes or <> needed
          $aext=strtolower(trim($aext0));
          if (count($vvA)>1 ) {
            $handler0=str_replace(['"',"'",'.','<','>'],'' ,trim($vvA[1]));  //2nd piece MUST be handler. no . or quotes or <> needed
            $handler1=strtolower(trim($handler0));
            $handler=substr($handler1,0,1);             // one char code is all that is needed!
            if (!array_key_exists($handler,$otherHandler)) {
               print "<br><b>Error</b> misspecified otherExts handler ($handler from $handler0) for $aext (must be v,e,i, or L). ($paramsFile),   bad row= $aline";
               exit;
            }
          } else {
             $handler='';
          }
          $amore= (count($vvA)>2) ? trim($vvA[2]) : '' ;
          $amore2=(count($vvA)>3) ? trim($vvA[3]) : '' ;
          if (trim($amore)=='.')  $amore='';   // semi deprecated
          if (trim($amore2)=='.')  $amore2='';   // semi deprecated

          if ($handler=='' || $amore=='' || $amore2=='') {
                if (array_key_exists($aext,$defVals['otherExts'])) {
                   $garg=$defVals['otherExts'][$aext];
                   if ($handler=='') $handler=trim($garg[0]);
                   if ($amore=='') $amore=trim($garg[1]);
                   if ($amore2==''  ) $amore2=trim($garg[2]);
                }
          }
          if ($handler=='') $handler='l';  // Link handler if none specified and no defaults
          if ($handler=='e' || $handler=='v') {
                  if (trim($amore)=='') $amore=extToMimetype($aext);  // add a mimetype if not specified
          }
          if (!array_key_exists('otherExts',$foundVals)) $foundVals['otherExts']=[];  // initialize
          $foundVals['otherExts'][$aext]=[$handler,$amore,$amore2] ;  // prevent duplcation
      }   // the csv after the : (otherExts)

  }   // paramsstuff

  foreach ($defVals as $aname=>$adef) {             // use default values (of otherExts, etc etc) if not specified
       if (!array_key_exists($aname,$foundVals)) $foundVals[$aname]=$adef;
  }

// if here, this dir has been checked (so it exists
   $dataDir=$_SESSION['wsGallery_dataDir'] ; //  used inmakeWsGalleryParams
   $paramsJson=$dataDir.'/params.json';
   $goof=json_encode($foundVals, JSON_UNESCAPED_UNICODE);
   $qok=@file_put_contents($paramsJson,$goof);
  return $foundVals ;


}

//=====================   ================
// read and parse the treelist.php file.
// save to json in cache
// also create treeListStatus.json (for disable and other status
function initTreeList($a) {

 // $curDir=getCwd();
  $wsMainDir=$_SESSION['wsGallery_mainDir'];
  $dataDir=$_SESSION['wsGallery_dataDir'] ;  // used here (initTreeList)
  $selToDataRoot=$_SESSION['wsGallery_selToDataRoot'] ;

  $treeListPhp=$wsMainDir.'/wsGallery_treeList.php';
  $treeListJson=$dataDir.'/treelist.json';
  $treeListJsonStatus=$dataDir.'/treelistStatus.json';

   $ttMake=[];

   $wwwRootDir=$_SERVER['DOCUMENT_ROOT'];      // ie : D:/www/
   $wwwRootDir=rtrim($wwwRootDir,'/');
   $wwwRootDir=str_replace('\\','/',$wwwRootDir);
   $iwwwRootDir=strlen($wwwRootDir);

   $thisrootSel=dirname($_SERVER['PHP_SELF']);   // ie  /www/gallery/wsGallery.php
   $thisrootSel=str_replace('\\','/',$thisrootSel);
   $_defaultRootDir=str_replace('\\','/' ,$wwwRootDir); $_defaultRootDir=rtrim($_defaultRootDir,'/');
   $tt0=[];
   $ttMake=[] ;
   $ttMake[0]='_default' ;  // the show-tree-on-startup  variable   (numeric indices of ttMake are informative. string indices are treeName specs
   $treesFound=[];

//   $cacheDirDefault2=str_replace('\\','/' ,$cacheDirDefault); $cacheDirDefault2=rtrim($cacheDirDefault2,'/'); // NO LONGER NEEDED

  $treeListPhpStuff=@file($treeListPhp, FILE_IGNORE_NEW_LINES  ); // read the _treelist file

  foreach ($treeListPhpStuff as $ith=>$aline) {
      $aline=trim($aline);
      if ($aline=='' || substr($aline,0,1)==';') continue ; // ignroe empty and comment lines
      $icolon=strpos($aline,':');
      if ($icolon===false) {
         print "<b>Error</b> in   treeListSpec file ($treeListPhp), bad row= <tt> $aline</tt>s";
         exit;
      }
      $vv=explode(':',$aline,2);
      if (count($vv)==1) {
         print "<b>Error</b> in   treeListSpec file ($treeListPhp), bad row= <tt> $aline</tt>";
         exit;
      }
      $pname=trim($vv[0]);$tpname=strtolower($pname);

      if ($tpname=='.showtree' ) {
         $showTree=trim(strtolower($vv[1]));
         if ($showTree=='' || $showTree=='0') $showTree='_default'; // assumes it exists. If  not, error
         $ttMake[0]=$showTree;    // the show-on-startup  variable
         continue ;
      }
      if (substr($tpname,0,1)=='.') {
         print "<b>Error</b> in   treeListSpec file ($treeListPhp). treename must NOT start with a `.`: <tt> $aline</tt> ";
         exit;
      }
// legal treename?
       if (str_word_count($tpname)!=1) {
         print "<b>Error</b> in   treeListSpec file ($treeListPhp). treename must be a single word: <tt> $aline</tt> ";
         exit;
      }
      if ($tpname=='' || is_numeric($tpname)) {
         print "<b>Error</b> in   treeListSpec file ($treeListPhp). treename can not be a number   <tt> $aline</tt> ";
      }

     $thisTreeCacheDir=  $dataDir.'/'.$tpname;
     if (!is_dir($thisTreeCacheDir)) {
        print "<b>Error:</b> missing the <tt>$tpname</tt> cache directory  ($thisTreeCacheDir) for this tree ($tpname). The administrator must create it.";
        exit;
     }

//      treename:  treeRootDir, selBase, descripton
      $stf=trim($vv[1]);
      $stf.=',,' ;   // hack to avoid problems when defaults are specified (guarantee 3 valuse in csv)

      $vstf=explode(',',$stf);

      $rootDir=trim($vstf[0]);
      if ($rootDir=='' || $rootDir=='0') $rootDir=$wwwRootDir;
      $ac1=substr($rootDir,0,1);
      if ($ac1 =='~') {
         $rootDir=substr($rootDir,1); $rootDir=ltrim($rootDir,'/');
         $rootDir=$wsMainDir.'/'.$rootDir;
      }
      $rootDir=str_replace('\\','/',$rootDir);
      $rootDir=rtrim($rootDir,'/') ;

      if (!is_dir($rootDir)) {
         print "Error: a rootDir (<tt>$rootDir</tt>) in a tree definition does NOT exist: <tt> $aline</tt>";
         exit;
      }
      $rootSel=trim($vstf[1]);
      $rootSel=str_replace('\\','/',$rootSel);
      $ac11=substr($rootSel,0,1);
      if ($ac11=='~') {
          $rootSel=substr($rootSel,1);
          $rootSel=ltrim($rootSel,'/');
          $rootSel=$thisrootSel.'/'.$rootSel;
      }
       if ($rootSel=='' || $rootSel=='/' ) {
          $rootSel='/';
      } else {
         $rootSel='/'.trim($rootSel,'/').'/';
      }
      $desc=trim($vstf[2]); if ($desc=='') $desc='A wsGallery tree: '.$tpname ;
      $desc=strip_tags($desc);

      $stdWwwDir=0;
      if (substr($rootDir,0,$iwwwRootDir)==$wwwRootDir) $stdWwwDir=1;

// this root/sel directory exists?
     $thisFinalDir=rtrim($rootDir,'/').'/'.ltrim($rootSel,'/');
     if (!is_dir($thisFinalDir)) {
         print "Error: a rootDir (<tt>$rootDir</tt>) + rootSel (<tt>$rootSel</tt>) directory (<tt>$thisFinalDir</tt>) in a tree definition does NOT exist:<tt> $aline</tt>";
         exit;
      }

      $ccuse=str_replace('\\','/',$thisTreeCacheDir);
      $tt0=['rootDir'=>$rootDir,'rootSel'=>$rootSel,'stdWwwDir'=>$stdWwwDir,'desc'=>$desc,'cacheTree'=>$ccuse,
            'cacheSel'=>$selToDataRoot.$tpname.'/'];
      $ttMake[$tpname]=$tt0;

      $treesFound[]=$tpname;

  }
   $ttMake[1]=time();
   $ttMake[2]='creating cache file';

// success! Save to treelist.json

   $goof=json_encode($ttMake, JSON_UNESCAPED_UNICODE);
   $qok=@file_put_contents($treeListJson,$goof);
   if ($qok===false) {
         print "<b>Error</b>: unable to save treeList file ($treeListJson) ";
         exit;
   }

// and create treeList STatus
  $treeStatus=[];
  foreach ($treesFound as $ith=>$aname) {
    $treeStatus[$aname]=[];
    $treeStatus[$aname]['disable']=0;
  }

  $goof2=json_encode($treeStatus, JSON_UNESCAPED_UNICODE);
  $qok2=@file_put_contents($treeListJsonStatus,$goof2);
  if ($qok===false) {
    print "<b>Error</b>: unable to save treeListStatus file ($treeListJsonStatus) ";
    exit;
  }

// -- make  switchTree menu

  $zstuff=initTree_create_treeSwitchMenu($ttMake);
  $treeListFileMenu=$dataDir.'/treelistMenu.html';      // the "cache" file to save to ....
  $nz=file_put_contents($treeListFileMenu,$zstuff );

  return true ;  // done with initTreeList. the caller can recall getTreeList(1) to retrieve info from these newly created cache files

}                           // initTreeList

//================
// create a html menu to select tree to view
// treeLIst is provided by initTree
function  initTree_create_treeSwitchMenu($treeList) {

 $stuff='';
 $stuff.='<!-- this is included at the top of a directory list of files. Do not modify it (it is generated by wsGallery using ';
 $stuff.=" information in wsGallery_treeList.php  --> \n";
 $stuff.='Select which directory <em>tree</em> to view ... ... ';

 if ($treeList==0 || count($treeList)==0)  {
   //$treeList=$_SESSION['wsGallery_treeList'] ;
    getJs\jsonReturnError(' makeDirList_create_treeSwitchMenu: empty treeList ');
 }

 $treeNameDefault=$treeList[0];

 $stuff.='<ul  class="linearMenu" >';
  foreach ($treeList as $atree0=>$tinfo) {
     $atree=strtolower(trim($atree0));
     if (is_numeric($atree) ) continue;
     $amess=$tinfo['desc'];
     $stuff.='<li class="linearMenuLi">';
     if ($atree==$treeNameDefault)  $amess.=' (the tree shown on startup) ';
     $stuff.='<button treeNameSwitch="'.$atree.'"  name="treeListSwitchButtons" onClick="switchCurrentTree(this)" style="font-weight:700" '; // the switch-to-this-tree button (in the switch tree menu)
     $stuff.='  title="'.$amess.'">';
     $stuff.="$atree</button>";
  }
  $stuff.='</ul>';
  return $stuff;
}



//===================
// createa list of spinner fils. return relsel to them. Save to cache (For use by getSpinnerList
// don't get if size of file > maxsize (default=300,000 bytes)
function makeSpinnerList($maxsize=300000) {

    $dalist=[];
    $goof=getcwd().'/icons/spinners';
    if (!is_dir($goof)) return [] ;  // give up
    $sfiles0=glob($goof.'/*');
    $sfiles=array_filter($sfiles0,'is_file');      // find files
    if (count($sfiles)==0) return [];
    foreach ($sfiles as $ith=>$afile) {
       if (filesize($afile)>$maxsize) continue;
       $afilename=pathinfo($afile,PATHINFO_FILENAME);
       $aext=pathinfo($afile, PATHINFO_EXTENSION );
       $aextLc=strtolower($aext);
       if ($aextLc=='gif' ||$aextLc=='png' || $aextLc=='jpeg' || $aextLc=='jpg' || $aextLc=='ico' || $aextLc=='bmp' || $aextLc=='svg') {
          $dalist[]='icons/spinners/'.$afilename.'.'.$aext;
       }  // ignore other extentions
    }
    $jgoo=json_encode($dalist,JSON_UNESCAPED_UNICODE);
    $goofJson=$goof.'/spinners.json';
    $bb=@file_put_contents($goofJson,$jgoo);  // save for later use
    return $dalist ;
}

//=====================
// get last mod date of a directory -- files or the directory itself.
// or, if a 2nd arg supplied: retrn the name of  first file (or directory itselfe) with a mod date after checkdate
//   If none greater, return ''
// REturns false on error (bad directory name, or non numeric checkdate
//
// Note the 'directory itself" has a modification date that changes when files are added or removed-- but NOT when files are changed.
// Thus, in 1 arg mode this checks all file change dates AND the directory mod date, and returns the largest (as unix time stamp)
//
// It does NOT check subdirectories -- only the files in a directory, and the directory itself!
//   So, adding a file to a subdirectory may change the directory mod date, even though the files in it are the same.
//   (but modifications of a file in a subdirectory will not be detected).
//
//  Jan 2022: this is NOT used. Instead, check the directory mod date and compare to a "json cache" date.
//            while this simple approarch does not capature changes to files,  it will capture added and removed files
//            which is basically good enough

function dirModDate($adir,$checkDate='.') {

if (func_num_args()<2) {
    $doCheckDate=0;
} else {
   if (!is_numeric($checkDate) ) return false;
   $doCheckDate =1  ;
}

$adir0=str_replace('\\','/',trim($adir));
if (!is_dir($adir0)) return false  ; // error

$mostRecent=filemtime($adir0);   // start with the directory mod

if ($doCheckDate==1) {                   // compare to this date -- '' if nothing is arfter this, otherwise the file (or dir) that is
  if ($mostRecent>$checkDate) return $adir0;
}

$adir1=rtrim($adir0,'/').'/*';   // find all files (ignore direcotries)
$bb=glob($adir1);
foreach ($bb as $ii=>$afile) {
  if (is_dir($afile)) continue ; // ignore sub directories
   $dd=filemtime($afile);
   if ($dd>$mostRecent)  {
     $mostRecent=$dd;
     $mostRecentFile=$afile;
     if ($doCheckDate==1) {
        if ($mostRecent>$checkDate) return str_replace('\\','/',$afile);   // first match with newer time
     }
   }
}
if ($doCheckDate==1) return '';  // nothing newer than checkdate
return $mostRecent ;    // timestamp of most receht (newest file, or directory itself if a file was recently deleted or added)
}
