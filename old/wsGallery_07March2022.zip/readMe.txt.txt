10 Feb 2022: wsGallery: quickly list and view images, and other files 

For details on installation and usage, see wsGallery_readMe.txt

The following files are installed in the wsGallery main directory

  The following MUST be modified as soon as wsGallery is installed.

     wsGallery_treeList.php   -- List of "tree" specifications. MUST be modified by an admin -- it tells wsGallery where to look for images and other files
     wsurvey.adminLogon_params.php   -- administration password information. MUST be modified by an admin -- admin logon requires it!

  The following can be modified, but for most installations the defaults should be fine.

     wsGallery_params.php  : various wsGallery parameters.  

  The following should NOT be modifiedl

     wsGallery.php   -- the main HTML file. 
     wsGallery.css    -- styles used by wsGallery
     wsGallery_externalHandler.html  -- displays files in external window. Not meant for direct access.
     wsGallery_vuHelp.php   -- view help in external window (can be accessed directly)
     wsGallery_readMe.txt   -- description, installation, and useage

The following directories are created. None of them contain files that a typical administrator will work with.

   data: wsGallery working data. In particular,  directory specific "cache" (thumbnails, snapshots). 
         This directory can become large (with lots of subdirectories --  especially if there are a lot of image files contained in the viewable directories.

   icons : contains various useful icons.  An ambitious administrator can add icons (such as spinners)
   images : the '_default' location of files and images. You don't have to use it (if you don't, treeList.php should be modified)
   libs : php and javascript libraries used by wsGallery.  Includes "wsurvey." libraries, and other libraries (such as jQuery).
   src :  wsGallery specific source code: php and js files. 
          src also contains "original" versions of wsGallery_treeList.php and wsGallery_params.php, which can be used if the working versions are damaged.



  -------------------

Contact: Daniel Hellerstein. danielh@crosslink.net. 
       http://www.wsurvey.org/distrib, or  https://github.com/dHellerstein 

Disclaimer:

    wsGallery is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    wsGallery is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    If you did not receive a copy of the GNU General Public License,
    see <http://www.gnu.org/licenses/>.

    Note: wsGallery uses security measures that are not strong.
           In particular: if you do not control access to the directory that wsGallery.php is installed on
                       -- you should NOT install wsGallery on your webserver!
           See wsGallery_readMe.txt for further discussion. 

 
Daniel Hellerstein, danielh@crosslink.net
