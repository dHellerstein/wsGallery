<?php
session_start() ;
ob_start();

// view some installation examples

$treeSpecs=[];
$rootdir=$_SERVER['DOCUMENT_ROOT'] ;
$nowtime=time();
$curDir=getcwd();
$rootDir=dirname($curDir);


$webRoot=dirname($_SERVER['PHP_SELF']);

require_once($rootDir.'/libs/php/wsurvey.getJson.php');
require_once($rootDir.'/src/wsGalleryLibUtils.php');


$wsGallery_dataDirBase=$curDir.'/data' ;

$oof=extractRequestVar('view','');

if ($oof=='params') {
  $daFile=$rootDir.'/data/wsGallery_params_original.php';
  $stuff=file_get_contents($daFile);
  print "<u>$daFile</u>: an example of wsGallery parameters file (with descriptions!)<hr> ";
  print '<pre>';
  print htmlentities($stuff);
  print '</pre>';
  print '<hr>';
   exit;
}
if ($oof=='treeList') {
  $daFile=$rootDir.'/data/wsGallery_treeList_original.php';
  $stuff=file_get_contents($daFile);
  print "<u>$daFile</u>: an example of wsGallery tree list file (with descriptions!)<hr> ";
  print '<pre>';
  print htmlentities($stuff);
  print '</pre>';
  print '<hr>';
   exit;
}

print $oof;
?>
