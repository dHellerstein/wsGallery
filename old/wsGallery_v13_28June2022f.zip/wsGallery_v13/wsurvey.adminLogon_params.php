<?php

// User changable logon paramers: used by wsCheckLogon.php
// the defaults
$passwordActual="";                   // Required. The "admin" password (it will be hashed when sent to server). It MUST be specified
$pwdDuration=200;                     // Default =2000. in milliseconds (pwd expires after this amount of time

?>
