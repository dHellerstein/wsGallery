<?php
session_start() ;
ob_start();
// wsGallery -- quickly  list and view  images in a directory tree
//  CAUTION: wsGallery can be setup to allow access to all the diretories of an account
//               Under windows: "account" typically means  any file on any directory in any drive accessible to you.
//         Thus: if you do not control access to wsGallery.php -- you should NOT install this on your webserver
//               Of, if you do, be sure there is nothing private in any file in your account.
// June 2022: user configurable parameter (minSizeViewing) can be set below  (around line 400)

$treeSpecs=[];
$rootdir=$_SERVER['DOCUMENT_ROOT'] ;
$nowtime=time();
$curDir=getcwd();
$webRoot=dirname($_SERVER['PHP_SELF']);
$wasErr='';
$wsGallery_version='20220628.v1_3';

require_once($curDir.'/libs/php/wsurvey.getJson.php');
require_once($curDir.'/src/wsGalleryLibUtils.php');


$wsGallery_dataDirBase=$curDir.'/data' ;

// first run? If so, show some admin tips and exit
$installTxt=$wsGallery_dataDirBase.'/install.txt';
if (!file_exists($installTxt)) {
  require_once($curDir.'/data/installNotes.php');
  exit;
}


// not a first run!
//$_SESSION['wsGallery_mainDir']=$curDir;  // initialzation
$_SESSION['wsGallery_mainDir']=str_replace('\\','/',$curDir);  // initialzation

$_SESSION['wsGallery_dataDirBase']=$wsGallery_dataDirBase ;
$requestUri=$_SERVER['REQUEST_URI'];

$wsSel=pathinfo($requestUri,PATHINFO_DIRNAME);
$_SESSION['wsGallery_mainSel']=$wsSel;  // initialzation

// first read params, to get the default gallery, and layout
$wsgp=readWsGalleryParams(1)  ; // read the "admin changable" cached (if need be) parameters.  (exists and not out of date)

if ($wsgp[0]===false)  {  // problem that is correctable. Admin should recreate this using... initTreeList
  $paramUpdateNeeded=1;
  $wasErr=$wsgp[1];
  goto endOfThis;  // a hack :()
}   else {
   $paramUpdateNeeded=0;
   $wsgp=$wsgp[1];
}
 $defaultGallery =trim($wsgp['defaultGallery']);
   if ($defaultGallery=='') $defaultGallery='main';
   $_SESSION['wsGallery_defaultGallery']=$defaultGallery;

 $switchGallery =trim($wsgp['switchGallery']);
   if ($switchGallery=='') $switchGallery='0';
   $_SESSION['wsGallery_switchGallery']=$switchGallery;

 $defaultScreenLayout=trim($wsgp['screenLayout']);
   if ($defaultGallery=='') $defaultGallery='main';
   $_SESSION['wsGallery_defaultScreenLayout']=$defaultScreenLayout;

  $enableFavorites=trim($wsgp['enableFavorites']);
   $_SESSION['wsGallery_enableFavorites']=$enableFavorites;

  $useThumbnails=trim($wsgp['useThumbnails']);
   $_SESSION['wsGallery_useThumbnails']=$useThumbnails;

  $enableNotes=trim($wsgp['enableNotes']);
   $_SESSION['wsGallery_enableNotes']=$enableNotes;

  $maxNoteSize=trim($wsgp['maxNoteSize']);
   $_SESSION['wsGallery_maxNoteSize']=$maxNoteSize;

  $doCompact=trim($wsgp['doCompact']);
   $_SESSION['wsGallery_doCompact']=$doCompact;


 $requireLockme=trim($wsgp['requireLockme']);
   if ($requireLockme=='') $requireLockme='1';
   $_SESSION['wsGallery_requireLockme']=$requireLockme;

// Feb 2022: wsGallery_dataDir could be changed to some other location
// March 2022. Look for   gallery specifications! Default is main
// If specifiedthe data dir is this dir under wsurvey/galleries

  $requestedGallery= trim(extractRequestVar('gallery',''));
  $galleryDir= ($requestedGallery=='')  ? $defaultGallery : $requestedGallery;
  if ($galleryDir=='') $galleryDir='main';
  if (strpos($galleryDir,'..')!==false) {
     print "Illegal gallery name: <tt>$galleryDir</tt>";
     exit;
  }
  $_SESSION['wsGallery_useGallery']=trim($galleryDir);

  $_SESSION['wsGallery_mainDir_tree']=$_SESSION['wsGallery_mainDir'].'/galleries/'.$galleryDir ; // initialzation
  $wsGallery_selToDataRoot='galleries/'.$galleryDir.'/';

  $wsGallery_dataDir=$curDir.'/galleries/'.$galleryDir;   // May 2022: same as $_SESSION['wsGallery_mainDir_tree'] -
                                                      // probably should consolidate (or could it be used to move galleries outside of www path)?
  if (!is_dir($wsGallery_dataDir)  ) {
     print "<b>Error</b>: there is no data directory for gallery: <b>$galleryDir</b> (<tt>$wsGallery_dataDir does not exist</tt>)";
     exit;
  }

// check for lockme
$lockme_file=$wsGallery_dataDirBase.'/lockme.txt';
$lockme_status= (file_exists($wsGallery_dataDirBase.'/lockme.txt')) ? 1 : 0 ;

$_SESSION['wsGallery_dataDirBase']=$wsGallery_dataDirBase ;
$_SESSION['wsGallery_dataDir']=$wsGallery_dataDir;
$_SESSION['wsGallery_selToDataRoot']=$wsGallery_selToDataRoot;

$_SESSION['wsGallery_treeList']=false ;
$_SESSION['wsGallery_treeListStatus']=false;
$_SESSION['wsGallery_currentTree']='';  // initialzation
$_SESSION['wsGallery_currentTreeDirlist']=[];      // wsGallery_currentTreeDirs

// these are set (and rewritten) below (by readWsGalleryParams). See wsGallery_params.php for a complete description!

$_SESSION['wsGallery_onTheFlyThumbnails']=0;   // 0 or 1 : 0 to suppress (use generic icons if no cached thumbnail)
$_SESSION['wsGallery_onTheFlySnapshots']=0;   // 0 or 1 : 0 to suppress (use generic icons if no cached thumbnail)
$_SESSION['wsGallery_noCache']=0;   // 0 or 1 : 0 to allow use of caching. 1 to suppress (create button and file lists on each request)

$memStuff=getSystemMemoryInfo() ;  // 'MemFree' => int 27486482432, 'MemAvailable' => int 29,103,550,464


if ($memStuff===false) {
  $_SESSION['wsGallery_memAvailable']=false ;
} else {
  $_SESSION['wsGallery_memAvailable']=$memStuff['MemAvailable'] ;
}

// Note: wsGallery_treeList.php is used to define "Trees". See it for a complete description!

$adminLogonRequired=0;
$treeListUse0=getTreeList(0 );  // read basic stuff from .json (cache) files (not from internal  cache). If none or out of date, create the json files from .php
if (array_key_exists('error',$treeListUse0)) { // problem. So try to recreate tree list?
   $wasErr=$treeListUse0['error'];

// if lockme.txt enabled and requireLockme enabled, must disable lockme First.

   if ($requireLockme==0  )  {  // problem that may be correctable -- by calling initTreeList.  But only if lockme disabled
      $adminLogonRequired=1 ;
   } else {   // locked -- so just issue a warning.  Admin must disable lockme.txt, and then try again
       if ($lockme_status==1) {
          print 'Administrator action needed:<tt> '.$wasErr.'</tt><br>Recommended action: <em>temporarily remove data/lockMe.txt; and then reload wsGallery.php.</em> <br>For the details, see the <a href="data/installNotes.php?jump=autoCreate&ver=Installation+problem" target="viewer">admin notes</a> ' ;
          exit;
       } else {
          $adminLogonRequired=1 ;
       }
   }
 }              //  if past here, treelist available

$_SESSION['wsGallery_adminLogonRequired']=$adminLogonRequired;
$requestedTree='';
if ($adminLogonRequired==0) {

   $treeListUse=$treeListUse0[1];          // 0: default tree, 1:creation time, 2: message, 'treename1' ... basics for a 'treename1' tree
   $treeListStatus=$treeListUse0[2];        // each index is a tree name, contains an associtaive array.  default is disable:0
   $defaultShowTree=$treeListUse[0];
  $requestedTree=strtolower(trim(extractRequestVar('tree','')));
  if ($requestedTree=='') {
      $showThisTree=$defaultShowTree;
  } else {
      $showThisTree=$requestedTree;
  }
  if (array_key_exists($showThisTree,$treeListUse)===false) {
     print "wsGallery error: no such tree (<tt>$showThisTree</tt>) in gallery <em>$galleryDir</em>";
     exit;
  }
} else {
   $treeListUse='' ;
   $treeListStatus='';
   $defaultShowTree='';
   $showThisTree=''    ;
}
// are there any collections:
$collectionsDir=$wsGallery_dataDirBase.'/collections';
$cAvail=  glob($collectionsDir . '/B_*.json');
$collectionsAvail=[];
foreach ($cAvail as $ii=>$aColl) {
   $collectionsAvail[]=substr(pathInfo($aColl,PATHINFO_FILENAME),2);
}

$requestedDir=strtolower(trim(extractRequestVar('dir','')));
if (strpos($requestedDir,'..')!==false) {
   print "Illegal dir name: <tt>$requestedDir</tt>";
   exit;
}
$showThisDir='';
if ($requestedDir!='') $showThisDir=$requestedDir;

// possible values: dualViewers,dualViewersCombo,dualViewers1,dualViewers2,rotating,tableau,singleImage
$requestedLayout=strtolower(trim(extractRequestVar('layout','')));
$showThisLayout= ($requestedLayout!='')  ? $requestedLayout : $defaultScreenLayout ;

$requestedNoCompact=strtolower(trim(extractRequestVar('noCompact','0')));

$showThisFile=trim(extractRequestVar('file',''))   ;
if  ( (strpos($showThisFile,'..')!==false)  ||  (strpos($showThisFile,'/')!==false) ||  (strpos($showThisFile,'\\')!==false) ) {
   print "Illegal file name: <tt>$showThisFile</tt>";
   exit;
}

$zrequestedThumbnail=trim(extractRequestVar('thumbnail thumb',''))   ;
$requestedThumbnail=strtolower(substr($zrequestedThumbnail,0,1));

$requestedFileListType=trim(extractRequestVar('fileList list',''))   ;
$useListDisplay= ($requestedFileListType!='') ? $requestedFileListType : 1 ;

$requestedShowInfo=trim(extractRequestVar('info showinfo','-1'))   ;
$requestedDesc=trim(extractRequestVar('desc',''))   ;

$requestedCollection=trim(extractRequestVar('collection',''));
$requestedEntry=trim(extractRequestVar('entry',''));

$collectionTitle=trim(extractRequestVar('collectionTitle',''));
$mainTitle=trim(extractRequestVar('mainTitle',''));
$mainTitleClass=trim(extractRequestVar('mainTitleClass',''));

$gooStatus=json_encode($treeListStatus, JSON_UNESCAPED_UNICODE);

$requestedFavorites=trim(extractRequestVar('favorites',''));

$_SESSION['wsGallery_errors']=[];

//=== more stuff with params
$_SESSION['wsGallery_supportedImages']=findPhpImageSupport(1);    // associateive array of exts that are supported (lower case, jpeg and jpg both recognized)

$imgExt1=array_keys($wsgp['imgExts']);

// check for support of the imgExt extensions

$imgFunctionList=['png'=>'imagecreatefrompng',
   'gif'=>'imagecreatefromgif',
   'jpeg'=>'imagecreatefromjpeg',
   'jpg'=>'imagecreatefromjpeg',
   'bmp'=>'imagecreatefrombmp',
   'xbm'=>'imagecreatefromxbm'  ];  // some of the more obscure functions could be added here, and in wsGallerLibUtils.php
$noImgFunction=[];
foreach ($imgExt1 as $ifoo=>$aext) {
    if (array_key_exists($aext,$imgFunctionList)) {
        $afunc=$imgFunctionList[$aext];
        if (!function_exists($afunc)) {
            $noImgFunction[]=$aext;
        }
    } else {
         $noImgFunction[]=$aext;
    }
}
if (count($noImgFunction)>0) {
    print "<br>Warning: this php installation does not support the following image types: ";
    print '<div style="font-family:monospace;border:1px solid gray;margin:2em">'.implode(' | ',$noImgFunction).'</div>';
    print "<br>Please edit <tt>wsGallery_params.php</tt> (in $curDir), and remove these extensions from the ";
    print "<tt>imgExts</tt> parameter. ";
    exit;
}


$otherExt1=array_keys($wsgp['otherExts']);
$allExt1=array_merge($imgExt1,$otherExt1);
$otherExtSpec1=$wsgp['otherExts'];
$goof=['imgExts'=>$imgExt1,'otherExts'=>$otherExt1,'allExts'=>$allExt1,'otherExtsSpecs'=>$otherExtSpec1];

$_SESSION['wsGallery_specsExts']=$goof;
$_SESSION['wsGallery_skipSubdirs']=$wsgp['skip'] ;
$_SESSION['wsGallery_onTheFlyThumbnails']=$wsgp['onTheFlyThumbnails'];   // 0 or 1 : 0 to suppress (use generic icons if no cached thumbnail)
$_SESSION['wsGallery_onTheFlySnapshots']=$wsgp['onTheFlySnapshots'] ;   // 0 or 1 : 0 to suppress (use generic icons if no cached thumbnail)
$_SESSION['wsGallery_noCache']=$wsgp['noCache'] ;   // 0 or 1 : 0 to allow use of caching. 1 to suppress (create button and file lists on each request)
$_SESSION['wsGallery_switchGallery']=$wsgp['switchGallery'] ;   // 0 or 1 : 0 to suppress (use generic icons if no cached thumbnail)

$_SESSION['wsGallery_preset3_viewer1']=$wsgp['preset3_viewer1'] ;   // specs for viewer1 (dual mod preset3)
$_SESSION['wsGallery_preset3_viewer2']=$wsgp['preset3_viewer2'] ;
$_SESSION['wsGallery_preset3_fileList']=$wsgp['preset3_fileList'] ;

$exts64=json_encode($_SESSION['wsGallery_specsExts']);

$spinnerError=0;
$spinnerListString='';
$spinnerList=getSpinnerList(500000);   // list of spinner image files from cache (exists and not out of date)
if ($spinnerList[0]===false)  {  // problem that is correctable.
  $spinnerError=1;
  $wasErr=$spinnerList[1];
}   else {
   $spinnerList=$spinnerList[1];
   $spinnerListString=implode(',',$spinnerList);
}


endOfThis: ; // jump here if problem with parameter file
?>
<!DOCTYPE HTML>
<html><head><title>wsGallery viewer</title>
<meta charset="utf-8">

<link rel="stylesheet" type="text/css" href="wsGallery.css" />


<style type="text/css">
 .help_shadow {box-shadow: 5px 5px 5px 3px tan ;}
 .wsGallery_logonMenu {
    position:fixed;
    left:50%;
    top:15%;
    z-index:50000;
    background-color:cyan;
    max-height:5em;
    max-width:30em;
    overflow:auto;
    border-radius:3px;
    padding:10px;
 }

</style>

<script type="text/javascript" src="libs/publicLib/jquery-3.6.0.min.js"></script>
<script type="text/javascript" src="libs/publicLib/md5b.js"></script>
<script type="text/javascript" src="libs/publicLib/keyShortcut.js"></script>
<script type="text/javascript" src="libs/publicLib/imagesLoadedMin.js"></script>
<script type="text/javascript" src="libs/publicLib/js.cookie.js"></script>

<!-- <script nomodule defer src="/path/to/js.cookie.js"></script>   -->   <!-- https://github.com/js-cookie/js-cookie -->

<script type="text/javascript" src="libs/js/wsurvey.utils1.min.js">  </script>
<script type="text/javascript" src="libs/js/wsurvey.dropdown.min.js">  </script>
<script type="text/javascript" src="libs/js/wsurvey.floatingContent.min.js"></script>
<script type="text/javascript" src="libs/js/wsurvey.sortTable.min.js"></script>
<script type="text/javascript" src="libs/js/wsurvey.getJson.min.js"></script>
<script type="text/javascript" src="libs/js/wsurvey.adminLogon.min.js"></script>
<script type="text/javascript" src="libs/js/wsurvey.uploadFiles.min.js"></script>

<script type="text/javascript" src="src/wsGallery.js"></script>
<script type="text/javascript" src="src/wsGallery_dirVu.js"></script>
<script type="text/javascript" src="src/wsGallery_showFile.js"></script>
<script type="text/javascript" src="src/wsGallery_collectionsFavorites.js"></script>

<!--  <script type="text/javascript" src="src/wsGalleryAdmin.js"></script>    Will be loaded when admin logons -->
<!-- <script type="text/javascript" src="src/wsGallery_dirCache.js"></script>      Will be loaded when admin logons -->

 <script type="text/javascript" >
 var wsurveyadmin_logonClass='wsGallery_logonMenu';     // used by wsurvey.adminLogon
 var wsurveyadmin_php='libs/php/wsurvey.adminLogon.php';     // used by wsurvey.adminLogon
 if (typeof(window['wsurvey'])=='undefined') {
    var wsurvey={}
 }


  $(document).data('logonStatus',0) ;
  $(document).data('logon',0);
  $(document).data('adminModeEnabled',0);
  $(document).data('skipSubDirs',[]);
  $(document).data('mouseScrollInImage',0);
  $(document).data('customImageWidth',1024);
  $(document).data('customImageHeight',768);
  $(document).data('mouseupLocationInImage',[]);
  $(document).data('mouseDownLocationInImage',[]);
    $(document).data('externalViewerInfo','');
    $(document).data('externalViewerWindow','');
   $(document).data('adminNotes',[]);
   $(document).data('currentFiles_dir','') ;
   $(document).data('currentFiles_treeName','' ) ;
   $(document).data('currentFiles_dirDesc','' ) ;
   $(document).data('currentFiles_buttons',[] ) ;
   $(document).data('currentFiles_snapshots',[] ) ;
   $(document).data('currentDir_desc',[]);
   $(document).data('currentFiles_stats',[]);
   $(document).data('currentFiles_otherExtsSpecs',[]) ;    // set below
   $(document).data('spinnerList',[])
   $(document).data('collectionButtons',[])
   $(document).data('isMobile','');
   $(document).data('helpMenu_howShow','list');  // list or table
   $(document).data('helpMenu_autoClose',1);  // 0 or 1 (1 = close after selection)
   $(document).data('helpMenu_asTable','');  // 0 or 1 (1 = close after selection)
   $(document).data('helpMenu_asList','');  // 0 or 1 (1 = close after selection)
   $(document).data('helpMenu_asTableAdmin','');  // 0 or 1 (1 = close after selection)
   $(document).data('helpMenu_asListAdmin','');  // 0 or 1 (1 = close after selection)

   let atitleBase="Toggle screen layout. "
//   let aiconList=["&#10697;","&#8862;","&#9638;","&#128618;",'&#9704;'] ;
   let aiconList=["&#10697;","&#8862;","&#9638;",'&#9704;',"&#129001;",] ;
   let atitleList=["Dual viewers and a fileList ",
                    "Rotating view (2x2 grid)",
                     "Images added in a multi column grid",
                     "One image on 2/3 screen, file list on  1/3",
                     "One image at a time covering most of screen"];
   let aclassList=['cToggleScreenLayout','clargeViewerRotating','clargeViewerTableau','cToggleScreenLayoutSingle','clargeViewerSingle'];

   $(document).data('screenLayout',0);  // default is dual viewer
   $(document).data('screenLayout_dual',0);   // default dual viewer is larger file list
   $(document).data('screenLayout_tempSingle',0);  // assume that singleImage view box is from a dual viewer

   $(document).data('screenLayout_titleList',atitleList);
   $(document).data('screenLayout_titleBase',atitleBase);  // 0 or 1 (1 = close after selection)
   $(document).data('screenLayout_iconList',aiconList);
   $(document).data('screenLayout_classList',aclassList);

   let aiconList_dual=["&#10697;","&#9714;","&#8863;"] ;
   let atitleList_dual=["Small & medium viewer, large file list",
       "Small and large viewer, medium file list",
       "Small and largest viewer, small file list"];
   let aclassList_dual=['cToggleScreenLayout','clargeViewerExpanded','clargeViewerAll'];

   $(document).data('screenLayout_titleList_dual',atitleList_dual);

   let atitleBase_dual="Toggle the sizes of file and viewer boxes (3 presets)";
   $(document).data('screenLayout_titleList_dual',atitleList_dual);
   $(document).data('screenLayout_titleBase_dual',atitleBase_dual);
   $(document).data('screenLayout_iconList_dual',aiconList_dual);
   $(document).data('screenLayout_classList_dual',aclassList_dual);


   $(document).data('favoritesSpecsAll',[])
   let ff={'readName':'','readNfiles':0,'current':[]};
   $(document).data('favoritesSpecs',ff);

   $(document).data('screenLayout_classList_dual',aclassList_dual);

  $(document).data('firstCall',1);

  $(document).data('minSizeViewing',400);


 <?php
 // default tree set on server side. User can switch which tree to vew
  if ($paramUpdateNeeded!=0) {
     print '   $(document).data(\'paramUpdateNeeded\' ,\''.$paramUpdateNeeded.'\') ;'."\n";
     print '   $(document).data(\'wasErr\' ,\''.$wasErr.'\') ;'."\n";
  } else {
     $wasErr = rtrim(str_replace('\\', '/', $wasErr), '/');
     print '   $(document).data(\'paramUpdateNeeded\' ,\''.$paramUpdateNeeded.'\') ;'."\n";
     print '   $(document).data(\'wasErr\' ,\''.$wasErr.'\') ;'."\n";
     print '   $(document).data(\'spinnerError\' ,\''.$spinnerError.'\') ;'."\n";
     print '   $(document).data(\'adminLogonRequired\' ,\''.$adminLogonRequired.'\') ;'."\n";

     print '   $(document).data(\'requestedGallery\' ,\''.$requestedGallery.'\') ;'."\n";
     print '   $(document).data(\'requestedTree\' ,"'.$requestedTree.'") ;'."\n";
     print '   $(document).data(\'requestedDir\' ,"'.$requestedDir.'") ;'."\n";
     print '   $(document).data(\'requestedFile\' ,"'.$showThisFile.'") ;'."\n";
     print '   $(document).data(\'requestedThumbnail\' ,"'.$requestedThumbnail.'") ;'."\n";
     print '   $(document).data(\'requestedLayout\' ,\''.$requestedLayout.'\') ;'."\n";
     print '   $(document).data(\'requestedFileListType\' ,"'.$requestedFileListType.'") ;'."\n";
     print '   $(document).data(\'requestedShowInfo\' ,"'.$requestedShowInfo.'") ;'."\n";
     print '   $(document).data(\'requestedDesc\' ,"'.$requestedDesc.'") ;'."\n";

     print '   $(document).data(\'requestedCollection\' ,"'.$requestedCollection.'") ;'."\n";
     print '   $(document).data(\'requestedEntry\' ,"'.$requestedEntry.'") ;'."\n";
     print '   $(document).data(\'requestedFavorites\' ,"'.$requestedFavorites.'") ;'."\n";

     print '   $(document).data(\'galleryDir\' ,\''.$galleryDir.'\') ;'."\n";
     print '   $(document).data(\'currentGallery\' ,\''.$galleryDir.'\') ;'."\n";
     print '   $(document).data(\'currentTree\' ,"'.$showThisTree.'") ;'."\n";
     print '   $(document).data(\'currentTreeAlt\' ,"'.$showThisTree.'") ;'."\n";  // will not be alt name
     print '   $(document).data(\'currentTreeStatus\' ,\''.$gooStatus.'\') ;'."\n";
     print '   $(document).data(\'currentDir\' ,"'.$showThisDir.'") ;'."\n";
     print '   $(document).data(\'wsGallery_version\' ,"'.$wsGallery_version.'") ;'."\n";
     print '   $(document).data(\'wsGallery_lockme\' ,"'.$lockme_status.'") ;'."\n";
     print '   $(document).data(\'spinnerList\' ,"'.$spinnerListString.'") ;'."\n";
     print '   $(document).data(\'specExts\' ,\''.$exts64.'\') ;'."\n";
     print '   $(document).data(\'defaultGallery\' ,\''.$defaultGallery.'\') ;'."\n";
     print '   $(document).data(\'switchGallery\' ,\''.$switchGallery.'\') ;'."\n";

     print '   $(document).data(\'collectionTitle\' ,\''.$collectionTitle.'\') ;'."\n";
     print '   $(document).data(\'mainTitle\' ,\''.$mainTitle.'\') ;'."\n";
     print '   $(document).data(\'mainTitleClass\' ,\''.$mainTitleClass.'\') ;'."\n";

     print '   $(document).data(\'screenLayout\',\''.$showThisLayout.'\') ;'."\n";
     print '   $(document).data(\'currentScreenLayout\',\''.$showThisLayout.'\') ;'."\n";    //1 2 3 4 (text smallThumb mediumtnumb, large thumb)
     print '   $(document).data(\'useThumbnails\',\''.$useThumbnails.'\') ;'."\n";    //1 2 3 4 (text smallThumb mediumtnumb, large thumb)
     print '   $(document).data(\'currentThumbnails\',\''.$useThumbnails.'\') ;'."\n";    //1 2 3 4 (text smallThumb mediumtnumb, large thumb)
     print '   $(document).data(\'useListDisplay\',\''.$useListDisplay.'\') ;'."\n";    //1 2 3  (grid, several col list,  table )
     print '   $(document).data(\'enableFavorites\',\''.$enableFavorites.'\') ;'."\n";
     print '   $(document).data(\'enableNotes\',\''.$enableNotes.'\') ;'."\n";
     print '   $(document).data(\'maxNoteSize\',\''.$maxNoteSize.'\') ;'."\n";

     print '   $(document).data(\'requestedNoCompact\' ,\''.$requestedNoCompact.'\') ;'."\n";
     print '   $(document).data(\'doCompact\' ,\''.$doCompact.'\') ;'."\n";

     print '   $(document).data(\'requireLockme\',\''.$requireLockme.'\') ;'."\n";
//     print ' alert("you and "+$(document).data(\'currentTree\')) ; '."\n";
     $p3List=['top','left','width','height'];
     $p3_1=[];$p3_2=[]; $p3_f=[];
     foreach ($p3List as $kk=>$aspec) {
        $p3_1[]=$_SESSION['wsGallery_preset3_viewer1'][$aspec];
        $p3_2[]=$_SESSION['wsGallery_preset3_viewer2'][$aspec];
        $p3_f[]=$_SESSION['wsGallery_preset3_fileList'][$aspec];
     }
     $z3_1=implode(',',$p3_1); $z3_2=implode(',',$p3_2); $z3_f=implode(',',$p3_f);
     print "// top left width height ... \n" ;
     print '   $(document).data(\'preset3_viewer1\' ,\''.$z3_1.'\') ;'."\n";
     print '   $(document).data(\'preset3_viewer2\' ,\''.$z3_2.'\') ;'."\n";
     print '   $(document).data(\'preset3_fileList\' ,\''.$z3_f.'\') ;'."\n";


    $cc2=implode(',',$collectionsAvail);
    print '   $(document).data(\'collectionsAvail\' ,\''.$cc2.'\') ;'."\n";

//dual, rotating, tableau,single (the default) ,singleLarge
     $zclassList=['dual'=>'.cToggleScreenLayout',
               'rotating'=>'.clargeViewerRotating',
               'tableau'=>'.clargeViewerTableau',
               'singleLarge'=>'.clargeViewerSingle',
               'single'=>'.cToggleScreenLayoutSingle'];
     $useLayout='.cToggleScreenLayoutSingle';
     if (array_key_exists($defaultScreenLayout,$zclassList))  $useLayout=$zclassList[$defaultScreenLayout];
     print '   $(document).data(\'screenLayout_default\' ,\''.$useLayout.'\') ;'."\n";

     print '   $(document).data(\'wsgMainSel\' ,\''.$wsSel.'\') ;'."\n";

  }      // param update

?>
// note: init() will fix up spinnerList and currentTreeStatus (make them into easy to use objects and array)

// convert stuff fed from php into javascript objects
   let pupdate=$(document).data('paramUpdateNeeded')  ;
   if (pupdate==0) {  // not a parameter update
     let oof=$(document).data('currentTreeStatus')  ;
     let oof2=JSON.parse(oof);
     $(document).data('currentTreeStatus',oof2 ) ;

     let oof6=$(document).data('specExts')  ;
     let oof62=JSON.parse(oof6);
     $(document).data('currentFiles_otherExtsSpecs',oof62['otherExtsSpecs']) ;
     $(document).data('currentFiles_imgSpecs',oof62['imgExts']) ;

     let arf=$(document).data('spinnerList');
     let arf2=arf.split(',');
     $(document).data('spinnerList',arf2)

// see if cookies are set  (but do not override request list params
    let acc=Cookies.get();

    if ($(document).data('requestedGallery')=='') {
        if (acc.hasOwnProperty('wsGallery_gallery'))  {
              let doit=acc['wsGallery_gallery'];
              $(document).data('galleryDir',doit)   ;
              $(document).data('currentGallery',doit)  ;
        }
    }
    if ($(document).data('requestedTree')=='') {
        if (acc.hasOwnProperty('wsGallery_tree'))  {
              let doit=acc['wsGallery_tree'];
              $(document).data('currentTree',doit)  ;
        }
    }
    if ($(document).data('requestedDir')=='') {
        if (acc.hasOwnProperty('wsGallery_dir'))  {
              let doit=acc['wsGallery_dir'];
              $(document).data('currentDir',doit)  ;
        }
    }

      if ($(document).data('requestedLayout')=='') {
        if (acc.hasOwnProperty('wsGallery_screenLayout'))  {
              let doit=acc['wsGallery_screenLayout'];
              $(document).data('currentScreenLayout',doit)  ;
              $(document).data('screenLayout',doit)  ;
        }
    }

      if ($(document).data('requestedNoCompact')=='1') {  // requestedNoCompact=1 -- don't show compact link
         $(document).data('showCompactLink',0)  ;   // 0 1 or 2
     } else {  // compact link not suppressed
        if (acc.hasOwnProperty('wsGallery_compactLink'))  {   // use cookie if exists
              let doit=jQuery.trim(acc['wsGallery_compactLink']);      // 0 1 or 2
              if (doit!='0' && doit!='1' && doit!='2'  && doit!='3') doit='0';
              $(document).data('showCompactLink',doit)  ;
        } else {                                        // use params.json value
              let doit=$(document).data('doCompact');
              if (doit!='0' && doit!='1' && doit!='2') doit='0';
              $(document).data('showCompactLink',doit)  ;   // 0 1 or 2
        }
    }


    if ($(document).data('requestedThumbnail')=='') {
        if (acc.hasOwnProperty('wsGallery_thumbnails'))  {
              let doit=acc['wsGallery_thumbnails'];
              $(document).data('useThumbnails',doit)  ;
              $(document).data('currentThumbnails',doit)  ;
        }
    }

    if ($(document).data('requestedFileListType')=='') {
        if (acc.hasOwnProperty('wsGallery_listDisplay'))  {
              let doit=acc['wsGallery_listDisplay'];
              $(document).data('useListDisplay',doit)  ;
              $(document).data('useListDisplay',doit)  ;
        }
    }




  }  // paramupdate needed
  $(document).ready(init) ;  // call on load (but maybe before  full load)



</script>


</head>

<body  >

<p>
<div class="topBar" style="width:100%">

<span  class="topBarLeft">
  <span  class="topBarLeft1">
    <button  type="button" value="&#8862;" which="0" whichBox="1"  id="iToggleScreenLayout"   class="cToggleScreenLayout"
        title="Toggle screen layout: currently the default (large fileList)   "
       onClick="doResizeViewers(this)" >&#10697;</button>

  </span>
  <span  id="iToggleScreenLayoutShowDropdown" >
     <span  class="topBarLeft1a"  name="whileDropdownNotOpen"  title="mouseover to see dropdown, click to freeze it in place" style="font-size:110%" >&#9207;</span>
    <span  class="topBarLeft1a"  name="whileDropdownOpen"   title="click to close dropdown " style="display:none;font-size:110%" >&#9206;</span>
  </span>
</span>



 <span class="topBarLeft">
   <button id="toggleViewers_2_alt"  class="ctoggleViewers_2_alt"  title="Toggle between the 3 presetSizes for the  file & dual image viewers"
      onClick="$('#toggleViewers_2').trigger('click')">&#10697; &#120031;</button>

    <input type="button" value="&#10068;" title="View basic help" onClick="doHelpVu(this)" topic="Intro"   class="helpButton helpButtonBigger" >
 </span>

 <span class="topBarLeft"> <input type="button" value="&#9636;" title="Click here To toggle view of directory list" onClick="toggleDirVu()" > </span>

 <span id="wsGallery_header1" title="Version is written here by init" class="topBarLeft2">
 <span id="wsGallery_header1A" title="Welcome!" class="topBarLeft2a">
     wsGallery: display image &amp; other files
    <span id="wsGallery_myGallery" class="cMyGallery" title="Viewing this gallery!"> &hellip</span>
    <span id="iCompactViewerLink" class="cCompactLink" title="Use the compact (mobile friendly) version">
     <button  title="switch to the compact viewer" onclick="switchCompactViewer(this)">compactViewer</button>
    </span>
 </span>&nbsp;&nbsp;

<!-- dual viewer stuff -->
 <span id="wsGallery_header1B" title="Dual viewer info ..." class="topBarLeft2a">

  <input id="currentImageJumpButton"  name="imageJumpButtons" type="button"  xpctAt="0.0"  ypctAt="0.0"  ;
        value="Viewer2 to: x=0% / y=0%  "
       title="Click to scroll location of viewer2 to this location ... as a fraction of the total image,  relative to the  upper left corner
         This automatically happens when `auto scroll to viewer2` is enabled"
          onClick="autoScrollSnapBox2(this)" >

    <span id="currentImageCursorSpot" class="cCurrentImageCursorSpot"  name="imageJumpButtons" title="most recently selected image: location of of cursor within image dimensions:  %width / %height "> &nbsp;</span>

 <span id="currentImageContinuousScroll"  class="ccurrentImageContinuousScroll"   >
   <input type="button" value="autoScroll" which="1" id="currentImageContinuousScrollButton" name="imageJumpButtons"   onClick="enableContinuouScroll(this)"
      class="ccurrentImageContinuousScrollButton"
    title="dualView/Combo mode feature: toggle auto scroll of viewer 2. When enabled:
        &#128433; click on a location in viewer 1,
       &#128073; the corresponding portion of this image (in viewer2) will be scrolled to">&nbsp;</span>
 </span>
 </span>

<!-- admin buttons -->
 <span class="topBarRight">
   <span id="adminButtonsHeader">
    <input id="iFavorites" type="button"  style="display:none" value="&#128153;" title="Add to favorites list " onclick="doFavorites(this)">
    <input id="iEnableAdminMode" type="hidden" value="0">
    <span id="showAdminEnableButton" style="display:none">
      <span class="topBarRightEnable" id="itopBarRightEnable">admin mode
      </span>
      <input  type="button" value="&#9966;"  style="color:blue" title="View admin tools" onClick="doAdmin(0)" id="openAdminMenuButton" >
    </span>
    
    <input type="button" value="&#9881;&#65039;" title="personal settings and logon" onClick="doSettings1(this)">
    <input  type="button" id="logonButton" value="Logon"   style="display:none" title="Admin logon"  >

    <input  type="button" id="logoffButton" style="display:none;color:red" from="wsGallery"  value="Logoff" origTitle="Admin logoff: " title="Admin logoff"
             onClick="doLogoff(this)" >
   </span> <!-- adminButtonsHeader -->
  </span>
</div>
<br clear="all" />


</div>

<div id="helpDump">
<?php
  require_once($curDir.'/src/wsGalleryHelp.html');  // help stuff
?>
</div>

<!-- :::::::::::::::::::::::::::::;;; :::::::::::::::::::::::::::: -->
<!-- dropdown menus -->
<div id="dropdown_layouts" style="display:none;border:2px dotted lightblue;"     >
<ul style="margin-top:1px">
  <li title="Dual viewers and a fileList" >
      <button class="cToggleScreenLayout clargeViewer_inDropdown"   onClick="doResizeViewers(this,0)">&#10697;</button>
  <li title="Rotating view (2x2 grid)">
      <button  class="clargeViewerRotating clargeViewer_inDropdown"  onClick="doResizeViewers(this,1)">&#8862;</button>
  <li title="Tableau (images added in a 2 column grid)" >
      <button  class="clargeViewerTableau clargeViewer_inDropdown"  onClick="doResizeViewers(this,2)">&#9638;</button>

<!--
deprecated: this is now an option in single viewer 2/3 screen
 <li title="Single  (one image at a time covering most of screen, with arrows to move to prior and next)" >
      <button  class="clargeViewerSingle clargeViewer_inDropdown"  onClick="doResizeViewers(this,3)">&#129001;</button>
-->
  <li title="Default: single viewer and a fileList" >
      <button class="cToggleScreenLayoutSingle clargeViewer_inDropdown"   onClick="doResizeViewers(this,3)">&#9704;</button>

</li>
</div>


<div id="dropdown_whichViewer" style="display:none;border:2px dotted lightblue;padding:0px;margin:0px"     >
<ul style="margin-top:1px ">
 <li title="combo: display in viewers 1 and 2 "><button onClick="toggleWhichViewerGet('',0)" > &#74787; </button>
 <li title="display in ... viewer 1"><button onClick="toggleWhichViewerGet('',1)">&#128437; &#9461; </button>
<!-- <li title="display in ... viewer 2"><button  onClick="toggleWhichViewerGet('',2)">&#128437;&#9462; </button> -->
 <li title="display in viewer 2"><button  onClick="toggleWhichViewerGet('',2)">&#128437; &#50;&#65039;&#8419;</button>
 <li title="display in external viewer (new window)"><button onClick="toggleWhichViewerGet('',3)" >&#128468; </button>
 </ul>
</div>

<div id="dropdown_showSnapshot" style="display:none;border:2px dotted lightblue;padding:0px;margin:0px"     >
<ul style="margin-top:1px ">
 <li title="Full image (as stored on server)"><button onClick="toggleSnapshotGet('',1,1)" >&#11034;</button>
 <li title="Snapshot (resized to 640x480)"><button onClick="toggleSnapshotGet('',2,1)"> &#12276; </button>
 <li title="Custom (you will provide Width and Height"><button  onClick="toggleSnapshotGet('',3,1)">&#12275;</button>
 </ul>
</div>

<div id="dropdown_shrink" style="display:none;border:2px dotted lightblue;padding:0px;margin:0px"     >
<ul style="margin-top:1px ">
 <li title="asis: image is displayed as received from server (it will be scrollable)"><button onClick="toggleShrinkToFit('',1,1)" >&#11036;</button>
 <li title="stretch : fills viewer, but aspect ratio is NOT retained"><button onClick="toggleShrinkToFit('',2,1)"> &#9641; </button>
 <li title="shrink:  retains aspect ratio, but may not fill the viewer"><button  onClick="toggleShrinkToFit('',3,1)">&#128476;</button>
 </ul>
</div>



</body>
</html>