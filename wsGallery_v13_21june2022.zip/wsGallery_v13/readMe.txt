21 June 2022: wsGallery ver 1.3: quickly list and view images, and other files

For details on installation and usage, see wsGallery_readMe.txt

The following files are installed in the wsGallery main directory

  The following MUST be modified as soon as wsGallery is installed.

     galleries/main/wsGallery_treeList.php   -- List of "tree" specifications: locations of images and other files
     wsurvey.adminLogon_params.php   -- administration password information: specify the admin password.

  The following can be modified, but for most installations the defaults should be fine.

     data/wsGallery_params.php  : various wsGallery parameters.

  The following should NOT be modifiedl

     wsGallery.php   -- the main HTML file.
     wsGallery.css    -- styles used by wsGallery
     wsGallery_externalHandler.html  -- displays files in external window. Not meant for direct access.
     wsGallery_get.php   -- "ajax" front-end to wsGallery data
     wsGallery_get.css    --  css classes used by wsGallery_get.php 
     wsGallery_get.txt   --  description of wsGallery_get.js and wsGallery_get.php (wsGallery_get.js is in the wsGallery/src directory)
     wsGallery_request.txt   --  notes on staring wsGallery with request line variables (to display a gallery/tree/dir)
     wsGallery_readMe.txt   -- description, installation, and useage
     wsGallery_simple.php      -- simpler program to view wsGallery's images.  
     wsGallery_vuHelp.php   -- view help in external window (can be accessed directly). To use it you should modify some of its user configurable parameters.

The following directories are created. None of them contain files that a typical administrator will work with on a frequent basis.

   data:  several wsGallery parameter files
          data also contains "original" versions of wsGallery_treeList.php and wsGallery_params.php, which can be used
          if the working versions are damaged.
          The collections subdirectory of data is where information on wsGallery "collections" is stored.
   galleries:  Working data for each wsGallery "gallery".
	  The wsGallery administrator can create subdirectories under galleries -- each subdirectory is a seperate "gallery".
          Each of these "gallery specific" subdirectories can become large.   With lots of subdirectories --  one for each
          viewable directory, with several files for each file in a viewable directory. 
          Note that on installation, galleries/main is created.
   icons : contains various useful icons.  An ambitious administrator can add icons (such as spinners)
   images : the '_default' location of files and images. You don't have to use it (if you don't, treeList.php should be modified)
          For demo purposes, images contains two small directories with a few photos in them: 'capeCodPHotos' and 'ptReyesPhotos'
   libs : php and javascript libraries used by wsGallery.  Includes "wsurvey." libraries, and other libraries (such as jQuery).
   src :  wsGallery specific source code: php and js files.

  Note: if you create additional "galleries" (other than the pre-built 'main' gallery), you MUST specify a 'gallery'
  specific wsGallery_treeList.php (for each of these additional galleries).
  For example, for a 'home2' gallery:
    a)  Create wsGallery/galleries/home2
    b)  Specify wsGallery/galleries/home2/wsGallery_treeList.php
  See wsGallery_readme.txt for details on working with galleries.
  -------------------

Contact: Daniel Hellerstein. danielh@crosslink.net. 
       http://www.wsurvey.org/distrib, or  https://github.com/dHellerstein 

Disclaimer:

    wsGallery is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    wsGallery is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    If you did not receive a copy of the GNU General Public License,
    see <http://www.gnu.org/licenses/>.

    Note: wsGallery uses security measures that are not strong.
           In particular: if you do not control access to the directory that wsGallery.php is installed on
                       -- you should NOT install wsGallery on your webserver!
           See wsGallery_readMe.txt for further discussion. 

 
Daniel Hellerstein, danielh@crosslink.net
