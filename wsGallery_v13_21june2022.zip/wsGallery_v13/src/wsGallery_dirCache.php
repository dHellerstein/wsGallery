<?php
// dircache functions
// for wsGallery

use wSurvey\getJson as getJs  ;


// ==========================================
// dir "cache initialization" -- create  filelist, thumbnails,   and snapshots for images in a selected directory
// ===================================================================

// dir init  -- create cacheable thumbnail, snapshot, and readme.txt files
// on first call, doDirCacheJs  is used to create a "control panel"
// The client then starts the process, using a sequence of  actionCalls  for filelist, each thumbnail, snapshots
//  Within each actionCall, there can be mupltiple timeout/resume calls (to avoid timeouts, and to allow the control panel to display ongoing status)
// doResume= flag that this is a resumption after a prior timeout (of
//  timeAllowed =seconds allowed before early return (on timeout, a flag is set to tell js side to display info and them make a "resume" call)
//
// NOte: this assumes that a cache directory exists for adir in treename -- as created using js makeTreeDirList(). If not, error
//
// called from:  wsGalleryActionsAdmin.php

function doDirCachePhp($nowDir0,$adir,$treeName,$isReinit,$action0,$doResume,$timeAllowed=4,$isMulti=0,$removeAll,$doOverwrite,$retainDesc) {
  
  if ($treeName=='') {    // feb 2022, must supply treename
      getJs\jsonReturnError("doDirCachePhp error: no treeName specified (for nowdir=$nowDir0, adir=$adir)");
  }

  $daSpecs=$_SESSION['wsGallery_specsExts'];
  $imgExts=$daSpecs['imgExts'];  $imageOnlyString=makeListCI($imgExts);   // imageOnlyString used in GLOB (for ci dir search)
  $nowTime=time();
  set_time_limit(60);

  $action=strtolower($action0);     // start makes a menu. Everything else does someting (often via timeout/resume several calls)

  $noCache=$_SESSION['wsGallery_noCache'];  // doDirCachePhp should not be called if noCache is set
  if ($noCache==1)   getJs\jsonReturnError("doDirCachePhp should not be called, since noCache is enabled.","For root of $nowDir, subdir=$adir, in tree=$treeName");

// fields of this changed below (this assume success at doing nothing). feb 2022: treename,dir,path sort of redundant.

// this is  where isMulti is used
 if ($action=='start'   ) {          // creates menu that will be filled in in future steps -- THIS IS THE FIRST CALL from doDirCacheJs
   $_SESSION['wsGallery_cacheDirStateVars']=[] ;
   if ($isMulti==0) {
       $nowDir=rtrim($nowDir0,'/').'/'.ltrim($adir,'/');  // the actual directory that contains the files (must be in the treeName tree)
       if (!is_dir($nowDir)) {
         getJs\jsonReturnError("Admin action needed: for $adir in tree $treeName: the `$nowDir`  directory can NOT be found!");
      }

       $infos=['status'=>'ok','treeName'=>$treeName,'dir'=>$adir,'path'=>$nowDir,'content'=>'Nothing done','action'=>$action,'header'=>''];
       $stuff=doDirCachePhp_makeMenu($adir,$treeName,$action,$isMulti,[]);       // create html menu that client selects from
       $infos['header']='Initializing: <span title="'.$nowDir.'">'.$adir.' </span> <em> ... to create information used to expedite wsGallery performance</em> ';
       $infos['content']=$stuff  ;
       getJs\jsonReturn($infos);
   } else {   // multi
       $adirV=explode(',',$adir)  ;
       $infos=['status'=>'ok','treeName'=>$treeName,'dir'=>$adir,'path'=>$nowDir0,'content'=>'Nothing done','action'=>$action,'header'=>''];
       $stuff=doDirCachePhp_makeMenu($adir,$treeName,$action,$isMulti,$adirV);       // create html menu that client selects from
       if (count($adirV)>2) {
          $nctA=count($adirV);
         $infos['header']='Initializing: <span title="'.$nctA.' directories in '.$treeName.'">'.$nctA.' directories </span> <em> ... create information used to expedite wsGallery performance</em> ';
       } else {
         $infos['header']='Initializing: <span title="'.count($adirV).' directories in '.$treeName.'">'.$adir.' </span> <em> ... create information used to expedite wsGallery performance</em> ';
       }
       $infos['content']=$stuff  ;
       getJs\jsonReturn($infos);
   }
 }


// ----
// initialize a single dir.
// multiple dir mode: this is called seperately for each dir.
// Its up to the js side to call this for each of the several dirs

// look for  cacheDir . And, if exists, perhaps delete all files
// Note: this step is done in one call (no timeout/resume)

  $nowDir=rtrim($nowDir0,'/').'/'.ltrim($adir,'/');  // the actual directory that contains the files (must be in the treeName tree)
  if (!is_dir($nowDir)) {
         getJs\jsonReturnError("Admin action needed: for $adir in tree $treeName: the `$nowDir`  directory can NOT be found");
  }

 $infos=['status'=>'ok','treeName'=>$treeName,'dir'=>$adir,'path'=>$nowDir,'content'=>'Nothing done','action'=>$action,'header'=>''];
 $cacheDir=doDirCachePhp_getCacheDir('~'.$adir,$treeName);  // cacheDir is used below. Note that  doDirCachePhp_getCacheDir error exits if no cacheDIr exists

 if ($action=='cacheinit') {

   if ($cacheDir===false) {
      $goo3=implode(' | ',$_SESSION['wsGallery_errors'] );
      getJs\jsonReturnError("Cache dir missing. For  ($adir) under [$nowDir] in tree $treeName. Try revising the directory listing for this tree.");
   }

//   $removeAll=extractRequestVar('removeall','0');     // if here, subdire specific cache dir DOES exist.
   if ($removeAll=='1') {       // clear it?
       $nfiles=0;  $nfails=0;
       $files = glob($cacheDir.'/*'); // get all file names
       foreach($files as $file){ // iterate files
          if (is_file($file)) {
             $q1=unlink($file); // delete file
             if ($q1) $nfiles++;
             if (!$q1) $nfails++;
          }  // isfile
       }
       $infos['content']=" $nfiles files deleted (out of ".count($files).")";
       if ($nfails>0)  $infos['content'].=" $nfails could not be deleted.";
     }  else {  // removall
       $infos['content'] =" Cache directory exists for <tt>$adir</tt> (in tree <em>$treeName</em>), and no files are removed. ";
     }
     getJs\jsonReturn($infos);

 }   // cacheinit


// these variables are used by all the actionCalls below
//  $doOverwrite=extractRequestVar('overwrite',0);  // the remaining steps may or may not overwrite existing files

  $resumeStatus=[];
   if ($doResume==0) {   // initialize state variables (in global var) which is read by doGetDirFileList
       $arf=['treeName'=>$treeName,'dir'=>$adir,'action'=>$action,'resumeStatus'=>[]] ;
       $_SESSION['wsGallery_cacheDirStateVars']=$arf;
   } else {
       $resumeStatus= $_SESSION['wsGallery_cacheDirStateVars']['resumeStatus'];
   }

// Note: all of these actionCalls make take use several timeout/resume calls

// First actionCall: create description, filelists, and button lists (one button per file -- click it to view the file!)

 if ($action=='filelist' ){

    $priorDescs=[];
    if (!array_key_exists('priorDescs',$resumeStatus)) {   // initialize state variables (in global var) which is read by doGetDirFileList
      if ($retainDesc==1)  {  // get current file desc
         $tempStuff=get_fileListCache('~'.$adir,$treeName,2) ;
          if ($tempStuff['status']=='ok') {
            foreach ($tempStuff['fileList'] as $is=>$vv1) {
               $adesc=$vv1['desc']; $aName=$vv1['relSelFile'];
               $priorDescs[$aName]=$adesc;
            }       // foreach
        }  //  tempStuff, ok (could be not okay if removed existin files occurred
      }       //retainDesc
      $resumeStatus['priorDescs']=$priorDescs; // note use of [] if retaindDesc!=1
    }  else {      // get from resumeStatus
       $priorDescs=$resumeStatus['priorDescs'];
    }

    $stuff=doGetDirFileList(0,0,$treeName,$adir,1,$timeAllowed)  ;  // // create button lists... (start with text, and then do thumbnails)

    if ($stuff['status']=='error') getJs\jsonReturnError($stuff['content'],"desc :  $adir  in $treeName ");

    if ($stuff['doResume']==1) { // not done, tell client to  show current status, and then ask to resume
        $infos['content']=$stuff['content'];
        $infos['doResume']=1;     // note: $_SESSION['wsGallery_cacheDirStateVars'] contains state data (For resuming on next call to this function)
       return $infos;
    }

    $infos['doResume']=0;
    $_SESSION['wsGallery_cacheDirStateVars']=[] ; // no longer needed, so clear space
    $fileList0=$stuff['fileList'];
    $cacheDir=$fileList0['pathSelectorInfo']['cacheDir'];
    $nonEmpty=0;

    if ($cacheDir!='' &&  count($priorDescs)>0)   {  // add prior descriptors back in (so long as cachedir is still extant!
         if ($cacheDir!='')  {  // should always be true
           $lookups=$fileList0['relSelLookup'] ;
           foreach ($priorDescs as $cfile=>$cdesc) {
             if (!array_key_exists($cfile,$lookups)) continue ; // maybe file was deleted?
             $ith=$lookups[$cfile];
             $fileList0['fileList'][$ith]['desc']=$cdesc ;
             if (trim($cdesc)!='') $nonEmpty++ ;
           }

           $fileCache=$cacheDir.'/_fileList.json' ;
           $goof=json_encode($fileList0, JSON_UNESCAPED_UNICODE);
           $nsave=file_put_contents($fileCache,$goof);     // _filelist.json -- won't happen if nocache  set above (doDirCachePhp)
        }
    }

    $mm=$stuff['content'];
    $infos['content']="fileLists (with $nonEmpty non-empty descriptions retained) created. $mm (for <tt>$adir</tt>)";

    return $infos;
  }       //end of  desc  ----------------------


// create  thumbnails actionCalls (3 different ones)  -----------------
 if ($action=='thm40' ||  $action=='thm66'  ||  $action=='thm90') {          // creates menu that will be filled in in future steps

   if ($doResume==1)  {   // a resume .. make sure it's not goofy
      $arf=$_SESSION['wsGallery_cacheDirStateVars'];
      if ($arf['treeName']==$treeName && $arf['dir']==$adir && $arf['action']==$action) {
        $resumeStatus=$arf['resumeStatus'];
      } else {
         getJs\jsonReturnError("Mismatch in $action resume ($adir,$treeName,$action)" ,$arf) ;
      }  // if no match, start from scratch (though will skip prior craeted stuff if overwritre=0
   }  else {    // first call
      $arf=['treeName'=>$treeName,'dir'=>$adir,'action'=>$action];
      $resumeStatus=[];
   }

  $c3x=substr($action,3);
  $thmSize=intval($c3x);

  if (!array_key_exists('img_files',$resumeStatus)) {
       $img_files =  glob($nowDir . '/' . $imageOnlyString, GLOB_BRACE);       // look for image files
      $resumeStatus['img_files']=$img_files;
      $nextToDo=0; $nToDo=count($img_files);
      $resumeStatus['nextToDo']=$nextToDo;
      $resumeStatus['nToDo']=$nToDo;
      $nThumbs=0;$nThumbsRetained=0;
      $resumeStatus['nThumbs']=0;
      $resumeStatus['nThumbsRetained']=0;
   } else {        // read file list and loop bouunds from resumestatus
     $img_files=$resumeStatus['img_files'];
     $nextToDo= $resumeStatus['nextToDo'] ;
     $nToDo= $resumeStatus['nToDo'] ;
     $nThumbsRetained= $resumeStatus['nThumbsRetained'] ;
     $nThumbs= $resumeStatus['nThumbs'] ;
   }

   $daFails=[];
   for ($ith1=$nextToDo;$ith1<$nToDo;$ith1++) {
     $aimg=$img_files[$ith1];
     $aimgName=pathInfo($aimg, PATHINFO_FILENAME);
     $aimgExt=pathInfo($aimg,  PATHINFO_EXTENSION );
     $aimgName2='thm'.$thmSize.'_'.$aimgName.'_'.$aimgExt.'.jpg';
     $saveToFile=$cacheDir.'/'.$aimgName2;
     if ($doOverwrite==0 && is_file($saveToFile))  {    // do not overwrite existing
         $nThumbsRetained++;
     }  else {
       $qq=imageResizerFile($aimg,$thmSize,$thmSize,65,$saveToFile,1) ;     // save a thumbnail as jpg. Note: this is never called if noCache
       if (is_array($qq) && array_key_exists('error',$qq) && $qq['error']==true) {
//       if ($qq===false ) {  // some kind of failure
//           $errorX = error_get_last();
//           $errorX['action']=$action;
           $errorX['action']=$action;
           $errorX['message']=$qq['message'];
           $daFails[$aimg]=$errorX;
        } else    {
           $nThumbs++;
        }
     }
     $ithDone=$ith1+1;
     $resumeStatus['nThumbsRetained']=$nThumbsRetained  ;
     $resumeStatus['nThumbs']=$nThumbs    ;
     $resumeStatus['nextToDo']=$ith1+1;

     $checkTime=time();
     if ($checkTime-$nowTime >= $timeAllowed) {
           $arf['resumeStatus']=$resumeStatus;
           $arf['doResume']=1;
           $_SESSION['wsGallery_cacheDirStateVars']=$arf;
           return ['status'=>'ok','action'=>$action,'doResume'=>1,'treeName'=>$treeName,'dir'=>$adir,'fails'=>$daFails,
             'content'=>" Created $action thumbnails: <em>$ithDone of $nToDo </em> ... <tt>$nThumbsRetained retained, $nThumbs created</tt> (in $adir of $treeName)",'doResume'=>1];
       }  // timeout

  }
   $infos['content']=$nThumbs." ($thmSize x $thmSize) thumbnails created (from images in $adir ).  ";
   if (count($daFails)==0) $daFails=false;
   $infos['fails']=$daFails;
   if ($doOverwrite==0) $infos['content'].=" $nThumbsRetained pre-existing thumbnails are retained.";
   $infos['doResume']=0;

   $_SESSION['wsGallery_cacheDirStateVars']=[] ; // no longer needed, so clear space

   return $infos;
}       // thm40 66 or 90  ..

// create snapshot actionCall  .....  ..................
 if ($action=='snap' ){
     $daFails=[];
    $docRoot=$_SERVER['CONTEXT_DOCUMENT_ROOT'];
    $docRoot = rtrim(str_replace('\\', '/', $docRoot), '/');
    $docRootLength=strlen($docRoot);
   if ($doResume==1)  {   // a resume .. make sure it's not goofy
      $arf=$_SESSION['wsGallery_cacheDirStateVars'];
      if ($arf['treeName']==$treeName && $arf['dir']==$adir && $arf['action']==$action) {
         $resumeStatus=$arf['resumeStatus'];
      } else {
         getJs\jsonReturnError("Mismatch in snap resume ($adir,$treeName,$action)" ,$arf) ;
      }  // if no match, start from scratch (though will skip prior craeted stuff if overwritre=0
   }  else {    // first call
       $arf=['treeName'=>$treeName,'dir'=>$adir,'action'=>$action];
       $resumeStatus=[];
   }

   if (!array_key_exists('img_files',$resumeStatus)) {
      $img_files =  glob($nowDir . '/' . $imageOnlyString, GLOB_BRACE);       // look for image files
      $resumeStatus['img_files']=$img_files;
      $nextToDo=0; $nToDo=count($img_files);
      $resumeStatus['nextToDo']=$nextToDo;
      $resumeStatus['nToDo']=$nToDo;
      $resumeStatus['nSnaps']=0;
      $resumeStatus['nSnapsRetained']=0;
      $resumeStatus['snapList']=[] ;
      $snapList=[];
      $nSnaps=0;$nSnapsRetained=0;
   } else {        // read file list and loop bouunds from resumestatus
      $img_files=$resumeStatus['img_files'];
      $nextToDo= $resumeStatus['nextToDo'] ;
      $nToDo= $resumeStatus['nToDo'] ;
      $nSnapsRetained= $resumeStatus['nSnapsRetained'] ;
      $nSnaps= $resumeStatus['nSnaps'] ;
      $snapList=$resumeStatus['snapList'] ;
   }

   for ($ith1=$nextToDo;$ith1<$nToDo;$ith1++) {
     $aimg=$img_files[$ith1];
     $aimgName=pathInfo($aimg, PATHINFO_FILENAME);
     $aimgExt=pathInfo($aimg,  PATHINFO_EXTENSION );
     $aimgFile=pathInfo($aimg,  PATHINFO_BASENAME);
     $aimgName2='snap_'.$aimgName.'_'.$aimgExt.'.jpg';
     $saveToFile=$cacheDir.'/'.$aimgName2;

     $pathToSnap=substr($saveToFile,$docRootLength);
     $pathToSnap='/'.ltrim($pathToSnap,'/');
     $snapImg='<img alt="Snapshot of '.$aimgFile.'" width="640" height="480" src="'.$pathToSnap.'"> ';
     $aa=[$snapImg,$pathToSnap,$aimgFile];
     $snapList[]=$aa;

     if ($doOverwrite==0 && is_file($saveToFile))  {    // do not overwrite existing
         $nSnapsRetained++;
         continue ;
     }
     $qq=imageResizerFile($aimg,640,480,60,$saveToFile,1) ;  // snapshots saved as jpeg .    Note: this is never called if noCache

      if (is_array($qq) && array_key_exists('error',$qq) && $qq['error']==true ) {
           $errorX['action']=$action;
           $errorX['message']=$qq['message'];
           $daFails[$aimg]=$errorX;
      } else    {
           $nSnaps++;
      }

     $ithDone=$ith1+1;
     $resumeStatus['nSnapsRetained']=$nSnapsRetained  ;
     $resumeStatus['nSnaps']=$nSnaps    ;
     $resumeStatus['nextToDo']=$ith1+1;
     $resumeStatus['snapList']=$snapList ;

     $checkTime=time();
     if ($checkTime-$nowTime >= $timeAllowed) {
           if (count($daFails)==0) $daFails=false;
           $arf['resumeStatus']=$resumeStatus;
           $arf['doResume']=1;
           $_SESSION['wsGallery_cacheDirStateVars']=$arf;
           return ['status'=>'ok','action'=>$action,'doResume'=>1,'treeName'=>$treeName,'dir'=>$adir,'fails'=>$daFails,
             'content'=>" Created snapShots : <em>$ithDone of $nToDo </em> ... <tt>$nSnapsRetained retained, $nSnaps created</tt> (in $adir of $treeName)",'doResume'=>1];
       }  // timeout

   }
   $infos['doResume']=0;
   $infos['content']=$nSnaps." (640 x 480) snapshots created (from images in $adir ).  ";
   $infos['snapList']=$snapList;
   if ($doOverwrite==0) $infos['content'].=" $nSnapsRetained pre-existing snapshots are retained.";

// special case: save to snapshots.json (in cachedir) -- as an associative array
   $snapListA=[];
   $allSnaps=[];
   foreach ($snapList as $jk=>$aa1) {
      $aaImg=$aa1[0];
      $aaSel=$aa1[1];
      $aaName=$aa1[2];
      $allSnaps[]=$aaName;
      $aa2=['img'=>$aaImg,'sel'=>$aaSel];
      $snapListA[$aaName]=$aa2;
    }
    $snapListA['.']=$allSnaps;
    $dSnaplist=json_encode($snapListA, JSON_UNESCAPED_UNICODE);

    $snapshotCacheFile=$cacheDir.'/_snapshots.json' ;
    file_put_contents($snapshotCacheFile,$dSnaplist);  // _snapshots.json

// clear space
   $_SESSION['wsGallery_cacheDirStateVars']=[] ; // no longer needed, so clear space
   if (count($daFails)==0) $daFails=false;
   $infos['fails']=$daFails;

   return $infos;
}      // snapshot


// create snapshot actionCall  .....  ..................
 if ($action=='summary' ){        // no resume capablity for summary

   $arfX=ws_GetDirectorySizeGlob($cacheDir,0);
   $infos['doResume']=0;
   $infos['summaryStats']=$arfX ;
   $infos['content']="Summary: $cacheDir contains: ".number_format($arfX[0])." bytes, in  ".$arfX[1]." files.";
   return $infos ;
}

// no more actionCalls defined.
getJs\jsonReturnError('doDirCachePhp: unknown action: '.$action);

}  // function


//====================
// Several get size of directory functions
//  Uses RecursiveDirectoryIterator.
// seems to best with midsized (100) files
// return [totsize,nfiles] -- across al subdirs if recurse=1, otherwise just path
function ws_GetDirectorySize($path,$recurse=0){
    $bytestotal = 0;
    $nfiles=0;
    $path = realpath($path);
    if($path!==false && $path!='' && file_exists($path)){
      if ($recurse==1) {
         foreach(new RecursiveIteratorIterator(new RecursiveDirectoryIterator($path, FilesystemIterator::SKIP_DOTS)) as $object){
              $bytestotal += $object->getSize();
              $nfiles++;
          }
      } else {
         $zdir= new DirectoryIterator($path);
         foreach($zdir as $afile ){
              if ($afile->isDot()) continue;
              $bytestotal += $afile->getSize();
              $nfiles++;
          }
      }
    }
    return [$bytestotal,$nfiles];
}

// Several get size of directory functions
//  Uses glob.     Seems to be best with small (30 files) dirs
// return [totsize,nfiles,nsubs] -- across al subdirs if recurse=1, otherwise just path
// recursive
function ws_GetDirectorySizeGlob($directory,$recurse=0){
    $size = 0; $nfiles=0; $nsubs=0;
    $files = glob($directory.'/*');
    foreach($files as $path){
        if (is_file($path)) {
            $size += filesize($path);
            $nfiles++;
        }
        if ($recurse==1) {
          if (is_dir($path)) {
             $t1 =  ws_GetDirectorySizeGlob($path,1);
             $nsubs++ ;
             $size+=$t1[0]; $nfiles+=$t1[1];$nsubs+=$t1[2];
          }
        }
    }
    return [$size,$nfiles,$nsubs];
} 


//=============
// files in a directory, first using system calls
// very good for very large directory structures. (100 x faster than the two above)
// returns [size,nfiles,code] : 0=unix sys calls, 1= win syscalls, 2= directory iterater, 3=just one file 
//
function ws_getTotalSizeSys($dir) {
    $dir = rtrim(str_replace('\\', '/', $dir), '/');

    if (is_dir($dir) === true) {
        $totalSize = 0;
        $nfiles=0;
        $os        = strtoupper(substr(PHP_OS, 0, 3));
        // If on a Unix Host (Linux, Mac OS)

        if ($os !== 'WIN') {
            $io = popen('/usr/bin/du -sb ' . $dir, 'r');
            if ($io !== false) {
                $totalSize = intval(fgets($io, 80));
                pclose($io);
            }
            $io2 = popen('/usr/bin/du  --inodes -s  ' . $dir, 'r');
            if ($io2 !== false) {
                $totalFiles = intval(fgets($io2, 80));
                pclose($io2);
            }
            return [$totalSize,$totalFiles,0];
        }       // not win

        // If on a Windows Host (WIN32, WINNT, Windows)
        if ($os === 'WIN' && extension_loaded('com_dotnet')) {
            $obj = new \COM('scripting.filesystemobject');
            if (is_object($obj)) {
                $ref       = $obj->getfolder($dir);
                $totalSize = $ref->size;
                $slug= $ref->Files ;
                $nfiles=$slug->count();
                $obj       = null;
                return [$totalSize,$nfiles,1];
            }
        }
        // If System calls did't work, use slower PHP 5
        $files = new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($dir));
        $nfiles=0;
        foreach ($files as $file) {
            $totalSize += $file->getSize();
            $nfiles++;
        }
        return [$totalSize,$nfiles,2];

    } else if (is_file($dir) === true) {  // just one file
        $fs=filesize($dir);
        return [$fs,1,3];

    }
}



//=========================
// find the cache directory for this path (uses tree information
// cache is stored under the wsGallery.php dire, NOT in the images directories.
// ie: if runing d:/www/gallery/wsGallery.php, the cacheDir  for "treeName" _default =
//   data/_default  subdirectory of  wsGallery.php
function doDirCachePhp_getCacheDir($adir,$useTreeName='') {

//  if ($useTreeName=='') $useTreeName=$_SESSION['wsGallery_currentTree']   ;   //DEPREACTED. Too much trouble

  $pp=returnSelector($adir,$useTreeName);   //  go get selector info
  if ($pp['error']!='')   getJs\jsonReturnError($pp['error'],$pp);

  $selUse=$pp['relSelDir'];  // still exists?
  $cacheDir=$pp['cacheDir'];

  if ($selUse=='' || $cacheDir=='') getJs\jsonReturnError("No such cachedir ($cacheDir) for with tree: $useTreeName",$pp);
  return $cacheDir  ;

}

// ====
// create control panel for doDirCache
// Note: dirCache ALWAYS recreates the varius .json files.... but not here (just get info from them)
function doDirCachePhp_makeMenu($adir,$treeName,$action,$isMulti,$adirV) {

   $currentDesc='';

   $noCache=$_SESSION['wsGallery_noCache'];
   if ($noCache==1) {
           $stuff='<div id="iDirCacheControl" class="cDirCacheControl">';
           $stuff.="Sorry, caching has been disabled. See wsGallery_readMe.txt for instructions on how to enable/disable caching";
           $stuff.='</div>';
           return $stuff;
   }

   $apathInfo=returnSelector( '~x'.$adir ,$treeName);
   if ($apathInfo['error']!='')   getJs\jsonReturnError('Problem in doDirCachePhp_makeMenu ',$apathInfo);

   if ($apathInfo['cacheDir']=='') {
           $stuff='<div id="iDirCacheControl" class="cDirCacheControl">';
           $stuff.="Sorry, no cache exists for this directory ('.$adir.'). Try updating the directory list for this tree.";
           $stuff.='</div>';
   }

   $stuff='<div id="iDirCacheControl" class="cDirCacheControl">';

   $stuff.='<input type="button" value="&#10068;" title="View help on directory initialization" help" onClick="doHelpVu(this)" topic="dirCache"  class="helpButton"  > ';

   if ($isMulti==0) {
      $stuff.='<span style="font-weight:700">Initializing: '.$adir.'</span> in tree <em>'.$treeName.'</em> ';
   } else {
      $stuff.='<span style="font-weight:700">Initializing: <input type="button" title="toggle view of a list of the directories to be initialized" value="'.count($adirV).'" onClick="$(\'#doDirCachePhp_makeMenu_multi\').toggle()"> ';
      $stuff.='</span> directories in tree <em>'.$treeName.'</em> ';
   }
   $stuff.='<span  style="border-bottom:1px dashed lightblue;font-style:oblique"> &hellip; to expedite wsGallery performance</span>.';
   $stuff.=' After selecting options ... ';
   $stuff.=' <button name="doDirCache_doButtons" id="iDoGoButton"  class="doGoButton"  title="Start the initialization" data-ismulti="'.$isMulti.'" treename="'.$treeName.'" dir="'.$adir.'" onClick="doDirCacheJs(this,0)">';   // Do it!
   $stuff.='<span   xstyle="font-size:110%;color:green">Go</button>      ';
   $stuff.='</div>';

   if ($isMulti==1) {
     $stuff.='<div id="doDirCachePhp_makeMenu_multi" class="cdoDirCachePhp_makeMenu_multi">';

     $nowTimeD=time();   $adirVct=count($adirV) ;
     $agoof='Directories to be initialized: <span class="cToBeInitStatus"  name="nToBeInitStatus" data-total="'.$adirVct.'"  title="# completed, in elapsed time" ';
     $agoof.=' data-done="0" data-start="'.$nowTimeD.'" >0 of '.$adirVct.' : eps=0:00:00</span> ' ;
     $stuff.=$agoof ;

     $goof1=[];
     foreach ($adirV as $ith=>$adirC) {
        if ($ith==0) {
           $goof1[]='<span data-ict="0" class="cToBeInit_now" title="Hit Go to start: initialize this directory first!">'.$adirC.'</span> ';
        } else {
             $goof1[]='<span  data-ict="'.$ith.'" class="cToBeInit_later" title="To be initialized">'.trim($adirC).' </span> ';
       }
     }

     $agoof2=implode(' ',$goof1);
     $stuff.='<div style="margin:8px 3em 6px 4em"  name="nToBeInitList">'.$agoof2.'</div>';
     $stuff.='</div>';
   }                              // ismulti  ==1

   $stuff.='<div class="cdoDirCache_startOptions" id="doDirCache_startOptions">';

  $stuff.='&nbsp;&boxv;&nbsp;<input type="checkbox" value="1" id="doDirCache_clearAll"  name="doDirCache_doButtons"  >  ';
   $stuff.='<label for="doDirCache_clearAll" ';
   $stuff.=' title="If checked, all existing readme.txt, thumbnails and snapshots are deleted from the cache directory. &#010;This is useful if you need to remove orphans (say, because images were deleted from the chosen image directory),&#010; This does NOT change files in the chosen images directory! ">';
   $stuff.='Remove existing files? </label>';

   $stuff.='&nbsp;&boxv;&nbsp;<input type="checkbox" value="1" id="doDirCache_noOverwrite" name="doDirCache_doButtons"   >  ';
   $stuff.='<label for="doDirCache_noOverwrite" title="If not checked, existing thumbnails and snapshots will be retained (this can speed up processing).&#010; If remove existing files is selected, this is ignored. ">';
   $stuff.='Overwrite existing files? </label>';

   $stuff.='&nbsp;&boxv;&nbsp;<input type="checkbox" value="1" checked id="doDirCache_retainFileDescs"  name="doDirCache_doButtons"  >  ';
   $stuff.='<label for="doDirCache_retainFileDescs" title="If checked, existing file descriptions (for files in this directory) will be retained. If not checked, descriptions will be removed. ">';
   $stuff.='Retain file descriptions? </label>';

   $stuff.='</div>';

   $stuff.='<div class="cDirCacheControl_stop">';
   $stuff.='  <input id="iDirCacheControl_stop" type="checkbox" value="1" title="stop initialzation of "'.$adir .'"  >';
   $stuff.=  '<label  title="stop initialzation of "'.$adir .'"   id="iDirCacheControl_stopLabel" for="iDirCacheControl_stop"> Stop processing </label>';
   $stuff.=  '  <span id="iDirCacheControlErr" class="cDirCacheControlErr"><em>Error messages ...</em></span>   ';
   $stuff.='</div>';

   $stuff.='<div id="iCustomEditBox" class="cCustomEditBox"> ... </div>';


$s3=<<<EOD3
<table cellpadding="5" width="92%" rules="rows" id="iDirCacheControlTable" class="cDirCacheControlTable">

<tr  width="99%">
    <td width="20%"><div class="cDirCacheControlTableCol1">
      <input type="checkbox" value="1" title="This step (create cacheDir) can NOT be skipped" checked  disabled id="chkDirCacheControlTable_cacheDir">
      cache directory creation</div></td>
    <td width="75%"><div class="cDirCacheControlTableCol2" id="iDirCacheControlTable_cacheInit"> ... </div> </td></tr>

<tr> <td><div class="cDirCacheControlTableCol1">
    <input type="checkbox" value="1" title="This step (create fileLists and buttons) can NOT be skipped" checked disabled id="chkDirCacheControlTable_desc">
    fileList  &amp; button creation</div></td>
    <td> <div class="cDirCacheControlTableCol2"  id="iDirCacheControlTable_desc"> ... </div> </td></tr>

<tr>
    <td><div class="cDirCacheControlTableCol1">
      <input type="checkbox" value="1" title="Uncheck to skip this step (40x40 thumbnail)" checked  name="chkDirCacheControlTable_steps"  id="chkDirCacheControlTable_thm40">
    THM40 (40x40) thumbnails creation</div></td>
     <td><div class="cDirCacheControlTableCol2" id="iDirCacheControlTable_thm40"> ... </div> </td></tr>

<tr>
    <td> <div class="cDirCacheControlTableCol1">
    <input type="checkbox" value="1" title="Uncheck to skip this step (66x66 thumbnail)" checked name="chkDirCacheControlTable_steps"  id="chkDirCacheControlTable_thm66">
    THM66 (66x66) thumbnails creation</div></td>
    <td> <div class="cDirCacheControlTableCol2"  id="iDirCacheControlTable_thm66"> ... </div> </td></tr>

<tr>
   <td>  <div class="cDirCacheControlTableCol1">
    <input type="checkbox" value="1" title="Uncheck to skip this step (90x90 thumbnail)" checked name="chkDirCacheControlTable_steps"  id="chkDirCacheControlTable_thm90">
    THM90 (90x90) thumbnails creation</div> </td>
    <td> <div  class="cDirCacheControlTableCol2"  id="iDirCacheControlTable_thm90"> ... </div> </td></tr>

<tr> <td><div class="cDirCacheControlTableCol1">
    <input type="checkbox" value="1" title="Uncheck to skip this step (snapShot)" checked name="chkDirCacheControlTable_steps"  id="chkDirCacheControlTable_snap">
    SNAP (640x480) snapshots creation</div></td>
    <td> <div class="cDirCacheControlTableCol2"  id="iDirCacheControlTable_snap"> ... </div> </td></tr>

<tr> <td><div class="cDirCacheControlTableCol1">
    <input type="checkbox" value="1" title="Uncheck to skip this step (summary)" checked name="chkDirCacheControlTable_steps"  id="chkDirCacheControlTable_summary">
    Summary:</div></td>
    <td> <div class="cDirCacheControlTableCol2"  id="iDirCacheControlTable_summary"> ... </div> </td></tr>

EOD3;

  $stuff.=$s3;
 $stuff.='</div>';
 return $stuff ;
}
?>