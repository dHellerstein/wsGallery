
The wsGallery/galleries subdirectories is where one specifies 'galleries'.
A 'gallery' is a unique set of trees and their directory specifications.
These 'trees'  point to images and files elsewhere (in other directories).

Each gallery is seperate. A gallery can refer to images referred to by other galleries.
Thus: a gallery can contain the same 'tree' specifications as some other gallery. Or not!

To specify a new gallery

 a) Create a directory under wsGallery/galleries with the gallery's (case sensitive name).
    For example:  wsGallery/galleries/familyPhotos

 b) Create a wsGallery_treeList.php file in this new directory.
    This wsGallery_treeList.php specifies what "trees" are to be contained in this gallery.
    And where these trees point to (the directories that actually contain the images and files to be viewed)
 
 c) You will then have to 'initialize' the trees. 
    See wsGallery_readMe.txt for details on how to do this.


