Jan 2022

Icons used by wsGallery.
  These are used as thumbnails for file types that are not images (hence it is not so easy to extract a thumbnail).

The spinners directory contains "spinner" icons. They can be added to.
  The spinners.json file is used to send a list of these to the client, where they are used to choose a spinner.
  If deleted, it will be recreated the next time a client ask for this list (when wsGallery is started).

  If images are added to spinners, it will be recreated.

Attribution:

  Many icons are from https://icons8.com/icons/set/ppt
  Spinners are from https://icon-library.com/icon/spinner-icon-gif-2.html or    https://loading.io/icon/
