Some photos of Cape Cod, MA. Circa 2017 and 2021
