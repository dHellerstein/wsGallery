<?php
session_start() ;
ob_start();

// May 2022
//   wsGallery_simple -- a simple viewer of  files and  images in a wsGallery installation
//  Although this works reasonably well as a  simple standalone viewer, it also serves to illustrate how
//  wsGallery_get.php  and wsGallery_get.js can be used.
//  You can, but do not have to, modify the user changable parameters
// Hint: the doAdjustSize function may be useful in other applications.
//
// May 2022: will now read ?xx of the url, and use parameters if they are specified (overrides user configured defaults)

// User configurable parameters start about 20 lines below here.
$treeSpecs=[];
$rootdir=$_SERVER['DOCUMENT_ROOT'] ;
$nowtime=time();
$curDir=getcwd();
$webRoot=dirname($_SERVER['PHP_SELF']);

require_once($curDir.'/libs/php/wsurvey.getJson.php');
require_once($curDir.'/src/wsGalleryLibUtils.php');


?>
<!DOCTYPE HTML>
<html><head><title>wsGallery: example of wsGallery_get</title>
<meta charset="utf-8">

<script type="text/javascript" src="libs/publicLib/jquery-3.6.0.min.js"></script>
<script type="text/javascript" src="libs/js/wsurvey.utils1.min.js">  </script>
<script type="text/javascript" src="libs/js/wsurvey.getJson.min.js"></script>
<script type="text/javascript" src="src/wsGallery_get.js">  </script>


<script type="text/javascript" >

var useGallery='';   // these can be set in the user changetable parameters section
var useTree=''  ;
var useDir=''
var useFile='';

// ---------begin   user changeable parameters    -----------------------
// Note: parameter values specified in the url (the ?xxx=yyy&...) will OVERRIDE parameters specified here.

// the id of  wsGallery viewer container -- its where the menus (gallery/tree/dir/file) and file viewers are displayed
var wsGalleryId='simple_viewer';
//var wsGalleryId2='simple_viewer2';  // uncomment to have two viewers.

//  The name of this wsGalleryViewer -- it use to stored information in $(document).data('wsGallery')
//     Or, set to '1'  of '0' to use $(document). If this is done: you can have only ONE wsGallery viewer per page.
//     It is generally best to use a dedicated dom element as the wsGalleryViewer (rather than using the entire document)

var wsgName_use='viewer1';
//var wsgName_use2='viewer2';    // uncomment to have two viewers

//  April 2022 note: the "two viewer" mode works, but the 2nd viewer's "resize to fit" options is a bit buggy.
//
// ::: default gallery/tree/dir
//  if these are set, the corresponding menu will NOT be displayed -- the value of this "preset" is used.
//  HOWEVER: if no such (case-sensitive) item (gallery, tree, or dir) exists, the menu WILL be displayed.
// IOW: This will 'auto-load" a gallery, tree, or directory.
//
//   This is quirky if you do not specify a "higher level" value
//   Example: if you specify useTree or useDir, but do not specify useGallery, the behaviour can be odd

var useGallery='';   // example: useGallery='main';
var useTree=''  ;    // example: useTree='photos' ;
var useDir=''        // example: useDir='july2020' ;
var useFile='';      // example: useFile="sunset1.jpg';

// close a list (galleries,trees,dirs, or files). 0 do not, 1 do close and show a descirptive line of the auto-selects, 2 do close and do NOT show a descriptive line
// for example: if useTree is specified and successful, autoCloseList controls whether or not the list of trees is hiddend
var autoCloseList=2;

//  ::: alternative directory descriptions (not specific to a gallery)

var altDirDescs={}
// example: 'july2020':'July 2020 beach vacation','birthday87':'Grandmas birthday party '};

//  ::: alternative file descriptions (not specific to a gallery)

var altFileDescs={};
// example : {'dog1.MOV':'Fido catching a frisbee','20150722_203558.jpg':'the lighthouse at evening'}

//  :::  height and width of inline elements for non-image files (such as pdf or .mov)

var fileViewerWidth=640 ;
var fileViewerHeight=480 ;

// size of the wsGallery viewer (after adjusting viewer size). 100% means 'use all available space in the browser window'
var targetHeight='100%'   ;

// what kind of thumbnail to display: values can be none,small (40x40) ,medium (65x65) , or large (90x90)
var showThumbnail='small';

// show the description (at the top of the file viewer). 0=no, 1=yes.
// Or , if > 1 : show, but clip length to this many chacaters (and remove html)
var showDesc=1   ;

// show the "fullscreen"   viewer button. 0=no, 1=yes
var showFull=1;

// show the    "external" viewer button. 0=no, 1=yes
var showExternal=1;

// text to display at top of window
var  headerLine="A simple wsGallery viewer";

// 0/1 : display a "reopen all lists (gallery/tree/dir)" button. 0=do Not  display
var reopenAllButton=0;

// 0/1/2 : display next/prior arrows in the dir list. 0 = display in file viewer, 1=display in file list, 2= display in both
var nextPriorInFiles=0 ;

// header at top of "list of files in this dir" column
var fileListHeader='' ;   // '', or 0, means "use default

var autoAdjustSize=0  ;  // if 1, and if useFile specified and is successful -- auto click the auto-adjust-size button

// --------- end of user changeable parameter   -----------------------

// === check for parameters specified in the url. These override user configurable values that are specified above
let arg1=queryString() ;

useGallery= (arg1.hasOwnProperty('useGallery')) ? arg1['useGallery'] : jQuery.trim(useGallery) ;
useTree= (arg1.hasOwnProperty('useTree')) ? arg1['useTree'] : jQuery.trim(useTree) ;
useDir= (arg1.hasOwnProperty('useDir')) ? arg1['useDir'] : jQuery.trim(useDir) ;
useFile= (arg1.hasOwnProperty('useFile')) ? arg1['useFile'] : jQuery.trim(useFile) ;

autoCloseList= (arg1.hasOwnProperty('autoCloseList')) ? arg1['autoCloseList'] : jQuery.trim(autoCloseList) ;
reopenAllButton= (arg1.hasOwnProperty('reopenAllButton')) ? arg1['reopenAllButton'] : jQuery.trim(reopenAllButton) ;
autoAdjustSize=(arg1.hasOwnProperty('autoAdjustSize')) ? arg1['autoAdjustSize'] : jQuery.trim(autoAdjustSize) ;

showThumbnail= (arg1.hasOwnProperty('showThumbnail')) ? arg1['showThumbnail'] : jQuery.trim(showThumbnail) ;
showDesc= (arg1.hasOwnProperty('showDesc')) ? arg1['showDesc'] : jQuery.trim(showDesc) ;
showFull= (arg1.hasOwnProperty('showFull')) ? arg1['showFull'] : jQuery.trim(showFull) ;
showExternal= (arg1.hasOwnProperty('showExternal')) ? arg1['showExternal'] : jQuery.trim(showExternal) ;

headerLine= (arg1.hasOwnProperty('headerLine')) ? arg1['headerLine'] : jQuery.trim(headerLine) ;
fileListHeader= (arg1.hasOwnProperty('fileListHeader')) ? arg1['fileListHeader'] : jQuery.trim(fileListHeader) ;

 window.onload=init;  // intialize on load .. uses the global variables set above


// --------------------
// intialize several event handlers, etc
//Note that wsGallery_get.css is loaded by .init()
     
function init() {

   wsurvey.getJson.setErrFunc('jsonErrorShow' );   // error reporting function for getJson. Hopefully is never needed!

// Initialize: for the wsgName_use   "wsGallery viewer" specified in the   wsGalleryId html container
//    create a wsgName_use entry in the wsGallery data storage area (that is specific to this container)
//    and assign some event halders to  the "wsgName_use", and specify the wsgallery callback,


// create a `wsGallery viewer`  -- a  html container where wsGallery menus are written to.
   let arf=wsGallery.createSimpleViewer(wsGalleryId,targetHeight);      // the 2 arguments are set above
   $('#simple_viewer_outer').html(arf);          // write to browser window

// create a 2nd viewer?
    if (typeof(wsgName_use2)!=='undefined' && typeof(wsGalleryId2)!=='undefined') {
      let arf2=wsGallery.createSimpleViewer(wsGalleryId2,targetHeight);      // the 2 arguments are set above
      $('#simple_viewer_outer2').html(arf2);          // write to browser window
    } else {                                // hide the viewer2 outer cont ainer
      $('#simple_viewer_outer2_b').hide();
    }

// Show some info on the optional presets.
// note that the fileList viewer is never hidden, even if useFile is specified (regardless of autoCloseList=1)

   if (useTree!='' || useDir!=='' || useGallery!=='' || useFile!=='' ) {
      if (autoCloseList!=2) {
          amess="Using presets: ";
         if (useGallery!=='') {
           amess+='<span  title="The preset gallery "  class="usePresetsC"    >Gallery: <tt>'+useGallery+'</tt></span>';
         }
         if (useTree!=='') {
            amess+='<span title="The preset tree" class="usePresetsC" >Tree: <tt>'+useTree+'</tt></span>';
         }
         if (useDir!=='') {
          amess+='<span title="The preset dir"  class="usePresetsC"  >Dir: <tt>'+useDir+'</tt></span>';
         }
         if (useFile!=='') {
         amess+='<span title="The preset file "  class="usePresetsC"     >File: <tt>'+useFile+'</tt></span>';
         }
         $('#simple_usePresets').html(amess).show();
      }
    }


// note: you can specify other wsGallery viewers by calling .init with unique wsgName_use AND wsGalleryID
// You can use the same, or different, wsgOpts options

// parameters  for this wsgName_use "wsGallery viewer". For unspecified paramters: defaults will be used.
// The ONLY required parameter is 'callback'
  let wsgOpts={'callback':'displayWsGalleryStuff',
              'altFileDescs':altFileDescs,'altDirDescs':altDirDescs,
             'fileViewHeight':fileViewerHeight,'fileViewWidth':fileViewerWidth,
             'showFull':showFull,'showExternal':showExternal,'showDesc':showDesc,'showThumbnail':showThumbnail} ;

// give dom 0.1 seconds to settle down
   window.setTimeout(function() {

// init will load css file, and assign event handlers
     wsGallery.init(wsgName_use,'#'+wsGalleryId,wsgOpts);

     if (typeof(wsgName_use2)!=='undefined' && typeof(wsGalleryId2)!=='undefined') {  // if the 2nd viewer is desired...
        wsGallery.init(wsgName_use2,'#'+wsGalleryId2,wsgOpts);
    }

// Ready to display !   Start  by displaying a list of galleries

    wsGallery.getGalleryList(wsgName_use);    // --- and start the display!
    if (typeof(wsgName_use2)!=='undefined' && typeof(wsGalleryId2)!=='undefined') {
        wsGallery.getGalleryList(wsgName_use2);    // --- and start the display!
    }


   if (reopenAllButton!='1') $('#ireopenAllbutton').hide() ;
   $('#iheaderLine').html(headerLine);


// Examples of other actions -- read & display a specific gallery, tree, directory ...
// These examples specify an alternative callback in the args by using 'callback':showBasic
// They will display raw data (the 'list' variable returned) in a notes section at window bottom
//    wsGallery.getGalleryList(wsgName_use, 'showBasic' );    // --- and start the display!
//    wsGallery.getTreeList({'gallery':'sharks','callback':'showBasic'},wsgName_use);    // --- and start the display!
//    wsGallery.getDirList({'gallery':'main','tree':'someshots','callback':'showBasic'},wsgName_use);    // --- and start the display!
//   oof=['desc','uriSel','thmSmall','snapshot','link','linkHandler'];
//       wsGallery.getFileList({'gallery':'main','tree':'someshots','dir':'sue3','toget':oof,'callback':'showBasic'},wsgName_use);    // --- and start the display!
//   wsGallery.viewAFile({'nth':'13','gallery':'main','tree':'someshots','dir':'sue3','callback':'showBasic'},wsgName_use);    // --- and start the display!

// adjust size of main elements (have to wait a bit more for dom to settle down)
    window.setTimeout(function() {
      doAdjustSize(0,{'parent':'*','target':'#simple_viewer [name="simpleTable"]','padding':"2.0em",});
     },200);
   },100) ;   // timeout after writing wsGallery viewer.

}


//=====================
// call back from wsGallery. "viewer" functions
// The wsGallery. viwer functions call this callback with information; such as a list of directory buttons
// ares is a javascript object:
// proprieties in ares:
//    wsgName:  identify the wsGallery container. Or '1' if document is used
//    what (with posssible values galleries,trees,dirs,files,viewFile
//    header: a short message  describing what was done. Suitable for posting in "column header"
//    content : the content to be written to the dom. Such as a list of buttons (say, select a dir); or an html element for inline display
//    where  : a string used to identify "where" this button was called from (a data-wsGallery attribute of <ul> containing it)
//    list: object with properties whose values are gallery names, directory names, or whatever
//          each of these properties is also an object, whos properties are  information fields

function displayWsGalleryStuff(ares) {
   if (arguments.length<2) ido='';

   if (typeof(ares['errors'])!='undefined'  && ares['errors'].length>0) {   // errors?
       let oo='<ul><li>'+ares['errors'].join('<li>')+'</ul>';
       $('#wsGallery_notes').append('<hr>'+oo);
   }

   let ewsgId=ares['wsgJquery'];
   let wsgName=ares['wsgName'];

   let whatDone=ares['what'];
   let aheader=ares['header'];
   let acontent=ares['content'];
   let awhere=ares['where'];
   let alist=ares['list'];

   if (whatDone=='galleries')   {
      let hhsay='';
       hhsay='<span>';
       hhsay+='<input type="button"  id="reheightButton1" value="&#8634;"  title="Adjust menus to fit screen " > ';

      hhsay+='</span>';

      let eheader=ewsgId.find('[name="content_galleries_header"]');
      let econtent=ewsgId.find('[name="content_galleries"]');    // name under id  -- so ther can be multiple wsGalleryViewers

      econtent.html(acontent).show();
      eheader.html(hhsay).show();
      clearAreas({'trees':'','dirs':'','files':'','viewFile':''});
      checkAutoOpen(awhere,useGallery,'gallery');
   
     window.setTimeout(function() {   // wait for dom to settle down, and then assign click handler
        let ddata={'padding':"1.0em",'minheight':"3em",
                 'target':'~[name="content_dirs"]','parent':'~[name="simpleTable"]',
                 'others':'~[name="content_files"],~[name="content_viewFile"]' };

         $("#reheightButton1").click(ddata,doAdjustSizeButton);     // the size button in the "gallery" list
     },120);

      return 1;
   }
   if (whatDone=='trees')   {
      let eheader=ewsgId.find('[name="content_trees_header"]');
      let econtent=ewsgId.find('[name="content_trees"]');    // name under id  -- so ther can be multiple wsGalleryViewers

      eheader.html(aheader).show();
      econtent.html(acontent).show();
      clearAreas({'dirs':'','files':'','viewFile':''});
      checkAutoOpen(awhere,useTree,'tree');
      return 1;
   }

   if (whatDone=='dirs')   {
      let vsay='<input class="selfButton" type="button" value="x" title="close: list of dirs" onClick="toggleListView(this)" data-which="dirs" data-wsgName="'+wsgName+'">';
      let eheader=ewsgId.find('[name="content_dirs_header"]');
      let econtent=ewsgId.find('[name="content_dirs"]');    // name under id  -- so ther can be multiple wsGalleryViewers

      eheader.html(vsay+aheader).show();
      econtent.html(acontent).show();
      clearAreas({'files':'<em>file list ...</em>','viewFile':''});
      checkAutoOpen(awhere,useDir,'dir');

 


      return 1;
   }
   if (whatDone=='files')   {
      let vsay='<input class="selfButton" type="button" value="x" title="close: list of files" onClick="toggleListView(this)" data-which="files" data-wsgName="'+wsgName+'">';
      let eheader=ewsgId.find('[name="content_files_header"]');
      let econtent=ewsgId.find('[name="content_files"]');    // name under id  -- so ther can be multiple wsGalleryViewers

      eheader.html(vsay+aheader).show();
      econtent.html(acontent).show();
      clearAreas({'viewFile':'<em>view a file ...</em>'});
      checkAutoOpen(awhere,useFile,'file');


      window.setTimeout(function() {
        let af=jQuery.trim(fileListHeader);
        if (af!='' && af!='0') {
          let ehh=$('[name="fileListHeaderSay"]').html(af);
        }
        if (nextPriorInFiles==0) {      // 0= do NOT display the prior and next image buttons (in the file list)
          let ehh=$('[name="fileListHeaderSayButtons"]');
          ehh.hide();   //  fileListHeader
        }
      },200);
      return 1;
   }
   if (whatDone=='viewFile')   {

      let eheader=ewsgId.find('[name="content_viewFile_header"]');
      let econtent=ewsgId.find('[name="content_viewFile"]');    // name under id  -- so ther can be multiple wsGalleryViewers
      vsay='<input type="button"  id="reheightButton2"  value="&#8634;"  title="Adjust menus to fit screen" > ';
      if (nextPriorInFiles!=1) {   // if 1, don't display (since they are in the dirlist)
        vsay+='<input class="wsGallery_actionButton" type="button" draggable="false" style="font-size:80%;color:brown" value="&larr;" title="View prior image" onclick="wsGallery.viewPriorImage(this,-1)">';
        vsay+='<input class="wsGallery_actionButton" type="button" draggable="false" style="font-size:80%;color:brown" value="&rarr;" title="View next image" onclick="wsGallery.viewPriorImage(this,1)">';
      }
      eheader.html(vsay+aheader).show();
      econtent.html(acontent).show();
      window.setTimeout(function() {
         let ddata={'padding':"1.0em",'minheight':"3em",
                 'target':'~[name="content_dirs"]','parent':'~[name="simpleTable"]',
                 'others':'~[name="content_files"],~[name="content_viewFile"]' };
          $("#reheightButton2").click(ddata,doAdjustSizeButton);

          if (autoAdjustSize==1) {
             window.setTimeout(function() {
                  $("#reheightButton2").trigger('click');
             },50) ;
          }
      },200);

      return 1;
   }

   alert('Unknown action: '+whatDone);

   return 0;

// ==== internal function: check the "useXXX" auto-open parameters
// special case: amenu=file, check either 'value' or 'data-nth'

   function checkAutoOpen(bwhere,bwhat,amenu) {  // uses autoCloseList global
        let astat;
        if (amenu=='file' && !isNaN(bwhat)) {
             astat=wsGallery.click(bwhere,bwhat,'click','data-nth');
        }  else {
            astat=wsGallery.click(bwhere,bwhat);
        }
        if (astat!==true ) return 0 ;  // no auto open, so done
        if (autoCloseList==0) return 1 ;  // no autoclose, so done

        if (amenu=='gallery')  {
               if (autoCloseList!=2) ewsgId.find('[name="content_galleries"]').hide()  ;
               if (autoCloseList==2) ewsgId.find('[name="content_galleries_outer"]').hide()  ;  // no autoclose, so done

        }
        if (amenu=='tree') {
               if (autoCloseList!=2) ewsgId.find('[name="content_trees"]').hide()  ;
               if (autoCloseList==2) ewsgId.find('[name="content_trees_outer"]').hide()  ;  // no autoclose, so done
        }

        if (amenu=='dir') {
               if (autoCloseList!=2) {
                 ewsgId.find('[name="content_dir"]').hide()  ;
                 ewsgId.find('[name="content_dir_header"]').hide()  ;
              }
               if (autoCloseList==2) {
                  toggleListView(this,'dirs','viewer1');
               }
        }

        if (amenu=='file'){
                 ewsgId.find('[name="content_file"]').hide()  ;
                 ewsgId.find('[name="content_file_header"]').hide()  ;
        }
        return 1;
   }        // checkautoopen

// ==== internal function: clear  "lower on the hierarchy" menu areas .. optionally place text in a header area

  function clearAreas(clist) {         // internal function  to clear menu and viewer container
    for (let ado in clist) {
        let aval=clist[ado];
        if (ado=='galleries') {
            ewsgId.find('[name="content_galleries"]').html('') ;
            ewsgId.find('[name="content_galleries_header"]').html(aval) ;
        }
        if (ado=='trees') {
            ewsgId.find('[name="content_trees"]').html('') ;
            ewsgId.find('[name="content_trees_header"]').html(aval) ;
        }
        if (ado=='dirs') {
            ewsgId.find('[name="content_dirs"]').html('') ;
            ewsgId.find('[name="content_dirs_header"]').html(aval) ;
        }
        if (ado=='files') {
            ewsgId.find('[name="content_files"]').html('') ;
            ewsgId.find('[name="content_files_header"]').html(aval) ;
        }
        if (ado=='viewFile') {
            ewsgId.find('[name="content_viewFile"]').html('') ;
            let aa='';
            ewsgId.find('[name="content_viewFile_header"]').html(aa+' '+aval) ;
        }
       return 1;
     }
   }  // clearareas

}      // end of displayWsGalleryStuff



//=============
// adjust height of "target" container so that it fits inside of a "parent" container.
// "fits within" means that scroll bars are NOT needed on the parent -- although they may be added to
// the target.   It uses wsurvey.fitToParent()
//  doAdjustSizeButton calls this
//
// This is called either as onClick event handler (1 argument), or directly (2 argments)
//   1 argument: athis should be the evt of the button (or other element) which calls
//               doAdjustSize as an event handler.
//          Options can be specfified in by a .click() event handler, or in data- attributes
//   2 arguments:
//        athis is optional: if specified it MUST be a jQuery object (pointing to a dom object)
//                           athis is only used if a "special selector" is used (defined below)
//        opts is an object with options as properties.
//
//  The options. Note that if specified in an attribute, use 'data-option="xxx" (i.e.; data-target="#bigOne")
//    target : the element whose height is to be adjusted
///   parent : the element that contains target -- the target height is adjusted so as to "fit" within the parent
//   padding:  pixels to pad (between bottom of target and bottom of parent)
//              Or, you can specify as nnEm or nn% (% is percent of parent height)
//  minheight : minimum height of target pixels (or em or %)
//             negative values means the target can extend below the parent (so a parent  will need scroll bars).
//   other: a csv of jquery selectors. If specified, these will be set to the height determined for "target"
//
// Hine: See wsurvey.utils1.doc for a description of "relative selectors" that can be sued in target,parent, and other


function doAdjustSize(athis,opts0) {
   var eTarget,eParent,aPadding='0.5em',aMinheight='2em', aTarget,aParent,aOthers='';
   var optsDef={'padding':'0.5em','minheight':'2em','target':'-1','parent':'-2','others':''};
   var opts={};

   var ethis=false;

   if (arguments.length>1)   {                  // 2 arg -- opts provided in a direct call
      if (typeof(opts0)!='object') opts0={};   // must be an object
      if (opts0===null) opts0={};
      for (let aopt in optsDef) {
        opts[aopt]= (opts0.hasOwnProperty(aopt)) ? opts0[aopt] : optsDef[aopt] ;
      }
      if (athis instanceof jQuery) ethis=athis;   // can be used to resolve -sel or ~sel specifications

  } else {                                         // 1 arg --  event handler call

     ethis=wsurvey.argJquery(athis);
     if (ethis.length==0) {
        alert('doAdjustSize: arg 1 does not resolve to a jQuery object ');
        return 0;
     }
     let data0={};
     if (typeof(athis.data)!=='undefined') data0=athis.data;
     if (data0===null) data0={};
     for (let aopt in optsDef) {      // search for attributes
        let anAtt='data-'+aopt;
        let anVal=ethis.wsurvey_attrCi(anAtt,false);
        if (anVal===false) {        // no such data- atrtibute
             opts[aopt] = (data0.hasOwnProperty(aopt)) ? data0[aopt] : optsDef[aopt]; // use .data if available
        } else {
            opts[aopt] = anVal ;      // attribute in "button" takes precedence
        }
      }
   }

   let stuff=wsurvey.fitToParent(ethis,opts);  //  error,parentHeight,targetHeight,newTargetHeight
   if (stuff['error']!==false) {
       alert('doAdjustSize: '+stuff['error']);
       return false;
   }

// are there "others"
   if (opts['others']!='' ) {
      let newHeight=stuff['newTargetHeight'];
      let vOthers=opts['others'].split(',');
      for (let iv=0;iv<vOthers.length;iv++) {
          let avOther=vOthers[iv];
          let eTarget2=wsurvey.fitToParent_find(ethis,avOther,'other_'+iv)
          if (eTarget2[0]!=false  ) {
              eTarget2[0].height(newHeight);
   //           console.log('  ... setting other: '+avOther);
          }
      }
   }
   if (arguments.length>1) return 1 ;

// ........ widths
 // reset widths using current width
   let awidth=$(window).width();
   let viewColWidth  ;
    let z0=$('#simple_viewer');
   let ee_dirCol=z0.find('[name="content_dirs"]');
   let ee_fileCol=z0.find('[name="content_files"]') ;
   let ee_viewCol=z0.find('[name="content_viewFile"]') ;

   if (awidth<500) {                // small, given first 2 cols some space
      let wide30=wsurvey.toPx('30%','w');
      let wide40=wsurvey.toPx('40%','w');
      ee_dirCol.width(wide30);
      ee_fileCol.width(wide30);
      ee_viewCol.width(wide40);
  } else   {                                             // not so narrow, so maybe give extra room to first 2?
      let wide15=wsurvey.toPx('15%','w');   // first reset to defaults
      let wide67=wsurvey.toPx('67%','w');
       viewColWidth=wide67 ;
      ee_dirCol.width(wide15);
      ee_fileCol.width(wide15);
      ee_viewCol.width(viewColWidth);

     if (viewColWidth>680) {   // wider than necessary?
        let dirVis=ee_dirCol.is(':visible');
        let fileVis=ee_fileCol.is(':visible');
        let extras=viewColWidth-720;
        let addViewerPx=0;
        if (dirVis) {
          let newDirCol=wide15+(extras/2);
          if (!fileVis)  {
              newDirCol+=(extras/2);
              addViewerPx+=extras/2;
          }
          z0.find('[name="content_dirs"]').width(newDirCol);
          z0.find('[name="content_dirs_header"]').width(newDirCol);
        }
        if (fileVis) {
          let newFileCol=wide15+(extras/2);
          if (!dirVis){
             newFileCol+=(extras/2);
             addViewerPx+=extras/2;
          }
          z0.find('[name="content_files"]').width(newFileCol);
          z0.find('[name="content_files_header"]').width(newFileCol);
        }
        let vw=660+addViewerPx
        z0.find('[name="content_viewFile"]').width(vw);
        z0.find('[name="content_viewFile_header"]').width(vw);

     }
   }

   return true;

}    //   doAdjustSize


//===============
// do adjust size on button
function doAdjustSizeButton(athis) {

  doAdjustSize(0,{'parent':'*','target':'#simple_viewer [name="simpleTable"]','padding':"2.0em",});
  doAdjustSize(athis)
  return 1;
}

//=====================================
//=====================
// Create a wsGallery viewer  -- a container with elements that are used to stored contents
// supplied  by wsGallery_get.js functions
// Returns a string that can be saved into a outer container
//   vuId shoud be the "id" parameters (2nd parameter) used wsGallery.init()
//   daHeight is optional. It sets the size of the wsGallery viewer AFTER clicking an adjustViewer button
//            The default is 100% -- adjust viewer to use all available space in the browser window
// Example:, if vuId='myViewer'
//  let stuff=wsGallery.createSimpleViewer('myViewer')
//  $('#myViewer_outer').html(stuff);
//  wsGallery.init('wsg_viewer','myViewer',{'callback':'myCallback'});
// ..
//  <div id="myViewer_outer"> ;
//    <!-- a string containing <div> and others elements used by myCallback, with
//            id="myViewer",  and
//            data-wsgname_main="wsg_viewer"
//        will be written here -->
//  </div>

wsGallery.createSimpleViewer=function(vuId,daHeight) {

let amess='';
if (arguments.length<2) daHeight='100%';
amess+='<div id="'+vuId+'" data-targetheight="'+daHeight+'" ';
amess+='    style="height:99%;overflow:auto;margin:0.2em 1em 0.2em 0.2em; ">';
amess+='';
amess+='<!-- choose-a-gallery row (linear list) -->';
amess+='<div style="width:98%;padding:0px;margin:1px;background-color:#eeefee;border-bottom:1px solid brown">';
amess+=' <div name="content_galleries_outer"  class="menuInRow"    >';
amess+=' <table><tr>';
amess+='   <td><input class="selfButton" type="button" value="x" title="close: list of galleries" onClick="closeMe(this)">';
amess+='   <td> <div name="content_galleries_header" style="color:blue"></div> </td>';
amess+='   </td>';
amess+='   <td> <div name="content_galleries" style="color:brown"></div>';
amess+='   </td>';
amess+=' </tr></table>';
amess+=' </div>';
amess+='</div>      <!-- choose-a-gallery row -->';
amess+='';
amess+='<!-- choose a tree row (in a gallery)(linear list) -->';
amess+='<div style="width:98%;padding:0px;margin:1px;border-bottom:1px solid tan;background-color:#efe1e2;">';
amess+=' <div name="content_trees_outer" class="menuInRow"   >';
amess+=' <table><tr>';
amess+='   <td><input class="selfButton" type="button" value="x" title="close: list of trees" onClick="closeMe(this)"   >';
amess+='   <td> <div name="content_trees_header" style="color:blue"></div> </td>';
amess+='   <td> <div name="content_trees" ></div> </td>';
amess+='  </tr></table>';
amess+=' </div>';
amess+='</div>      <!-- choose a tree row -->';
amess+='';
amess+='<!-- 3 floating divs (in adjacent columns)  showing lists of  dirs,files, and file viewer -->';
amess+='';
amess+='<div name="simpleTable" style="height:77em;width:98%;overflow:auto;white-space:nowrap" >';
amess+='';
amess+=' <div name="simpleTable_headers"  >';
amess+='   <div   name="content_dirs_header"  class="viewSimpleTableHeaderC"  style="width:15%">';
amess+='  <input class="selfButton" type="button" value="x" title="close: list of dirs" onclick="toggleListView(this)" data-which="dirs" data-wsgname="viewer1">';
amess+='    <em> list of dirs </em>';
amess+='  </div>';
amess+='   <div   name="content_files_header"  class="viewSimpleTableHeaderC"  style="width:15% ">';
amess+='    <em> list of files </em>';
amess+='  </div>';
amess+='   <div   name="content_viewFile_header"  style="display:inline-block"';
amess+='            class="viewSimpleTableHeaderC"  style="width:67%;">';
//amess+='     <input type="button" value="&#8634;" title="adjust the viewer sizes to fit screen" onClick="doAdjustSize(this)" >';
amess+='';
amess+='    <em>file viewer </em>';
amess+='  </div>';
amess+='  <br clear="all" />';
amess+=' </div>      <!-- simpleTable_headers -->';
amess+='';
amess+=' <div name="simpleTable_content"    >';
amess+='   <div   name="content_dirs"  class="viewSimpleTableListC"  style="width:15%">';
amess+='      <em> ... </em>';
amess+='   </div>';
amess+='   <div name="content_files"  class="viewSimpleTableListC "  style="width:15% ">';
amess+='      <em> ... </em>';
amess+='   </div>';
amess+='   <div   name="content_viewFile"  style="white-space:normal"';
amess+='             class="viewSimpleTableListC"  style="width:67%;">';
amess+='      <em> ... </em>';
amess+='   </div>';
amess+='  <br clear="all" />';
amess+=' </div>      <!-- simpleTable_content -->';
amess+='                                             ';
amess+=' </div>      <!--  simpleTable -->';
amess+='                                       ';
amess+=' </div>      <!-- simple_viewer1 --> ';
amess+=' ';

return amess ;
}

// =========== some helper functions

// --- error reporting function used by wsurvey.getJson. Hopefully will never be called.
function jsonErrorShow(amess) {
   $('#wsGallery_notes').append('<hr>'+amess) ;
  return 1
}

//=------
// alternate "callback"
function showBasic(ares) {
  var goo=wsurvey.dumpObj(ares['list'],'var','alternate callback ');
  $('#simple_notes').html('<pre>'+goo+'</pre>').show();
}

// ================
// toggle view of a list (galleries trees dirs files )
function toggleListView(athis,awhich,wsgName) {
  var   e1=[],ethis ;
  if (arguments.length<2) {
       ethis=wsurvey.argJquery(athis);
       awhich=ethis.attr('data-which');
       wsgName=ethis.attr('data-wsgName');
   }
   let ewsgid=$('[data-wsgName_main="'+wsgName+'"]');
   if (ewsgid.length!=1) {
      alert('toggleListView: No unique match for data-wsgName_main='+wsgName);
      return false;
   }
   if (awhich=='galleries') {
       e1=ewsgid.find('[name="content_galleries"]');
   }
   if (awhich=='trees') {
      e1=ewsgid.find('[name="content_trees"]');
   }
   if (awhich=='dirs') {
      e1=ewsgid.find('[name="content_dirs"],[name="content_dirs_header"]');
   }
   if (awhich=='files') {
      e1=ewsgid.find('[name="content_files"],[name="content_files_header"]');
   }

   if (e1.length>0 ) {
       e1.toggle();
       if (arguments.length<2) ethis.toggleClass('usePresetsC_isHidden');
   }
   return 1;
}
//==================
// close a listbox
function closeMe(athis) {
   ethis=wsurvey.argJquery(athis);
   let e1=ethis.closest('.menuInRow');
   if (e1.length==1) e1.hide();
}

//========
// reopen all the menus
function reopenMenus(athis) {


   let ewsgid=$(document);
   let e1= ewsgid.find('[name="content_galleries_outer"]');
   e1.show();
   ewsgid.find('[name="content_trees_outer"]').show();
   e1=ewsgid.find('.viewSimpleTableListC');
   e1.show();
   ewsgid.find('.viewSimpleTableHeaderC').show();

   let earf=ewsgid.find('.usePresetsC_isHidden');
   earf.removeClass('usePresetsC_isHidden');

   return 1;
}


function queryString(a0) {     // https://fellowtuts.com/jquery/get-query-string-values-url-parameters-javascript/
  if (arguments.length<1) a0=window.location.search.substr(1); // stirp leading ?
   if (a0 == "") return {};
   a=a0.split('&');
    var b = {};
    for (var i = 0; i < a.length; ++i)        {
            var p=a[i].split('=');
            if (p.length != 2) continue;
            b[p[0]] = decodeURIComponent(p[1].replace(/\+/g, " "));
        }
        return b;
}
</script>


<style type="text/css">

.viewSimpleTableHeaderC {           /* the header of the viewfile column */
  border:1px dotted blue;
  margin:4px;
  height:1.3em
  overflow:auto;
  display:inline-block;
    xfloat:left ;
}

.viewSimpleTableListC {
  border:1px dotted cyan;
  margin:4px;
  height:21em ;
  align:top;
  overflow:auto;
  vertical-align: top;
  display:inline-block;
}

.usePresetsC,.usePresetsC0 {             /* display the values of the preset variables (at top of screen) */
   margin:3px 1em 3px 1em;
   background-color:#dfdad1;
}

.usePresetsC0 {
   border:1px dotted gray !important ;
}

/* use this to signal that a column is currently hidden */
.usePresetsC_isHidden {
   color:red  !important ;
}

.menuInRow {
   max-height:3em;
   overflow:auto;
}

</style>


</head>

<body  >

<!-- some headers -->
<div id="simple_header" style="border:1px dotted brown;overflow:auto">
   <div style="font-weight:700">
<span id="ireopenAllbutton">
     <input type="button" value="&#128260;" title="reopen all menus ... "    data-wsgName="'+wsgName+'" onClick="reopenMenus(this)">
</span>
<span id="iheaderLine">
   Simple wsGallery viewer
</span>
</div>
  <div id="simple_usePresets" style="margin:3px 3em 3px 3em;border:1px dashed tan;display:none"> </div>
</div>

<!-- createSimpleViewer is used to create the html content that is copied into here (1st viewer) -->
<div id="simple_viewer_outer"  >
    <!-- the container with gallery/tree/dir/file selection menus, and file viewer -->
</div>

<!-- createSimpleViewer is used to create the html content that is copied into here (2nd viewer) -->
<hr>
<div id="simple_viewer_outer2_b">
<em>Viewer 2.... </em>
<div id="simple_viewer_outer2"  >
    <!-- the container with gallery/tree/dir/file selection menus, and file viewer -->
</div>
</div>


<!-- for error display -->
<div style="background-color:#ddccdd;display:none" id="simple_notes">
Debugging and technical notes.
<hr>
</div>

<!-- a spacer -->
<div   style="height:0.3em;border-bottom:1px dotted black" title="a screen bottom spacer/indicator"></div>

</body>
</html>