; Example of a wsGallery  tree  specification file. Original version -- for reference uses.
;
; Each gallery (subdirectory under wsGallery/galleries) MUST have a version of this, named wsGallery_treeList.php
; If a gallery is selected that does not have its own copy of wsGallery_treeList.php, wsGallery will exit with an error message
;
; ================================================================================
;
;  For security reasons: this must be edited by a site administrator. It is not editable via wsGallery.php
;
; Changes should be made in the user changable  section, using the syntax described in the details section;
; Note that lines beginning with a ";" are comments, and are ignored. Empty lines are ignored.
;
; The use of trees allows one to specify different sets of  subdirectories (and their files) that can be viewed by the public.
; If you have distinct groups of directories (say, for different individuals) the use of trees can be helpful.
; AND: you can specify  a tree to provide access to subdirectories outside of the normal path supported by the hosting web server.
;
;    Recommendation:
;       When possible, use the site`s default www directory as the treeRootDir
;        In other words: if possible, do NOT specify the treeRootDir!
;
;     CAUTION:
;         Specifying a tree `outside of the normal path` can be a security risk.
;         It can be used to access  any file in the file space (of whatever account is hosting the web domain).
;         For example: any drive on a windows machine hosting the website.
;         THUS: wsGallery should NOT be installed if one can not control access to this configuration file!
;
;; ============================== begin user changeable parameters

.showTree:
_default:  , ~/images/,The default tree for wsGallery

;; ============================== end of user changeable parameters
;
; Some details
;      A longer discussion is in wsGallery_readMe.txt.
;
;    You can specify several "trees" -- each tree being a directory and its subdirectories.
;    Typically, these trees are under your web root. But they do NOT have to be.
;
;    Tree specification is done using a simple syntax, with one row used for each tree.
;    Syntax of a row:
;        treename:  treeRootDir, selBase, descripton
;
;
;    where
;        treeName: REQUIRED. A  one word  name (a string) used to identify this tree.
;                  We strongly recommend using lowercase ONLY in the treename
;        treeRootDir : a fully qualified path to the root of the tree.
;                    If not specified, the web site`s root is used (i.e.; d:\www).
;                    For better performance: whenever possible, use treeRootDir='' (or the full path to the www root dir)
;        selBase : the "selector" used to point to files, relative to the treeRootDir.
;                  If not specified, '/' is used
;                    If ~, the ~ is replaced by the relative path of wsGallery.php is installed in (relative to the treeRootDir)
;        desription: optional one line used for this tree. Do NOT use HTML tags (they will be removed)!
;                    If not specified, a generic description is used
;
;
;
; In addition to tree specification rows, you can specify a default tree using  (it MUST start with a period).
;        .showTree:  aTreename
;  This what tree wsGallery will show when first invoked.
;           If not specified, `_default` is used.
;           If specified, it MUST be one of the treenames you specified, or `_default`
;
;    The _default tree.
;        *  wsGallery is packaged with support for a '_default' tree, specified as:
;           _default: , ~/images,   The default tree for wsGallery
;          where, as noted above, ~ is the path to wsGallery.
;
; Examples:
;           _default: , ~/images, /, The default tree for wsGallery
;           newPhotos: , personal/photos, My family photos
;           oldPhotos: f:\archive, /pre2000/photos, f:\archive, My old photos