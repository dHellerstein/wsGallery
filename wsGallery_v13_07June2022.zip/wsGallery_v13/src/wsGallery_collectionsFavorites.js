//========== collection and favorites functions

// collection functions
function openCollection(acollection,aentry,afile) {
   if (arguments.length<1) acollection='';
   if (arguments.length<2) aentry='';
   if (arguments.length<3) afile='-1';
   var adata={'todo':'listCollections','collection':acollection,'entry':aentry,'file':afile  }  ;
   wsurvey.getJson.get('wsGalleryActions.php',adata,openCollection2,'openCollection ');
}

// [$cname1,$adesc,$nentries,$mdate,$mdateShow];
function openCollection2(aresponse,origdata) {
    hh=wsurvey.getJson.check(aresponse,0,'openCollection2');
    if (hh===false) return 1;
    let acollection=origdata['collection'];
    let aentry=origdata['entry'];
    let afile=origdata['file'];

    let astatus=hh['content'];

    let bmess='<input type="button" value="?" title="Selecting a collection" class="helpButton" onclick="doHelpVu(this)" topic="selectCollection">';
     bmess+=' <b>Available collections</b>';

    let reqCtitle=$(document).data('collectionTitle');
    if (reqCtitle!='') bmess=reqCtitle;

    bmess+='<table cellpadding="3" style="width:95%"  >';
    bmess+='<tr><td width="50%">';

    bmess+='<div style="padding:3px 3px 1em 3px;  overflow:auto;border:1px dotted #dfdfef;"  id="openCollection2_A">';
    let ulist='<ul class="selectFileMenu">';
    gotmatch=0;
    for (let ii in astatus) {
      let vv=astatus[ii];
      let bmess1='<li class="selectFileMenuLi">'  ;
      bmess1+='<input type="button" value="'+vv[0]+'" data-admin="0" onclick="showACollection(this)" title="view '+vv[2]+' entries in this collection" ';
      if (acollection!='' && acollection==vv[0]) {       // requested collection
          bmess1+=' data-requested="1" data-entry="'+aentry+'"   data-file="'+afile+'" ' ;      // aentry is requested entry ...
          gotmatch=1;
      }  else {
          bmess1+='  data-entry="" ' ;
      }
      bmess1+=' >';
      bmess1+='<span style="font-style:oblique" title="Created '+vv[4]+'"><em>'+vv[1]+'</em></span>'+'\n';
      ulist+=bmess1;
    }
   ulist+='</ul>';

    bmess+=ulist;
    bmess+='</div>';  // list of collections

    bmess+='</td>'

    bmess+='<td width="45%"  valign="top">';   // dirs in a collection
    bmess+='<div style="padding:3px 3px 1em 3px;overflow:auto;border:1px dotted #efdfdf;" title="Directories in this collection" id="availCollections_dir">... ';
    bmess+='</div>';
    bmess+='</td>'

    bmess+='</tr>';
    bmess+='</table>';

    wsurvey.flContents.content('collectionList',bmess,{'header':'Currently available collections','onTop':1});

//    resize...

    oof=wsurvey.flContents.current('collectionList');
    let bheight=oof['height'];
    let btop=oof['top'];
    let ea=$('#openCollection2_A');
    let eaTop=ea.offset().top;
    let eaD1=eaTop-btop;
    let bheight2=bheight-(eaD1 );

    $('#openCollection2_A').height(bheight2);
    $('#availCollections_dir').height(bheight2);


    if (gotmatch==1) {                   // requested collection was found
      window.setTimeout(function() {
        let ehh=wsurvey.flContents.find('collectionList','[data-requested="1"]');
        if (ehh.length==1) {
           foo=ehh.attr('data-entry');  // only one of the entries might have a data-entry attriburte
           ehh.trigger('click' );            // will contain data-entry and data-file attributes
        }
      },50) ;  // wait for dom to settle
    }


}


//============
// retrieve details on a collection
function showACollection(athis) {
   let ethis=wsurvey.argJquery(athis);
   let acollection=ethis.val();
   let isadmin=ethis.wsurvey_attrCi('data-admin',1);

   if (isadmin==1) {
      let adata={'todo':'collection_viewDetails','collection':acollection,'isadmin':isadmin }  ;
      wsurvey.getJson.get('wsGalleryActionsAdmin.php',adata,showACollection2,'showACollection ');
   } else {
      let dentry=ethis.attr('data-entry');
      let dfile=ethis.attr('data-file');

    //  alert(' gotDentry '+dentry);
      if (typeof(dentry)=='undefined' || dentry==null) dentry='';
      if (typeof(dfile)=='undefined' || dfile==null) dfile='-1';

      let adata={'todo':'collection_listDirs','collection':acollection,'isadmin':isadmin,'entry':dentry,'file':dfile }  ;
      wsurvey.getJson.get('wsGalleryActions.php',adata,showACollection2,'showACollection ');
   }
 }
function showACollection2(aresponse,origdata) {
    let hh=wsurvey.getJson.check(aresponse,0,'showACollection2');
    if (hh===false) return 1;
    let isadmin=origdata['isadmin'];
    let aentry=origdata['entry'];
    let dfile=origdata['file'];
    if (isadmin==0) {    // client view of collections
       let ed1=$('#availCollections_dir');
       ed1.html(hh['content']);
       if (jQuery.trim(aentry)!='') {   // an entry (in this colelction) was specified. It might exist?
          let eaa=ed1.find('[data-entry="'+aentry+'"]');
          if (eaa.length>0) {
              eaa.trigger('click');
          } else {           // no matching entry, stop
              return 1;
          }
         if (dfile!=-1 || jQuery.trim(dfile)!=='') {  // was a file also specified (by number or name)
           window.setTimeout(function() {
              let earf=$('#listOfFileInCurrentDir');
              if (!isNaN(dfile)){  // click a file entry (by number)
                 let earfs=earf.find('[buttonnumber="'+dfile+'"]');  // spans that surrond a button
                 if (earfs.length>0)  {
                     let earfs2=earfs.find('button');
                     if (earfs2.length>0) earfs2.trigger('click');
                 }
              } else {    // by name
                 let earfs=earf.find('[name="listOfFileInCurrentDir_button"]');  // the buttons
                 dfile=jQuery.trim(dfile);
                  if (earfs.length>0) {
                     let goo=earfs.filter(function() {
                         thisone=jQuery.trim($(this).text());
                         if (thisone==dfile) return $(this);
                      }) ;  // filter
                      if (goo.length>0) goo.trigger('click');
                 }  // earfs.length

              }    // dfile is number
           },200);
          }  // dfile!=-1

       }

   } else {            // admin view
     $('#collectionsView2_col2').html(hh['content']);
   }
}


//=============
// display the files in a colletion specified directory
// similar to getDirFileListJs -- but returns more info (all the button lists)

function showCollectionDirFiles(athis) {

    let ethis=wsurvey.argJquery(athis);
    let acollection=ethis.attr('data-collection');
    let aentry=ethis.attr('data-entry');
    let agallery=ethis.attr('data-gallery');
    let atree=ethis.attr('data-tree');
    let adir=ethis.attr('data-dir');
    let inNew=$('#showCollectionInNewWindow').prop('checked');
   let goo=[ agallery,atree,adir];

    if (inNew) {           //  .................. show in new window
       let aurl='wsGallery_simple.php?';
       aurl+='useGallery='+agallery;
       aurl+='&useTree='+atree;
       aurl+='&useDir='+adir;
       aurl+='&useFile=0';
       let tt=goo.join('+/+');
       aurl+="&headerLine=Collection+"+acollection+':+'+tt;
       aurl+='&autoAdjustSize=1';
       window.open(aurl,'viewer','popup=1');
       return 1;
   }

// .... otherwise, show in normal gallery (flContent container)

    let ihow=ethis.attr('how');

  let adata={'todo':'getCollectionFiles','collection':acollection,'entry':aentry,'how':ihow,
             'gallery':agallery,'dir':adir,'tree':atree };
    wsurvey.getJson.get('wsGalleryActions.php',adata,showCollectionDirFiles2,'showCollectionDirFiles ');
}

function showCollectionDirFiles2(aresponse,origdata) {
    let hh1=wsurvey.getJson.check(aresponse,0,'showCollectionDirFiles2');
    if (hh1===false) return 1;

    let hh=hh1['content'];

// hh fields: dir summary treename gallery dirInfo dirDesc  fileList  fileStats  messageTop     basics
//            buttonListText  buttonList40  buttonList66   buttonList90 snapList
     let acollection=origdata['collection'],aentry=origdata['entry'];
     let ihow=origdata['how'];  // button type (use one of the 4 buttonList arrays

     let basics=hh['basics'];
     let agallery=basics['gallery'],adir=basics['dir'], treeName=basics['tree'];
     let dirDesc=hh['dirDesc'];
     let fileStats= hh['fileStats'];

     let buttonList=[];
     if (ihow==1) {
       buttonList=hh['buttonList40'] ;
      } else if (ihow==2) {
        buttonList=hh['buttonList66'] ;
      } else if (ihow==3) {
       buttonList=hh['buttonList90'] ;
      } else {
       buttonList=hh['buttonListText'] ;
      }
      let nbuttons= buttonList.length;

      let toCache={};
      toCache['collection']=acollection;
      toCache['entry']=aentry;
       toCache['buttonText']=hh['buttonListText'];
       toCache['button40']=hh['buttonList40'];
       toCache['button66']=hh['buttonList66'];
       toCache['button90']=hh['buttonList90'];

      $(document).data('collectionButtons',toCache);  // for future use (if thumbnails are chosen)
     let messageHeader=hh['messageTop'];  //  craeted by php doGetDirFileList_header

     $(document).data('currentFiles_dirDesc',dirDesc) ;
     $(document).data('currentFiles_snapshots',hh['snapList']) ; // use to change menu layout
     $(document).data('currentFiles_stats',fileStats) ; // use to change menu layout

     toggleDirVu(2);

     if (typeof(saveNotes)=='function')   saveNotes('Read info for collection '+origdata['collection']+' / ' +origdata['entry']);

// build html menu (of buttons) using buttonList (depend
     let stuff='';
     stuff+=messageHeader;
     stuff+='<div id="listOfFileInCurrentDir" class="listOfFileInCurrentDirC" nButtons="'+nbuttons+'">';
     let s3=showFileList_buttonView('from collection','',buttonList ) ;

      stuff+=s3;
      stuff+='</div>' ;

      wsurvey.flContents.contents('gallery',stuff) ;
      wsurvey.flContents.onTop('gallery');

      let  gheader=' <input type="button" value="&#10068;" title="Help for: viewing an image" onClick="doHelpVu(this)"  class="helpButton"  topic="viewFiles" > ';

      var hhsay='';
//      var hhsay='<span title="Files in ...">&#10162;</span>';
      hhsay+='<button  id="targetHereViewer_which"  name="targetHereWhich"  title="File display in next viewer"  ';
      hhsay+='        class="targetHere_off targetHereButton" data-which="0">&vellip;</button> ';
                  

      hhsay+='<span title="(entry in a collection) Files in .... " style="padding-left:1em;border:1px solid cyan">';
      hhsay+='directory:<span class="headerEmphasizer" > '+adir;
      hhsay+='</span> &nbsp; &nbsp; | tree: <span style="font-size:120%;font-weight:700">'+treeName+'</span>';
      hhsay+=' (<em>in the </em> <span class="cMyGallery" > '+agallery+'</span> gallery) ';

      hhsay+='</span> ';

      wsurvey.flContents.header('gallery',gheader+hhsay);
      wsurvey.flContents.onTop('collectionList',0);

      var eii=$('#iToggleScreenLayout'), aii=eii.attr('which');  //0:dual, 1:rotate, 2:tableau, 3: rotate,4: singlePair

      window.setTimeout( function(){
         $('#getImgInfo').trigger('click')     ;  // will show the 'directory description'

// click handler
         $('#listOfFileInCurrentDir').on('click',listOfFileClickHandler);

// some dropdowns
         let ddopts={'openerActive':'[name="whileDropdownOpen"]',
           'openerInactive':'[name="whileDropdownNotOpen"]','delayOnEnter':1000,
           'zindex':2300,'leftOffset':'-5em','topOffset':'1o+5','closers':'*'};
         let gg=wsurvey.dropdown('iopenerWhichViewer','dropdown_whichViewer',ddopts   );

         ddopts={'openerActive':'[name="whileDropdownOpen"]',
            'openerInactive':'[name="whileDropdownNotOpen"]','delayOnEnter':1000,
            'zindex':2300,'leftOffset':'-2em','topOffset':'1o+5','closers':'*'};
         gg=wsurvey.dropdown('iopenerGetSnapshot','dropdown_showSnapshot',ddopts);

         ddopts={'openerActive':'[name="whileDropdownOpen"]',
            'openerInactive':'[name="whileDropdownNotOpen"]','delayOnEnter':1000,
            'zindex':2300,'leftOffset':'-3em','topOffset':'1o+5','closers':'*'};
         gg=wsurvey.dropdown('iopenerShrink','dropdown_shrink',ddopts);

         let ej=$('[name="imageJumpButtons"]');
         if (aii!=3) {
               ej.show();
         } else {
             ej.hide();
             if (aii==0) $('#currentImageCursorSpot').hide();
         }

 // fix some stuff given other parameter values
         if (aii==1)  {       // rotating -- change file list options to avoid issues
          let dosaves={'shrink':'shrink','snap':'snapshot','viewer':'viewer1','info':0}; // same as which=0
          let doenables={'shrink':1,'snap':1,'viewer':0,'info':1};
          daopts={'save':dosaves,'enable':doenables};
          doResizeViewers_setButtons(daopts);
         }
         if (aii==2)  {       // tableau -- change file list options to avoid issues
          let dosaves={'shrink':'shrink','snap':'snapshot','viewer':'viewer1','info':0}; // same as which=0
          let doenables={'shrink':1,'snap':1,'viewer':0,'info':1};
          daopts={'save':dosaves,'enable':doenables};
          doResizeViewers_setButtons(daopts);
         }
         if (aii==4)  {       // singlePair -- change file list options to avoid issues
          let dosaves={'shrink':'shrink','snap':'snap','viewer':'viewer2','info':1};
          let doenables={'shrink':1,'snap':1,'viewer':0,'info':1};
          daopts={'save':dosaves,'enable':doenables};
          doResizeViewers_setButtons(daopts);
          wsurvey.flContents.onTop('snapBox2');
          wsurvey.flContents.onTop('gallery');
        }

      }  // settimeout
      ,120);


}

// ----------
// redisplay currently selected collection/entry -- used saved info from call to showCollectionDirFiles
function showCollectionDirFiles_how(athis){

   let ethis=wsurvey.argJquery(athis);
   let ihow=ethis.attr('data-how');
   let acollection=ethis.attr('data-collection');
   let aentry=ethis.attr('data-entry')
   let buttonList=$(document).data('collectionButtons');


   if (buttonList['collection']!=acollection || buttonList['entry']!=aentry) {
       alert('Mismatch between requested collection/entry ('+acollection+'/'+aentry+') and cache ('+buttonList['collection']+' / '+buttonList['entry']+')');
       return 0;
   }

     if (ihow==1) {
       buttonList=buttonList['button40'] ;
      } else if (ihow==2) {
        buttonList=buttonList['button66'] ;
      } else if (ihow==3) {
       buttonList=buttonList['button90'] ;
      } else {
       buttonList=buttonList['buttonText'] ;
      }
      let nbuttons= buttonList.length;

     showFileList_buttonView('collection '+acollection+' / entry '+aentry,'listOfFileInCurrentDir',buttonList);

     return 1;
}


//=============
// reshow colllection view window
function collectionListOnTop(athis) {
   wsurvey.flContents.onTop('collectionList')  ;

}


//=================
// favorites functions
function doFavorites(athis,noHide) {
   var noHideReal=0;
   if (arguments.length<2) noHide=0;
   if (noHide==10) { 
       noHide=0;
       noHideReal=1;
   }
   if (noHide==0 && noHideReal==0) {         // toggle? (noHide=10 supresses this)
      let isvis=wsurvey.flContents.visible('favorites');
      if (isvis==1) {
        wsurvey.flContents.hide('favorites',10);
        return 0;
      }
   }

// not a toggle off .. so show (on top)
    wsurvey.flContents.show('favorites',10,1);  // show the favorites menu

    let afavorites=$(document).data('enableFavorites');

    if (afavorites==0) {
      wsurvey.flContents.content('favorites','Sorry, favorites are currently disabled.');
      return 0;
    }

   var faveStuff=$(document).data('favoritesSpecs');

// transient header ...
    let hmess='';
    hmess+='<input type="button" value="&#127989;" class="favoritesMenuButton" title="Display options (read, create, etc) menu " onClick="doFavorites(this,2)"> ';
    hmess+='<input type="button" value="&#8634;" title="refresh (show most recently viewed file)" onClick="doFavorites(this,1)"> ';

    if (afavorites==1)  hmess+='<b>Read </b>';
    if (afavorites==2)  hmess+='<b>Read &amp; create </b>';
    if (afavorites==3)  hmess+='<b>Read &amp; create  </b>';

   let readName=faveStuff['readName'];
   let readNfiles=faveStuff['readNfiles'];
    if (readName!='') {
      hmess+='<span title="Using favorites from here (with '+readNfiles+' files)" style="padding:3px;margin:3px 3px 3px 1em;border:1px dashed gray;font-family:monospace">'+readName+'</span> ';
   }
    wsurvey.flContents.header('favorites',hmess )  ;

// view the save read etc menu ?
  if (noHide==2) {
     let amess="  ";
     let favesList=faveStuff['current'];
     amess+='<em>There are '+favesList.length+' entries in the current list of favorites </em>';
     amess+='<ul class="linearMenu">';
     amess+='<li class="linearMenuLiBlank"> You can ... ... ';
     amess+='<li class="linearMenuLi2"><input type="button" value="Read" title="read a list of favorites (from local file or server)" onClick="doFavorites(this,3)"> ';

     let afavorites=$(document).data('enableFavorites');
     if (afavorites>1)  amess+='<li class="linearMenuLi2"><input type="button" value="Create" title="Save the current list of favorites  (to a  local file)" onClick="doFavorites(this,4)"> ';
     amess+='<li class="linearMenuLi2"><input type="button" value="View" title="View the entries in the current list of favorites  " onClick="doFavorites(this,7)">   ';
     amess+='<li class="linearMenuLi2"><input type="button" value="&Cscr;urrentFile" id="iCreate_update" title="Update -- view information on the most recently viewed file\nYou can then save it!" onClick="doFavorites(this,1)"> ';
     amess+='</ul>';
     wsurvey.flContents.content('favorites',amess);
     return 1;
 }

//   read a favorites menu ?
  if (noHide==3) {
     let bmess='';
     bmess+='<div style="background-color:#deedde;margin:3px 1em 3px 1em">';
     bmess+='<input  type="button" value="&#128153" title="Open favorites menu" onclick="doFavorites(this,10)" class="cFavorites2"> ';
     bmess+='<ul class="linearMenu">';
     bmess+='<li class="linearMenuLi2">Select a <input type="button" value="locally saved" onClick="doFavorites_localSaveToggle(1)"> ';
     bmess+=' favorites list (from your hard drive) ';
     bmess+='<li class="linearMenuLi2">Select a <input type="button" value="public" onClick="doFavorites_getPublicLists(this)"> favorites list (from the server)';
     bmess+='</ul>';
     bmess+='</div>';
     bmess+='<div id="favorites_read_local" style="margin:3px 1em 3px 1em;border:1px solid black;display:none">';
     bmess+=' <input type="file"    id="readFiles_favorites"   title="Select a favorites list"  >   ';


     bmess+='<span  class="cDropFavoriteOuter" title="Do not drop it here! Drop it in the cyan circle below &darr;"  >';
     bmess+'<table border="2">';
     bmess+='<tr draggable="false"><td title="do not drop it here .. drop it in the tan circle!">';
     bmess+='  <span draggable="false">or drop a file &darr;</span></td></tr><td>   ';
     bmess+='</tr>';
     bmess+'<tr><td bgcolor="cyan"> ';
     bmess+='<span id="uploadNow_favorites_drop" class="cDropFavorite" title="you can drop a file here"  >...</span>';
     bmess+=' </td>';
     bmess+='</tr></table>';
     bmess+='</span>'

     bmess+='<input type="button"  id="uploadNow_favorites" style="opacity:0.5" disabled value="..."  title="and use it"  >  ';
     bmess+='</div>';
     bmess+='<div id="favorites_read_server" style="margin:3px 1em 3px 1em;border:1px solid blue;display:none">';
     bmess+=' list of serverside favorites-lists ';
     bmess+='</div>';

     wsurvey.flContents.content('admin',bmess,{'show':1,'onTop':1});

  $(".cDropFavorite").hover(function(){
    $(this).addClass('cYesHere');
  }, function() {
    $(this).removeClass('cYesHere');
  });

      let opts={'button':'readFiles_favorites',
                'submit':'uploadNow_favorites',
                'drop':'uploadNow_favorites_drop',
                 'pathPhp':'src/wsGallery_readFile.php',
                 'callbackGetFile':doFavorites_gotFile,
                  'callback':doFavorites_readLocal} ;
     window.setTimeout(function(){
         wsurvey.uploadFiles.setup(1,opts);
     },50);
     return 1;
  }
  if (noHide==4) {    // save locally
    let favesList=faveStuff['current'];
    let amess='';
     amess+='<input type="button" class="smallButton" value="&#10068;" title="Help on: saving favorites to local file" topic="favoritesSaveLocal"   onClick="doHelpVu(this)" >' ;
     amess+="There are "+favesList.length+' <em>favorite</em> entries ';
     amess+='<br>Enter a 1-word name: <input type="text" size="22" id="iFavorites_saveName" value=" ">';
     let ttime=wsurvey.get_currentTime(1,1);
     amess+='<br>Enter a short description: <input type="text" size="50" id="iFavorites_saveDesc" value="'+favesList.length+' entries. Created: '+ttime+' ">';
     amess+='<br><input type="button" title="After entering a description and a comment: Save (locally)" value="Save these favorites!" onClick="doFavorites_saveLocal(this)"> ';
     amess+='<div style="background-color:#dffddf;margin:5px 1em 5px 1em;display:none"  id="iFavorites_saveStatus"> </div> ';
     wsurvey.flContents.content('favorites',amess);
     return 1;
  }

  if (noHide==5) {      // save on server
     wsurvey.flContents.content('favorites','Save favorites (on server) ');
     return 1;
  }

// save currently selected file as an entry
 if (noHide==6) {
   let  e1=wsurvey.flContents.find('gallery','#listOfFileInCurrentDir') ;
   let efile=e1.find('.thisImgInSnapshot');
   if (efile.length==0) {

     doFavorites(this,2)  ; // open menu
//      wsurvey.flContents.content('favorites','No file has been chosen. ');
      return 0;
   }
   let favesList=faveStuff['current'];
   let agallery=efile.attr('galleryname');
   let atree=efile.attr('treename');
   let afileSel=efile.attr('file');
   let espan=efile.closest('span');
   let adir=espan.attr('data-dir');
   let afile=espan.attr('data-file');

   if (favesList.length>0) {
       let alast=favesList[favesList.length-1];
       if (agallery==alast['gallery'] && atree==alast['tree'] && adir==alast['dir'] && afile==alast['file']) {
           let qq=confirm('You just saved this file to favorites. Are you sure you want to save it again? ');
           if (!qq) return 0;
       }
   }

   let bnumber=espan.attr('buttonnumber');
   let eFDesc=$('#iCreate_desc');
   let aFDesc=wsurvey.removeAllTags(eFDesc.val());
   aFDesc = aFDesc.replace(/\n|\r/g,'');

   let arow={'gallery':agallery,'tree':atree,'dir':adir,'file':afile,'bnumber':bnumber,'dirFile':afileSel,'desc':aFDesc} ;
   favesList.push(arow);
   faveStuff['current']=favesList;
    $(document).data('favoritesSpecs',faveStuff);
    let afoo='';
    if (afavorites>1) afoo='<input type="button" value="Create" title="Save the current list of favorites" onclick="doFavorites(this,4)">';
   $('#iFavorites_saveThis').html(afoo+' There are now '+favesList.length+' entries in Favorites').show();
   $('#iCreate_saveEntry').prop('disabled',true);
  // $('#iCreate_update').prop('disabled',true);

   return 1;
 }


// delete an entry in current favorites
 if (noHide==8) {
    let ethis=wsurvey.argJquery(athis);
    let iwhich=ethis.attr('data-which');
    let favesList=faveStuff['current'];
    let xx1=favesList.splice(iwhich,1);
     faveStuff['current']= favesList ;
    $(document).data('favoritesSpecs',faveStuff);
    doFavorites(0,7)  ;
    return 1;
 }

// delete all current enties
 if (noHide==81) {
     let qq=confirm("Are you sure you want to delete all the entries in the current favorites list \n(this will NOT effect the saved version) ");
     if (!qq) return 0;
     faveStuff['current']= [] ;
     $(document).data('favoritesSpecs',faveStuff);
    doFavorites(0,7)  ;
     return 1;
 }


// view current entries
 if (noHide==7 || noHide==77 || noHide==777 || noHide==7777) {
   let colors=['lime','cyan'],icth=0;
   let favesList=faveStuff['current'];

   let amess="There are "+favesList.length+' <em>favorite</em> entries ';
   amess+='<table rules="rows" cellpadding="5"><tr><td>';
   amess+='<input type="button" value="DeleteAll"   style="color:red" title="Delete all entries" onClick="doFavorites(this,81)"></td>';
   amess+='<th>Gallery</th><th>Tree</th><th>Directory</th><th>File</th><th>Description</th></tr>';
   for (let jf=0;jf<favesList.length;jf++) {
       let ff1=favesList[jf];
       icth=1-icth;
       let arow='<tr bgcolor="'+colors[icth]+'">';
       arow+='<td>';
       arow+='<span style="font-size:70%">'+jf+'</span> ';
       arow+='<input type="button" value="&#8998;" data-which="'+jf+'"  onClick="doFavorites(this,8)" title="delete this entry"></td>';
       arow+='<td><tt>'+ff1['gallery']+'</tt></td>';
       arow+='<td><tt>'+ff1['tree']+'</tt></td>';
       arow+='<td><tt>'+ff1['dir']+'</tt></td>';
       arow+='<td><tt>'+ff1['file']+'</tt></td>';
       arow+='<td><em>'+ff1['desc']+'</em></td>';
       arow+='</tr>';
       amess+=arow;
   }
   amess+='</table>';
   if (noHide==7) {
     wsurvey.flContents.contents('admin',amess,{'onTop':1,'show':1});
   } else if (noHide==77) {
     $('#doFavorites_readLocal_use_view').html(amess);
   } else  if (noHide==777){
     $('#doFavorites_readLocal_use_view_warning').html(amess);
   } else {  // 7777
     $('#doFavorites_readPublic_use_view').html(amess);
   }

   return 1;
 }

// show currently viewed file, with option to save
   let e1=wsurvey.flContents.find('gallery','#listOfFileInCurrentDir') ;
   let efile=e1.find('.thisImgInSnapshot');
   if (efile.length==0) {
      doFavorites(this,2)  ; // open menu
      return 0;

//      wsurvey.flContents.content('favorites','No file has been chosen ... ');
   }
   let agallery=efile.attr('galleryname');
   let atree=efile.attr('treename');
   let espan=efile.closest('span');
   let adir=espan.attr('data-dir');
   let afile=espan.attr('data-file');
   let bnumber=espan.attr('buttonnumber');

   let eFDesc=$('#fileDescriptions');
   let aFDesc=eFDesc.text();
   let aaa=wsurvey.parseAt(aFDesc,':');
   if (jQuery.trim(aaa[0])==afile) aFDesc=aaa[1];
   let amess='';
  if (afavorites>1) {
      amess+='<input type="button" value="&Ascr;dd!"  id="iCreate_saveEntry"  title="Add this to the list of favorites. You can first customize the description!" onClick="doFavorites(this,6)">';
  }
   amess+='<input type="button" value="&Cscr;urrent file" id="iCreate_update" title="Current file info -- view information for the most recently viewed file\nYou can then save it!" onClick="doFavorites(this,1)"> ';
   amess+=' selected file: <span style="border:1px dotted gray;display:inline-block" title="gallery / tree / dir / file\nButton #'+bnumber+' "><tt>'+agallery+'</tt> / <tt>'+atree+ '</tt> / <tt>'+adir+'</tt> /  <tt>'+afile+ '</tt></span>';
   amess+='<div style="margin:5px 1em 5px 1em;border:1px solid gray;" id="iFavorites_save">';
   amess+='Description: <input type="text" id="iCreate_desc" title="A description of this file (no html)"  size="90" value="'+aFDesc+'">';
   if (afavorites==1) amess+='<br><span style="font-size:80%;padding:3px;background-color:lightyellow">Note: creation of favorites is currently disabled</span>';
   amess+='<div id="iFavorites_saveThis" style="background-color:cyan;margin:5px 1em 5px 1em;display:none">...</div>';
   amess+='</div>';
   wsurvey.flContents.content('favorites',amess);
   return 0;

}


//=======================
// open local save div
function  doFavorites_localSaveToggle(x) {
       $('#favorites_read_local').toggle() ;
       e1=$('#uploadNow_favorites_drop');
       e1.text('Drop here!');
}

//==============
// callback after file gotten from hard drive and stored in uploadDataName (in (document).data()
function doFavorites_gotFile(adata) {
  let arf= wsurvey.uploadFiles.unpackFileData(adata);
  let e1=$('#uploadNow_favorites') ;
  e1.val(' Retrieve this favorites list: '+arf[0]['fileName']);
  e1.css({'opacity':'1.0'});
  e1.prop('disabled',false);

}
//==================
// return from upload file
function doFavorites_readLocal(data,stuff,tstatus,xhr) {
   let oof=JSON.parse(data);   //  multiple levels of encoding...
   let oof2=oof[0]['fileContent'];
   let oof3=JSON.parse(oof2);
  $(document).data('favoritesSpecsAll',oof3);
  let nentries=oof3['allList']['current'].length;
  let fname=oof3['name'],fdesc=oof3['desc'];
  let bmess='';
  bmess+='<input  type="button" value="&#128153" title="Open favorites menu" onclick="doFavorites(this,10)" class="cFavorites2">';
  bmess+='Collection <span   style="font-weight:700">'+fname+'</span> ';
  bmess+=' has '+nentries+ ' entries';
  bmess+=' (<span title="description" style="font-style:oblique">'+fdesc+'</span>) ';
  bmess+='<br>You can ...<br>';
  bmess+='<ul class="linearMenu">';
  bmess+='<li class="linearMenuLi2"><input type="button" value="Use these" title="use these entries as your current favorites list" onclick="doFavorites_readLocal_use(this)"> as favorites ';
  bmess+='<li class="linearMenuLi2"><input type="button" value=Display these files" title="display buttons to view each of these files "  onclick="showFavoritesDirFiles(this)"> in the directory list';
  bmess+='<li class="linearMenuLi2"><input type="button" value="Read another" title="Read a different favorites list "  onclick="doFavorites(this,3)">  ';

  bmess+='</ul>';
  bmess+='<div id="doFavorites_readLocal_use_view" style="margin:1em 2em 1em 2em;background-color:#dfefcf;padding:5px" ';
  bmess+='  title="List of favorites can be displayed here " > ...</div>';
  wsurvey.flContents.content('admin',bmess,{"onTop":1,'show':1});
}


 function doFavorites_readLocal_use(athis) {
    let  fspecs=$(document).data('favoritesSpecsAll');
    let  fspecs0=fspecs['allList'];
    $(document).data('favoritesSpecs',fspecs0);

    let fname=fspecs['name'];
    let nentries=fspecs0['current'].length;
    let bmess='';
    bmess+='<br>Favorites <tt>'+fname+'</tt> with '+nentries+': is now the favorites list';
    bmess+=' <input type="button" value="View" title="View  the entries in the current list of favorites" onclick="doFavorites(this,77)">';
    wsurvey.flContents.content('admin',bmess,{"onTop":1,'show':1,'append':1});
 }

 // NOT CURRENTLY USED
 function doFavorites_readLocal_display(athis) {
    let  fspecs=$(document).data('favoritesSpecsAll');
    let  fspecs0=fspecs['allList'];
    $(document).data('favoritesSpecs',fspecs0);
    let fname=fspecs['name'];
    let nentries=fspecs0['current'].length;
    let bmess='';
    bmess+='<input type="button" value="Display files! " title=" ... buttons that will display each file!" ';
    bmess+=' onClick="showFavoritesDirFiles(this)" >';
    bmess+=nentries+' entries in favorites <tt>'+fname+'</tt> '

    wsurvey.flContents.content('admin',bmess,{"onTop":1,'show':1,'append':1});


}

//===================
// save a list of favorites (locally)
function doFavorites_saveLocal(athis) {
     var faveStuff=$(document).data('favoritesSpecs');
    //let favesList=faveStuff['current'];
    let amess='';
    let adesc=jQuery.trim($('#iFavorites_saveDesc').val());
    let aname=jQuery.trim($('#iFavorites_saveName').val());
    let dd=wsurvey.getWord(aname,0);
    if (dd.length!=1) {
        alert('Favorites name must be a single word ');
        return 1;
    }
    aname=wsurvey.removeAllTags(aname);
    adesc=wsurvey.removeAllTags(adesc);
    let adata={'todo':'createFavorites','name':aname,'desc':adesc,'list':faveStuff};
    wsurvey.getJson.get('wsGalleryActions.php',adata,doFavorites_saveLocal2,'doFavorites_saveLocal');

}

function doFavorites_saveLocal2(response,origData) {

   hh=wsurvey.getJson.check(response,0,'doFavorites_saveLocal2 ');
   if (hh===false) return 1;

   var hideTreeList=0;
   let afavorites=$(document).data('enableFavorites');

   let warnings= hh['content']['warnings'] ;
   let fname= hh['content']['name'] ;
   let fdesc0= hh['content']['desc'] ;
   let fdesc=wsurvey.removeAllTags(fdesc0);

   let hcontent=wsurvey.htmlspecialchars(hh['content']['stuff']);
   let amess='';
   if (warnings.length>0) {
       amess+='<div style="border:3px dotted yellow;padding:1em;margin:1em;"> '+warnings.length+' warnings detected.<br>';
       amess+='This is usually because a directory was not inititalized -- hence snapshots &amp; thumbnails are missing.';
       amess+='<br>In this case: for some files thumbnails and snapshots may not be available ';
       amess+=' <input type="button" value="details" title="display the warnings" onClick="doFavorites_saveLocal2_warnings(1)">';
       amess+='<div id="favoritesWarnings" style="display:none;font-size:80%">';
       amess+='<pre>Warnings: <br>';
       amess+=warnings.join('<br>');
       amess+='</pre>';
       amess+='<div id="doFavorites_readLocal_use_view_warning"  style="margin:1em 2em 1em 2em;background-color:#cfefdf;padding:5px"></div>';
       amess+='</div>';
       amess+='</div>';
   }
   amess+='<div>The favorites-list specification (<span style="font-family:monospace" title="Desc: '+fdesc+'">'+fname+') </span>';
   amess+='is ready to be saved!</div>';

   if (afavorites==3)  {   // both
     amess+='<ul class="linearMenu">';
     amess+='<li class="linearMenuBlank">You can ... ';
     amess+='<li class="linearMenuLi2"><input type="button" value="Save locally" onClick="$(\'#favorites_saveLocal_outer\').toggle()">';
     amess+=' (on your computer, only you can use) ';
     amess+='<li class="linearMenuLi2"><input type="button" value="Save publically" onClick="doFavorites_save_public(this)">';
     amess+=' (on the server, anyone can use)   ';
     amess+='<input type="hidden" id="idoFavorites_save_public_name" value="'+fname+'">';
     amess+='<input type="hidden" id="idoFavorites_save_public_desc" value="'+fdesc+'">';
     amess+='<input type="hidden" id="idoFavorites_save_public_content" value="'+hcontent+'">';
     amess+='</ul>';
     amess+='<div id="idoFavorites_save_public_status" style="display:none;margin:3px 2em 3px 2em;border:1px solid gray">..</div>';
  }
  if (afavorites==2)  {   // local only
     amess+='<div id="favorites_saveLocal_outer">  ';
  } else {
     amess+='<div id="favorites_saveLocal_outer" style="display:none">  ';
  }
  amess+='<div title="this is the `favorites-list specification`" class="favorites_saveBox" id="iFavorites_local1">';
  amess+=hcontent;
  amess+='</div>';
     amess+="You need to take a few more steps ... ";
     amess+='<ol class="smooshedList">';
     amess+='<li> Open your favorite text editor ';
     amess+='<li> Click <input type="button" value="Select, and copy to clipboard, the favorites-list specification" title="select the text in the box above" onClick="doFavorites_saveLocal2_select(this)"> to copy it to the clipboard. ';
     amess+='<li> Paste it (into the text editor). Only paste this -- do not add or remove any other content!';
     amess+='<li>Save it to a file on your hard drive (as a .txt file).';
     let aread='<input type="button" value="Read" title="read a list of favorites (from local file or server)" onclick="doFavorites(this,3)">';
     amess+='<li> At a later date you can '+aread+' (from your hard drive) this <em>local</em> favorites-list.' ;
  amess+='</ul>';
  amess+='</div>';

   wsurvey.flContents.contents('admin',amess,{'show':1});

}

function doFavorites_saveLocal2_warnings(x) {   // show warnings
       doFavorites(this,777);
       $('#favoritesWarnings').toggle() ;
}
//===========
//seledt favorites createdion (for copy and pase)
function doFavorites_saveLocal2_select(athis) {
   wsurvey.selectText('iFavorites_local1','CLIP');
   return 1;
}

//=-----------------
// save to server
function doFavorites_save_public(athis) {
  let ehh=$('#idoFavorites_save_public_content');
  let acontent=ehh.val();
  let aname=$('#idoFavorites_save_public_name').val();
  let adesc=$('#idoFavorites_save_public_desc').val();
  let adata={'todo':'saveFavoritesPublic','content':acontent,'name':aname,'desc':adesc};
  wsurvey.getJson.get('wsGalleryActions.php',adata,doFavorites_save_public2,'doFavorites_save_public');
}


function doFavorites_save_public2(response,origData) {
   hh=wsurvey.getJson.check(response,0,'doFavorites_save_public2 ');
   if (hh===false) return 1;
   let smessage=hh['content'];
   $('#idoFavorites_save_public_status').html(smessage).show();
   return 1;

}

//================
// ret rieve and display lists of favorties (from server)
function doFavorites_getPublicLists(athis) {
  if (arguments.length<2) loadit=0;
  let adata={'todo':'getPublicFavoritesList'  };
  wsurvey.getJson.get('wsGalleryActions.php',adata,doFavorites_getPublicLists2,'doFavorites_getPublicLists');
}
 function doFavorites_getPublicLists2(response,origData) {
   hh=wsurvey.getJson.check(response,0,'doFavorites_getPublicLists2 ');
   if (hh===false) return 1;
   let smessage=hh['content'];
   $('#favorites_read_server').html(smessage).show();
}

//==========
// get a public favorite's list
function doFavorites_getPublic(athis,alist,loadit,afile) {
  let startup=1;
  if (arguments.length<2) {
    let ethis=wsurvey.argJquery(athis);
    alist=ethis.val();
    startup=0;
  }
  if (arguments.length<3) loadit=0;
  if (arguments.length<4) afile='';

  let adata={'todo':'getAPublicFavorite','name':alist,'startup':startup,'loadit':loadit,'dofile':afile };
  wsurvey.getJson.get('wsGalleryActions.php',adata,doFavorites_getPublic2,'doFavorites_getPublic');
}
 function doFavorites_getPublic2(response,origData) {
   hh=wsurvey.getJson.check(response,0,'doFavorites_getPublic2 ');
   if (hh===false) return 1;
   let hcontent=hh['content'];
   let startup=origData['startup'];
   if (hcontent['status']=='error') {
     $('#igetPublicFavoritesList').html(hcontent['stuff']);
     return 1;
   } else {
      let dacontent=hcontent['stuff'] ;
      $(document).data('favoritesSpecs',dacontent['allList']);
      $(document).data('favoritesSpecsAll',dacontent);
      let bmess='';
      bmess+='Favorites list <span style="font-weight:700" title="Desc: '+dacontent['desc']+'">'+dacontent['name']+'</span> ';
      bmess+=' has been retrieved. ';
      bmess+=' <input type="button" value="View" title="View the entries in the current list of favorites  " onclick="doFavorites(this,7777)">';

      bmess+='&nbsp;&nbsp;<input type="button" value="Display" title=" display buttons to view each of these files " onclick="showFavoritesDirFiles(this)">';

       bmess+='<div id="doFavorites_readPublic_use_view"  style="margin:1em 2em 1em 2em;background-color:#dfefcf;padding:5px" ';
      bmess+='  title="List of favorites (from public favorites list: '+origData['name']+') "></div>';
      if (startup==0) {
         $('#igetPublicFavoritesList').html(bmess);
      } else {
        wsurvey.flContents.content('admin',bmess,{'show':1,'onTop':1});
        let loadit=origData['loadit'];
        if (loadit==1)  showFavoritesDirFiles(this) ;
        let dofile=origData['dofile']  ;
        if (dofile!='') {
           if (!isNaN(dofile)) {
             let ehh=wsurvey.flContents.find('gallery','[buttonnumber="'+dofile+'"]');
             if (ehh.length==1)  {
                 let eh2=ehh.find('button');
                  window.setTimeout(function(){eh2.trigger('click' )},500);            // will contain data-entry and data-file attributes
             }
          } else {              // by name
             let dofileT=jQuery.trim(dofile);
             let ehh=wsurvey.flContents.find('gallery','[name="listOfFileInCurrentDir_button"]');
             let ehUse=false;
             if (ehh.length>0)  {
                 for (let iarf=0;iarf<ehh.length;iarf++) {
                      let  eh1=$(ehh[iarf]);
                      let thisone= jQuery.trim(eh1.text()) ;
                      if (thisone==dofile) {
                        ehUse=eh1;
                        break;
                      }
                 }  // for
                 if (ehUse!==false) {
                    window.setTimeout(function(){ehUse.trigger('click' )},500);            // will contain data-entry and data-file attributes
                 }
             }  // ehh
           }   //  nan dofile
        }        // dofile !=''

      }   // startup
      return 1;
   }
}


//==============
//==================
// show favorites as buttons in the dirlist
function showFavoritesDirFiles(athis) {
   let faves=$(document).data('favoritesSpecsAll');
   if (typeof(faves['allList'])=='undefined') {
     alert('No favorites currently selected ');
      return 0;
   }
   let allList=faves['allList'];
   let fname=faves['name'];
   let fdesc=faves['desc'] ;
   let ihow=0 ;  // text butto type

   let fileInfos= faves['fileInfo'];

   buttonList=showFavoritesDirFiles_buttonList(faves,ihow) ;  // might have to do some cleanup

    let nbuttons= buttonList.length;

    let messageHeader=faves['messageTop'];

     $(document).data('currentFiles_dirDesc',fdesc) ;
     $(document).data('currentFiles_snapshots',faves['snapshot']) ; // use to change menu layout

// creawte filestats
    let fileStats={};
    for (let j2 in fileInfos) {
        let aff1=fileInfos[j2];
        afilename=aff1['relSelFile'];
        let tt=aff1['fileInfo'];
        let poo={};
        poo['fileName']=aff1['realFileName'];
        poo['size']= tt['size'];
        poo['time']= tt['time'];
        poo['date']= tt['date'];
        poo['desc']= tt['desc'];
        poo['width']= tt['width'];
        poo['height']= tt['height'];
        poo['mimetype']= tt['mimetype'];
        poo['fullSel']= aff1['fullSel'];
        poo['uriSel']= aff1['uriSel'];

        if (typeof(fileStats[afilename])=='undefined') { //  no ot her file name in diffefent gallery/tree/dir (in this favofites)
           let poo2={};
           poo2['all']=[];   // used if another same file encountered
           poo2['all'][0]={} ;
           for (let ax in poo) {    // all[0] replicates the fields in poo2 -- since most of the time no duplicates
              poo2[ax]=poo[ax];
              poo2['all'][0][ax]=poo[ax];
           }
           fileStats[afilename]=poo2;
      } else {
           let poo2=fileStats[afilename] ;
           let pooall=poo2['all'];
           let ilen=pooall.length;
           pooall[ilen]={};
           for (let ax in poo) {    // all[0] replicates the fields in poo2 -- since most of the time no duplicates
              pooall[ax]=poo[ax];
           }
           poo2['all']=pooall;
          fileStats[afilename]=poo2; // first encount4ed for this filename are used as the "defaults"
      }
    }
    $(document).data('currentFiles_stats',fileStats) ; // use to change menu layout

    toggleDirVu(2);

// build html menu (of buttons) using buttonList (depend
     let stuff='';
     stuff+=messageHeader;
     stuff+='<div id="listOfFileInCurrentDir" class="listOfFileInCurrentDirC" nButtons="'+nbuttons+'">';

     let s3=showFileList_buttonView('from favorites','',buttonList ) ;

      stuff+=s3;
      stuff+='</div>' ;

      wsurvey.flContents.contents('gallery',stuff) ;
      wsurvey.flContents.onTop('gallery');

      let butts=wsurvey.flContents.find('gallery','[buttonnumber]');
      for  (let i1=0;i1<butts.length;i1++) {
          let abut=$(butts[i1]);
          let bnumber=abut.attr('buttonnumber');
          let tt=fileInfos[bnumber]['relSelDir'];
          tt=tt.slice(0,-1);
          abut.attr('data-dir',tt);
      }


      let  gheader=' <input type="button" value="&#10068;" title="Help for: viewing an image" onClick="doHelpVu(this)"  class="helpButton"  topic="viewFiles" > ';

      var hhsay='';
      hhsay+='<button  id="targetHereViewer_which"  name="targetHereWhich"  title="File display in next viewer"  ';
      hhsay+='        class="targetHere_off targetHereButton" data-which="0">&vellip;</button> ';      
      hhsay+='<span title="Files in favorites list   .... " style="padding-left:1em;border:1px solid cyan"> &#128154;';
      hhsay+='<span class="headerEmphasizer" > '+fname+'</span>';
      hhsay+=' <em>'+fdesc+'</em>';
      hhsay+='</span> ';

      wsurvey.flContents.header('gallery',gheader+hhsay);

      wsurvey.flContents.hide('admin',100);

      var eii=$('#iToggleScreenLayout'), aii=eii.attr('which');  //0:dual, 1:rotate, 2:tableau, 3: rotate,4: singlePair

      window.setTimeout( function(){
         $('#getImgInfo').trigger('click')     ;  // will show the 'directory description'

// click handler
         $('#listOfFileInCurrentDir').on('click',listOfFileClickHandler);

// some dropdowns
         let ddopts={'openerActive':'[name="whileDropdownOpen"]',
           'openerInactive':'[name="whileDropdownNotOpen"]','delayOnEnter':1000,
           'zindex':2300,'leftOffset':'-5em','topOffset':'1o+5','closers':'*'};
         let gg=wsurvey.dropdown('iopenerWhichViewer','dropdown_whichViewer',ddopts   );

         ddopts={'openerActive':'[name="whileDropdownOpen"]',
            'openerInactive':'[name="whileDropdownNotOpen"]','delayOnEnter':1000,
            'zindex':2300,'leftOffset':'-2em','topOffset':'1o+5','closers':'*'};
         gg=wsurvey.dropdown('iopenerGetSnapshot','dropdown_showSnapshot',ddopts);

         ddopts={'openerActive':'[name="whileDropdownOpen"]',
            'openerInactive':'[name="whileDropdownNotOpen"]','delayOnEnter':1000,
            'zindex':2300,'leftOffset':'-3em','topOffset':'1o+5','closers':'*'};
         gg=wsurvey.dropdown('iopenerShrink','dropdown_shrink',ddopts);
  
           let ej=$('[name="imageJumpButtons"]');
         if (aii!=3) {
               ej.show();
         } else {
             ej.hide();
             if (aii==0) $('#currentImageCursorSpot').hide();
         }

 // fix some stuff given other parameter values
         if (aii==1)  {       // rotating -- change file list options to avoid issues
          let dosaves={'shrink':'shrink','snap':'snapshot','viewer':'viewer1','info':0}; // same as which=0
          let doenables={'shrink':1,'snap':1,'viewer':0,'info':1};
          daopts={'save':dosaves,'enable':doenables};
          doResizeViewers_setButtons(daopts);
         }
         if (aii==2)  {       // tableau -- change file list options to avoid issues
          let dosaves={'shrink':'shrink','snap':'snapshot','viewer':'viewer1','info':0}; // same as which=0
          let doenables={'shrink':1,'snap':1,'viewer':0,'info':1};
          daopts={'save':dosaves,'enable':doenables};
          doResizeViewers_setButtons(daopts);
         }
         if (aii==4)  {       // singlePair -- change file list options to avoid issues
          let dosaves={'shrink':'shrink','snap':'snap','viewer':'viewer2','info':1};
          let doenables={'shrink':1,'snap':1,'viewer':0,'info':1};
          daopts={'save':dosaves,'enable':doenables};
          doResizeViewers_setButtons(daopts);
          wsurvey.flContents.onTop('snapBox2');
          wsurvey.flContents.onTop('gallery');
        }

      }  // settimeout
      ,120);

}  ///hh

//==============
// button list for favorites (text,thumbnails..)
function showFavoritesDirFiles_buttonList(faves,ihow) {
   let buttonList0,buttonList,btemp;
   if (ihow==1) {
        buttonList0=faves['thm40'] ;
      } else if (ihow==2) {
        buttonList0=faves['thm66'] ;
      } else if (ihow==3) {
       buttonList0=faves['thm90'] ;
      } else {
       buttonList0=faves['text'] ;
     }
   if (typeof(buttonList0)=='object' && !jQuery.isArray(buttonList0) ) { // might be an object (if added to)
        btemp=[];
        for (let ibb in buttonList0) {
            let ibb2=parseInt(ibb);
            btemp[ibb2]=buttonList0[ibb];
        }
        buttonList=btemp;
    } else {
       buttonList=buttonList0;
    }
    return buttonList
}

// ----------
// redisplay currently selected collection/entry -- used saved info from call to showCollectionDirFiles
function showFavoriteDirFiles_how(athis){

   let ethis=wsurvey.argJquery(athis);
   let ihow=ethis.attr('data-how');
   let fname=ethis.attr('data-favorites');

   let faves=$(document).data('favoritesSpecsAll');   // only one favorites list can be active
   if (typeof(faves['allList'])=='undefined') {
      alert('No favorites currently selected ');
      return 0;
   }
   let allList=faves['allList'];
   let fname2=faves['name'];
   let fdesc=faves['desc'] ;

   let fileInfos= faves['fileInfo'];

   buttonList=showFavoritesDirFiles_buttonList(faves,ihow) ;  // might have to do some cleanup
   showFileList_buttonView('from favorites','listOfFileInCurrentDir',buttonList ) ;

     return 1;
}

