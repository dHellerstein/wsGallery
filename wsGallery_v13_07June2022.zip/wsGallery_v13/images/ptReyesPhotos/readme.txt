Some photos from Pt. Reyes, CA. Circa 2019
