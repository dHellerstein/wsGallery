10 July 2025

The wsGallery/images directory is the default location for storing images and other files.
It is the location pointed to by the "_default" tree, in the wsGallery_treeList.php packaged
with wsGallery.

This is done as a convenience. That is: you don't need to use wsGallery/images.
Why? Typically, images and other viewable files are stored in a directories that are NOT under wsGallery! 

For illustrative purposes, a few nature photos (in two folders) are included! You can use these, along
with the sample wsGallery_treelist.php (in wsGallery/data/wsGallery_treelist_original.php) to practice wsGallery initialization.

Specifying directory descriptions. 

  A readme.txt files, in a subdirectory of a "tree root directory", is used as the default description of the directory.

     Example: wsGallery/images/capeCodPhotos/readme.txt contains a short description of the contents of capeCodPhotos.

  These descriptions are displayed in wsGallery's list of directory menus. If no readme.txt file is found a default description
   is created.

   An alternative way of specifying descripitons is to use a describe.txt the actual "tree root directory". 
   For example:  /www/myPhotos/describe.txt 

   Descriptions in describe.txt take precedence over descriptions in a readme.txt.

   Note that the admin can change directory descriptions using at any time.

