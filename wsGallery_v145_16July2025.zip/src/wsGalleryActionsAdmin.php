<?php
session_start() ;
ob_start();

use wSurvey\getJson as getJs  ;

// -----------------------------------
// action handle, ADMIN VERSION, for wsGallery  -- called from .js side use ajax (.get) functions
//
// Admin changeable parameters are in wsGallery_params.php,
//  what trees (directory paths) are set in wsGallery_treeList.php
//  username/password (for admin only are in wsCheckLogonParams.php
//
// -----------------------------------
//
// actions handled here:
// makeDirList      :create a list of directories in a tree. Save to to a tree specific dirList. json' 'cache' file
// updateFileDescs : update file descrptions
// displayFileDescs : display file descriptions (all files in a dir)
// disableATree : disable a tree
// doDisableDir :  disable view of a directory (in a tree). Tweaks the dirList for this dir
// dirCache  :   wsgallery-init a directory cache
// getAdminMenu  :  show menu of trees (to update, etc)
//
// may 2022: a number of "create collection" , "create favorites", "edit notes" functions
// july 2025 : getDirCacheStatus (see if directory contents have changed since last caching

//  ------------------------

$nowtime=time();
$rootdir=$_SERVER['DOCUMENT_ROOT'] ;
 $curDir=getcwd();
 $wsgDir=$curDir;
 if (substr($wsgDir,-3)=='src')  {
     $wsgDir=substr($wsgDir,0,strlen($wsgDir)-4) ;
 }

if (!array_key_exists('wsGallery_mainDir',$_SESSION)) {
        print 'Error: wsGallery_main is missing. $_SESSION has #fields= '. count($_SESSION)  ;
        exit;
}
$wsMainDir=$_SESSION['wsGallery_mainDir'];
if (trim($wsMainDir)=='') {
     print  "Error: wsGallery_main is empty. $_SESSION has #fields= ". count($_SESSION)   ;
     exit;
}

require_once($wsMainDir.'/libs/php/wsurvey.getJson.php');

require_once($wsMainDir.'/src/wsGalleryLibUtils.php');
require_once($wsMainDir.'/src/wsGalleryLibUtilsAdmin.php');
require_once($wsMainDir.'/src/wsGallery_dirList.php');
require_once($wsMainDir.'/src/wsGallery_dirCache.php');
require_once($wsMainDir.'/src/wsGallery_fileList.php');

$todo=extractRequestVar('todo','');

// put in admin check here (june 2022)
if ( (!array_key_exists('wsurveyadminLogon_status_wsGallery',$_SESSION) )  ||
     ($_SESSION['wsurveyadminLogon_status_wsGallery']==0 ) ) {
        getJs\jsonReturnError("wsGallery admin action ($todo) requires logon " );
        exit;
}



  //=====
// create a list of directories in a tree. Save to to a tree specific dirList. json' 'cache' file,
// called by js makeTreeDirList  and  makeTreeDirList_Go (timeout/resume)
if ($todo=='makeDirList') {

   $res=['status'=>'error','content'=>'','foo'=>'bake'] ;

  $logonOk=wsCheckLogon_logonStatusG('wsGallery') ;   // must be admin logon
  if ($logonOk[0]!=1) {
     if ($logonOk[0]==2) {
        $infos=['status'=>'okay','logonName'=>'wsGallery','expire'=>1,'content'=>'Logon session expired. Please relogon!  '];
     } else {
        $infos=['status'=>'error','logonName'=>'wsGallery','content'=>'You must be an administrator to make a directory list '];
        getJs\jsonReturn($infos);
        exit;
     }
   }
   $doThisTree=extractRequestVar('treeName','');
   if ($doThisTree=='') getJs\jsonReturnError('makeDirList error: no treename ');  // debug check feb 2022
   $askips=[];
   $askips1=trim(extractRequestVar('doSkips',''));
   if ($askips1!=='') {
     $askips2=explode(',',$askips1);
     foreach ($askips2 as $jj=>$aa) $askips[trim($aa)]=1;
   }

   $isPreview=trim(extractRequestVar('isPreview','0'));
   $keepDisabled=trim(extractRequestvar('keepDisabled',1));
   $keepDescriptions=trim(extractRequestvar('keepDescriptions',1));
   $removeUnusedCache=trim(extractRequestvar('removeUnusedCache',0));
   $mustHaveViewable=extractRequestVar('mustHaveViewable',1);
   $doResume=extractRequestVar('doResume',0);
   $timeAllowed=extractRequestVar('timeAllowed',3) ;                    // seconds allowed before early return (resumeStatus is set for next call)
   $describeFile=trim(extractRequestVar('describeFile',''));

// timeallowed is for first view. "resume" iterations use 3 or 4 seconds
// makeDirList_base is in wsGallery_dirlist.php -- it will save to dirlist. json

    $resa= makeDirList_base($doResume,$doThisTree,$keepDisabled,$keepDescriptions,$removeUnusedCache,
               $mustHaveViewable,$timeAllowed,$askips,$isPreview,$describeFile )  ;
     if ($resa['doResume']==1) {
        $tinfo=['status'=>'ok','doResume'=>1,'treeName'=>$doThisTree,'resumeMessage'=>$resa['content'],
               'keepDisabled'=>$keepDisabled,'mustHaveViewable'=>$mustHaveViewable,'removeUnusedCache'=>$removeUnusedCache];
        getJs\jsonReturn($tinfo);

    }

// not a resume

   $resa['resumeMessage']=count($resa['dirList']).' directories found.';

   if ($resa['status']=='ok') {         // success at find  directories with stuff in them.
      $resCache=makeDirList_makeCacheDirs($resa['dirList'],$doThisTree,$removeUnusedCache,$isPreview); // create cache dirs, possibly remove orphans
      if ($isPreview==1)  {    // a preview
           getJs\jsonReturnContent($resCache);
      }
      $resa['cacheInfo']=$resCache  ;
      if ($removeUnusedCache==1) {
        $resa['resumeMessage']='Cache directories created (orphans removed).';
      } else {
        $resa['resumeMessage']='Cache directories created.';
      }
   }
   getJs\jsonReturn($resa);


}

// ::::::::::::::::
// display all keywoirds for all files in adir
if ($todo=="displayFileKeywords"){
  $atreename=extractRequestVar('treename','');
  $agalleryname=extractRequestVar('galleryname','zzz');
  $adir=extractRequestVar('dir');
  $wsMainDir=$_SESSION['wsGallery_mainDir'];
  $gDir="$wsMainDir/galleries/$agalleryname/$atreename/$adir";
  if (!is_dir($gDir)) {
       getJs\jsonReturnContent(['message'=>"No directory for this file: $gDir "]);  // should never happen
  }
  

}


// :::::::::::::::::::::::
// display list of changeable file descriptions
if ($todo=="displayFileDescs"){
  $atreename=extractRequestVar('treename','');
  $agalleryname=extractRequestVar('galleryname','zzz');
  $adir=extractRequestVar('dir');
  $vstuff=doGetDirFileList(0,1,$atreename,$adir); // get   file desc list just for this dir (in atree)
 // var_dump($vstuff);exit;
  $vstats=$vstuff['fileStats'];

// which ones have notes?
 $wsMainDir=$_SESSION['wsGallery_mainDir'];
 $gDir="$wsMainDir/galleries/$agalleryname/$atreename/$adir";
 if (!is_dir($gDir)) {
       getJs\jsonReturnContent(['message'=>"No directory for this file: $gDir "]);  // should never happen
  }
  $notesGot=[];
  foreach ($vstats as $afile=>$afileStuff) {
   $gfile="$gDir/$afile.note";
   $gsize = (file_exists($gfile)) ? filesize($gfile) : false ;
   $notesGot[$afile]=$gsize;
  }


  $stuff='';
  $stuff.='<div   name="fileDescChangeTable" adir="'.$adir.'" treename="'.$atreename.'">';
  $stuff.='<table  style="border-collapse: collapse;" cellpadding="4" xrules="rows" >';
  $stuff.='<tr border="2px solid blue">';
  $stuff.='<th>';
  
//  $stuff.='<input type="button" value="&forall;&#128477;&#65039; " name="dirListKeywordButton" title="Click to view & change keywords for all files " ';
  $stuff.='<input type="button" value="&forall;&#128273;" name="dirListKeywordButton" title="Click to view & change keywords for all files " ';
    $stuff.='      data-dir="'.$adir.'" data-tree="'.$atreename.'"  data-gallery="'.$agalleryname.'" ';
    $stuff.=' onClick=" doChangeAllKeywords(this)" >' ;

// 11 july 2025 not working, so just use change and view
//  $stuff.='  <input type="button" value="&#128273;" title="View keywords for all files&#010;This will also create a keyword list (all keywords for all files in the directory) that users can view "  ';
//    $stuff.='   data-gallery="'.$agalleryname.'" data-tree="'.$atreename.'"  data-dir="'.$adir.'"  class="cShowKeywordAllLarge"  ' ;
//    $stuff.='     onclick="updateFileKeywordsToggle(this)"  "> ';

  $stuff.='  <input type="button" value="?" title="Help for: changing file" onclick="doHelpVu(this)" topic="changeFileDesc0" class="helpTopic_otherTopicButtonNarrow"> ';
  $stuff.='File</th>';
  $stuff.='<th>w x h </th><th>date</th>';
  $stuff.='<td> ';

  $stuff.='<input type="button" id="updateFileDescriptionsButton" value="Update file descriptions" title="Update the descriptions of files in this directory" onclick="updateFileDescriptions(this)"  ';
  $stuff.=' adir="'.$adir.'" treename="'.$atreename.'">';
  $stuff.='  <input type="button" value="?Desc" title="Help for: file descriptions" onclick="doHelpVu(this)" topic="changeFileDesc" class="helpTopic_otherTopicButtonNarrow"> ';
  $stuff.='  <input type="button" value="Import" title="Import file descriptions (in a csv)" onclick="doImportDesc(this)"  > ';
  $stuff.='  <input type="button" value="Export" title="Export file descriptions (as a  csv)" onclick="doExportDesc(this)" > ';

  $stuff.='</td></tr>';
  $stuff.='<tr  id="descriptionReport" style="display:none"><td colspan="4"><div  style= "border:2px solid tan;border-radius:3px" id="descriptionReport2">..</div></td></tr>';
 $ibb=0;
  foreach ($vstats as $afile=>$ainfo) {
      $amime=$ainfo['mimetype'];
      $afull=$ainfo['fullSel'];
     $stuff.='<tr style="border-top:1px solid blue"><td> ';
     $isnotimg='';
     $awidth=$ainfo['width']; $aheight= $ainfo['height'];
     if ($awidth=='') {
         $aext= pathinfo($ainfo['fullSel'],PATHINFO_EXTENSION) ;
         $isnotimg= ' isnotimg="'.strtolower($aext).'" ';
     }

     $ibb++;
     if ($notesGot[$afile]===false) { // no notes for this one
        $stuff.='<input type="button" value="&sung;" title="Currently: there are no notes for this file" onClick="editFileNotes(this)"  ';
        $stuff.='   data-gallery="'.$agalleryname.'" data-tree="'.$atreename.'"  data-dir="'.$adir.'" data-file="'.$afile.'" bnumber="'.$ibb.'" ' ;
        $stuff.=' > ';
     } else {
        $stuff.='<input type="button" style="color:green;border:1px solid lime;font-size:110%" value="&sung;" title="Currently: there are '.$notesGot[$afile].' bytes in the notes for this file" onClick="editFileNotes(this)"  ';
        $stuff.='   data-gallery="'.$agalleryname.'" data-tree="'.$atreename.'"  data-dir="'.$adir.'" data-file="'.$afile.'" bnumber="'.$ibb.'" ' ;
        $stuff.=' > ';
     }

     $stuff.='<button  '.$isnotimg.' file="'.$afull.'" name="fileDescChangeTable_viewFile" galleryname="'.$agalleryname.'" treename="'.$atreename.'"  showIn="2"  getSnap="2" doShrink="3" ';
     $stuff.=' title="'.$afull.' ('.$amime.')"> ';
     $stuff.= $afile.'</button>';
     $stuff.='</td>';
     $stuff.='<td><div class="fileDesc_dims">'.$awidth.' x ' .$aheight.'</div></td>';
     $bdate=date("M/j/Y",$ainfo['time']);
     $stuff.='<td><div class="fileDesc_date">'.$bdate.'</div></td>';
     $stuff.='<td><textarea title="Enter a description. No active (script, etc) html tags -- but simple (b, em. etc) are allowed" ';
     $adesc=$ainfo['desc'];
     $stuff.='   rows="1.5" cols="60" name="fileDescs" data-changed="0" afile="'.$afile.'" >'.$adesc.' </textarea>' ;
     $stuff.='</td></tr>';
     $stuff.='<tr>';
     $stuff.=' <td colspan="4">';
     $stuff.='<div name="fileKeywords" data-filekey="'.$afile.'" class="cFileKeywords" ';
     $stuff.='     style="display:none"><em>no keywords...</em></div>';
     $stuff.='</td></tr>';
  }
  $stuff.='</table>';
  $stuff.='</div>';
  getJs\jsonReturnContent($stuff);

}

//::::::::::::::::::
// read keywords for files in dir
if ($todo=='getKeywordsDir') {
  $atree=extractRequestVar('tree','');
  $agallery=extractRequestVar('gallery','main');
  $adir=extractRequestVar('dir','');
  $filesAlso=extractRequestVar('filesAlso','0');
  $forceDo=extractRequestVar('forceDo','0');
  $wsMainDir=$_SESSION['wsGallery_mainDir'];
  $gDir=$wsMainDir.'/galleries/'.$agallery.'/'.$atree.'/'.$adir.'/';
  $fileListUse=[];

  if ($filesAlso==1)  {  // get the file list
     $fileList=$gDir.'/_fileList.json' ;
     if (!file_exists($fileList))  getJs\jsonReturnContent(['keywordList'=>[],'cache'=>0,'okay'=>'no filelist','fileList'=>$fileListUse ]);
     $filelist2=file_get_contents($fileList);
     $fileListUse=json_decode($filelist2,true);
  }

 // does a "cache" (_keywords.json) exist? Is it new enough?
  $flagFile=$gDir.'_flag.txt';

  if (file_exists($flagFile) && $forceDo!=1)  { // maybe can use cache?
      $flagMtime=filemtime($flagFile);
      $keywordFile=$gDir.'_keyword.json';
      if (file_exists($keywordFile))  { // it exists
         $keyMtime=filemtime($keywordFile);
         if ($keyMtime>$flagMtime) { // not out of date
            $aa=file_get_contents($keywordFile);
            $bb=json_decode($aa,true);
            getJs\jsonReturnContent(['keywordList'=>$bb,'cache'=>1,'okay'=>1,'fileList'=>$fileListUse ]);
         }
      }
   }

// else, create from .note files  (and create .json on the fly)
  $keyWordList=createKeywordJson($gDir);
  getJs\jsonReturnContent(['keywordList'=>$keyWordList,'cache'=>0,'okay'=>1,'fileList'=>$fileListUse]);

}

//::::::::::::::::::
// save keywords for  multiple files in dir
if ($todo=='saveKeywordsFiles') {
  $atree=extractRequestVar('tree','');
  $agallery=extractRequestVar('gallery','main');
  $adir=extractRequestVar('dir','');
  $dchanges=extractRequestVar('changes',[]);
  $wsMainDir=$_SESSION['wsGallery_mainDir'];
  $gDir=$wsMainDir.'/galleries/'.$agallery.'/'.$atree.'/'.$adir.'/';
  $ddo=[];
  $dres=[];
  foreach ($dchanges as $ij=>$avv) {
      $fname=$avv['file'];
      $keya=$avv['keywords'];
      foreach ($keya as $ikoo=>$akey) $keyHash[$akey]=1;
      $checkf=$gDir.$fname.'.note';

      if (file_exists($checkf)) {        // exist: add new ones (From adin)
         $s1=file_get_contents($checkf);
         $kGot=json_decode($s1,true);
         $oof=['name'=>'admin','time'=>time(),'note'=>'','key'=>$keya];
         $kGot[]=$oof;
         $kGotJson=json_encode($kGot,JSON_UNESCAPED_UNICODE)    ;
         $qq=file_put_contents($checkf,$kGotJson);
         if ($qq>0) touch($checkf);
         $dres='For <tt>'.$fname.' : added (new size='.$qq.')';
         $ddo[]=$dres;

      } else {
         $kGot=['name'=>'admin','time'=>time(),'note'=>'','key'=>$keya];
         $kgot2=[];
         $kgot2[]=$kGot  ;  // one row per note (notes contain keywords)
         $kGotJson=json_encode($kgot2,JSON_UNESCAPED_UNICODE)    ;
         $qq=file_put_contents($checkf,$kGotJson);
         if ($qq>0) touch($checkf);
         $dres='For <tt>'.$fname.' : created (new size='.$qq.')';
         $ddo[]=$dres;

      }
  }
  $flagFile="$gDir/_flag.txt";
  $say1="Notes and keywords added (by admin) ...  ".time();
  $cc2=file_put_contents($flagFile,$say1);

  $keyWordList=createKeywordJson($gDir);
   $nInJsonWords=count($keyWordList, COUNT_RECURSIVE);
   $nInJson=count($keyWordList);

   $ddo[]="<hr>$nInJson files have $nInJsonWords  keywords (saved in _keyWords.json cache) ";

  getJs\jsonReturnContent($ddo);
}

//::::::::::::::
// update file descrptions
if ($todo=='updateFileDescs') {
   $noCache=$_SESSION['wsGallery_noCache'] ;
   if ($noCache==1) {
      $infos=['status'=>'error','content'=>'Sorry. Caching is disabled, so file descriptions can not be created '];
      getJs\jsonReturn($infos);
   }

   $adir=extractRequestVar('dir','');
   $atree=extractRequestVar('treeName','');
   $changes=extractRequestVar('changes');

   $fileList0=get_fileListCache('~'.$adir,$atree,2)  ; // since allowCache=2, just read from cache file.
   $fileList=$fileList0['fileList'];
   $dirDesc=$fileList0['desc'];
   $lookups=$fileList0['relSelLookup'];

  $oks=[];
   foreach ($changes as $ii=>$c1) {
       $cfile=$c1[0];
       if (!array_key_exists($cfile,$lookups)) {
           $oks[]="Could not save descrptions for: <tt>$cfile</tt> ";
           continue;
       }
       $ith=$lookups[$cfile];   // where in fileList?
       $daDesc= $c1[1] ;      // assume that caller already stripped tags (or removed active tags)
       $fileList[$ith]['desc']=$daDesc;
       $fileList[$ith]['fileInfo']['desc']=$daDesc;
       $oks[]= " <tt>$cfile</tt> "  ;
   }
   $fileList0['fileList']=$fileList;
   $fileList0['modeTime']=time();

    $cacheDir=$fileList0['pathSelectorInfo']['cacheDir'];
    if ($cacheDir=='' || !is_dir($cacheDir) )  {
      $infos=['status'=>'error',
             'content'=>"Unable to save descriptions: missing or bad cacheDir ($cacheDir) for  dir=$adir in tree=$atree  "];
      getJs\jsonReturn($infos );
    }

   $fileCache=$cacheDir.'/_fileList.json' ;      // can also be used below (if need to create or recreate this file)
   $goof=json_encode($fileList0, JSON_UNESCAPED_UNICODE);
   $nsave=file_put_contents($fileCache,$goof);     // filelist.json --  updateFileDescs
   $sayit='<ul  class="linearMenu"><li class="linearMenuLi3">'.implode('<li class="linearMenuLi3">',$oks).'</ul>';
   $stuff="Descriptions changed: ".$sayit ;
   getJs\jsonReturnContent($stuff);

}


//:::::::::::::
// disable view of a directory (in a tree). Tweaks the dirList for this dir
if ($todo=='doDisableDir') {
  $res=['status'=>'ok','content'=>''] ;
  $thisTree=trim(extractRequestVar('treeName',''));
  $doDisableList= extractRequestVar('disable',[] );    //an associative array
  $mustHaveViewable=extractRequestVar('mustHaveViewable',1);

   $nchanges=count($doDisableList);
   if ($nchanges>0) {          // if no changes, no call. Hence, doDisableList is always non-empty
      $res=dirList_changeStatus($thisTree,$doDisableList,$mustHaveViewable)  ;
   } else {
       $res['content']=" There were no directories selected (so no disable status are changed)";
   }
   getJs\jsonReturn($res);
}


// ::::
// wsgallery-init a directory cache.
if ($todo=='dirCache') {

  $logonOk=wsCheckLogon_logonStatusG('wsGallery') ;   // must be admin logon
  if ($logonOk[0]!=1) {
      $infos=['status'=>'nologon','logonName'=>'wsGallery'];
       getJs\jsonReturn($infos);
       exit;
   }

  $treeName=extractRequestVar('treename','');
  if ($treeName=='') getJs\jsonReturnError('adminAction dirCache error: no treeName was provided');  // feb 2022: no longer allow for "use default treename"

  $adir=extractRequestVar('dir','');    // adir is a subdirectory -- of the rootdir/rootsel of a treeName. Ie: it is NOT fully qualified

// feb 2022 : should only read this on first call FIX THIS

  $isReinit=extractRequestVar('reinit',0);
  $jstep=extractRequestVar('step',1);
  $action=extractRequestVar('action','start');
  $doResume=extractRequestVar('doResume',0);
  $timeAllowed=extractRequestVar('timeAllowed',4);
  $isMulti=extractRequestVar('isMulti',0);      // not used if action !=start or startmulti
   $removeAll=extractRequestVar('removeall','0');     // if here, subdire specific cache dir DOES exist.
   $doOverwrite=extractRequestVar('overwrite',0);  // the remaining steps may or may not overwrite existing files
   $retainDesc=extractRequestVar('retainDesc','1');

    $thisTreeInfo=getTreeInfo($treeName) ;    // deal with defaults
    $treeName2=$thisTreeInfo['treeName'];
    $imagesDir=$thisTreeInfo['useDir'];
    $infos=doDirCachePhp($imagesDir,$adir,$treeName2,$isReinit,$action,$doResume,$timeAllowed ,$isMulti,$removeAll,$doOverwrite,$retainDesc) ;  // this does the work (in wsgallery_dirCache.php

    getJs\jsonReturn($infos);
}


// show menu of trees (to update, etc)
// Note: instead of getDirListEntry calls : directly  read (of dirlist. json)
//
if ($todo=='getAdminMenu') {

   $treeList=$_SESSION['wsGallery_treeList'];
   $treeListStatus=$_SESSION['wsGallery_treeListStatus'];

   $currentTree=trim($_SESSION['wsGallery_currentTree']);

  $infos=['content'=>'','status'=>'ok'];
  $stuff='<div style="margin:3px 3em 3px 3em;font-weight:700">The current default treeName:<tt> '.$currentTree.'</tt> </div>';
  $stuff.='<div style="margin:4px 5em 4px 5em;display:none;background-color: #cbf9f9 " id="getDirAdmin_status">status messages</div>';

  $stuff.='<input type="button" value="&#10068;" title="View help on creating a directory listing" help" onClick="doHelpVu(this)" topic="dirCreateList"   class="helpButton" > ';

//  $stuff.='You can work with a <b>tree</b>; work with <b>directories</b> in a tree, ... or <span style="border:1px solid black;border-radius:2px">&#128065;&#9998; dirs</span>  a <u>tree</u> directory list   ';
  $stuff.='You can work with a <b>tree</b>; work with <b>directories</b> in a tree   ';
  $stuff.='   &hellip; or  create a <input type="button" value="&#128445; collection" class="cCreateCollection" title="create a collection" onClick="createCollection()"> ';
  $stuff.='  &hellip; or delete <input type="button" value="&#128153; favorites" class="cFavorites1" title="view/delete a favorites list (on the server)" onClick="deletePublicFavorites()">';


//   $stuff.='<div id="getAdminMenu_results" style="xdisplay:none;border:2px solid blue;margin:5px 3em 5px 3em;padding:5px"> ... </div>';

  $stuff.='<table id="iDirTreeManagement" title="Directory `tree` management" cellpadding="5" border="1" xrules="rows" style="max-height:16em;overflow:auto;margin:3px 2em 4px 2em;border:3px groove cyan">';
   $stuff.='<tr><td><b>TreeName</b> ';
   $stuff.=' <div style="font-size:80%"><input type="checkbox" checked title="the check box is used to disable, or enable, a directory" style="font-size:80%">uncheck to disable a tree </div>';
   $stuff.='</td>';
   $stuff.='<td><b>Tree</b> actions: refresh / update / create </td><td><b>Directories</b> (in a tree) actions: initialize / refresh / ...  </td><th>Tree description</th><th>Tree root</th><th>selector (under root)</th><th>dirs &amp; files</th></tr>';
  foreach ($treeList as $aTreeName=>$tinfo) {
     $aTreeName=trim($aTreeName);
     if (is_numeric($aTreeName) ) continue;
     $stuff.="<tr>";

     $treeDisabled=0;
     if (array_key_exists($aTreeName,$treeListStatus)) {
          if (array_key_exists('disable',$treeListStatus[$aTreeName] )) $treeDisabled=$treeListStatus[$aTreeName]['disable'];
     }

  // &#9745;&#65039; blue check,   &#127485; blue x   black x &#127367;
     if ($treeDisabled==1) {
        $disableMe='<input type="button" isDisabled="1" treename="'.$aTreeName.'" class="makeDirListDiableButton" title="Currently disabled: Click to Enable this directory tree" value="&#127367;" onClick="doDisableTree(this)">';
        $ccdisable=' class="cDisabledTree" ';
     } else {
        $disableMe='<input type="button"  isDisabled="0" treename="'.$aTreeName.'" class="makeDirListDiableButton" title="Currently enabled: Click to disable this directory tree" value="&#9745;&#65039;" onClick="doDisableTree(this)">';
        $ccdisable=' ';
     }
     if ($aTreeName==$currentTree)  {
       $stuff.=' <td><div style="white-space:nowrap;font-weight:700;text-decoration:underline;" title="The currently chosen tree">'.$disableMe.'<span '.$ccdisable.' name="atreename">'.$aTreeName.'</span></div></td> ';
     } else {
       $stuff.=' <td><div style="white-space:nowrap;font-weight:700;text-decoration:underline;"  title=" ">'.$disableMe.'<span '.$ccdisable.' name="atreename">'.$aTreeName.'</span></div></td> ';
     }

     $treeCacheDir=$tinfo['cacheTree'] ;
     if (!is_dir($treeCacheDir))  {   // this should never happen
         $stuff.='<td><span style="color:red">There is no cache directory for this tree ('.$treeCacheDir.').</span> The administrator must create it.';
         $stuff.=' (<a href="wsGallery_readMe.txt" target="notes">how to create</a>  ... see the notes in section II.c)';
         $stuff.='</td></tr>';
         continue;
     }
     $actualDir=rtrim($tinfo['rootDir'],'/').'/'.ltrim($tinfo['rootSel'],'/');

     $dirListJsonFile=$treeCacheDir.'/dirList.json';  // getAdminMenu direct call  -- better control of error messages
     $gotDirListJson=is_file($dirListJsonFile);

     $stuff.='<td>';               // the "create/update/refresh" tree
     if ($gotDirListJson) {            // dirlist. json (in cache dir) for this actual dir exists (in the
         $actualDirMod=filemtime($actualDir) ;
         $tt1=filemtime($dirListJsonFile);
         $updateDate=date("Y-m-d H:i",$tt1);
         if ($actualDirMod>$tt1)  {  // recent changes to actual directory -- new or removed subdir (but won't detect sub/sub dir changes
            $stuff.='<button  onClick="makeTreeDirList(this)" data-isUpdate="1"    data-treeName="'.$aTreeName.'" ';
            $stuff.=' title="There have been recent changes to the directory structure of this tree -- `update is recommended.&#010;Cache file modTime ('.number_format($tt1).') is older than actualDir  modTime ('.number_format($actualDirMod).')">';
            $stuff.='  <b>!update</b></button>';
//  feb 2022, no longer used rootDir="'.$tinfo['rootDir'].'" rootSel="'.$tinfo['rootSel'].'" stdOut="'.$tinfo['stdWwwDir'].'" ';
        } else {                        // no recent changes
            $stuff.=' <button  onClick="makeTreeDirList(this)"  data-isUpdate="1" data-treeName="'.$aTreeName.'" ';
            $stuff.='  title="No changes detected. You can `refresh` (to refresh file counts and other information).&#010;Last updated: '.$tt1.' = '.$updateDate.'">';
            $stuff.='refresh</button>';
// feb 2022, no longer used rootDir="'.$tinfo['rootDir'].'" rootSel="'.$tinfo['rootSel'].'" stdOut="'.$tinfo['stdWwwDir'].'"
         }
     } else {          // NO listing!
         $stuff.=' <button  onClick="makeTreeDirList(this)"    data-treeName="'.$aTreeName.'"  data-isUpdate="0" ';
         $stuff.='     title="No listing! To display the directories & files in this tree, you MUST create a directory list!">';
         $stuff.='<b>&#10069; Create </b></button>';
// feb 2022, no longer used   rootDir="'.$tinfo['rootDir'].'" rootSel="'.$tinfo['rootSel'].'" stdOut="'.$tinfo['stdWwwDir'].'"
     }
     $stuff.='</td>';

     $stuff.='<td>';
      if ($gotDirListJson)   {
            $stuff.='<input type="button"  treeName="'.$aTreeName.'" onClick="getDirCacheAdmin(this)"   ';
            $stuff.=' title="Select one or more directories, in this tree, to initialize (create thumbnails, etc)" value="&#128065;&#9998;dirs">';
            $dateCheck='<button  name="dirCheckStatusButton" treeName="'.$aTreeName.'"  title="check if out of date (any new files)?" onClick="checkDirCacheStatus(this)">&#128504;</button> ';
             $stuff.=$dateCheck ;

      } else {        // disable the "initialize a directory" menu IF dirlist. json is out of date. Enccourate admin to update dirlist. json!
            $stuff.='<input type="button"  disabled style="opacity:0.3" treeName="'.$aTreeName.'" onClick="getDirCacheAdmin(this)"   ';
            $stuff.=' title="dirList is out of date: When this tree`s  directory list is updated, on can then initialize its directories (create thumbnails, etc)" value="&#128065;&#9998;dirs">';
       }
     $stuff.='</td>';


     $stuff.='<td><div style="font-size:85%;font-style:oblique">'.$tinfo['desc'].'</div></td>';



     $stuff.='<td><div style="font-size:85%">';
     if ($tinfo['stdWwwDir']==1) { // stdout
        $stuff.='<span style="font-family:monospace;" title="This IS the root directory for this domain"> '.$tinfo['rootDir'].' </span>';
     } else {
        if ($tinfo['underStdWwwDir']==1) { // stdout
          $stuff.='<span style="font-family:monospace;" title="This is under the root directory for this domain (recommendation: change treelist.php!)"> &#9887; '.$tinfo['rootDir'].'</span>';
       } else {
            $stuff.='<span style="font-family:monospace;" title="This is OUTSIDE of  the root directory for this domain"> &#9888; '.$tinfo['rootDir'].'</span>';
       }
     }
     $stuff.='</div></td>'  ;
     $stuff.='<td><div style="font-size:80%">'.$tinfo['rootSel'].'</div></td>';


     if ($gotDirListJson)  {
       $jj1=file_get_contents($dirListJsonFile);
       $stuff3=json_decode($jj1,true);
       $baseI=$stuff3[1]['.'];
       $aDisabled= ($baseI['disabled']>0) ? '#disabled='.$baseI['disabled']  : '';
       $partiallyDisabled= ($baseI['partiallyDisabled']>0) ? ' #partiallyDisabled='.$baseI['partiallyDisabled']  : '' ;

       $stuff.='<td><div style="font-size:80%;overflow:auto;height:2.3em">  <tt>'.$baseI['totDirs'].' </tt>dirs ';
       if ($aDisabled!='' || $partiallyDisabled!='' )$stuff.=" ($partiallyDisabled $aDisabled) ";
       $stuff.=' w/<tt>'.$baseI['totFiles'].'</tt> files  (<tt>'.$baseI['totImages'].'</tt> images)</div></td>';
     }
     $stuff.='</tr>';
  }
  $stuff.='</table>';

  $stuff.='<div style="background-color:#dfefdf;padding:5px">Note: there are several admin changeable parameters in <tt>data/wsGallery_params.php</tt> ';
  $stuff.=' (such as <tt>switchGallery</tt>) ';
  $stuff.='</div>';

  $infos['skipSubDirs']=$_SESSION['wsGallery_skipSubdirs']  ;
  $infos['content']=$stuff ;
  $infos['treeUse']=$aTreeName ;
  getJs\jsonReturn($infos);
}     // getAdminMenu



//==============
// date sstatus chck of a tree
if ($todo=='getDirCacheStatus') {
  $atree=extractRequestVar('treename','');
  if ($atree=='')  getJs\jsonReturnError('getDirCacheAdmin error: no tree specified');

  $thisTreeInfo=getTreeInfo($atree) ;     // error exit if no such tree

  $useTree=$thisTreeInfo['treeName'];
  $treeCacheDir=$thisTreeInfo['cacheTree'];
  $treeCacheDir2=rtrim($treeCacheDir,'/');

  $stuff=[];

  $stuff['treeName']=$useTree ;
  $stuff['thisTreeInfo']=$thisTreeInfo;
  $stuff['error']=false;
  $stuff['info']=false;

  $vexts=[];
  $zexts= $_SESSION['wsGallery_specsExts']['allExts']  ;
  for ($j=0;$j<count($zexts);$j++) {
      $aext=strtolower($zexts[$j]);
      $vexts[$aext]=1;
  }

//   $stuff['allexts']=$vexts ;


  $adir0= $thisTreeInfo['useDir']    ;
  $adir=rtrim($adir0,'/');
  $adirLen=strlen($adir);
   $subList=getSubDirectories2($adir);
   $thisTreeInfo['subdirs']=$subList;
   $lookfors=[];
//   $lastTime=0;$newestFile=false;
   $igot=0;
   $nmodified=0;

   for ($i=0;$i<count($subList);$i++) {  // each subdir in this tree

       $bdir=$subList[$i];
       if ($bdir==$adir) continue ; // skip root

       $igot++;
       $cacheSel= trim(substr($bdir,$adirLen),'/');
       $filelist=trim($treeCacheDir2.'/'.$cacheSel.'/_fileList.json');
       $lookfors[$igot]=['bdir'=>$bdir,'filelist'=>$filelist,'dir'=>$cacheSel] ; // ,'treecachdir2'=>$treeCacheDir2,'cachecel'=>$cacheSel];

       if (!file_exists($filelist)) {
         $lookfors[$igot]['error']='No _fileList.json';
         $lookfors[$igot]['fileListTime']=false;
          continue  ; // try next dir
       }

      $filelistContents=file_get_contents($filelist);
      $filelistContentsUse=json_decode($filelistContents,true);
      $existingFileStuff=$filelistContentsUse['fileList'];

      $existingFiles=[];
      for ($iff=0;$iff<count($existingFileStuff);$iff++){
          $af3=$existingFileStuff[$iff]['relSelFile'];
          $existingFiles[$af3]=0;                  // assume actual file is not in the cached file list
      }

       $fileListTime=filemtime($filelist);

       $lookfors[$igot]['fileListTime']=$fileListTime ;

       $blook=$bdir.'/*'    ;
       $files =glob_file_only($blook);
       $lookfors[$igot]['nFiles']= count($files);

       if (count($files)==0) continue ;  // skip empty
//     $checkfiles=[];
//       $lastTime=0;           // reset for each subdir
       $nModified=0;
       foreach ($files as $ii=>$afile ) {   // ii=0;$ii<count($files);$ii++){
           $afile_name=basename($afile);
           if (array_key_exists($afile_name,$existingFiles)) {
              $existingFiles[$afile_name]=1;    // match       -- but might be modified?
              $fftime=filemtime($afile);
              if ($fftime>$fileListTime) {
                  $nModified++ ;
                  $existingFiles[$afile_name]=4;
              }
           } else {        // newly added .. but might be a non-recognized extension
              $myext=strtolower(pathinfo($afile_name)['extension']);
              if (array_key_exists($myext,$vexts)) {          // supported extensions
                 $existingFiles[$afile_name]=2;  // new addition. Note that preexisting avlue of 0, if still 0 at end of this function, means "recently removed)
              } else {
                 $existingFiles[$afile_name]=3;  // new addition, but not supported (can be ignored)
              }
           }          // not in existing files

//          $fftime=filemtime($afile);
//          $checkFiles[]=['file'=>$afile,'time'=>$fftime];
//          if ($fftime>$lastTime) {
//           if ($fftime>$fileListTime) {
//             $nModified++ ;
//             $lastTime=$fftime;
//             $newestFile=$afile;
//          }

       }         // each file in this subdir

       $gotMatch=[0,0,0,0,0] ; // 0: missing, 1:match, 2: add
       foreach ($existingFiles as $zname=>$zmatch) $gotMatch[$zmatch]++ ;

       $lookfors[$igot]['existingFiles']=$existingFiles;
//       $lookfors[$igot]['newest']=$lastTime;
       $lookfors[$igot]['matches']=$gotMatch;
       $lookfors[$igot]['modified']=$nModified;

       if ($nModified>0 || $gotMatch[0]>0 || $gotMatch[2]>0 ) {   // note: added file of non-supported extension is NOT a needsUpdate condition!
           $lookfors[$igot]['needsUpdate']=1;
       } else {
           $lookfors[$igot]['needsUpdate']=0;
       }

   }    // each subdir in this tree

   $stuff['info']=$lookfors;
     $stuff['info']=$lookfors;
   getJs\jsonReturn($stuff);
}

function glob_file_only($path){
    return array_filter(glob($path,GLOB_MARK),function($file){
        return substr($file,-1)!=DIRECTORY_SEPARATOR;
    });
}

function getSubDirectories2($dir) {      //https://stackoverflow.com/questions/2524151/php-get-all-subdirectories-of-a-given-directory
    $subDir = array();
    $directories = array_filter(glob($dir), 'is_dir');
    $subDir = array_merge($subDir, $directories);
    foreach ($directories as $directory) $subDir = array_merge($subDir, getSubDirectories2($directory.'/*'));
    return $subDir;
}

function getDirsx($path, $recursive = false, array $filtered = []) {
    if (!is_dir($path)) {
        throw new RuntimeException("$path does not exist.");
    }

    $filtered += ['.', '..'];

    $dirs = [];
    $d = dir($path);
    while (($entry = $d->read()) !== false) {
        if (is_dir("$path/$entry") && !in_array($entry, $filtered)) {
            $dirs[] = $entry;

            if ($recursive) {
                $newDirs = getDirs("$path/$entry");
                foreach ($newDirs as $newDir) {
                    $dirs[] = "$entry/$newDir";
                }
            }
        }
    }

    return $dirs;
}

//====
// get list of trees in a gallery  -- used by collection specifiction tool
if ($todo=='collection_treeList') {
   $wsMainDir=$_SESSION['wsGallery_mainDir'];
   $agallery=extractRequestVar('gallery','main');
   $sGalleries=glob($wsMainDir.'/galleries/'.$agallery.'/*', GLOB_ONLYDIR );
   $gnames=[];
   foreach ($sGalleries as $a1=>$b1) {
     $gnames[]=pathinfo($b1,PATHINFO_FILENAME);
   }
   getJs\jsonReturnContent($gnames);
}

//==========
// read the dirlist. json for   a tree -- collection mode
if ($todo=='collection_dirList') {
  $checkems=['_fileList','_buttonList_text','_buttonList_thm40','_buttonList_thm66','_buttonList_thm90','_snapshots'];

  $agallery=extractRequestVar('gallery','');
  $atree=extractRequestVar('tree','');
  $wsMainDir=$_SESSION['wsGallery_mainDir'];
  $trydir=$wsMainDir.'/galleries/'.$agallery.'/'.$atree;
  if (!is_dir($trydir))    getJs\jsonReturnError('no such directory: '.$trydir);
  $jsonfile=$trydir.'/dirList.json' ;
  print " $trydir | and json file $jsonfile ";
  if (!file_exists($jsonfile))  getJs\jsonReturnError('no such treelist.json file: '.$jsonfile);

  $goo=file_get_contents($jsonfile);
  $stuff=json_decode($goo,true);

  $dirLookup=$stuff[1]['.']['dirLookup'];
  $checkProblems=[];
   foreach ($dirLookup as  $adir=>$idx) {
      $dirStuff=$stuff[1][$idx];
      $isDisabled=$dirStuff['isDisabled'];
      if ($isDisabled==1) {
          $checkProblems[$adir]='disabled';
          continue;
      }
      $cacheDir=$dirStuff['cacheDir'];
      $isDesc=$dirStuff['dirDesc'];
      foreach ($checkems as $ijj=>$aff) {
          $dafile=$cacheDir.'/'.$aff.'.json';
          if (!file_exists($dafile)) {
             $checkProblems[$adir]='Missing file: '.$dafile;
             break ;
          }
      }
   }
   $stuff['checkProblems']=$checkProblems;
   getJs\jsonReturn($stuff);
}

//=============
// read the dirlist. json for   a tree -- admin mode menu of trees (to update, etc). Returns html table, list of dirs, basics
// read dirlist. json directly (insteads of use getDirListEntry) -- to catch out of date files
if ($todo=='getDirCacheAdmin') {

  $atree=extractRequestVar('treename','');

  if ($atree=='') getJs\jsonReturnError('getDirCacheAdmin error: no tree specified');

//  $needUpdates=extractRequestVar('needUpdates');
//  $needUpdatesUse=[];
//  if ($needUpdates!=='')  {
//      $needUpdates1=explode(',',$needUpdates);
//      for ($m1=0;$m1<count($needUpdates1);$m1++) {
//          $amm=$needUpdates1[$m1];
//          $needUpdatesUse[$amm]=1;
//      }
//  }

  $thisTreeInfo=getTreeInfo($atree) ;     // error exit if no such tree

  $useTree=$thisTreeInfo['treeName'];
  $treeCacheDir=$thisTreeInfo['cacheTree'];

  $dirListJsonFile=$treeCacheDir.'/dirList.json';   // getDirCacheAdmin direct call  -- better control of error messages
   if (!is_file($dirListJsonFile)) {        // shluld not happen
       getJs\jsonReturnError("$useTree problem:  $dirListJsonFile cacheFile is unavailable");
   }
  $dirListJsonFileMod=filemtime($dirListJsonFile);
  $dirListJsonFileModView=date("Y-m-d H:i",$dirListJsonFileMod);

  $actualDir=rtrim($thisTreeInfo['rootDir'],'/').'/'.ltrim($thisTreeInfo['rootSel'],'/');
  $actualDirMod=filemtime($actualDir) ;
  $actualDirModView=date("Y-m-d H:i",$actualDirMod);

  if ($actualDirMod>$dirListJsonFileMod)  {  // recent changes to actual directory -- new or removed subdir (but won't detect sub/sub dir changes
    $res=['status'=>'ok','basics'=>'oof1'];
    $asay="The directory structure of  tree (<tt>$actualDir</tt>  changed ($actualDirModView)-- the dirList. json <em>cache file</em> is ";
    $asay.=" <b>out of date</b> ($dirListJsonFileModView). You should <button onClick=\"wsurvey.flContents.onTop('admin',1)\">!update</button> (or refresh) the directory list for this tree.";
    $res['content']=$asay;
    getJs\jsonReturn($res);
  }

  $jj1=file_get_contents($dirListJsonFile);
  $stuff3=json_decode($jj1,true);
  $useDirs=$stuff3[1] ;        // the dirlist is useable. [0] is the non-admin list of driectorues -- not used for this "admin mode"

  $t1=makeDirList_create_dirsTableHeader($useTree,1) ;
  $t2=makeDirList_create_dirsTable($useDirs,0,1);


  $basics=[];
  $basics['totDirs']=$useDirs['.']['totDirs'];
  $basics['treeName']=$useDirs['.']['treeName'];
  $basics['totFiles']=$useDirs['.']['totFiles'];
  $basics['totImages']=$useDirs['.']['totImages'];
  $basics['disabled']=$useDirs['.']['disabled'];
  $basics['partiallyDisabled']=$useDirs['.']['partiallyDisabled'];
  $basics['desc']=$useDirs['.']['desc'];     // tree description

  $res=['status'=>'ok','content'=>$t1.$t2,'basics'=>$basics ];

//  $res=['status'=>'ok','content'=>$t1.$t2,'basics'=>$basics,'needUpdatesUse'=>$needUpdatesUse];

  getJs\jsonReturn($res);


}     //  getDirCacheAdmin


if ($todo=='updateDirDescs') {
   $treename=extractRequestVar('treename','');
   $dlist=extractRequestVar('list','');
   $lookups=[];
   foreach ($dlist as $ith=>$xx) {
       $adir=$xx[0]; $atitle=strip_tags($xx[1]);
       $lookups[$adir]=$atitle;
   }

   $useDirs=getDirListEntry('*',$treename,1);     // transformed for updateDIrDesc quicker lookup
   if (array_key_exists('.error',$useDirs))  {
       getJs\jsonReturnContent($useDirs['error']); // most likely a "no dirlist. json"
   }

   $ndid=[];
   foreach ($useDirs as  $bdirname=>$bdir) {
       if (!array_key_exists('dirname',$bdir)) continue ;
       $bdirname=$bdir['dirname'];
       if (array_key_exists($bdirname,$lookups)) {
//           $useDirs[$bdirname]['readme']=$lookups[$bdirname];
           $useDirs[$bdirname]['dirDesc']=$lookups[$bdirname];
           $ndid[]=$bdirname;
       }
   }

   setDirListEntry('**',$treename,$useDirs,0,1);     // ** to reacrate html menu -- untransform the dirlist! And okay to work with noViewable dirs

   $sfoo="<b>Descriptions</b> in $treename updated: ".implode(', ',$ndid) ;
   $sfoo.=' &boxV; <input type="button" title="Click to reload wsGallery" value="reload" onClick="wsGallery_reload(this,1,0)" > to update this tree\'s <em>directory list</em> ';

   getJs\jsonReturnContent($sfoo );
}


//===============
// disable a tree
if ($todo=='disableATree') {
   $atreename=extractRequestVar('treename','');
   $isTreeDisabled=extractRequestVar('current','');
   if ($isTreeDisabled==0) {                       // curently enabled
      $nowDisabled=1;
      $sayEnable=" disabled ";
   } else {
      $nowDisabled=0;
      $sayEnable  = ' enable ';
  }

   $dataDir=$_SESSION['wsGallery_dataDir'] ;
   $treeListJsonStatus=$dataDir.'/treeListStatus.json';

   if (!is_file($treeListJsonStatus))   getJs\jsonReturnError("Unable to find  treeListStatus (trying to change $atreename): $treeListJsonStatus " );

   $arf3=@file_get_contents($treeListJsonStatus );
   $statusStuff=json_decode($arf3, true);
   if (!array_key_exists($atreename,$statusStuff)) {  // should not happen
        $statusStuff[$atreename]=['disable'=>$nowDisabled];
    } else {
        $statusStuff[$atreename]['disable']=$nowDisabled;
   }
   $goof5=json_encode($statusStuff, JSON_UNESCAPED_UNICODE);
   $nsave=file_put_contents($treeListJsonStatus,$goof5);     // treeListStatus.json -- won't happen if nocache  set above

   $dog=getTreeList(0) ; // a shortcut to update $_SESSION vars
   if (array_key_exists('error',$dog)) {
      getJs\jsonReturnError('Problem updating session info (after dir disable) ',$dog);
   }
   getJs\jsonReturnContent("Tree: <tt>$atreename</tt> is <b>$sayEnable</b>: (bytes written: $nsave)");

}

// :::: collection functions .....

//==========
// save the colletion
if ($todo=='saveCollection') {
  $cname=extractRequestVar('name','');
  if (trim($cname)=='')  getJs\jsonReturnError("No name specified");

  $overwrite=extractRequestVar('overwrite','0');

  $grub=['\\','/',':',',']  ;
  $cname=str_replace($grub,"_",$cname);
  $cdesc=extractRequestVar('desc','');
  $centries=extractRequestVar('entries','');
  $cc=explode("\n",$centries);
  $cuse=[]; $comments=[];
  foreach ($cc as $ia=>$vv) {       // check for rrors
      $vv2=trim($vv);
      if ($vv=='' ) continue;
      if (substr($vv,0,1)==';'){
         $comments[]=substr($vv,1);
         continue;
      }
      $vv3=explode(':',$vv,2);
      if (count($vv3)!==2) getJs\jsonReturnError("Bad entry (nothing after :) : <tt>$vv</tt>");
      $vname=$vv3[0];
      $zub=preg_split("/[\s,]+/", $vname);
      if (count($zub)!=1) getJs\jsonReturnError("Bad entry (name must be a single word) : <tt>$vname</tt>");

      $ps=explode(',',$vv3[1],4);
      if (count($ps)<3)  getJs\jsonReturnError("Bad entry (gallery,tree,dir not specified as csv) : <tt>".$vv3[1]."</tt>");
      if (trim($ps[0])=='' ) getJs\jsonReturnError("Bad entry (no gallery specified) : <tt>$vv</tt>");
      if (trim($ps[1])=='' ) getJs\jsonReturnError("Bad entry (no tree specified) : <tt>$vv</tt>");
      if (trim($ps[2])=='' ) getJs\jsonReturnError("Bad entry (no directory specified) : <tt>$vv</tt>");
      if (count($ps)<4) $ps[3]='';
      $ps[4]=$vname;
      $cuse[]=$ps;
  }
  $goo=[];
  $goo['name']=$cname;
  $goo['desc']=$cdesc;
  $goo['entries']=$cuse;
  $goo['comments']=$comments;
  $wsMainDir=$_SESSION['wsGallery_mainDir'];
  $jfile=$wsMainDir.'/data/collections/B_'.$cname.'.json';
  $doover=' written to ';
  if (file_exists($jfile)) {
     if ($overwrite==0) getJs\jsonReturnError("Bad entry (collection directory already exists):  <tt>$jfile</tt>");
     $doover=' updated in ';
  }

// ... now create dirlist & filelist for each entry in this collection (for sving to C_collectionName.json
  $jfileCache=$wsMainDir.'/data/collections/C_'.$cname.'.json';
  $gooCache=[];

  foreach ($cuse as $ic=>$acc) {
    $bgallery=$acc[0]; $btree=$acc[1]; $bdir=$acc[2]; $bentry=$acc[4] ;
    $ff=getDirInfo_collection( $cname,$bgallery,$btree, $bdir,$bentry)    ;
    if ($ff[0]=='error') getJs\jsonReturnError($ff[1]);
    if (array_key_exists($bentry,$gooCache)) getJs\jsonReturnError("Multiple entries with the same name ($bentry) in collection $cname ");
    $gooCache[$bentry]=$ff[1];
  }

// all good -- save tmen
  $goo2=json_encode($goo, JSON_UNESCAPED_UNICODE);
  $ss=file_put_contents($jfile,$goo2);

  $goo3=json_encode($gooCache, JSON_UNESCAPED_UNICODE);
  $ss=file_put_contents($jfileCache,$goo3);

  $goo['result']=count($cuse).' entries '.$doover.' to collection <b>'.$cname.'</b>';
  getJs\jsonReturnContent($goo);
}

// list info on a colletion
if ($todo=="collection_viewDetails") {
  $acollection=extractRequestVar('collection','');
   $wsMainDir=$_SESSION['wsGallery_mainDir'];
   $jfile=$wsMainDir.'/data/collections/B_'.$acollection.'.json';
   if (!file_exists($jfile)) getJs\jsonReturnError('No such collection: '.$acollection);
   $xx=file_get_contents($jfile);
   $xx2=json_decode($xx,true);
   $bmess='';
   $bmess.='For collection: <b>'.$xx2['name'].'</b> <span style="font-style:oblique" title="Description">'.$xx2['desc'].'</span>';
   $bmess.='<ul class="selectFileMenu" style="overflow:auto">';

   foreach ($xx2['entries'] as $ia=>$vv) {
     $agallery=$vv[0]; $atree=$vv[1] ; $adir=$vv[2];
     $aentry=$vv[4];
     $aurl='';
     $dd="$aentry in collection $acollection: $agallery /  $atree / $adir  ";
     $aurl.='  <span title="Quick view of files in entry '.$dd.' " >';
     $aurl.=' <button ';
     $aurl.=' data-collection='.$acollection;
     $aurl.=' data-entry='.$aentry;
     $aurl.=' data-gallery='.$agallery;
     $aurl.=' data-tree='.$atree;
     $aurl.=' data-dir='.$adir;
     $aurl.='  onClick="collectionViewFiles_admin(this)" ';
     $aurl.='>&#128065;</button>';
     $aurl.='</span>';

     $aurl.='  <span title="View this directory in an external viewer"> ';
     $aurl.='<a class="makeDirListGoButton" href="wsGallery_simple.php?';
     $aurl.='useGallery='.$agallery;
     $aurl.='&useTree='.$atree;
     $aurl.='&useDir='.$adir;
     $aurl.='&useFile=0';
     $aurl.="&headerLine=Collection+Preview:+files+in:+$agallery+/+$atree+/+$adir" ;
     $aurl.='&autoAdjustSize=1';
     $aurl.='" target="viewer" title="Preview the files in this gallery/tree/dir">&neArr;</a>';
     $aurl.='</span>';
     $bmess.='<li class="selectFileMenuLi">'.$aurl.' <b>'.$aentry.'</b> <span title="Description of this directory" style="font-style:oblique">'.$vv[3].'</span>';

//     $bmess.='<li>'.$aurl.' <b>'.$aentry.'</b>:  <tt>'.$agallery.' / '.$atree.' / '.$adir.'</tt> <span title="Description of this directory" style="font-style:oblique">'.$vv[3].'</span>';
   }
   $bmess.='</ul>';
   getJs\jsonReturnContent($bmess);

}

//=============
// remove a collection
if ($todo=='collection_remove') {
    $acollection=extractRequestVar('collection','');
    $wsMainDir=$_SESSION['wsGallery_mainDir'];
    $jfile=$wsMainDir.'/data/collections/B_'.$acollection.'.json';
    if (!file_exists($jfile)) getJs\jsonReturnError('No such collection: '.$acollection);
    $qq=unlink($jfile);

    $jfile2=$wsMainDir.'/data/collections/C_'.$acollection.'.json';
    $qq2=unlink($jfile2);

    if ($qq2)  getJs\jsonReturnContent('Collection removed: '.$acollection);
     getJs\jsonReturnError('Unable to remove collection: '.$acollection);
}

//=============
// edit a collection
if ($todo=='collection_edit') {
    $acollection=extractRequestVar('collection','');
    $wsMainDir=$_SESSION['wsGallery_mainDir'];
    $jfile=$wsMainDir.'/data/collections/B_'.$acollection.'.json';
    if (!file_exists($jfile)) getJs\jsonReturnError('No such collection: '.$acollection);
    $jstuff=file_get_contents($jfile);
    $jvars=json_decode($jstuff,true);
     getJs\jsonReturnContent($jvars);
}


//============
// retrieve info for an entry in a collection  (similar  to getCollectionFiles in wsGalleryActoins
if ($todo=='getCollectionFiles_admin') {
    $acollection=extractRequestVar('collection','');        // relative dir (relative to treename rootDir/rootSel
    $aentry=extractRequestVar('entry','');        // relative dir (relative to treename rootDir/rootSel

    $wsMainDir=$_SESSION['wsGallery_mainDir'];

    $file1=$wsMainDir.'/data/collections/C_'.$acollection.'.json';
    if (!file_exists($file1)) getJs\jsonReturnError("No spec file for collection $acollection ($file1)");
    $stuff=file_get_contents($file1);
    $jstuff=json_decode($stuff,true);
    if (!array_key_exists($aentry,$jstuff))  getJs\jsonReturnError("No entry ($aentry) in  file for collection $acollection ($file1)");
    $daEntry=$jstuff[$aentry];
    $buttonFile=$daEntry['basic']['buttonList'];
    if (!file_exists($buttonFile)) getJs\jsonReturnError("No text-button list for $acollection / $aentry ($buttonFile)");
    $bstuff=file_get_contents($buttonFile);
    $bjson=json_decode($bstuff,true);
    getJs\jsonReturnContent(['all'=>$jstuff[$aentry],'buttons'=>$bjson]);
}

//========================
// admin logon to fix treelist
if ($todo=='logonAdmin_fix') {

  //      getJs\jsonReturnContent($_SESSION);
     $useGallery=  $_SESSION['wsGallery_useGallery'] ;

     $qok=initTreeList('fix',0,$useGallery);
     if ( $qok[0]!==true)  {
          $errMess="Problem creating tree list "  ;
          $qok['message']=$errMess.': '.$qok[1];
          $qok['ok']=0;
          getJs\jsonReturnContent($qok);
     }
     $treeListUse0=getTreeList(0);  //  try again! To get the newly created stuff (that was saved to .json files)
     if (array_key_exists('error',$treeListUse0)) { // shouldn't happen....
        $errMess='Error: unable to create treelist: '.$treeListUse0['error']  ;
        getJs\jsonReturnError($errMess,$treeListUse0);
        exit;
     }
     $qok['treeListUse']=$treeListUse0;
     $qok['gallery']=$useGallery;
     $qok['ok']=1;
     $qok['messages']=$qok[2];

     getJs\jsonReturnContent($qok);

}


//========================
// admin logon to fix params
if ($todo=='logonAdmin_fixParams') {
     require_once($curDir."/wsGalleryLibUtilsAdmin.php");
     $wsgp=makeWsGalleryParams(1);
     getJs\jsonReturnContent($wsgp);  // false true, message or array with paramers, extra info for some errorsw
}

//========================
// admin logon to fix params
if ($todo=='logonAdmin_fixSpinners') {
     require_once($curDir."/wsGalleryLibUtilsAdmin.php");
     $spinnerList=makeSpinnerList(300000,$_SESSION['wsGallery_mainDir']);  // max size of file to use as a spinner (in bytes). You could change this
     getJs\jsonReturnContent($spinnerList);  // false true, message or array with paramers, extra info for some errorsw
}

//=============
// list of public favorites
if ($todo=='listPublicFavorites') {
   $wsMainDir=$_SESSION['wsGallery_mainDir'];
    $favesDir=$wsMainDir.'/data/favorites/';

   $jfiles=$wsMainDir.'/data/favorites/C_*.json';
   $sCollections=glob($jfiles  );
   if (count($sCollections)==0) {
     getJs\jsonReturnContent('There are no available <em>public</em> favorites-lists');
   }
   $danames=[]; $oof='';
   foreach ($sCollections as $ij=>$a1) {
      $goofile=file_get_contents($a1);
      $gooJson=json_decode($goofile,true);
      if (!array_key_exists('allList',$gooJson)) continue ; // not a valid favorites list
      $fname=$gooJson['name']; $fdesc=$gooJson['desc'];
      $danames[]='<input type="button" value="'.$fname.'"  title="Desc: '.$fdesc.'"  onClick="deletePublicFavoritesDo(this)">' ;
   }
   $oof.='You can delete (one at a time) any of the <tt>'.count($danames).'</tt>  <em>public</em> favorites-lists   ';
   $oof.='<ul class="linearMenu"><li class="linearMenuLi">'.implode('<li class="linearMenuLi">',$danames).'</ul>';
   $oof.='<div id="idelPublicFavoritesList" style="margin:3px 1em 3px 1em;background-color:#dffddf"> ... </div>';
   getJs\jsonReturnContent($oof);

}

//=========
// delete a public faves
if ($todo=='deleteAPublicFavorites') {
    $aname=extractRequestVar('name');
    $wsMainDir=$_SESSION['wsGallery_mainDir'];
    $afavorite=$wsMainDir.'/data/favorites/C_'.$aname.'.json';
    if (!file_exists($afavorite)) getJs\jsonReturnError('No such favorites list: '.$afavorite);
    $qq=unlink($afavorite);

    if ($qq)  getJs\jsonReturnContent('Favorite-list (public) removed: '.$afavorite);
    getJs\jsonReturnError('Unable to remove favorite-list (public): '.$afavorite);
}

//=========
// save a full set of filenotes (after admin edits)
if ($todo=='saveAFileNotes') {
   $newnotes=extractRequestVar('stuff',[]);
   $odata1=extractRequestVar('location','');       //[agallery,atree,adir,afile,bnumber];

   $odata=explode(',',$odata1);
   $agallery=$odata[0]; $atree=$odata[1]; $adir=$odata[2];$afile=$odata[3];
   $sayWhere='For <span title="gallery / tree / dir / file ">'." $agallery /  $atree  / $adir  / $afile  </span>";

   $newnotesJson=json_encode($newnotes, JSON_UNESCAPED_UNICODE);
   $amess=$sayWhere.' : '.count($newnotes).' to be saved ';
   $wsMainDir=$_SESSION['wsGallery_mainDir'];
   $gDir="$wsMainDir/galleries/$agallery/$atree/$adir";
   if (!is_dir($gDir)) {
       getJs\jsonReturnContent(['message'=>"No directory for this file: $gDir "]);
   }
   $gfile="$gDir/$afile.note";

   $qq=file_put_contents($gfile, $newnotesJson)  ;
   $amess.='<br>Bytes saved: '.$qq ;
    $amess.='<br>';
    $amess.=' <input type="button" value="Close this file-notes menu!"  ';
    $amess.='    title="When done edting file-notes, we advise using this -- it will clean up the singleImage viewer!" ';
    $amess.='    onclick="$(\'#singleImageOtherInfo\').hide()"  >';
    
   $flagFile="$gDir/_flag.txt";
   $say1="Notes and keywords added (by admin): ".time();
   $cc2=file_put_contents($flagFile,$say1);

   getJs\jsonReturnContent(['message'=> $amess]);
}



//=======
// get dirLIst and fileList info for a gallery/tree/dir (an entry in a collection)
function getDirInfo_collection($acollection,$agallery,$atree,$adir,$aentry) {
    $wsMainDir=$_SESSION['wsGallery_mainDir'];
    $dir1=$wsMainDir.'/galleries/'.$agallery;
    if (!is_dir($dir1)) return ['error',"No such gallery (from collection $acollection): $agallery"];

    $dir2=$dir1.'/'.$atree;
    if (!is_dir($dir1))   return ['error',"No such tree (from collection $acollection entry $aentry) / gallery $agallery): $atree"];

    $dirListJsonFile=$dir2.'/dirList.json';    // getDirListEntry read!
    if (!is_file($dirListJsonFile)) {
       $sfoo="For gallery/tree: $agallery /  $atree: unable to find a directory list (<br>$dir1, <br>$dir2, <br>$dirListJsonFile).";
       return ['error',$sfoo];
    }
    $dirListC=file_get_contents($dirListJsonFile);
    $dirListJ=json_decode($dirListC,true);
    $dLook=$dirListJ[1]['.']['dirLookup'];
    if (!array_key_exists($adir,$dLook)) return ['error',"No such dir in dirLookup table  (from collection $acollection entry $aentry) / gallery $agallery / tree $atree): $adir"];
    $ido=$dLook[$adir];
    $dirRet=$dirListJ[1][$ido];

    $dir3=$dir2.'/'.$adir;
    if (!is_dir($dir3))  return['error',"No such dir  (from collection $acollection entry $aentry)  gallery $agallery / tree $atree): $adir"];

    $fileListJsonFile=$dir3.'/_fileList.json';
    if (!is_file($fileListJsonFile)) {
        $sfoo="For gallery/tree/dir: $agallery /  $atree / $adir : unable to find a file list ($fileListJsonFile).";
        return ['error',$sfoo];
    }
    $buttonListFile=$dir3.'/_buttonList_text.json';
    if (!is_file($buttonListFile)) {
        $sfoo="For gallery/tree/dir: $agallery /  $atree / $adir : unable to find a button list ($buttonListFile).";
        return ['error',$sfoo];
    }
    $thm40File=$dir3.'/_buttonList_thm40.json';
    if (!is_file($thm40File)) {
        $sfoo="For gallery/tree/dir: $agallery /  $atree / $adir : unable to find a 40x40 thumbnail list ($thm40File).";
        return ['error',$sfoo];
    }
    $thm66File=$dir3.'/_buttonList_thm66.json';
    if (!is_file($thm66File)) {
        $sfoo="For gallery/tree/dir: $agallery /  $atree / $adir : unable to find a 66x66 thumbnail list ($thm66File).";
        return ['error',$sfoo];
    }
    $thm90File=$dir3.'/_buttonList_thm90.json';
    if (!is_file($thm90File)) {
        $sfoo="For gallery/tree/dir: $agallery /  $atree / $adir : unable to find a 90x90 thumbnail list ($thm90File).";
        return ['error',$sfoo];
    }
    $snapshotFile=$dir3.'/_snapshots.json';
    if (!is_file($thm90File)) {
        $sfoo="For gallery/tree/dir: $agallery /  $atree / $adir : unable to find a snapshot list ($snapshotFile).";
        return ['error',$sfoo];
    }


//    $fileListC=file_get_contents($fileListJsonFile);
//    $fileListJ=json_decode($fileListC,true);

    $basics=['collection'=>$acollection,'entry'=>$aentry,'gallery'=>$agallery,'tree'=>$atree,'dir'=>$adir,
          'fileList'=>$fileListJsonFile,'buttonList'=>$buttonListFile,'snapshotList'=>$snapshotFile,
          'thm40List'=>$thm40File,'thm66List'=>$thm66File,'thm90List'=>$thm90File,'dirList'=>$dirListJsonFile];

    $stuff=['basic'=>$basics,'dirInfo'=>$dirRet   ];
    return ['ok',$stuff];

}

//
//=================
// create _keyword.json

function createKeywordJson($gDir) {

  $goget=$gDir.'*.note';
  $sGalleries=glob($goget);

  if (count($sGalleries)==0) return [];

  $keyWordList=[];
  foreach ($sGalleries as $jj=>$jfile) {
     $goofile=file_get_contents($jfile);
     $usefile=pathinfo($jfile,PATHINFO_FILENAME);
     $goojson=json_decode($goofile,true);
     $theseKeywords=[];
     foreach ($goojson as $ii=>$afoo) {

         $akeys=$afoo['key'];
         $theseKeywords=array_merge($theseKeywords,$akeys);
     }
     foreach ($theseKeywords as $jj=>$a1) $theseKeywords[$jj]=trim(strtolower($a1));
      sort($theseKeywords,SORT_STRING);
     $keyWordList[$usefile]=  array_unique($theseKeywords) ; //($goojson);
  }

// save keyword list

   $keywordFile=$gDir.'_keyword.json';
   $jj=json_encode($keyWordList,JSON_UNESCAPED_UNICODE);
   $cc=file_put_contents($keywordFile,$jj);
   return $keyWordList ;
}