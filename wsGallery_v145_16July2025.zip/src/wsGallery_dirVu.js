//===============================
// direcotry view and retrieve stuff (for current or specifid  tree)
// and disable views of specified diretories
// for wsGallery

//============
// toggle, or force, view of  the 'dirList flContent box -- where the list of the currentTree's directories is displayed
// doshow is optional. 0 (default)= toggle, 1=force show, 2= force hide

function toggleDirVu(doshow,athis) {

   var doshow1='0';
   if (arguments.length<=0) doshow='0';
   let atype=typeof(doshow);
   if (atype=='number' || atype=='string'){
      doshow=jQuery.trim(doshow);
   } else {           // a click handler? look for 'show' attribute. if not available, assume toggle
      let e1=wsurvey.argJquery(doshow);
      if (e1.length>0) {
        let aa=e1.wsurvey_attr('show',0)
        doshow=jQuery.trim(aa);
      }
   }

   if (doshow=='2') {     // special case
       wsurvey.flContents.hide(100,'dirList');
        return 1;
   }
   if (doshow=='1') {     // special case
        wsurvey.flContents.hide(100,'dirList',1);
        toggleSwitchTreeMenu(1);
        toggleDirVu_2(1,1.2);
        return 1;
   }

// else toggle
   var isvis =wsurvey.flContents.visible('dirList');
   if (isvis==0  || doshow==1 ) {
        wsurvey.flContents.show(100,'dirList',1);
        let dadir='';
        if (arguments.length>1) {
            let ethis=wsurvey.argJquery(athis);
            dadir=ethis.attr('data-last');
        }  else {
            dadir=$(document).data('currentDir');
        }
        let stuff1=makeCurrentChoicesList_gtd(1);

        toggleSwitchTreeMenu(1);
        if (dadir!='') {              // scroll to most recently view directory
            zbuttons=wsurvey.flContents.find('dirList','[name="dirListFileViewFiles"]') ;
            zbuttons.removeClass('cThisDirChosen');
            let zbutton1=zbuttons.filter('[value="'+dadir+'"]');
            if (zbutton1.length==1) {
              zbutton1.addClass('cThisDirChosen');
              wsurvey.flContents.scrollTo('dirList',zbutton1,0.70 ,100);
            }
         }  //dadir
    } else {      // isvis or doshow
        wsurvey.flContents.hide(200,'dirList');
    }

// hide gallery/colletion buttons?
    toggleDirVu_2(2,1.3) ;


    return isvis;
}


//====================
// verbose
function toggleDirVu_long(isDualViewer) {
  let dualViewerIcons=$(document).data('screenLayout_iconList_dual');
   let dualViewerTitles=$(document).data('screenLayout_titleList_dual');

// 0 : dual panes
// 1 : rotating (4 panes)
// 2 :tableau  (multiple rows and columns of images)
// 3: standard (two panes)
//
   let layoutWhich=  $(document).data('screenLayout' );

// only used if  dual panes (layoutwhich=0)
// 0: small previewer and viewer, large fiel list
// 1 :  Small previewer and large viewer, medium file list
// 2 :   Small previewer and largest viewer, small file list
   let layoutWhichDual=  $(document).data('screenLayout_dual');  // default is dual viewer

   let amess='<div><b>Choose a <em>display &amp; view </em> screen layout...</b>';
   amess+='<span style="float:right;margin-right:3em"><input type="button" class="helpTopic_otherTopicButton" value="Screen layout details ..." topic="basic_screenLayout" onclick="doHelpVu(this,1)"> </span> ';
   amess+='</div>';
   
   amess+='<ul class="menuChose4">';


   amess+='<li>';         // 3
   if (layoutWhich==3) amess+='<div  title="currently selected layout" style="background-color:cyan"> ';
     amess+='<button class="cToggleScreenLayoutSingle cChoseScreenLayout " data-frommenu="1"   onClick="doResizeViewers(this,3)">&#9704;</button>';
     amess+='  Standard (2 panes): file list (images, etc), and image viewer (<span style="font-size:80%">scrollable</span> ';
   if (layoutWhich==3) amess+='</div> ';

   amess+='<li>';   // 0
   if (layoutWhich==0) amess+='<div  title="currently selected layout" style="background-color:cyan"> ';
   amess+='<button class="cToggleScreenLayout cChoseScreenLayout "   data-frommenu="1" onClick="doResizeViewers(this,0)">&#10697;</button>';
   amess+=' Dual viewers (3 panes): file list,  previewer (compressed image), viewer (<span style="font-size:80%">full image,  zoomable &amp; scrollable</span>)';
//   amess+='<button title="The three verions of dualViewers" onClick="$(\'#toggleDirVu_long_dual3\').toggle()"> more ...</button> ';
   if (layoutWhich==0) amess+='</div> ';

  let dispnone=(layoutWhich==0)  ? '' : 'display:none;';
   amess+='<div   id="toggleDirVu_long_dual3" style="'+dispnone+';margin:5px 1em"> There are 3 versions of <b>dual viewers</b> ';
   amess+='<ol type="i" style="list-style-type:i">';

   amess+='<li>' ;      //2
   if (layoutWhichDual==0) amess+='<div title="currently selected version of dualViewers" style="background-color:lime">';
   amess+='  <button id="toggleViewers_2" which="2" onclick="doResizeViewers2(this,1)" class="cToggleScreenLayout"  >'+dualViewerIcons[0] +'</button>';
   amess+='   '+dualViewerTitles[0];
   if (layoutWhichDual==0) amess+='</div>';

   amess+='<li>';
   if (layoutWhichDual==1) amess+='<div title="currently selected version of dualViewers" style="background-color:lime">';
   amess+='  <button id="toggleViewers_2" which="0" onclick="doResizeViewers2(this,1)" class="cToggleScreenLayout"  >'+dualViewerIcons[1] +'</button>';
   amess+='   '+dualViewerTitles[1];
   if (layoutWhichDual==1) amess+='</div>';

   amess+='<li>' ;
   if (layoutWhichDual==2) amess+='<div title="currently selected version of dualViewers" style="background-color:lime">';
   amess+='  <button id="toggleViewers_2" which="1" onclick="doResizeViewers2(this,1)" class="cToggleScreenLayout"  >'+dualViewerIcons[2] +'</button>';
   amess+='   '+dualViewerTitles[2];
   if (layoutWhichDual==2) amess+='</div>';

   amess+='</ol>';
   amess+='</div>';

   amess+='<li>';  //1
   if (layoutWhich==1) amess+='<div  title="currently selected layout" style="background-color:cyan"> ';
   amess+=' <button  class="clargeViewerRotating cChoseScreenLayout "  data-frommenu="1" onClick="doResizeViewers(this,1)">&#8862;</button>';
   amess+='   Rotating  (4 equi-sized Panes):  file list, 3 panes for images (with cylical replacement)';
   if (layoutWhich==1) amess+='</div> ';

   amess+='<li>' ;  //2
   if (layoutWhich==2) amess+='<div  title="currently selected layout" style="background-color:cyan"> ';
   amess+=' <button  class="clargeViewerTableau cChoseScreenLayout " data-frommenu="1"  onClick="doResizeViewers(this,2)">&#9638;</button>' ;
   amess+='Tableau  (multiple panes): multiple columns and rows, with compressed images added  as chosen';
   if (layoutWhich==2) amess+='</div> ';

   amess+='</ul>';
  wsurvey.flContents.header('alerts','Which version of wsGallery to use?');
  wsurvey.flContents.content('alerts',amess);

}

//====================
// hide/show gallery or collection buttons (in dir menu)
function toggleDirVu_2(xx,fooid) {     /// 7 july 2025 args not used

   let ss1=$(document).data('switchGallery'  );    // if 0, do NOT allow user to switch galleries
   let collectionsList=$(document).data('collectionsAvail'  );

    $('#selectOtherGalleries2').show();

  window.setTimeout(function() {

   let afavorites=$(document).data('enableFavorites');

   e2e=$('#selectOtherGalleries2e');
   if (afavorites>0) {
       $('#selectOtherGalleries2e').show();
   } else {
       $('#selectOtherGalleries2e').hide();
   }

   if (ss1==1 && collectionsList!='') {        // show both
    //     alert('jinkx1');
       $('#selectOtherGalleries2a').show();
       $('#selectOtherGalleries2b').show();
       $('#selectOtherGalleries2c').show();
       $('#selectOtherGalleries2d').show();
       let ff=collectionsList.split(',');
       $('#selectOtherCollectionutton').attr('title','Select one of the '+ff.length+' available collections.');

       return 1;
   }

   if (ss1==0 && collectionsList=='') {        // hide both
   //alert('jinkx2');
       $('#selectOtherGalleries2a').hide();
       $('#selectOtherGalleries2b').hide();
       $('#selectOtherGalleries2c').hide();
       $('#selectOtherGalleries2d').hide();
       return 1;
   }
   if (ss1==1 && collectionsList=='') {        // switch gallery, but not collectiosn
    // alert('jinkx3');
       $('#selectOtherGalleries2a').show();
       $('#selectOtherGalleries2b').show();
       $('#selectOtherGalleries2c').hide();
       $('#selectOtherGalleries2d').hide();
       return 1;
   }

   if (ss1==0 && collectionsList!='') {        // no switch gallery, but yes collectiosn
            //  alert('jinkx4');
       $('#selectOtherGalleries2a').show();
       $('#selectOtherGalleries2b').hide();
       $('#selectOtherGalleries2c').hide();
       $('#selectOtherGalleries2d').show();

       let ff=collectionsList.split(',');
       $('#selectOtherCollectionutton').attr('title','Select one of the '+ff.length+' available collections ');

       return 1;
   }
   alert('toggleDirVu_2 should never get here ');
   return 0;
 },100);
 return 1;
}

//=====================
// show file list (on top by efault, or not if ontop=0)
function fileListShow(onTop) {
  if (arguments.length<1) onTop=1;
  wsurvey.flContents.show('gallery',5,onTop);
}
//=====================
// show file list (on top by efault, or not if ontop=0)
// file lists overlaps tableau area
function tableauShow(onTop) {
  if (arguments.length<1) onTop=1;

// larger filevioewer that overlaps filelist
  let s1={'top':'5%','left':'4%','width':'88%', 'height':'25%'};
  wsurvey.flContents.container.doResize('gallery',s1)
  let s4={'top':'15%','left':'2%','width':'93%','height':'85%'};
  wsurvey.flContents.container.doResize('tableau',s4)   ;
  wsurvey.flContents.show('tableau',5,onTop);
}
//=====================
// toggle tabelau modes (size of the tableau and gallery flconttainers
// nowmode as arg: 0 = large tableau , 1: file list float above tableau
function tableauMode(athis,nowmode) {
  if (arguments.length<2) {
    let ethis=wsurvey.argJquery(athis);
    nowmode=ethis.attr('data-which');
    nowmode=1-parseInt(nowmode);
    ethis.attr('data-which',nowmode);
  }      

  if (nowmode==0) {
     doResizeViewers(0,22);
  } else {
       let s1={'top':'5%','left':'4%','width':'88%', 'height':'20%'};
        wsurvey.flContents.container.doResize('gallery',s1)
        let s4={'top':'31%','left':'2%','width':'93%','height':'65%'};
        wsurvey.flContents.container.doResize('tableau',s4)   ;
  }

}

//===================
// set pre-defines to "2", and showImages to 1-
function tableauModeCompact(athis) {
  setTableauLayout(0,2) ;
  tableauShowImageList(0,2);
  wsurvey.flContents.onTop('tableau',1);
}


//===============
// get list of directories for a tree, and display
// Feb 2022: treename is always 0.  Always use the .data('currentTree') value.   7 july 2025 -- will remove this argument in later version?
//          debug1: not currently used. Could be used for debugging
//          hideTreeList : 7 july 2025 not currently used ( set to 0)
//                       Future use: if 1, then hide the tree list menu after displaying stuff in dirList flContents
//          afile: file name from the requestUri
//          dflag: a time stamp

// Note: to toggle view of the currentTree's directory list (and not reload), use toggleDirVu
//
// loadTreeDirs is called in 3 places in  wsGallery.js
//   in init (~590), at the end of initialization-- to load the current default gallery/tree/dir Treename=0 : use the "currenTree"
//        loadTreeDirs(0,'end of init()',0,$(document).data('currentDir'),areqf,dflag)   ; // read directory list  for the default tree  and display it.

//   in switchCurrentTree, the event handler for switch tree button in the treeList menu
//       loadTreeDirs(0,'switch tree',hideTreeList);

//    in init , in a button loaded in top of the dirLIst - to reload the current dlirst. NOt that useful anymore  -- except to switch from admin to normal view
//        loadTreeDirs(0,\'dirlist button\')

function loadTreeDirs(treeName,debug1,hideTreeList,adir,afile,useflag ) {

   if (arguments.length<1) treeName='';       // feb 2022: it should always be '0'
   if (arguments.length<2) debug1='';
   if (arguments.length<3) hideTreeList=0;
   if (arguments.length<4) adir='';
   if (arguments.length<5) afile='';
   if (arguments.length<6) useflag='';

   let cGallery=$(document).data('currentGallery');

// 7 july 2025 .. treeName is always 0
   if (treeName=='' || treeName=='0') treeName=$(document).data('currentTree'); // loadTreeDirs -- always use currentTree (invocation=default, or after switchTree call
    var adata={'todo':'retrieveDirList','treeName':treeName,'hideTreeList':hideTreeList,'dir':adir,'file':afile,'useflag':useflag}  ;
    wsurvey.getJson.get('wsGalleryActions.php',adata, loadTreeDirsB ,' Retrieving list of files in a directory (using loadTreeDirs)');
    return 1;
}


//=========
// display list of dirs
function loadTreeDirsB(response,origData,otherArgs) {      // don't need  otherArg,tstatus,xhr)

   var hideTreeList=0;
   var useFlag=origData['useflag'];
   var isFirstCall=$(document).data('firstCall');
   var afile='',alayout='',adir='',athumb='',aFileListType='',aShowInfo='',aDesc='';

   let cGallery=$(document).data('currentGallery');
   let cTree=$(document).data('currentTree');
   let cDir=$(document).data('currentDir');

   if (isFirstCall==1) {

      adir=origData['dir'];           // show a requested driectory.
      afile=origData['file'];           // show a requested driectory.
      alayout=jQuery.trim($(document).data('screenLayout'));  // if first call, auto layout?

//          alert('this isfirstcallxx . gallery='+cGallery+' tree='+cTree+' ::  origDir =' +adir+', current dir '+cDir);

      athumb=$(document).data('requestedThumbnail');  // if first call, auto layout?
      aFileListType=$(document).data('requestedFileListType');  // if first call, auto layout?
      aShowInfo=$(document).data('requestedShowInfo');

      aDesc=$(document).data('requestedDesc');
   }

    hh=wsurvey.getJson.check(response,0,'Callback from loadTreesDir');
    if (hh===false)    return 0;

    let acontent;
    if (hh===null || !hh.hasOwnProperty('content') || hh['content']===null) {
        acontent='no directories available. The admin should ';
        acontent+='<input type="button" onClick="$(\'#logonButton\').trigger(\'click\')" id="logonButton" value="Logon" style="" title="Admin logon"> and initialize directories!';
    } else {
        acontent=hh['content'];
    }

    if (hh['status']=='na') {  // not avaialble
         wsurvey.flContents.contents('dirList',acontent);
         let mm=hh['treeSwitchMenu'];                   // show treelist
         $('#switchTreeMenu').html(mm);
         let ehh=$('[name="headerToggleSwitchTreeButton"]');
         ehh.css({"opacity":''})
         if (useFlag!='') $(document).data(useFlag,1);  // flag to invoker (that contents have been written -- although contents are an error message);
         return 1;
    }

// if here okay
     let basics=(hh.hasOwnProperty('basics')) ? hh['basics'] : false ;
     if(basics == null  ) basics=false;  // sometimes happens (june 2022)
//     wsurvey.dumpObj(basics,1,'bbbb');
      wsurvey.flContents.contents('dirList',acontent);
       wsurvey.sortTable.init('dirListingTable',{'sortUse':'data-sortuse'})  ;


     let mm=hh['treeSwitchMenu'];
     $('#switchTreeMenu').html(mm);
      let ehh=$('[name="headerToggleSwitchTreeButton"]');
      ehh.css({"opacity":''})

      if (origData.hasOwnProperty('hideTreeList'))  hideTreeList=origData['hideTreeList']  ;  // 7 july 2025 .. always 0

      if (basics===false) { // problem -- maybe default tree not inititliazed?
         alert('wsGallery problem: no basic information. Perhaps the current tree ('+origData['treeName']+') has not been initialized (by the admin)  ?');
         if (didToggle==0 && useFlag!='') $(document).data(useFlag,1);  // flag to invoker (that contents have been written);
         return 1;

      }

     //  wsurvey.dumpObj(basics,1,'bbbb');
      let galname=basics['galleryName'];
     let aheader=' :  In the <tt>'+basics.totDirs+' </tt> directories in tree <span class="headerEmphasizer" >'+basics['treeName']+'</span> ';

     let swg1=$(document).data('switchGallery'  );    // if 0, do NOT allow user to switch galleries
     if (swg1==1) {
       aheader+=' <span style="margin:1px 5px;color:darkgreen" title="You can select a different gallery!">&#127963; in gallery <tt>'+galname+'</tt></span>: # files=<tt>'+basics.totFiles+' (including <tt>'+basics.totImages+'</tt> images) ';
     } else {
       aheader+=' <span style="margin:1px 5px;color:purple" title="The admin has suppressed switching galleries. So this is the only one you can view!">  in gallery <tt>'+galname+'</tt></span>: # files=<tt>'+basics.totFiles+' (including <tt>'+basics.totImages+'</tt> images) ';
     }

     wsurvey.flContents.header('dirList',aheader);
     if (hideTreeList!=1) {          // 7 july 2025 .. always 0
           toggleSwitchTreeMenu(1);
           let ehh=$('[name="headerToggleSwitchTreeButton"]');
          ehh.css({"opacity":''})

     } else {
         $('#switchTreeMenu').hide();
     }


   var didToggle=0;
// add click handlers
    $('#dirListingTable').on('click',dirListClickHandlerClient)  ;

    wsurvey.flContents.onTop('gallery',20);
    if (adir!='') {
          let dbuttons=wsurvey.flContents.find('dirList','[name="dirListFileViewFiles"]');
          let abutton=dbuttons.filter('[dir="'+adir+'"]');
         if (abutton.length==1) {
            abutton.trigger('click');
            toggleDirVu(2);
            didToggle=1;
         }
    }

   if (didToggle==0 && useFlag!='') $(document).data(useFlag,1);  // flag to invoker (that contents have been written);

// select a file? and a layout
  $(document).data('firstCall',0) ;

  window.setTimeout(function() {

     eTreeList=$('#iTreeListEncoded');   // 7 july 2025 ... hack to read tree list of current gallery
     eTreeList0=eTreeList.text();
     let zTreeList=JSON.parse(eTreeList0);
    $(document).data('currentTreeList',zTreeList ) ;   // save to global
 // [0]= default tree
 // [1] timestamp
 // [2] status message
 // [3] gallery
 //  [4] {object of altnames f9r trees
 //  [treename] object of tree attributes (for all trees in [4] : rootDir rootSEl stdWeeDir desc cacheTree underStdWwwDir cacheSel

//     wsurvey.dumpObj(zTreeList,1,'xxx');

    let stuff1=makeCurrentChoicesList_gtd(1);

    let ej=$('[name="imageJumpButtons"]');
    ej.hide();

// possible values: combo,v1,v2,rotating,tableau,singleImage
      let edrops=$('#dropdown_layouts');
     if (jQuery.trim(alayout)=='')  alayout=jQuery.trim($(document).data('screenLayout')) ;

    if (alayout=='dualviewers' || alayout=="dual" ||   alayout=='dualViewersCombo' ||
        alayout=='' || alayout=="v0" ||
        alayout=="v1" || alayout=="v2") {  // dualViewers, combo

        let eLay=edrops.find('.cToggleScreenLayout');
        eLay.trigger('click');

// deprecated 7 July 2025
//        let etv=$('#toggleViewers_2');
//           if (etv.length>0) {  // might have to wait for dom?
//          let iwhich=etv.attr('which');
//          let iwhichDo=0;
//          if (alayout=='dualViewers1' || alayout=='v1') iwhichDo=1 ;
//          if (alayout=='dualViewers2' || alayout=='v2') iwhichDo=2 ;
//          let nclicks=Math.abs(iwhichDo);
//          for (var inn=0;inn<nclicks;inn++) {  // a bit of a hack
//              etv.trigger('click');
//          }
//          wsurvey.flContents.onTop("dirList",1);
//         ej.show();
//       }

      } else if (alayout.substr(0,3)=='rot' || alayout==2) {
        let eLay=edrops.find('.clargeViewerRotating');
        eLay.trigger('click');

      } else if (alayout.substr(0,3)=='tab') {
        let eLay=edrops.find('.clargeViewerTableau');
        eLay.trigger('click');
        if (alayout.length>3) {
           let ipre=alayout.substr(3,1);
           if (!isNaN(ipre)) {
               ipre=parseInt(ipre);
               if (ipre>0 && ipre<5) setTableauLayout(0,ipre);
           }
        }

      } else if (alayout.substr(0,3)=='lar'  ||  alayout==4) {
        let eLay=edrops.find('.clargeViewerSingle');
        eLay.trigger('click');
        wsurvey.flContents.onTop("gallery",1);

      } else if (alayout.substr(0,3)=='sin'  ||  alayout==3) {
        let eLay=edrops.find('.cToggleScreenLayoutSingle');
        eLay.trigger('click');
        wsurvey.flContents.onTop("gallery",1);

      }

      if (athumb!='') {
         let edd=wsurvey.flContents.find('gallery','#divListWiththumbnails'),edd2=false ;
         if (athumb=='n') edd2=edd.find('#divListWiththumbnails_name');
         if (athumb=='s') edd2=edd.find('#divListWiththumbnails_small');
         if (athumb=='m') edd2=edd.find('#divListWiththumbnails_medium');
         if (athumb=='l') edd2=edd.find('#divListWiththumbnails_large');
         if (edd2!==false) edd2.trigger('click');
      }

      if (aFileListType!='') {
         if (isNaN(aFileListType)) aFileListType=1;
         aFileListType=parseInt(aFileListType) ;
          window.setTimeout(function() {
             chooseFileListType(false,aFileListType);
         },30);
      }


      window.setTimeout(function() {

         if (afile!='') {

            let fbuttons=wsurvey.flContents.find('gallery','#listOfFileInCurrentDir');
            let nbuttons=fbuttons.attr('nbuttons');
            let doems=loadTreeDirsB_list(afile,nbuttons );
            for (var iem=0;iem<doems.length;iem++) {
                let mjj2=doems[iem];
                let abutton=fbuttons.find('[buttonnumber="'+mjj2+'"]');
                if (abutton.length==1) {
                    let abutton2=abutton.find('button');
                    abutton2.trigger('click');              // this will call showThisFile in a standard fashion
                }
            }   // iem
         }  // afile
         if (alayout.substr(0,3)=='tab')  $('#iTightenUp').trigger('click');
         if (jQuery.trim(aShowInfo)=='1'){
            toggleViewInfo('',1,1);
         }

         if (jQuery.trim(aDesc)!=='') {
             $('#dirDescriptions').prepend(aDesc+'<hr>');
        }
        if (aShowInfo!=='' && aShowInfo>-1) {
   //             alert('oooo2 '+aShowInfo);
          toggleViewInfo('',1,1,aShowInfo);
        }

//       let askLayout=$(document).data('screenLayout');
       let askLayout=alayout;

        if (askLayout =='') {
          let doLayout=$(document).data('currentScreenLayout');
          let doLayoutClass=$(document).data('screenLayout_default');
          let arf=$('#dropdown_layouts');
          let arf2=arf.find(doLayoutClass);
          if (arf2.length==1) arf2.trigger("click") ;
          wsurvey.flContents.onTop('dirList');
        }

// load a colledtion?
        let acollection=$(document).data('requestedCollection');
        if (jQuery.trim(acollection)!='') {
           let aentry=$(document).data('requestedEntry');
           openCollection(acollection,aentry,afile);
        }

// load a colledtion?
        let afavorites=$(document).data('requestedFavorites');
        if (jQuery.trim(afavorites)!='') {
           doFavorites_getPublic(0,afavorites,1,afile) ;  // 2nd arg 1 means "display favorites after retrievint
        }

     },200) ;

    },500);  //

}



//==================
// create <ul> of current gallery, tree, directory choices
function makeCurrentChoicesList_gtd(ii) {
   let zTreeList=$(document).data('currentTreeList');
   let galleryDir=$(document).data('galleryDir');
   let curGallery=$(document).data('currentGallery');
   let curTree=$(document).data('currentTree');
   let curDir=$(document).data('currentDir');

   let stuff1='';

    stuff1+='<ul name="currentChoices"  class="linearMenu">';
    let altNames1=zTreeList[4];

    let curTreeAlt=(altNames1.hasOwnProperty(curTree)) ? altNames1[curTree]  : curTree ;
    let curTreeDesc=(zTreeList.hasOwnProperty(curTree)) ? ' <span title="description"><em>'+zTreeList[curTree]['desc']+'</em></span> ' :  '' ;

//   wsurvey.dumpObj(altNames1,1,'altNames1 '+curTree+','+curTreeAlt);

    stuff1+='<li class="linearMenuLiBlank">Current choices: </li>';
    stuff1+='<li class="linearMenuLi1">Gallery: <span name="cgallery" >'+curGallery+'</span> </li> '  ;
    if (curTreeAlt!==curTree) {
      stuff1+='<li class="linearMenuLi2">Tree: <span name="ctree" " <u>'+curTreeAlt+'</u> (<span title="internal name"><tt>'+curTree+'</tt></span>) '+curTreeDesc +'</li>' ;
    } else {
      stuff1+='<li class="linearMenuLi2">Tree: <span name="ctree" " <u>'+curTree+'</u>  '+curTreeDesc +'</li>' ;
    }
    stuff1+='<li class="linearMenuLi3" >Dir: <u>'+curDir+'</u> </li> ';

    if (ii==2)  {          // special case: also add current file
     let imgFile_name=$(document).data('current_file_filename' );

     if (imgFile_name=='') {
        stuff1+='<li class="linearMenuLi4" title="No file selected">&hellip;</span></li> ';
      } else {
        stuff1+='<li class="linearMenuLi4"> Current file: <tt>'+imgFile_name+'</tt></li>';
      }

    }

    stuff1+='</ul>';

   if (ii==1)  {   // or caller could do it
      let egtd= $('#currentChoices_gtd');
       egtd.html(stuff1);
  }


  return stuff1;
}

//=================
// make array of image numbers from csv

function loadTreeDirsB_list(alist,nbuttons) {
  let mylist=[];
  let ifiles=alist.split(',');
  let istart=0,iend=nbuttons-1;
  for (var jj in ifiles) {    // each of the csvs
     let ifiledo=ifiles[jj];
     if (ifiledo.indexOf('-')<0) {   //  not a range
        if (!isNaN(ifiledo))  mylist.push(parseInt(ifiledo));
        continue;
    }
    let oof=ifiledo.split('-');
    if (oof.length<2) oof[1]=nbuttons;
    istart=jQuery.trim(oof[0]); iend=oof[1];
    if (jQuery.trim(istart)=='' || isNaN(istart)) istart=0;
    if (jQuery.trim(iend)=='' || isNaN(iend)) iend=nbuttons-1;
    istart=parseInt(istart),iend=parseInt(iend);
    for (var mjj=istart;mjj<=iend;mjj++) mylist.push(mjj);
  }   
  return mylist;

}

//================  ==========================================
// dirlist click handler (several possible actions, depending on what was clicked ) -- client version
function dirListClickHandlerClient(evt) {

   let ethis=wsurvey.argJquery(evt);
   let aname=ethis.attr('name');
   if (aname=='dirListFileViewFiles') {  //  ignore if not dir button
      let dname=ethis.attr('dir');
       $(document).data('currentDir',dname);
      getDirFileListJs(evt);
      return 1;
   }           // dirlistdescarea



}