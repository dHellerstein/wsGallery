// functions for wsGallery_small

// ===================================
// called by init: make sure requested gallery exists
function getGalleries(athis,dogo) {

  if (arguments.length<2) dogo=0;
  if (dogo==0) {
     wsGallery.getGalleryList(false,'getGalleries2')   ;
  } else {
     wsGallery.getGalleryList(false,'getGalleries2a')   ;
  }
}

// make sure useGallery is an existing gallery
function getGalleries2a(astuff) {         // front end to getGalleries (get treelist for useGallery)
   getGalleries2(astuff,1);
   return 0;
}

function getGalleries2(astuff,dogo) {
    if (arguments.length<2) dogo=0;
    let uu=jQuery.trim(useGallery.toLowerCase());   // useGallry is global ('main' by default)
    var okay=0;
    for (let jj in astuff) {
      let uu2=jQuery.trim(astuff[jj]).toLowerCase() ;
      if (uu==uu2) {
          okay=1;
          break;
      }
    }
    if (okay==0) {
      alert('wsGallery: the desired gallery (useGallery) does not exist ');
      return 0;
    }

    currentGallery=useGallery;        // global currentGallery

    if (dogo==1) {
       selectTree(1);  // load treelist for this gallery
    }

}

//================
// get list of trees in currentGallery, and then display
function selectTree(dogo) {
 $("#simple_viewer").swipe("disable");

  let args={'gallery':currentGallery,'callback':selectTree2 };
  if (dogo==1) args['callback']=selectTree2a;
  wsGallery.getTreeList(args,false) ;
}
function selectTree2a(stuff) {
  selectTree2(stuff,1);
}

function selectTree2(stuff,dogo) {
  if (arguments.length<2) dogo=0;
  goo=[];
  let amess='';
  currentTreeDirs=stuff;

 amess+='<div style="height:1.6em">';
  amess+='<span title="select a tree in gallery: '+currentGallery+'"><em>Select a tree</em></span>   ';
  amess+='<button title="Select a directory in this tree" id="currentTree_getDir" class="ccurrentTreeShowNext" onClick="selectDir(0)"> &Nscr;ext &rArr; </button>   ' ;
  amess+='<span title="currently selected tree" id="currentTreeShow" class="ccurrentTreeShow"></span> ' ;
  amess+='</div>';

  amess+='<ul class="linearListTree">';
  let auseTree=jQuery.trim(useTree);

  for (let aa in stuff['status']) {
    if (aa=='/') continue ;
     let bb=stuff['status'][aa];

     let adesc=wsurvey.removeAllTags(bb['desc']);
     let daclass= (aa==auseTree) ? 'chosenTree' : ' ' ;
     amess+='<li> <span name="treeListButtons" class="'+daclass+'"  style="margin:3px;padding:2px">';
     amess+='  <input type="button"  style="font-size:150%" value="'+aa+'" ';
     if (dogo==1 && auseTree==aa) {       // auto load?
        currentTree= jQuery.trim(auseTree);
        dogo=2;
        amess+=' class="chosenTree" ';
     }
     amess+='     title="Desc: '+adesc;
     amess+='&#010;  # of directories: '+bb['dirList'].length+'" ';
     amess+='    onClick="selectTree3(this)" > </span> ';
     amess+='</li> ';
   }
   amess+='</ul>';
  $('#simple_viewer').html(amess);

  if (dogo==2 ) {        // first call, match found
       selectDir(1);
       $('#selectADir1').attr('title','In requested tree: '+useTree );
  }
}

//============================
function selectTree3(athis) {
   let ethis=wsurvey.argJquery(athis);
   let atree=ethis.val();
   let atitle=ethis.attr('title');
     let espan=ethis.closest('span');
   let isAlready=(espan.hasClass('chosenTree')) ? true : false ;
   if (isAlready) {  // double click
     selectDir(0);
     return 1;
   }

   let eall=$('[name="treeListButtons"]');
   eall.removeClass('chosenTree');
   e1=ethis.closest('li');
   e1b=e1.find('[name="treeListButtons"]');
   e1b.addClass('chosenTree');
   currentTree=atree;
   currentTreeDesc=atitle;
   $('#currentTreeShow').html('<tt>'+atree+'</tt>: <em>'+atitle.substr(5)+'</em>').show();
   $('#choseTreeButton').addClass('buttonClicked');
   $('#choseDirButton').removeClass('buttonClicked');
    currentDirDesc='';   currentDir='';
   $('#choseFileButton').removeClass('buttonClicked');
   currentFileDesc='';   currentFile='';

  $('#selectADir1').attr('title','In tree: '+atree );

   $('#currentTree_getDir').show();

   return 1;
}

//============================
function selectDir(dogo) {
     $("#simple_viewer").swipe("disable");

  let ss1=currentTreeDirs['trees'][currentTree];
  let amess='';
  amess+='<div style="height:1.6em">';
  amess+='<span id="selectADir1"> <em>Select a <u>directory</u> ... </em></span>';
  amess+='<button title="Select a file in this directory" id="currentDir_getFile" class="ccurrentTreeShowNext" onClick="selectFile(0)"> &Nscr;ext &rArr; </button>   ' ;
    amess+='<span title="currently selected dir" id="currentDirShow" class="ccurrentTreeShow"></span> ' ;
  amess+='</div>';

  amess+='<ul class="linearListTree" style="xmax-height:8em;overflow:auto">';
  let auseDir=jQuery.trim(useDir);
  

  for (let aa in ss1 ) {
     let bb=ss1[aa];

     let adesc=wsurvey.removeAllTags(bb['desc']);
     let daclass= (aa==currentDir) ? 'chosenDir' : ' ' ;
     amess+='<li><span name="dirNameButtons" class="'+daclass+'"  style="margin:3px;padding:2px">';
     amess+='  <input type="button" value="'+aa+'" ';
     amess+='     title="Desc: '+adesc;
     amess+='&#010;  # of files: '+bb['nFiles']+'" ';
     if (dogo==1 && auseDir==aa) {          // autoload
        currentDir= jQuery.trim(auseDir);
        dogo=2;
        amess+=' class="chosenDir" ';
     }
     amess+='    onClick="selectDir3(this)" > </span>';
  }
   amess+='</ul>';
   $('#simple_viewer').html(amess);

  if (dogo==2 ) {        // first call, match found
       selectFile(1);
  }

}

function selectDir3(athis) {
   let ethis=wsurvey.argJquery(athis);
   let adir=ethis.val();
    let espan=ethis.closest('span');
   let isAlready=(espan.hasClass('chosenDir')) ? true : false ;
   if (isAlready) {  // double click
     selectFile(0);
     return 1;
   }

   let atitle=ethis.attr('title');
   let eall=$('[name="dirNameButtons"]');
   eall.removeClass('chosenDir');
   e1=ethis.closest('li');
   e1b=e1.find('[name="dirNameButtons"]');
   e1b.addClass('chosenDir');
   currentDir=adir;
   currentDirDesc=atitle;
   $('#choseDirButton').addClass('buttonClicked');
   $('#currentDirShow').html('<tt>'+adir+'</tt>: <em>'+atitle.substr(5)+'</em>').show();
   $('#currentDir_getFile').show();
   $('#choseFileButton').removeClass('buttonClicked');
    $('#selectAFile1').attr('title','In directory: '+currentDir );

   currentFile='';currentFileDesc='';


}


//=======================
function selectFile(dogo) {
   $("#simple_viewer").swipe("disable");

  let toget=['name','uriSel','height','width','link','linkNoDim'];
   let args={'gallery':currentGallery,'tree':currentTree,'dir':currentDir,'callback':selectFile2} ;
   if (dogo==1)  args['callback']=selectFile2a;
    wsGallery.getFileList(args,false) ;
}

function selectFile2a(stuff) {
  selectFile2(stuff,1) ;
}

function selectFile2(stuff,dogo) {
  if (arguments.length<2) dogo=0;
  let amess='';
  currentFileList=stuff;

  amess+='<div style="height:1.6em">';
  amess+='<span id="selectAFile1"> <em>Select a <u>file</u> ... </em></span>';
  amess+='<button title="View this file" id="currentTree_viewFile" class="ccurrentTree_viewFile" onClick="viewChosenFile(this)"> &#128065; &Vscr;iew </button>   ' ;
  amess+='<span id="currentTree_viewFile_note"  style="display:none;font-style:oblique;margin:3px 1.4em"  ';
  amess+='   title="Click View to view file, or double click on the file (with the red square"> &hellip; or doubleClick to view</span>'   ;

  amess+='<span title="currently selected file" id="currentFileShow" class="ccurrentTreeShow"></span> ' ;
  amess+='</div>';
  amess+='<ul class="linearListTree" style="xmax-height:8em;overflow:auto">';
  let fixView=false,aname='',adesc='',fixViewMess='';
  let auseFile=jQuery.trim(useFile);
   currentFile=useFile ;

//   wsurvey.dumpObj(currentFileList,1,[' got 1: ' ,currentGallery,currentTree,currentDir,currentFile].join(' | '));

  for (let aa in stuff ) {
     let bb=stuff[aa];
      aname=bb['name'];
     let awidth=bb['width'],aheight=bb['height'];
      adesc=wsurvey.removeAllTags(bb['desc']);
     let abutton=aname;
     if (showThumbnails==1) {
         abutton=bb['thmSmall'];
     } else if (showThumbnails==2) {
         abutton=bb['thmMedium'];
     } else if (showThumbnails==3) {
         abutton=bb['thmLarge'];
     }
     let daclass=' ';
     if (aname==currentFile) {
         daclass=' class="chosenFile"  ';
         fixView=aa;
         fixViewMess='<tt>'+aname+'</tt>: <em>'+adesc+'</em>';
     }
     amess+='<li style="background-color:#dfdee1;" title="file: '+aname+'" >';
     amess+='<div style="vertical-align:center"><table cellpadding="2">';
     amess+='<tr>';
     if (showThumbnails!=0 && alwaysShowName==1) amess+='<td><span title="file name" style="font-size:80%">'+aname+'</span></td><td>';
     amess+=' <span name="fileNameButtons"  '+daclass+'    ';
     if (dogo==1 && auseFile==aname) {      // autoload
        currentFile= jQuery.trim(auseFile);
        dogo=2;
        amess+=' class="chosenFile" ';
     }
     amess+='style="margin:3px;padding:2px">';
     amess+='   <button value="'+aname+'"  data-which="'+aa+'" ';
     amess+='      title="Desc: '+adesc+' &#010;['+awidth+'x'+aheight+']" ';
     amess+='      onClick="selectFile3(this)" >'+abutton+'</button>';
     amess+='</span>';
     amess+='</td></tr></table>';
     amess+='</div>';
  }
   amess+='</ul>';
  $('#simple_viewer').html(amess);
  if (fixView!==false) {
    $('#currentFileShow').html(fixViewMess).show();
    $('#currentTree_viewFile').attr('data-which',fixView);
  }

  if (dogo==2) {
     $('#currentTree_viewFile').trigger('click');
     return 1;
  }

}

function selectFile3(athis) {
   let ethis=wsurvey.argJquery(athis);
   let afile=ethis.val();

   let espan=ethis.closest('span');
   let isAlready=(espan.hasClass('chosenFile')) ? true : false ;
   if (isAlready) {  // double click
      $('#currentTree_viewFile').trigger('click');
     return 1;
   }

   let ith=ethis.attr('data-which');

   let atitle=ethis.attr('title');
   let eall=$('[name="fileNameButtons"]');
   eall.removeClass('chosenFile');
   e1=ethis.closest('li');
   e1b=e1.find('[name="fileNameButtons"]');
   e1b.addClass('chosenFile');
   currentFile=afile;


   currentFileDesc=atitle;
   $('#choseFileButton').addClass('buttonClicked');
   $('#currentFileShow').html('<tt>'+afile+'</tt>: <em>'+atitle.substr(5)+'</em>').show();
   $('#currentTree_viewFile').attr('data-which',ith);
   
   $('#currentTree_viewFile').css({'border':'1px dashed red'});
   $('#currentTree_viewFile_note').show();

}

function viewChosenFile(athis,ith) {
   if (arguments.length<2) {
     let ethis=wsurvey.argJquery(athis);
     ith=ethis.attr('data-which');
   }
   if (!currentFileList.hasOwnProperty(ith)) return 0 ; // a problem

   let myfile=currentFileList[ith];
   let atime=wsurvey.get_currentTime(31,1,myfile['date']*1000);
   currentFileNumber=ith;
   let eview=$('#simple_viewer');
   let eviewRect=eview[0].getBoundingClientRect();


//  showSnapShot=1    ; // 0=full image, 1=snapshot image
//  doStretch=2;     ; // 0:as is, 1:stretch , 2:shrink (preserve aspect ratio)

  let showStuff;
  if (showSnapShot==1) {
    showStuff=myfile['snapshot'];
  } else {
    showStuff=myfile['link'];
  }
  let adesc=wsurvey.removeAllTags(myfile['desc']);

  showStuff+='<div class="cshowSingleOpts" id="simple_viewer_info">';
  showStuff+='<input type="button" value="x" title="leave full screen view" onClick="leaveFullScreen()"> ';
  let saySwipeon= (doSwipe==1) ? ' class="cSwipeOn" ' : '  ';
  showStuff+='<input type="button" '+saySwipeon+' value="&Sscr;wipe" data-which="'+doSwipe+'"  title="toggle swipeEnable -- when enabled, swiping left and right to view prior and next files" onClick="doSwipeEnable(this)"> ';
  showStuff+='<span id="simple_viewer_info_file" style="font-size:70%" title="Desc: '+adesc+'">'+myfile['name']+'</span>';
  showStuff+='</div> ';
  eview.html(showStuff);
  let eviewRect2=eview[0].getBoundingClientRect();
  let atop=parseInt(eviewRect2.top)+6;
  $('#simple_viewer_info').css({'top':atop});
  if (!document.fullscreenElement) $('#simple_viewer_info').hide();

  eview.attr('data-imagewidth',myfile['width']);
  eview.attr('data-imageheight',myfile['height']);
  let atitle=myfile['name']+' ; '+atime+', '+myfile['width']+'x'+myfile['height']+': '+adesc;

  eview.attr('title',atitle);
  
  if (doSwipe==1)  $("#simple_viewer").swipe("enable");

  if (doStretch==0) return 1 ; // don't try stretching
  if (myfile['width'] =='' || myfile['height'] =='') return 1;   // no orig image info, can't stretch

//  stretch or shrink
  let imgboxWidth=eview.attr('data-usewidth');
  let imgboxHeight=eview.attr('data-useheight');
  let eimgbox=eview.find('img');
  if (eimgbox.length==0) return 0;  // can't shrink non-img
  if (doStretch==1)  {        // stretch
     eimgbox.height(parseInt(0.95*imgboxHeight));
     eimgbox.width(parseInt(0.90*imgboxWidth));
  }
  if (doStretch==2) {
     let wshrink=0.95*imgboxWidth/myfile['width'];
     let hshrink=0.95*imgboxHeight/myfile['height'];
     let ashrink=Math.min(wshrink,hshrink);

     let gheight=parseInt(ashrink*myfile['height'])   ;
     let gwidth=parseInt(ashrink*myfile['width'])  ;
     eimgbox.attr({'height':gheight,'width':gwidth});
  }


}


//======================
// view next

function viewNextFile(athis,idire) {
   let ndo=parseInt(currentFileNumber);
   ndo=ndo+parseInt(idire);
   if (ndo<0) ndo=0;
   if (ndo>=currentFileList.length) ndo=currentFileList.length-1;
   viewChosenFile(0,ndo);
}

//==========
// set setting sfor full image (asis)
function viewFullImage(athis) {
  showSnapShot=0;
  doStretch=0;
  if (currentFileNumber>=0) viewChosenFile(0,currentFileNumber);
}

//==========
// set setting squooshed snapshot image (asis)
function viewReducedImage(athis) {
  showSnapShot=1;
  doStretch=2;
  if (currentFileNumber>=0) viewChosenFile(0,currentFileNumber);
}

// display using entire screen (ESC to exit)
function viewFullScreen(xx) {
  let earf=$('#simple_viewer');
  let earf2=$('#simple_viewer_info');
  earf2.show();
  let elem=earf[0];
    if (elem.requestFullscreen) {
    elem.requestFullscreen();
  } else if (elem.webkitRequestFullscreen) { /* Safari */
    elem.webkitRequestFullscreen();
  } else if (elem.msRequestFullscreen) { /* IE11 */
    elem.msRequestFullscreen();
  }

}
function leaveFullScreen(athis) {
    if (document.fullscreenElement){
       document.exitFullscreen() ;
    }
   $('#simple_viewer_info').hide();
}

//============
// enable ssipe
function doSwipeEnable(athis) {
   ethis=wsurvey.argJquery(athis);
   let iwhich=ethis.attr('data-which');
   if (iwhich==1)  {   // swipe is enabled... dsiable
 // alert('disabling sip');
      $("#simple_viewer").swipe("disable");
      ethis.attr('data-which',0);
      ethis.removeClass('cSwipeOn');
  } else {
      $("#simple_viewer").swipe("enable");
      ethis.attr('data-which',1);
      ethis.addClass('cSwipeOn');
  }
}


//==========
// display current status
function showCurrentStatus(athis) {
  let amess='';
  amess+='<em>Current status...</em>';
  amess+='<ul class="selectDirListC">';

  amess+='<li>Gallery:<tt> '+currentGallery+'</tt> ';

  amess+='<li>Tree:<tt> '+currentTree+'</tt>';
  amess+=' &vellip; <span style="font-style:oblique;font-size:80%" title="Tree description">'+currentTreeDesc.substr(6)+'</span>';

  amess+='<li>Dir:<tt> '+currentDir+'</tt>';
  amess+=' &vellip; <span style="font-style:oblique;font-size:80%" title="Dir description">'+currentDirDesc.substr(6)+'</span>';

  amess+='<li>File:<tt> '+currentFile+'</tt>';
  amess+=' &vellip; <span style="font-style:oblique;font-size:80%" title="File description">'+currentFileDesc.substr(6)+'</span>';

  amess+='</ul>';
  $('#simple_viewer').html(amess);
}

//-----------------
// settings
// showThumbnails=0 ;    // 0=text,1,2,3 for small,medium,large thumbnails
// showSnapShot=1    ; // 0=full image, 1=snapshot image
// doStretch=1;     ; // 0:as is, 1:stretch , 2:shrink (preserve aspect ratio)


function doSettings(athis) {
  let amess='';
  amess+='<input type="button" value="&#9853;" title="recalculate image sizes (use this after resizing a browser window)" onClick="doSettingsResize(1)"> ';
  if  (currentFileNumber>=0)  amess+='<input type="button" value="&#128260; &#128374;" title="redisplay current file" onClick="viewChosenFile(this,'+currentFileNumber+')"> ';
  amess+='<em>Current settings...</em>';
  amess+=' <input type="button" value="Large viewer " onClick="doSettingsLargeViewer(1)" >';

  amess+='<ul class="selectDirListC" style="width:95%">';

  let sayThumbnails=['text','small','medium','large'];
  let saySnapshot=['full image','snapshot (640x480) version'] ;
  let sayStretch=['as is (with scrollbars)','stretch ','shrink (preserve aspect ratio)'];
  let sayShowName=['no','yes'];
  let saySwipe=['disabled','enabled: swipe to view prior or next file (in file viewer)'];

  amess+='<li  style="width:95%"><input type="button" title="Toggle thumbnail view" onClick="doSettingsThumbnail(this)" data-which="'+showThumbnails+'"  ';
  amess+='    value="Thumbnails:"> <tt> '+sayThumbnails[showThumbnails]+'</tt> ';
  amess+='<li  style="width:95%"><input type="button" title="Always display filename (even if thumbnails are used)" onClick="doSettingsShowName(this)" data-which="'+alwaysShowName+'"  ';
  amess+='    value="showFileName:"> <tt> '+sayShowName[alwaysShowName]+'</tt> ';
  amess+='<li  style="width:95%"><input type="button" title="Toggle snapshot view" onClick="doSettingsSnapshot(this)" data-which="'+showSnapShot+'"  ';
  amess+='    value="Snapshot:"> <tt> '+saySnapshot[showSnapShot]+'</tt> ';
  amess+='<li  style="width:95%"><input type="button" title="Toggle image stretch or shrink" onClick="doSettingsStretch(this)" data-which="'+doStretch+'"  ';
  amess+='    value="Stretch:"> <tt> '+sayStretch[doStretch]+'</tt> ';
  amess+='<li  style="width:95%"><input type="button" title="Enable swiping" onClick="doSettingsSwipe(this)" data-which="'+doSwipe+'"  ';
  amess+='    value="Swipe:"> <tt> '+saySwipe[doSwipe]+'</tt> ';

   let scWidth=screen.width;
   let scHeight=screen.height;
   let windowHeight=$(window).height();   // returns width of browser viewport
   let windowWidth=$(window).width();   // returns width of browser viewport


  let ismo=isThisMobile(1);
  amess+='<li  style="width:95%"><u>'+ismo+'</u> resolution. Screen: <tt>'+scWidth+ 'x' +scHeight+'</tt>; window: <tt>'+windowWidth+'x'+windowHeight+'</tt>';
  amess+='</ul>';
  $('#simple_viewer').html(amess);

}

//========
function doSettingsLargeViewer(ido) {
   var  myOrigin=window.location.protocol+'//'+window.location.hostname;
   if (window.location.port!='') myOrigin+=':'+window.location.port;
   let wsMainSel=wsgMainSel ;
   let aurl= myOrigin+wsMainSel+'/wsGallery.php';
   aurl+='?noCompact=1&gallery='+currentGallery+'&tree='+currentTree;
   aurl+='&dir='+currentDir  ;
   window.location=aurl;
   return 1;
}

function doSettingsResize(athis) {
   let scWidth=screen.width;
   let scHeight=screen.height;
   let windowHeight=$(window).height();   // returns width of browser viewport
   let windowWidth=$(window).width();   // returns width of browser viewport

   let eheader=$('#simple_header');
   let eheaderRect=eheader[0].getBoundingClientRect();

   let esimple=$('#simple_viewer');
   esimple.html('');
   esimple.css({'border':'3px inset #dedfc1','background-color':'#dddec1'});

   let esimpleRect=esimple[0].getBoundingClientRect();

   let simpleViewerUseHeight=parseInt(windowHeight-(35+eheaderRect.bottom));
   let simpleViewerUseWidth=parseInt(windowWidth-(18+eheaderRect.left));

   esimple.attr('data-useWidth',simpleViewerUseWidth);
   esimple.attr('data-useHeight',simpleViewerUseHeight);

   esimple.width(simpleViewerUseWidth);
   esimple.height(simpleViewerUseHeight);
   esimple.css({'border':'3px inset #dedfc1','background-color':'#dddec1'});

   if (athis==1)  doSettings(1);
}

function doSettingsThumbnail(athis) {
   let ethis=wsurvey.argJquery(athis);
   let awhich=parseInt(ethis.attr('data-which'));
   awhich++;
   if (awhich>3) awhich=0;
   ethis.attr('data-which',awhich);
   showThumbnails=awhich;
   doSettings(0);
}
function doSettingsShowName(athis) {
   let ethis=wsurvey.argJquery(athis);
   let awhich=parseInt(ethis.attr('data-which'));
   awhich++;
   if (awhich>1) awhich=0;
   ethis.attr('data-which',awhich);
   alwaysShowName=awhich;
   doSettings(0);
}

function doSettingsSnapshot(athis) {
   let ethis=wsurvey.argJquery(athis);
   let awhich=parseInt(ethis.attr('data-which'));
   awhich++;
   if (awhich>1) awhich=0;
   ethis.attr('data-which',awhich);
   showSnapShot=awhich;
   doSettings(0);
}
function doSettingsStretch(athis) {
   let ethis=wsurvey.argJquery(athis);
   let awhich=parseInt(ethis.attr('data-which'));
   awhich++;
   if (awhich>2) awhich=0;
   ethis.attr('data-which',awhich);
   doStretch=awhich;
   doSettings(0);
}

function doSettingsSwipe(athis,awhich) {
   let ethis=wsurvey.argJquery(athis);
   if (arguments.length<2) {
     let awhich=parseInt(ethis.attr('data-which'));
     awhich++;
     if (awhich>1) awhich=0;
     ethis.attr('data-which',awhich);
     doSwipe=awhich;
     doSettings(0);
     return 1;
   }

   if (awhich==2) {  // Sscr;wipe button
      doSwipe=1-doSwipe;
      if (doSwipe==0) {
        $("#simple_viewer").swipe("disable");
        ethis.removeClass('cSwipeOn');
      } else {
         $("#simple_viewer").swipe("enable");
         ethis.addClass('cSwipeOn');
      }
   } else {
      doSwipe=awhich;
   }
}


//============
// heop
function showTips(athis) {
  let amess='';
 let cbutton='<input type="button" value="x" title="close these tips" onClick="$(\'#helpBox1\').hide()" >' ;

  amess+='<div style="background-color:#dfdfaf;padding:3px">'+cbutton+' wsGallery file viewer <em>(compact)</em></div>';
  amess+='<div>Click an icon for a description of what it does... ';
  amess+='<input type="button" value="&#128712;" title="Current status (gallery/tree/dir/file)" onClick="showTipsB(1)" > ';
  amess+='<input type="button" value="&#9965;"   title="Settings" onClick="showTipsB(2)" > ';
  amess+='<input type="button" value="&#127794;" title="Select a tree (and then select a directory)" id="choseTreeButton" onClick="showTipsB(3)" > ';
  amess+='<input type="button" value="&#9636;"   title="Select a directory (in the currently selected tree)"  id="choseDirButton"   onClick="showTipsB(4)" > ';
  amess+='<input type="button" value="&#128193;" title="Select a file (in the currently selected directory)"   id="choseFileButton"  onClick="showTipsB(5)"  >  ';
  amess+='<input type="button" value="&#8612;"   title="View prior file (in the currently selected directory)" onClick="showTipsB(6)"> ';
  amess+='<input type="button" value="&#8614;"   title="View next file (in the currently selected directory)" onClick="showTipsB(7)" >    ';
  amess+='<input type="button" value="&#129001;" title="View full image "  onClick="showTipsB(8)" > ';
  amess+='<input type="button" value="&#128476;" title="View reduced image "  onClick="showTipsB(9)" > ';
  amess+='<input type="button" value="&#128918;" title="Display using the entire screen  "  onClick="showTipsB(10)" >' ;

  amess+='</div>';
  amess+='<div id="helpBox1" style="chelpBox1"> ... </div>';
  amess+='</div>';
  $('#simple_viewer').html(amess);
}

function showTipsB(ido) {
  var aheader,amess='';
 if (ido==1) {
  aheader='&#128712; Current status';
  amess+='Displays a table:  the currently selected gallery, tree, directory, and file<br>';
 }
 if (ido==2) {
  aheader='&#9965 View and change settings';
  amess+='View, and change, the display settings:  use thumbnails when listing files, show filename, display a snapshot, stretch image to fit screen<br>';
 }
 if (ido==3) {
  aheader="&#127794; Select a tree (and then select a directory)";
  amess+='Trees are the <em>root directory</em>  -- they are setup by the wsGallery administrator.<br>';
  amess+='After selecting a tree, you can then select one of the directories in the <em>tree</em><br>';
  amess+=' ... either by clicking on it again, or clicking   <button>&Nscr;ext &rArr;</button> <br>';
 }
 if (ido==4) {
  aheader="&#9636; Select a directory (in the currently selected tree)" ;
  amess+='There can be several, or several hundred, directories in a tree.  <br>';
  amess+='After selecting a directory, you can then select one of the files in the <em>directory</em><br> ';
  amess+=' ... either by clicking on it again, or clicking   <button>&Nscr;ext &rArr;</button> <br>';
 }
 if (ido==5) {
  aheader=" &#128193;  Select a file (in the currently selected directory)"   ;
  amess+='There can be several, or several hundred, files in a directory.  <br>';
  amess+='After selecting a file, you can then view it <br> ';
  amess+=' ... either by clicking on it again, or clicking   <button>&#128065; &Vscr;iew</button> <br>';
 }
 if (ido==6) {
  aheader="&#8612; View prior file (in the currently selected directory)" ;
  amess+='View the <em>prior</em> file in the currently selected directory. If you are already viewing the first file, nothing will change.  ';
  amess+='<br>You can also use the <button>PgUp</button> to view a <em>prior</em> file.';
 }
 if (ido==7) {
  aheader="&#8614; View next file (in the currently selected directory)"    ;
  amess+='View the <em>next</em> file in the currently selected directory. If you are already viewing the last file, nothing will change. ';
  amess+='<br>You can also use the <button>PgDn</button> to view a <em>prior</em> file.';
 }
 if (ido==8) {
  aheader="&#129001;  View full image ";
  amess+='Redisplay the currently selected file. If it is an image file, display the full resolution image. <br>';
  amess+='You can then scroll within the image.<br> ';
  amess+='For finer control of how an image is displayed, use the &#9965; settings ';
 }
 if (ido==9) {
   aheader="&#128476;  View reduced image ";
   amess+='Redisplay the currently selected file. If it is an image file, display a <em>snapshot<em> (640x480) resolution image. <br>';
   amess+='The images will be scaled to fit in the viewing area (using scaling that preserves the aspect ratio<br>';
   amess+='For finer control of how an image is displayed, use the &#9965; settings ';
 }

  if (ido==10) {
   aheader="&#128918; Full screen display ";
   amess+='Redisplay the currently selected file. If it is an image file, display using the full screen. <br>';
   amess+='Hit ESC to leave full screen. PgUp and PgDn can be used to view prior and next images<br> ';
   amess+='At the top of full screen: ';
   amess+'<ul  class="selectDirListC">';
   amess+='<li><input type="button" value="x"> : exit full screen ';
   amess+='<li><input type="button" value="&Sscr;"> : toggle swipe mode. If on  (cyan background) swipe will move to prior and next files. If off, swipe will scroll within the file (if a touch screen devise is being used)';
   amess+='<li><span style="background-color:#dfdfdf">fileName being viewed</span>';
   amess+='</ul>';
  }


  let bmess='';
  bmess+='<div id="helpBox1_h" style="border:1px solid gray;border-radius:3px;padding:4px">'+ aheader+'</div>';
  bmess+='<div id="helpBox1_c" style="margin:4px 2em 4px 2em;;padding:4px">'+amess+'</div>';

 $('#helpBox1').html(bmess).show();
}


// --- error reporting function used by wsurvey.getJson. Hopefully will never be called.
function jsonErrorShow(amess) {
   $('#wsGallery_notes').append('<hr>'+amess) ;
  return 1
}


function queryString(a0) {     // https://fellowtuts.com/jquery/get-query-string-values-url-parameters-javascript/
  if (arguments.length<1) a0=window.location.search.substr(1); // stirp leading ?
   if (a0 == "") return {};
   a=a0.split('&');
    var b = {};
    for (var i = 0; i < a.length; ++i)        {
            var p=a[i].split('=');
            if (p.length != 2) continue;
            b[p[0]] = decodeURIComponent(p[1].replace(/\+/g, " "));
        }
        return b;
}

function isThisMobile(athis) {
   let auu=navigator.userAgentData;
   let isMobile='unknown';
//https://stackoverflow.com/questions/3514784/what-is-the-best-way-to-detect-a-mobile-device
   if (typeof(navigator.userAgentData)!='undefined'){
     isMobile= (navigator.userAgentData.mobile) ? 'mobile' : 'notmobile' ;
   }    else {
     const ua = navigator.userAgent;

     if (/(tablet|ipad|playbook|silk)|(android(?!.*mobi))/i.test(ua)) {
       isMobile="tablet";
     } else  if (/Mobile|Android|iP(hone|od)|IEMobile|BlackBerry|Kindle|Silk-Accelerated|(hpw|web)OS|Opera M(obi|ini)/.test(ua)) {
        isMobile="mobile";
     } else {
         isMobile="notmobile";
      }
   }
  return isMobile;
}