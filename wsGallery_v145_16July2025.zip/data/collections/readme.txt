The wsGallery collections directory.

Collections are stored here (as .json files)

