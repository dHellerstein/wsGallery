The wsGallery favorites directory.

Favorites-lists are stored here (as .json files)

