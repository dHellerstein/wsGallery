; wsGallery parameters specification file. Original version -- for reference uses.
;   You can copy this to the main directory, and modify as you see fit. Removing the ;comment lines from the working
;   version will cause no harm!
;
; Note that the parameters values specified in this original file yield the same results as the default.
;  That is, the same results as having a wsGallery_params.php file with NO parameters specified.
;
; ====================================================================================================
;
; wsGallery parameters specification file
;  For security reasons: this must be edited by a site administrator. It is not editable via wsGallery.php
;
; Changes should be made in the user changable parameters section. See below for what these parameters do.
; Note that lines beginning with a ";" are comments, and are ignored. Empty lines are ignored.
;
;     In general, we recommend keeping the default versions of these parameters.
;     There are cases where modifying the defaults is useful, such as:
;        *  if you want to display  more kinds of files
;        *  if you need to control wsGallery`s use of disk space,
;        *  or wish to limit wsGallery`s capacities to
;
; The syntax of these lines is (case insensitive).
;    parameterName: parameterValue
; a parameterName that is not recognized will generate an error
; parameterValue can be multi-word (such as a list of extensions in a csv). For some parameters, unknown values will generate an error.
;
; Notes:
;  *  If one of the  parameter is not specified, its default value will be used.
;  *  If nothing is after the :, it is ignored (its the same result as not specifying it).
;  *  Specifying imgExts or otherExt multiple times is addtitve, the values are appended together
;      If   you specify an extension more than once, the last "handler" value is used.
;  *  This additive feature is also true for skips
;  *  If any imgExts or otherExts is specified, you must specify all of the extensions you want to support!
;  *  If onTheFlyThumbnails,  onTheFlySnapshots, or  noCache more than once, the last value is used.
;  *  A copy of the original version of this file is in wsGallery/lib -- which uses explicit values of the defaults for all parameters.
;
; ============================== begin user changeable parameters
imgExts:    png , gif , jpg , jpeg , bmp , xbm

otherExts:    mov  v   video/quicktime  , mp4 v video/mp4
 otherExts:   mpg v , mpeg v  ,  avi v
 otherExts:    pdf e application/pdf
 otherexts:   txt  frame text  text , text f text  text
 otherExts:   htm f text  html  , html  f text html
 otherExts:   xls f   https://view.officeapps.live.com/op/embed.aspx?src=
 otherExts:   xlsx f  https://view.officeapps.live.com/op/embed.aspx?src=
 otherExts:   ppt f  https://view.officeapps.live.com/op/embed.aspx?src=
 otherExts:   pptx f  https://view.officeapps.live.com/op/embed.aspx?src=
 otherExts:   doc f https://view.officeapps.live.com/op/embed.aspx?src=
 otherExts:   docx f  https://view.officeapps.live.com/op/embed.aspx?src=

; --  less important parameters (in alphabetical order)

defaultGallery:

doCompact: 1

enableFavorites: 1
enableNotes: 1
maxNoteSize: 1.5

noCache: 0
onTheFlyThumbnails: 1
onTheFlySnapshots: 1

preset3_viewer1 : top:4%,left:1%,width:20%,height:15%
preset3_fileList: top:4%,left:24%,width:71%, height:14%
preset3_viewer2 : top:24%,left:1%,width:94%,height:72%

requireLockme: 0
screenLayout:

switchGallery:

skips:    trash,tmp,temp,$RECYCLE.BIN

useThumbnails: 1

; =========================== end user changeable parameters
;
;  Description of parameters.
;
;   Important: for wsGallery to recognize a file, it MUST have an extension in either imgExts or otherExts.
;              If not, wsGallery ignores the files - they will NOT appear in any list of files.
;              That is: they will NOT be viewable (or displayable).
;
; imgExts. What files (by extension) are treated as images; hence can be resized, zoomed in, and have thumbnails generated.
;      If specified, use a csv (case insensitive).  Quotes and periods are NOT needed. Extra spaces are removed.
;
;      Currently, wsGallery supports the following image files:
;           png , gif , jpg , jpeg , bmp , xbm
;      These MUST be files that PHP supports. Note that the many php installations support other (obscure) image types.
;
;      Synonyms: you can use img: or imageExts: as synonyms for imgExts
;
;      Notes:
;       * in contrast to otherExts: you do not need to specify a "handler" for imgExts. If you do, it is ignored.
;       * when wsGallery starts it checks if these image types are supported by the local installation of php.
;         If not, an error message is displayed.
;         The administrator should then remove the unsupported image types from imgExts. 
;        These could be added to otherExts
;
; otherExts. What files (by extension) are treated as viewable files.
;       These can be displayed in wsGallery internal viewers,but are not as manipuable as image files.
;       For example: no zooming, and  no thumbnail creation capability.
;       If specified, use a csv (case insensitive) list.  Quotes and periods are NOT needed. Extra spaces are removed.
;       For readablity, you can specify multiple lines of otherExts (they will be appended).
;
;       Currently, wsGallery supports the following other files.
;           mov , mpg , mpeg , mp4 , avi , pdf , txt , text , htm , html , xls , xlsx , ppt , pptx , doc , docx
;
;       If you add to this list, you must specify a "handler" for the file.
;           The simplest case, if you can not determine the best handler, is L -- create a link that opens the file in an
;           external window. Which means the browser, or the operating system, gets to deal with it.
;
;     Synonyms: you can use other: as a synonym for otherExts
;
;     Specifying the handler for other files.
;
;       When you specify an other extension, you can follow it with a few extra fields specifying what handler to use.
;       The first field is the "handler" (case insensitive), which can be followed by a modifier.
;          i   use <img>.
;              These are for image files that php can not process (such as TIFF).  Display depends on the
;              browser, and perhaps on what addons the client has installed.
;              Examples:  tif i , tiff i
;               Note that there are no default "otherExts" that use this (i) handler.
;               But if one of the imgExts is NOT supported by the server`s php, using an i handler is recommended.
;          v: use <video>.
;              This can be followed by a mimetype
;              If the mimetype is not specified, wsGallery uses an extension-to-mimetype lookup table to guess.
;              Examples: 'mov v video/quicktime, mp4 v '
;              The mov, mp4 defaults otherExts use video. As do mpeg, mpg and avi
;          e : use <embed>.
;               This can be followed by a mimetype.
;               If a mimetype is not specified, wsGallery uses an extension-to-mimetype lookup table to guess.
;              Example: 'pdf e application/pdf  '
;              The pdf is the only default otherExts to use embed.
;          f : use an <iframe>.
;             This can be followed by  a modifier: either a  `type` designation, or a url pointing to an web
;             resource that can return something that is displayed properly in an <iframe>.

;             The text, text, htm, html, ppt, xls, doc, pptx, xlsx, and docx  use a frame handler -- with differnt modifiers

;             The url method is useful for non-text like documents.
;               For example, for  ppt (and other microsoft files), this url is used if none is specified.
;                 ppt f  https://view.officeapps.live.com/op/embed.aspx?src=
;
;             The `type` designation should have a syntax of  `typeViewer typeExternal`
;             where either of these can be `text` or `html`.
;                 `text` tells wsGallery to try to show the  file as text -- with html any HTML tags shown as is (no formatting is done).
;                 `html` tells wsGallery to allow the file to be shown with html formatting.
;             typeViewer and typeExternal  tells wsGallery to use different types depending on where the file is displayed.
;                 typeViewer is used for the viewers, and for external view when the NE arrow button is clicked in a viewer.
;                 typeExternal is used for direct external view, and for link (at the bottom of a viewer box).
;
;             Example:
;                  html text html , js text
;
;            Notes:
;                * `text` is a shorthand  for `text text`, and `html` is a shorthand for `html html`
;                * for txt and text extensions: if no `type` is specified, then `text text` is used
;                * for htm and html extensions: if no `type` is specified, then `text html` is used
;                * if no extension is specified: then `text text` is used
;
;          L : use a link. This is the default for extensions that are not one of the defaults.
;              No modifier is needed: since wsGallery just creates a link to an external viewer
;             (and lets the browser or operating system do what it will do).
;                Example:   js L, php L
;              Note that there are no default "otherExts" that use this (l) handler.
;
;       Example:
;             mov v video/mp4 controls , pdf e application/pdf, text f, xls f  https://view.officeapps.live.com/op/embed.aspx?src=
;       is the same as the default:
;             mov ,   pdf , text  , xls
;
;       Notes:
;        * If you specify a url in a f (iframe), the file MUST be web accessible to the public.
;        * mpeg, mpg, and avi typically do NOT work well with <video>. You might want to try to find a f (iframe) handler.
;        * Technical note:  <embed> is surrounded by an <object> (seems to work better with older browsers)
;        * The handler can be a full word - only the first character is used (case insensitive!).
;          For example:   mov video video/mp4  , pdf embe application/pdf, text  frame
;
;  ------ less important parameters (in alphabetical order) ----------
;
; defaultGallery. The name of a gallery to use. If empty, or not specified, 'main' is used.
;          If specified, this MUST be an existing gallery (a directory under the galleries/ directory of wsGallery)
;          If no such directory exists, wsGallery displays an error message and exits
;          The value is case sensitive (unimportant under Windows)
;          Note that if the request line specified a gallery, defaultGallery is ignored
;
;  doCompact: 0, 1
;    0 : do not display the 'switch gallery versions' button (top bar right)
;    1 : display it
;
; enableFavorites: 0,1 2 or 3: enable creation of list-of-favorites
;    Favorites are a list of files, where each file in the list can be from any gallery/tree/directory.
;    The files in these lists can be displayed as if it was a directory of files.
;   Accepted values:
;     0: disable. Favorites can not be read or created
;     1: read. Favorites can be read from the server, or uploaded from a local file
;     2: create. Same as 1. And favorites can be created, and saved locally.
;     3: save. Same as 2. And favorites can also be saved to the server.
;  The default is 2
;  Note: you can also specify  `disable`, `read` `create`, and `save` (for 0,1,2,3 respectively)
;
; enableNotes: 0,1 2 or 3: enable view and creation of notes,and keywords (for individual files)
;    Notes are comments and descriptions added to individual files, by any user at any time.
;    Keywords are short (single word) keywords useful for searching.
;    These notes, and keywords can be viewed on a file-at-time basis.
;  Accepted values:
;   0 : disable  (notes and keywords not accessible)
;   1 : read     notes and keywords can be read but not added to
;   2 : create   notes and keywords can be read and be added to
;  Note: you can also specify  `disable`, `read` `create` (for 0,1,2 )
;
; maxNoteSize: 1.5  : max size of a note (k characters)
;   The maximum size of a set of file notes.  This is ignored if enableNotes ne 2.
;    File notes are stored in the `cache` directory  (galleries/`gallery/tree/directory`):
;     using files with names like myImage.jpg.note.
;    Each of these files stores the notes (and keywords) for one file.
;    maxNoteSize sets an upper limit on the size of each of these files (in kilobytes).
;    Example: 1.5 means "1500 byte maximum size"
;    Setting this can limit damage from a malfeasant actor adding junk notes to as many files as he can.
;    Note that this is the entire size of the file. These are .json file, and contain control code.
;    Thus, the useful content of the file will be less than maxNoteSize
;
; noCache.    0 or 1. 0 to enable caching, 1 to disable caching.   The default is 0 (enable caching.)
;            If disabled, wsGallery will not attempt to use its caching. Nothing will be read from the cache, and nothing written.
;            Which includes thumbnails, snapshots, and list of files (and menus containing buttons for viewing a file).
;            If disabled, all of these must be generated each and every  time a client requests a file list,
;            a thumbnails view, or a snapshot.
;            This can be time consuming, especially for directories with several hundred files.
;            Thus: disabling caching should only be done if disk space, and not processing time, is a constraint.
;
;             Note that existing cache information will be retained.
;             Thus, you can re-enable caching without having to  regenerate this information (you will not
;             have to initialize all the directories).
;
;      Synonyms: you can use noCaching  as a synonym for noCache
;
; onTheFlyThumbnails.  0 or 1. 0 to disble, 1 to enable.  The default is 1 (enable onTheFly thumbNails).
;        If disabled, wsGallery will not attempt to create thumbnails "on the fly".
;        That is: they will be available to clients only if the administrator created them (using initialize directory).
;        If not available, generic icons are used for the thumbnails.
;
;        Note that onTheFly generation will generate cache thumbnails. Thus, the onTheFly thumbNail generation only occurs once (per file).
;              This "caching of onTheFly thumbnails" is NOT true if caching is disabled!
;
;      Synonyms: you can use thumb: or thumbNails: as a synonym for onTheFlyThumbnails
;
;
; onTheFlySnapshots.   0 or 1. 0 to disble, 1 to enable. The default is 1 (enable onTheFly snapshots).
;            If disabled, wsGallery will not attempt to create snapShots (640x480 images) "on the fly".
;            That is: they will be available to clients only if the administrator created them (using initialize directory).
;            If not available, full images are returned instead of the snapShot.
;
;        Note that onTheFly generation will generate cache snapShots. Thus, the onTheFly snapShot generation only occurs once (per file).
;              This "caching of onTheFly snapShots" is NOT true if caching is disabled!
;
;      Synonyms: you can use snap:, or snapShots:, or onTheFlySnapshots:  as a synonym for onTheFlySnapshots
;
; preset3_viewer1, preset3_viewer2, and preset3_fileList: location and size specifications
;   These 3 parameters are used for  the dual mode, preset 3, screen layout
;   If not specified, defaults are used
;   You can specify any set of these three -- but it is best to specify all 3 (so as to avoid unwanted overlaps)
;  The sytnax is:  top:xx,left:xx,width:xx%,height:xx%
;    where `xx` is a specification -- typically a %
;  The defaults are:
;     preset3_viewer1 : top:4%,left:1%,width:20%,height:15%
;     preset3_fileList: top:4%,left:24%,width:71%, height:14%
;     preset3_viewer2 : top:24%,left:1%,width:94%,height:72%
; Note that if you specify one of these, you MUST include  top,left,width, and height.
;
; requireLockme. 0 or 1 :  check for data/lockme.txt (when initializing galleries)
;        If 0 . Do NOT check for lockme.txt
;        If 1 (the default). Check for lockme.txt.
;    When a gallery is created, or when it is modifed, wsGallery must initialize it.
;    This can be automatically done (after an administrative logon).
;    However: as a security measure, one can suppress this automatic gallery initialization.
;         a) Set requireLockme: 1
;         b) Be sure that data/lockme.txt exists (its contents do not matter)
;    If this is the case, wsGallery will issue an error message suggesting that you rename data/lockme.txt.
;    Doing so, upon restarting wsGallery (and then logging on) will initialize the (current) gallery.
;    Setting requireLockme to 0 disables this security check.
;    See wsGallery_readMe.txt for the details.
;
;
;screenLayout: the default screen layout
;  Valid choices are: dual, rotating, tableau,single (the default) ,singleLarge
;     dual : dual viewer mode --  for quick scrolling and zooming. Uses the large file list, equi-sized viewers preset
;     rotating : 3 viewers and 1 file list. Display rotates through the 3 viewers
;     tableau:  as a file is selected, a small viewer is added to a scrollable area.
;     single : the default.  2/3 of screen in a viewer (with expand and other buttons), 1/3 a file list
;    singleLarge: similar to single, with viewr covering most of screeen, and small file list on top
;
; skips.  Subdirectories to skip.
;      If specified, use a csv (case insensitive).  Quotes are NOT needed. Extra spaces are removed. Periods are NOT removed.
;
;        The default is: skips: trash,tmp,temp,$RECYCLE.BIN
;
;       If a subdirectory name (final word in a /word1/word2/wordFinal path) equals one of these it is ignored.
;       Thus: any files, or sub directories, in one of these skipped paths  will never be seen by wsGallery.
;       For example, if you include `archive` in this list, anything under x/yy/archive, and under z/abc/archive, will be ignored
;
;   Notes:
;     *   do not use / or \ in the subdirectories. The subdirectories should be single words!
;     *  Abbreviation matching:
;          If you end a subdirectory with a *, than an abbreviation match is done.
;          For example: note* would match z/note, dogs/noteNew, and zebras/note31.
;
;      Synonyms: you can use  skip:   as a synonym  for skips
;
; switchGallery. 0 or 1 : display a "switch gallery" button
;        If 0 (the default), do not show this button.
;        If 1, show this button.
;          When clicked, a list of currently available galleries (directories unde wsGallery/galleries) is displayed.
;          Clicking on one  will reload wsGallery with an appropriate ?gallery=xxx request line variable.
;
; useThumbnails: 0,1,2,3  : use thumbnails as view-file buttons (when showing files in a directory)
;  0 : use textbuttons  (or 'n')
;  1 : use  small (40x40) thumbnails (or 's')
;  2 : use medium (60x60) thumbnails
;  3:  use large (90x90) thumbnails
; You can also use : N,S,M,L (respectively)
; This is used when a directory is first chosen. You can switch display usin the `Thumbnails` button
