; ====================================================================================================
;
; wsGallery parameters specification file
;  For security reasons: this must be edited by a site administrator. It is not editable via wsGallery.php
; See wsGallery_readMe.txt, or wsGallery_params_original.php, for more details
;
; ============================== begin user changeable parameters

imgExts:    png , gif ,jpg, jpeg    , bmp , xbm

otherExts:    mov  v   video/quicktime  , mp4 v video/mp4
 otherExts:   mpg v , mpeg v  ,  avi v
 otherExts:    pdf e application/pdf
 otherexts:   txt  frame text  text , text f text  text
 otherExts:   htm f text  html  , html  f text html
 otherExts:   xls f   https://view.officeapps.live.com/op/embed.aspx?src=
 otherExts:   xlsx f  https://view.officeapps.live.com/op/embed.aspx?src=
 otherExts:   ppt f  https://view.officeapps.live.com/op/embed.aspx?src=
 otherExts:   pptx f  https://view.officeapps.live.com/op/embed.aspx?src=
 otherExts:   doc f https://view.officeapps.live.com/op/embed.aspx?src=
 otherExts:   docx f  https://view.officeapps.live.com/op/embed.aspx?src=
 otherExts:   tiff i, tif i
 otherExts:  js l , php f

; -- SECONDARY PARAMETERS (ALPHABETICAL ORDER) ---


defaultGallery:

; compactViewer link: 0=no display, 1=display, 2=display and autoclick if mobile device
doCompact: 2

; 0=disable,1=read, 2=read and create (save local), 3=read and create and saveToServer
enableFavorites: 3

; 0=disable,1=read, 2=read and create
enableNotes: 2

; in kb
maxNoteSize: 1.5

noCache: 0
onTheFlyThumbnails: 1
onTheFlySnapshots: 1

preset3_viewer1 : top:6%,left:1%,width:20%,height:15%
preset3_fileList: top:6%,left:24%,width:71%, height:16%
preset3_viewer2 : top:27%,left:1%,width:94%,height:69%

requireLockme: 0

; dual, rotating, tableau,single (the default)  
screenLayout:  single

skips:  trash,tmp,temp,$RECYCLE.BIN

switchGallery: 0

;  n: do not use thumbnails (default), s:small thumbnails, m:medium, l:large
useThumbnails: s