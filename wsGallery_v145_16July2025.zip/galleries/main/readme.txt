
wsGallery/galleries/main is used to store data for wsGallery's 'main' gallery.
The 'main' gallery is the default gallery created when wsGallery is installed.

To add 'trees' to a gallery, you must:

   * edit the version of wsGallery_treeList.php in each  gallery-specific 'root' directory
   * re-initialize the tree -- see wsGallery_readMe.txt for the details

 

